"""Count grape berries in one image."""

import argparse
from pathlib import Path
from .inference import GrapeCounter


def main():
    parser = argparse.ArgumentParser(description="GrapePBC per-bunch berry counting")
    parser.add_argument("image", type=Path)
    args = parser.parse_args()
    counter = GrapeCounter()
    result = counter.infer(args.image.read_bytes(), args.image.name)
    print(f"Berries: {result['total_count']}")
    print(f"Bunches: {result['bunch_count']}")
    print(f"Results: {result['result_id']}")


if __name__ == "__main__":
    main()
