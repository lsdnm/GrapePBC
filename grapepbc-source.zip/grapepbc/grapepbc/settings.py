"""Locations of trained models, configuration files, and inference outputs."""

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = Path(os.environ.get("GRAPEPBC_CONFIG_DIR", ROOT / "configs"))
CHECKPOINT_DIR = Path(os.environ.get("GRAPEPBC_CHECKPOINT_DIR", ROOT / "checkpoints"))
RESULT_ROOT = Path(os.environ.get("GRAPEPBC_RESULTS_DIR", ROOT / "results"))
LR_CHECKPOINT = CHECKPOINT_DIR / "low_resolution.pt"
BUNCH_MODEL = CHECKPOINT_DIR / "bunch_detector.pt"
LR_CALIBRATOR = CONFIG_DIR / "count_calibration.json"
