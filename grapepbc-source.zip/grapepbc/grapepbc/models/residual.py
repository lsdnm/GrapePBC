from __future__ import annotations
import torch
from torch import Tensor, nn


class ResidualCountHead(nn.Module):

    def __init__(
        self,
        feature_dim: int,
        hidden_dim: int = 64,
        bottleneck_dim: int = 32,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        if min(feature_dim, hidden_dim, bottleneck_dim) <= 0:
            raise ValueError("feature dimensions must be positive")
        self.feature_dim = int(feature_dim)
        self.trunk = nn.Sequential(
            nn.Linear(feature_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, bottleneck_dim),
            nn.SiLU(),
        )
        self.delta = nn.Linear(bottleneck_dim, 1)
        self.log_error = nn.Linear(bottleneck_dim, 1)

    def forward(self, features: Tensor) -> dict[str, Tensor]:
        if features.ndim != 2 or features.shape[1] != self.feature_dim:
            raise ValueError(
                f"expected [N,{self.feature_dim}] features, got {tuple(features.shape)}"
            )
        hidden = self.trunk(features)
        return {
            "delta": self.delta(hidden).squeeze(1),
            "log_error": self.log_error(hidden).squeeze(1),
        }


def decode_residual_counts(
    low_counts: Tensor, predicted_delta: Tensor, candidate_counts: Tensor
) -> Tensor:
    if (
        low_counts.shape != predicted_delta.shape
        or low_counts.shape != candidate_counts.shape
    ):
        raise ValueError("all count tensors must have identical shapes")
    corrected = (low_counts.float() + predicted_delta).round().long().clamp_min(0)
    return torch.minimum(corrected, candidate_counts.long().clamp_min(0))


__all__ = ["ResidualCountHead", "decode_residual_counts"]
