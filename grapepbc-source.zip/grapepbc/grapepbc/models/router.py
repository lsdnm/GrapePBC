from __future__ import annotations
import torch
from torch import Tensor, nn


class SequentialUtilityRouter(nn.Module):

    def __init__(
        self,
        feature_dim: int,
        hidden_dim: int = 64,
        bottleneck_dim: int = 32,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        if min(feature_dim, hidden_dim, bottleneck_dim) <= 0:
            raise ValueError("feature dimensions must be positive")
        self.feature_dim = int(feature_dim)
        self.network = nn.Sequential(
            nn.Linear(feature_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, bottleneck_dim),
            nn.SiLU(),
            nn.Linear(bottleneck_dim, 1),
        )

    def forward(self, features: Tensor) -> Tensor:
        if features.ndim != 2 or features.shape[1] != self.feature_dim:
            raise ValueError(
                f"expected [N,{self.feature_dim}] features, got {tuple(features.shape)}"
            )
        return self.network(features).squeeze(1)


def encode_utility(utility: Tensor) -> Tensor:
    return torch.sign(utility) * torch.log1p(utility.abs())


def decode_utility(encoded: Tensor) -> Tensor:
    return torch.sign(encoded) * torch.expm1(encoded.abs().clamp(max=8.0))


__all__ = ["SequentialUtilityRouter", "encode_utility", "decode_utility"]
