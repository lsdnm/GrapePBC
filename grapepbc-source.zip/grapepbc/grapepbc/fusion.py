from __future__ import annotations
from dataclasses import dataclass
from typing import Mapping, Sequence
import numpy as np
from .tiles import CoreHaloTile, assign_points_to_tiles

LR_SOURCE = np.int8(0)
SPARSE_HR_SOURCE = np.int8(1)


@dataclass(frozen=True)
class PointFusionResult:
    points: np.ndarray
    sources: np.ndarray
    owners: np.ndarray
    expected_count: int
    exact_duplicate_count: int


def _points(value: np.ndarray | Sequence[Sequence[float]]) -> np.ndarray:
    array = np.asarray(value, dtype=np.float32)
    if array.size == 0:
        return np.empty((0, 2), dtype=np.float32)
    if array.ndim != 2 or array.shape[1] != 2 or (not np.isfinite(array).all()):
        raise ValueError("points must be a finite array with shape (N, 2)")
    return array


def _scores(value: np.ndarray | Sequence[float], count: int) -> np.ndarray:
    array = np.asarray(value, dtype=np.float32).reshape(-1)
    if len(array) != count or not np.isfinite(array).all():
        raise ValueError("scores must be finite and aligned with points")
    return array


def exact_duplicate_count(points: np.ndarray) -> int:
    points = _points(points)
    if not len(points):
        return 0
    return int(len(points) - len(np.unique(points, axis=0)))


def _validate_selected(
    selected: Sequence[int], tiles: Sequence[CoreHaloTile]
) -> tuple[int, ...]:
    values = tuple((int(value) for value in selected))
    if len(values) != len(set(values)):
        raise ValueError("selected tile IDs must be unique")
    valid = {tile.tile_id for tile in tiles}
    unknown = set(values).difference(valid)
    if unknown:
        raise ValueError(f"unknown selected tile IDs: {sorted(unknown)}")
    return values


def fuse_sparse_core_points(
    low_points_xy: np.ndarray | Sequence[Sequence[float]],
    tiles: Sequence[CoreHaloTile],
    selected_tile_ids: Sequence[int],
    requested_counts_by_tile: Mapping[int, int],
    high_candidates_by_tile: Mapping[int, np.ndarray],
    high_scores_by_tile: Mapping[int, np.ndarray],
) -> PointFusionResult:
    low = _points(low_points_xy)
    low_owners = assign_points_to_tiles(low, tiles, strict=True)
    selected = _validate_selected(selected_tile_ids, tiles)
    if set(requested_counts_by_tile) != set(selected):
        raise ValueError("requested-count keys must equal selected tile IDs")
    if set(selected).difference(high_candidates_by_tile) or set(selected).difference(
        high_scores_by_tile
    ):
        raise ValueError("selected tiles require HR candidates and scores")
    selected_set = set(selected)
    keep = ~np.isin(low_owners, np.asarray(selected, dtype=np.int64))
    point_parts = [low[keep]]
    source_parts = [np.full(int(keep.sum()), LR_SOURCE, dtype=np.int8)]
    owner_parts = [low_owners[keep]]
    expected = int(keep.sum())
    tile_map = {tile.tile_id: tile for tile in tiles}
    for tile_id in selected:
        requested = int(requested_counts_by_tile[tile_id])
        if requested < 0:
            raise ValueError("requested core count must be non-negative")
        candidates = _points(high_candidates_by_tile[tile_id])
        scores = _scores(high_scores_by_tile[tile_id], len(candidates))
        tile = tile_map[tile_id]
        owned = (
            (candidates[:, 0] >= tile.core_x0)
            & (candidates[:, 0] < tile.core_x1)
            & (candidates[:, 1] >= tile.core_y0)
            & (candidates[:, 1] < tile.core_y1)
        )
        candidates, scores = (candidates[owned], scores[owned])
        if requested > len(candidates):
            raise ValueError(
                f"tile {tile_id} has {len(candidates)} owned candidates for requested count {requested}"
            )
        order = np.argsort(-scores, kind="stable")[:requested]
        chosen = candidates[order]
        point_parts.append(chosen)
        source_parts.append(np.full(len(chosen), SPARSE_HR_SOURCE, dtype=np.int8))
        owner_parts.append(np.full(len(chosen), tile_id, dtype=np.int64))
        expected += requested
    points = np.concatenate(point_parts).astype(np.float32, copy=False)
    sources = np.concatenate(source_parts).astype(np.int8, copy=False)
    owners = np.concatenate(owner_parts).astype(np.int64, copy=False)
    if len(points) != expected:
        raise AssertionError("sparse point fusion violated count conservation")
    if len(points) and (
        not np.array_equal(assign_points_to_tiles(points, tiles, strict=True), owners)
    ):
        raise AssertionError("stored point ownership does not match geometry")
    return PointFusionResult(
        points, sources, owners, expected, exact_duplicate_count(points)
    )
