from __future__ import annotations
import math
import numpy as np
import torch
from torch import Tensor
from torch.nn import functional as F
from .models import ResidualCountHead, SequentialUtilityRouter, decode_residual_counts


def rect_mask(
    valid: Tensor, bounds: Tensor, height: int, width: int, input_size: int
) -> Tensor:
    resized = F.interpolate(
        valid[None, None].float(), size=(height, width), mode="nearest"
    )[0, 0].bool()
    x0 = max(0, min(width - 1, int(math.floor(float(bounds[0]) * width / input_size))))
    y0 = max(
        0, min(height - 1, int(math.floor(float(bounds[1]) * height / input_size)))
    )
    x1 = max(x0 + 1, min(width, int(math.ceil(float(bounds[2]) * width / input_size))))
    y1 = max(
        y0 + 1, min(height, int(math.ceil(float(bounds[3]) * height / input_size)))
    )
    owned = torch.zeros_like(resized)
    owned[y0:y1, x0:x1] = True
    return resized & owned


def to_native(
    points: np.ndarray, inverse: np.ndarray, origin: np.ndarray
) -> np.ndarray:
    points = np.asarray(points, dtype=np.float32).reshape(-1, 2)
    if not len(points):
        return points.copy()
    inverse = np.asarray(inverse, dtype=np.float32)
    homogeneous = np.column_stack((points, np.ones(len(points), dtype=np.float32)))
    if inverse.shape == (2, 3):
        mapped = homogeneous @ inverse.T
    elif inverse.shape == (3, 3):
        mapped_h = homogeneous @ inverse.T
        mapped = mapped_h[:, :2] / mapped_h[:, 2:3]
    else:
        raise ValueError(f"unsupported inverse affine: {inverse.shape}")
    return (mapped + np.asarray(origin, dtype=np.float32)).astype(np.float32)


def signed_log(value: float) -> float:
    return math.copysign(math.log1p(abs(value)), value) if value else 0.0


def map_region(
    array: np.ndarray, valid: np.ndarray, affine: np.ndarray, tile
) -> np.ndarray:
    corners = np.asarray(
        [[tile.core_x0, tile.core_y0, 1.0], [tile.core_x1, tile.core_y1, 1.0]],
        dtype=np.float32,
    )
    mapped = corners @ affine.T
    x0 = int(np.floor(min(mapped[:, 0]) / 2.0))
    x1 = int(np.ceil(max(mapped[:, 0]) / 2.0))
    y0 = int(np.floor(min(mapped[:, 1]) / 2.0))
    y1 = int(np.ceil(max(mapped[:, 1]) / 2.0))
    x0, x1 = (max(x0, 0), min(x1, array.shape[1]))
    y0, y1 = (max(y0, 0), min(y1, array.shape[0]))
    if x1 <= x0 or y1 <= y0:
        return np.empty(0, dtype=np.float32)
    region = array[y0:y1, x0:x1].astype(np.float32)
    mask = valid[y0:y1, x0:x1].astype(bool)
    return region[mask]


def distribution_features(points: np.ndarray, scores: np.ndarray, tile) -> list[float]:
    if len(points):
        x = np.clip(
            (points[:, 0] - tile.core_x0) / max(tile.core_x1 - tile.core_x0, 1),
            0.0,
            1.0,
        )
        y = np.clip(
            (points[:, 1] - tile.core_y0) / max(tile.core_y1 - tile.core_y0, 1),
            0.0,
            1.0,
        )
        grid_x = np.minimum((x * 4).astype(np.int64), 3)
        grid_y = np.minimum((y * 4).astype(np.int64), 3)
        histogram = np.bincount(grid_y * 4 + grid_x, minlength=16).astype(np.float32)
        histogram /= max(float(histogram.sum()), 1.0)
        nonzero = histogram[histogram > 0]
        entropy = float(-(nonzero * np.log(nonzero)).sum() / math.log(16.0))
        boundary = (x < 0.1) | (x > 0.9) | (y < 0.1) | (y > 0.9)
        spatial = [
            float(x.mean()),
            float(y.mean()),
            float(x.std()),
            float(y.std()),
            float(boundary.mean()),
            float((histogram > 0).mean()),
            entropy,
        ]
    else:
        histogram = np.zeros(16, dtype=np.float32)
        spatial = [0.5, 0.5, 0.0, 0.0, 0.0, 0.0, 0.0]
    if len(scores):
        score_stats = [
            float(scores.mean()),
            float(scores.max()),
            *[float(value) for value in np.quantile(scores, [0.25, 0.5, 0.75])],
        ]
    else:
        score_stats = [0.0] * 5
    return score_stats + spatial + histogram.tolist()


def map_features(values: np.ndarray, total: float) -> list[float]:
    if len(values):
        return [
            math.log1p(max(float(values.sum()), 0.0)),
            float(values.mean()),
            float(values.std()),
            float(values.max()),
            float(np.quantile(values, 0.9)),
            float(values.sum() / max(total, 1e-06)),
        ]
    return [0.0] * 6


def state_features(
    image: dict[str, object], selected: tuple[int, ...], candidate: int, max_calls: int
) -> np.ndarray:
    cores = image["cores"]
    core = cores[candidate]
    deltas = np.asarray(
        [cores[index]["hr_delta"] for index in selected], dtype=np.float32
    )
    calls = len(selected)
    delta_sum = float(deltas.sum()) if calls else 0.0
    current_count = int(image["lr_total"]) + int(delta_sum)
    if calls:
        distances = np.asarray(
            [
                np.linalg.norm(core["center"] - cores[index]["center"])
                for index in selected
            ],
            dtype=np.float32,
        )
        same_row = np.mean([core["row"] == cores[index]["row"] for index in selected])
        same_column = np.mean(
            [core["column"] == cores[index]["column"] for index in selected]
        )
        state = [
            signed_log(current_count),
            signed_log(delta_sum),
            signed_log(float(deltas.mean())),
            math.log1p(float(np.abs(deltas).mean())),
            float((deltas > 0).mean()),
            float((deltas < 0).mean()),
            calls / max(max_calls, 1),
            (len(cores) - calls) / len(cores),
            float(distances.min()),
            float(distances.mean()),
            float(same_row),
            float(same_column),
        ]
    else:
        state = [
            signed_log(current_count),
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            1.0,
            1.5,
            1.5,
            0.0,
            0.0,
        ]
    return np.concatenate((core["base"], np.asarray(state, dtype=np.float32))).astype(
        np.float32
    )


def model_instance(protocol: dict[str, object]) -> SequentialUtilityRouter:
    return SequentialUtilityRouter(
        int(protocol["feature_dim"]),
        int(protocol["router"]["hidden_dim"]),
        int(protocol["router"]["bottleneck_dim"]),
        float(protocol["router"]["dropout"]),
    )


def decode_numpy(
    low: np.ndarray, delta: np.ndarray, candidate: np.ndarray
) -> np.ndarray:
    return decode_residual_counts(
        torch.from_numpy(low), torch.from_numpy(delta), torch.from_numpy(candidate)
    ).numpy()


def head_instance(protocol: dict[str, object]) -> ResidualCountHead:
    return ResidualCountHead(
        int(protocol["feature_dim"]),
        int(protocol["head"]["hidden_dim"]),
        int(protocol["head"]["bottleneck_dim"]),
        float(protocol["head"]["dropout"]),
    )


def gain_count(lr: int, density: int, gain: float) -> int:
    return max(0, int(np.floor(lr + gain * (density - lr) + 0.5)))
