"""Adaptive-resolution grape berry counting."""
