from __future__ import annotations
from dataclasses import dataclass
import math
from typing import Sequence
import numpy as np


@dataclass(frozen=True)
class ClusterBox:
    cluster_id: str
    bbox_xyxy: tuple[float, float, float, float]
    confidence: float
    source: str = "detector"

    def __post_init__(self) -> None:
        if not self.cluster_id:
            raise ValueError("cluster_id must be non-empty")
        values = np.asarray(self.bbox_xyxy, dtype=np.float64)
        if values.shape != (4,) or not np.isfinite(values).all():
            raise ValueError("bbox_xyxy must contain four finite values")
        if values[2] <= values[0] or values[3] <= values[1]:
            raise ValueError("box must have positive width and height")
        if not math.isfinite(self.confidence) or not 0 <= self.confidence <= 1:
            raise ValueError("confidence must lie in [0, 1]")
        if not self.source:
            raise ValueError("source must be non-empty")


def _normalized_center_cost(point: np.ndarray, box: ClusterBox) -> float:
    x0, y0, x1, y1 = box.bbox_xyxy
    center = np.asarray([(x0 + x1) / 2, (y0 + y1) / 2], dtype=np.float64)
    half = np.maximum(np.asarray([(x1 - x0) / 2, (y1 - y0) / 2]), 1.0)
    return float(np.sum(((point - center) / half) ** 2))


def _normalized_edge_cost(point: np.ndarray, box: ClusterBox) -> float:
    x0, y0, x1, y1 = box.bbox_xyxy
    dx = max(x0 - point[0], 0.0, point[0] - x1)
    dy = max(y0 - point[1], 0.0, point[1] - y1)
    diagonal = max(math.hypot(x1 - x0, y1 - y0), 1.0)
    return math.hypot(dx, dy) / diagonal


def _point_envelope(points: np.ndarray, width: int, height: int) -> ClusterBox:
    minimum = points.min(axis=0)
    maximum = points.max(axis=0)
    margin = max(4.0, 0.015 * math.hypot(width, height))
    x0 = max(0.0, float(minimum[0] - margin))
    y0 = max(0.0, float(minimum[1] - margin))
    x1 = min(float(width - 1), float(maximum[0] + margin))
    y1 = min(float(height - 1), float(maximum[1] + margin))
    if x1 <= x0:
        x1 = min(float(width - 1), x0 + 1.0)
    if y1 <= y0:
        y1 = min(float(height - 1), y0 + 1.0)
    return ClusterBox(
        "cluster_fallback_001", (x0, y0, x1, y1), 0.0, "point_envelope_fallback"
    )


def assign_berries_to_cluster_boxes(
    points_xy: np.ndarray,
    clusters: Sequence[ClusterBox],
    *,
    image_size: tuple[int, int],
    border_margin: int = 0,
) -> dict[str, object]:
    points = np.asarray(points_xy, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 2 or (not np.isfinite(points).all()):
        raise ValueError("points_xy must be a finite (N, 2) array")
    width, height = image_size
    if isinstance(width, bool) or isinstance(height, bool) or width < 1 or (height < 1):
        raise ValueError("image_size must contain positive integer width and height")
    if np.any(points < 0) or np.any(points >= [width, height]):
        raise ValueError("all points must lie inside the source image")
    if (
        isinstance(border_margin, bool)
        or not isinstance(border_margin, int)
        or border_margin < 0
    ):
        raise ValueError("border_margin must be a non-negative integer")
    if len({cluster.cluster_id for cluster in clusters}) != len(clusters):
        raise ValueError("cluster IDs must be unique")
    active = list(clusters)
    synthetic = False
    if not active and len(points):
        active = [_point_envelope(points, width, height)]
        synthetic = True
    if not active:
        return {
            "clusters": [],
            "total_assigned": 0,
            "unassigned": 0,
            "overlap_resolved": 0,
            "nearest_fallback": 0,
            "synthetic_box_used": False,
            "assignments": [],
        }
    counts = [0] * len(active)
    assignments = []
    overlap_resolved = 0
    nearest_fallback = 0
    for point in points:
        containing = []
        for index, box in enumerate(active):
            x0, y0, x1, y1 = box.bbox_xyxy
            if x0 <= point[0] <= x1 and y0 <= point[1] <= y1:
                containing.append(index)
        if containing:
            overlap_resolved += int(len(containing) > 1)
            owner = min(
                containing,
                key=lambda index: (
                    _normalized_center_cost(point, active[index]),
                    -active[index].confidence,
                    (active[index].bbox_xyxy[2] - active[index].bbox_xyxy[0])
                    * (active[index].bbox_xyxy[3] - active[index].bbox_xyxy[1]),
                    index,
                ),
            )
            reason = (
                "overlap_normalized_center" if len(containing) > 1 else "inside_unique"
            )
        else:
            nearest_fallback += 1
            owner = min(
                range(len(active)),
                key=lambda index: (
                    _normalized_edge_cost(point, active[index]),
                    _normalized_center_cost(point, active[index]),
                    -active[index].confidence,
                    index,
                ),
            )
            reason = "nearest_box_fallback"
        counts[owner] += 1
        assignments.append({"cluster_id": active[owner].cluster_id, "reason": reason})
    rows = []
    for index, box in enumerate(active):
        x0, y0, x1, y1 = box.bbox_xyxy
        touches = (
            x0 <= border_margin
            or y0 <= border_margin
            or x1 >= width - 1 - border_margin
            or (y1 >= height - 1 - border_margin)
        )
        rows.append(
            {
                "cluster_id": box.cluster_id,
                "bbox_xyxy": [float(value) for value in box.bbox_xyxy],
                "visible_berry_count": counts[index],
                "confidence": float(box.confidence),
                "source": box.source,
                "touches_image_border": bool(touches),
                "possibly_complete": not bool(touches),
                "completeness_verified": False,
            }
        )
    if sum(counts) != len(points):
        raise RuntimeError("point-count conservation failed")
    return {
        "clusters": rows,
        "total_assigned": int(sum(counts)),
        "unassigned": 0,
        "overlap_resolved": int(overlap_resolved),
        "nearest_fallback": int(nearest_fallback),
        "synthetic_box_used": bool(synthetic),
        "assignments": assignments,
    }
