"""Image inference, per-bunch assignment, and result rendering."""

from __future__ import annotations
from dataclasses import dataclass
import io
import json
import math
from pathlib import Path
import threading
import time
import uuid
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageOps
import torch
import torch.nn.functional as F
from .assignment import ClusterBox, assign_berries_to_cluster_boxes
from .images import IMAGENET_MEAN, IMAGENET_STD, letterbox_image_and_points
from .models import BerryPointNet, decode_points
from .counting import LRObservation, CountingPipeline
from .settings import LR_CHECKPOINT, LR_CALIBRATOR, BUNCH_MODEL, RESULT_ROOT

APP_DIR = Path(__file__).resolve().parent
PIPELINE_NAME = "GrapePBC"


def round_half_up(value):
    return max(0, int(math.floor(value + 0.5)))


class CountCalibrator:

    def __init__(self, path):
        payload = json.loads(Path(path).read_text(encoding="utf8"))
        self.weights = np.asarray(payload["calibrator"]["weights"], np.float64)
        self.count_bias = float(payload.get("count_bias", 0.0))

    def predict(self, features):
        return np.asarray(features, np.float64) @ self.weights[:-1] + self.weights[-1]


@dataclass
class CompletePipelineTrace:
    execution_mode: str

    def to_dict(self):
        return {"execution_mode": self.execution_mode}

    @classmethod
    def live_complete(cls):
        return cls("live_complete_pipeline")


def _font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        Path("C:/Windows/Fonts/msyh.ttc"),
        Path("C:/Windows/Fonts/arialbd.ttf"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return ImageFont.truetype(str(candidate), size=size)
    return ImageFont.load_default()


def _safe_points(points: np.ndarray, width: int, height: int) -> np.ndarray:
    points = np.asarray(points, dtype=np.float32).reshape(-1, 2)
    if not len(points):
        return points
    good = np.isfinite(points).all(axis=1)
    points = points[good]
    points[:, 0] = np.clip(points[:, 0], 0, max(width - 1, 0))
    points[:, 1] = np.clip(points[:, 1], 0, max(height - 1, 0))
    return points


def to_native(points: np.ndarray, inverse: np.ndarray) -> np.ndarray:
    points = np.asarray(points, dtype=np.float32).reshape(-1, 2)
    if not len(points):
        return points.copy()
    homogeneous = np.column_stack((points, np.ones(len(points), dtype=np.float32)))
    mapped = homogeneous @ np.asarray(inverse, dtype=np.float32).T
    return (mapped[:, :2] / mapped[:, 2:3]).astype(np.float32)


class GrapeCounter:

    @torch.inference_mode()
    def _live_preview(self, image: Image.Image) -> dict:
        self._ensure_live_models()
        width, height = image.size
        letterboxed, _, valid_np, affine = letterbox_image_and_points(
            image, np.empty((0, 2), dtype=np.float32), 1024
        )
        array = np.asarray(letterboxed, dtype=np.float32).transpose(2, 0, 1) / 255.0
        tensor = (torch.from_numpy(array) - IMAGENET_MEAN) / IMAGENET_STD
        images = tensor.unsqueeze(0).to(self.device)
        masks = torch.from_numpy(valid_np).unsqueeze(0).to(self.device)
        outputs = self._lr_model(images, masks)
        probability = outputs["center_logits"].float().sigmoid()
        valid = F.interpolate(
            masks[:, None].float(), size=probability.shape[-2:], mode="nearest"
        ).bool()
        probability = probability.masked_fill(~valid, 0.0)
        density = F.softplus(outputs["density_logits"].float()).masked_fill(~valid, 0.0)
        local = probability * (probability == F.max_pool2d(probability, 3, 1, 1))
        peaks = [
            int(((local[0, 0] >= value) & valid[0, 0]).sum())
            for value in self._thresholds
        ]
        features = np.asarray(
            [
                np.log1p(float(density.sum())),
                np.log1p(float(probability.sum())),
                np.log1p(int(valid[0, 0].sum())),
                *[np.log1p(value) for value in peaks],
            ],
            dtype=np.float32,
        )
        requested = round_half_up(
            float(
                np.expm1(self._calibrator.predict(features[None].astype(np.float64))[0])
                + getattr(self._calibrator, "count_bias", 0.0)
            )
        )
        candidates = decode_points(
            outputs,
            score_threshold=1e-06,
            topk=4096,
            local_max_kernel=3,
            output_stride=self._lr_model.output_stride,
        )[0]
        count = min(requested, len(candidates["points"]), 4096)
        points = to_native(
            candidates["points"][:count].cpu().numpy(), np.linalg.inv(affine)
        )
        point_scores = (
            candidates["scores"][:count].detach().cpu().numpy().astype(np.float32)
        )
        points = _safe_points(points, width, height)
        runtime_diagnostic: dict[str, object] = {}
        reliability = point_scores
        hr_calls = None
        if self._complete_runtime is None:
            self._complete_runtime = CountingPipeline(self.device)
        self._lr_affine = affine
        counting = self._complete_runtime.count(
            image,
            LRObservation(
                points=points,
                scores=point_scores,
                global_features=features,
                probability=probability[0, 0].detach().cpu().numpy().astype(np.float32),
                density=density[0, 0].detach().cpu().numpy().astype(np.float32),
                valid=valid[0, 0].detach().cpu().numpy().astype(bool),
                forward_affine=affine.astype(np.float32),
            ),
        )
        points = _safe_points(counting.points, width, height)
        reliability = counting.reliability
        hr_calls = counting.hr_calls
        runtime_diagnostic = counting.diagnostics
        result = self._bunch_model.predict(
            source=np.asarray(image)[:, :, ::-1],
            imgsz=1536,
            conf=float(__import__("os").environ.get("BBA_CONF", "0.35")),
            max_det=100,
            retina_masks=True,
            device=0 if self.device.type == "cuda" else "cpu",
            verbose=False,
        )[0]
        boxes: list[ClusterBox] = []
        if result.boxes is not None:
            xyxy = result.boxes.xyxy.detach().cpu().numpy()
            confidences = result.boxes.conf.detach().cpu().numpy()
            for index, (bbox, confidence) in enumerate(zip(xyxy, confidences), start=1):
                x0, y0, x1, y1 = [float(value) for value in bbox]
                if x1 > x0 and y1 > y0:
                    boxes.append(
                        ClusterBox(
                            f"B{index}", (x0, y0, x1, y1), float(confidence), "detector"
                        )
                    )
        if len(points) and boxes:
            import sys as _sys

            _sys.path.insert(0, str(APP_DIR))
            from .allocation import rebalance as _rebalance

            points, _, _rebalance_info = _rebalance(
                points,
                np.ones(len(points), np.float64),
                [list(b.bbox_xyxy) for b in boxes],
                [float(b.confidence) for b in boxes],
                min_conf=0.25,
            )
        try:
            self._masks_np = (
                result.masks.data.detach().cpu().numpy()
                if result.masks is not None
                else None
            )
            self._confs_np = [
                float(c) for c in result.boxes.conf.detach().cpu().numpy()
            ]
        except Exception:
            self._masks_np = None
            self._confs_np = []
        assignment = assign_berries_to_cluster_boxes(
            points, boxes, image_size=(width, height)
        )
        mode = "live_complete_pipeline"
        mode_label = "Full-pipeline inference"
        notice = "Berry centers and per-bunch counts were computed with GrapePBC."
        trace = CompletePipelineTrace.live_complete()
        return self._save_result(
            boxes=boxes,
            image=image,
            points=points,
            assignment=assignment,
            mode=mode,
            mode_label=mode_label,
            notice=notice,
            sample_id=None,
            hr_calls=hr_calls,
            trace=trace,
            extra={"runtime_diagnostics": runtime_diagnostic},
        )

    def _save_result(
        self,
        *,
        image: Image.Image,
        points: np.ndarray,
        assignment: dict,
        mode: str,
        mode_label: str,
        notice: str,
        sample_id: str | None,
        hr_calls: int | None,
        trace: CompletePipelineTrace,
        extra: dict | None = None,
        boxes: list | None = None,
    ) -> dict:
        result_id = uuid.uuid4().hex[:16]
        folder = RESULT_ROOT / result_id
        folder.mkdir(parents=True, exist_ok=False)
        image.save(folder / "source.jpg", quality=98, subsampling=0, optimize=True)
        overlay = self._draw_overlay(image, points, assignment)
        overlay.save(folder / "overlay.jpg", quality=98, subsampling=0, optimize=True)
        _src = [[float(v) for v in b.bbox_xyxy] for b in boxes or []]
        _used = set()

        def _iou(a, b):
            x1 = max(a[0], b[0])
            y1 = max(a[1], b[1])
            x2 = min(a[2], b[2])
            y2 = min(a[3], b[3])
            iw = max(0.0, x2 - x1)
            ih = max(0.0, y2 - y1)
            inter = iw * ih
            ua = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
            return inter / ua if ua > 0 else 0.0

        clusters = []
        for index, cluster in enumerate(assignment["clusters"], start=1):
            row = dict(cluster)
            row["display_id"] = f"B{index}"
            _cur = [float(v) for v in row.get("bbox_xyxy", [0, 0, 0, 0])]
            _best, _score = (None, 0.0)
            for _j, _b in enumerate(_src):
                if _j in _used:
                    continue
                _s = _iou(_cur, _b)
                if _s > _score:
                    _best, _score = (_j, _s)
            if _best is not None and _score >= 0.3:
                _used.add(_best)
                row["bbox_xyxy"] = _src[_best]
            clusters.append(row)
        _mk = getattr(self, "_masks_np", None)
        if clusters and _mk is not None and (len(_mk) == len(_src)):
            import sys as _s4

            _s4.path.insert(0, str(APP_DIR))
            from .merging import merge as _merge

            _idx, _used2 = ([], set())
            for _c in clusters:
                _cur = [float(v) for v in _c["bbox_xyxy"]]
                _b, _sc = (None, 0.0)
                for _j, _sb in enumerate(_src):
                    if _j in _used2:
                        continue
                    _v = _iou(_cur, _sb)
                    if _v > _sc:
                        _b, _sc = (_j, _v)
                if _b is not None and _sc >= 0.3:
                    _used2.add(_b)
                    _idx.append(_b)
                else:
                    _idx.append(-1)
            _sel = [i for i in _idx if i >= 0]
            if len(_sel) == len(clusters):
                _bx = [list(c["bbox_xyxy"]) for c in clusters]
                _cn = [int(c.get("visible_berry_count", 0)) for c in clusters]
                _ms = [_mk[i] > 0.5 for i in _sel]
                _nb, _nc, _nm = _merge(
                    _bx, getattr(self, "_confs_np", [0.5] * len(_sel)), _ms, _cn
                )
                if _nm > 0:
                    _new = []
                    for _bb, _cc in zip(_nb, _nc):
                        _row = dict(clusters[0])
                        _row["bbox_xyxy"] = [float(v) for v in _bb]
                        _row["visible_berry_count"] = int(_cc)
                        _row["display_id"] = ""
                        _new.append(_row)
                    for _k, _r in enumerate(_new, start=1):
                        _r["display_id"] = "B%d" % _k
                    clusters = _new
                    print(
                        "MASK_MERGE groups %d -> %d" % (len(_nb), len(clusters)),
                        flush=True,
                    )
        response = {
            "result_id": result_id,
            "mode": mode,
            "mode_label": mode_label,
            "pipeline_name": PIPELINE_NAME,
            "pipeline_code": "GrapePBC",
            "execution_trace": trace.to_dict(),
            "sample_id": sample_id,
            "total_count": int(len(points)),
            "bunch_count": int(len(clusters)),
            "hr_calls": None if hr_calls is None else int(hr_calls),
            "clusters": clusters,
            "points": [
                [float(_x), float(_y)] for _x, _y in np.asarray(points).reshape(-1, 2)
            ],
            "unassigned": int(assignment["unassigned"]),
            "overlap_resolved": int(assignment["overlap_resolved"]),
            "nearest_fallback": int(assignment["nearest_fallback"]),
            "synthetic_box_used": bool(assignment["synthetic_box_used"]),
            "overlay_url": f"/result/{result_id}/overlay.jpg",
            "source_url": f"/result/{result_id}/source.jpg",
            "notice": notice,
            "task_boundary": "Counts visible or partly occluded berries with inferable centers; does not infer fully hidden berries.",
        }
        if extra:
            response.update(extra)
        (folder / "result.json").write_text(
            json.dumps(response, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        return response

    @staticmethod
    def _draw_overlay(
        image: Image.Image, points: np.ndarray, assignment: dict
    ) -> Image.Image:
        canvas = image.copy()
        draw = ImageDraw.Draw(canvas, "RGBA")
        width, height = canvas.size
        scale = max(1.0, math.sqrt(width * height) / 1500.0)
        radius = max(3, round(3.4 * scale))
        line = max(3, round(3.0 * scale))
        label_font = _font(max(19, round(22 * scale)))
        for x, y in points:
            draw.ellipse(
                (x - radius, y - radius, x + radius, y + radius),
                fill=(44, 255, 195, 225),
                outline=(3, 35, 31, 245),
                width=max(1, round(scale)),
            )
        colors = [
            (255, 183, 61, 255),
            (81, 190, 255, 255),
            (232, 106, 255, 255),
            (139, 238, 111, 255),
        ]
        for index, cluster in enumerate(assignment["clusters"], start=1):
            x0, y0, x1, y1 = cluster["bbox_xyxy"]
            color = colors[(index - 1) % len(colors)]
            draw.rectangle((x0, y0, x1, y1), outline=color, width=line)
            label = f"B{index}  {cluster['visible_berry_count']}"
            left, top, right, bottom = draw.textbbox((0, 0), label, font=label_font)
            tw, th = (right - left, bottom - top)
            ly = y0 - th - 10 if y0 > th + 14 else y0 + 4
            lx = min(max(0, x0), max(0, width - tw - 12))
            draw.rounded_rectangle(
                (lx, ly, lx + tw + 12, ly + th + 8), radius=5, fill=(9, 20, 24, 224)
            )
            draw.text((lx + 6, ly + 2), label, font=label_font, fill=color)
        return canvas

    def __init__(self):
        self._lock = threading.Lock()
        self._lr_model = None
        self._calibrator = None
        self._thresholds = [0.2, 0.4, 0.6, 0.8]
        self._bunch_model = None
        self._complete_runtime = None
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        if self.device.type != "cuda":
            raise RuntimeError("GrapePBC adaptive-resolution inference requires CUDA.")
        RESULT_ROOT.mkdir(parents=True, exist_ok=True)

    @property
    def status(self):
        return {
            "ready": all(
                (p.exists() for p in (LR_CHECKPOINT, BUNCH_MODEL, LR_CALIBRATOR))
            ),
            "pipeline_name": PIPELINE_NAME,
            "device": str(self.device),
        }

    def _ensure_live_models(self):
        if self._lr_model is None:
            checkpoint = torch.load(
                LR_CHECKPOINT, map_location="cpu", weights_only=False
            )
            self._lr_model = BerryPointNet(
                pretrained=False, **checkpoint["model_config"]
            ).to(self.device)
            self._lr_model.load_state_dict(checkpoint["model"], strict=True)
            self._lr_model.eval()
            self._calibrator = CountCalibrator(LR_CALIBRATOR)
        if self._bunch_model is None:
            from ultralytics import YOLO

            self._bunch_model = YOLO(str(BUNCH_MODEL))

    def infer(self, payload, filename):
        if not payload:
            raise ValueError("No image data received")
        with Image.open(io.BytesIO(payload)) as source:
            image = ImageOps.exif_transpose(source).convert("RGB")
        started = time.perf_counter()
        with self._lock:
            result = self._live_preview(image)
        result["elapsed_ms"] = round((time.perf_counter() - started) * 1000, 1)
        return result
