from __future__ import annotations
import numpy as np
from PIL import Image
import torch

IMAGENET_MEAN = torch.tensor([0.485, 0.456, 0.406])[:, None, None]
IMAGENET_STD = torch.tensor([0.229, 0.224, 0.225])[:, None, None]


def letterbox_image_and_points(
    image: Image.Image,
    points_xy: np.ndarray,
    size: int,
    *,
    fill: tuple[int, int, int] = (114, 114, 114),
) -> tuple[Image.Image, np.ndarray, np.ndarray, np.ndarray]:
    if size <= 0:
        raise ValueError("size must be positive")
    image = image.convert("RGB")
    width, height = image.size
    scale = min(size / width, size / height)
    resized_width = max(1, round(width * scale))
    resized_height = max(1, round(height * scale))
    left = (size - resized_width) // 2
    top = (size - resized_height) // 2
    resized = image.resize((resized_width, resized_height), Image.Resampling.BILINEAR)
    canvas = Image.new("RGB", (size, size), fill)
    canvas.paste(resized, (left, top))
    valid = np.zeros((size, size), dtype=np.bool_)
    valid[top : top + resized_height, left : left + resized_width] = True
    transformed = np.asarray(points_xy, dtype=np.float32).copy()
    if len(transformed):
        transformed[:, 0] = transformed[:, 0] * scale + left
        transformed[:, 1] = transformed[:, 1] * scale + top
    affine = np.array(
        [[scale, 0.0, float(left)], [0.0, scale, float(top)], [0.0, 0.0, 1.0]],
        dtype=np.float32,
    )
    return (canvas, transformed, valid, affine)
