"""Sequential region selection and count-bin fusion."""

from __future__ import annotations
from dataclasses import dataclass
import json
import os
import math
from pathlib import Path
import numpy as np
from PIL import Image
import torch
import torch.nn.functional as F
from .images import IMAGENET_MEAN, IMAGENET_STD, letterbox_image_and_points
from .models import decode_points, HighResolutionExpert
from .tiles import assign_points_to_tiles, make_core_halo_tiles
from .fusion import fuse_sparse_core_points
from . import features as fusion_ops
from . import features as geometry
from . import features as residual_features
from . import features as router_features
from .settings import CONFIG_DIR, CHECKPOINT_DIR

REGION_CONFIG = CONFIG_DIR / "region_processing.json"
RESIDUAL_CHECKPOINT = CHECKPOINT_DIR / "count_residual.pt"
ROUTER_PACKAGE = CHECKPOINT_DIR / "router.pt"
REGION_FEATURE_DIM = 349


@dataclass(slots=True)
class LRObservation:
    points: np.ndarray
    scores: np.ndarray
    global_features: np.ndarray
    probability: np.ndarray
    density: np.ndarray
    valid: np.ndarray
    forward_affine: np.ndarray


@dataclass(slots=True)
class CountingResult:
    points: np.ndarray
    reliability: np.ndarray
    candidate_points: np.ndarray
    candidate_scores: np.ndarray
    hr_calls: int
    heatmap: np.ndarray
    diagnostics: dict[str, object]


def _json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _safe_points(value: np.ndarray) -> np.ndarray:
    points = np.asarray(value, dtype=np.float32).reshape(-1, 2)
    if not np.isfinite(points).all():
        raise ValueError("non-finite point coordinates")
    return points


def _make_tile_item(image: Image.Image, tile, input_size: int) -> dict[str, object]:
    context = image.crop(
        (tile.context_x0, tile.context_y0, tile.context_x1, tile.context_y1)
    )
    transformed, _, valid, affine = letterbox_image_and_points(
        context, np.empty((0, 2), dtype=np.float32), input_size
    )
    corners = np.asarray(
        [
            [tile.core_x0 - tile.context_x0, tile.core_y0 - tile.context_y0, 1.0],
            [tile.core_x1 - tile.context_x0, tile.core_y1 - tile.context_y0, 1.0],
        ],
        dtype=np.float32,
    )
    mapped = (affine @ corners.T).T[:, :2]
    bounds = np.asarray(
        [mapped[0, 0], mapped[0, 1], mapped[1, 0], mapped[1, 1]], np.float32
    )
    array = np.asarray(transformed, dtype=np.float32).transpose(2, 0, 1).copy() / 255.0
    tensor = (torch.from_numpy(array) - IMAGENET_MEAN) / IMAGENET_STD
    return {
        "image": tensor,
        "valid_image_mask": torch.from_numpy(valid),
        "target": {
            "sample_id": "runtime:phone",
            "tile_id": str(tile.tile_id),
            "core_bounds_xyxy": torch.from_numpy(bounds),
            "inverse_affine": torch.from_numpy(
                np.linalg.inv(affine).astype(np.float32)
            ),
            "context_origin_xy": torch.tensor(
                [tile.context_x0, tile.context_y0], dtype=torch.float32
            ),
            "core_count": torch.tensor(0, dtype=torch.int64),
        },
    }


class CountingPipeline:

    def __init__(self, device: torch.device) -> None:
        if device.type != "cuda":
            raise RuntimeError("完整AHR运行链需要CUDA；CPU路径保留基础LR回退")
        self.device = device
        self.region_config = _json(REGION_CONFIG)
        self.density_config = _json(CONFIG_DIR / "density_model.json")
        self.core_size = int(self.region_config["core_size"])
        self.halo = int(self.region_config["halo"])
        self.input_size = int(self.region_config["input_size"])
        self._density = None
        self._residual = None
        self._residual_checkpoint = None
        self._router = None
        self._router_payload = None

    def _ensure_counting_models(self) -> None:
        if self._density is None:
            self._density = HighResolutionExpert(
                decoder_norm="group", freeze_backbone_bn=True
            ).to(self.device)
            checkpoint = torch.load(
                CHECKPOINT_DIR / "high_resolution.pt",
                map_location="cpu",
                weights_only=False,
            )
            self._density.load_state_dict(checkpoint["model"], strict=True)
            self._density.eval()
        if self._residual is None:
            checkpoint = torch.load(
                RESIDUAL_CHECKPOINT, map_location="cpu", weights_only=False
            )
            self._residual_checkpoint = checkpoint
            self._residual = residual_features.head_instance(checkpoint["protocol"]).to(
                self.device
            )
            self._residual.load_state_dict(checkpoint["model"], strict=True)
            self._residual.eval()
        if self._router is None:
            payload = torch.load(ROUTER_PACKAGE, map_location="cpu", weights_only=False)
            self._router_payload = payload
            self._router = router_features.model_instance(payload["protocol"]).to(
                self.device
            )
            self._router.load_state_dict(payload["model"], strict=True)
            self._router.eval()

    def _base_cores(
        self, observation: LRObservation, tiles, width: int, height: int
    ) -> list[dict]:
        owners = assign_points_to_tiles(observation.points, tiles, strict=True)
        probability_total = float(observation.probability[observation.valid].sum())
        density_total = float(observation.density[observation.valid].sum())
        max_row = max((tile.row for tile in tiles))
        max_column = max((tile.column for tile in tiles))
        rows = []
        for tile in tiles:
            chosen = owners == tile.tile_id
            core_points = observation.points[chosen]
            core_scores = observation.scores[chosen]
            probability_values = router_features.map_region(
                observation.probability,
                observation.valid,
                observation.forward_affine,
                tile,
            )
            density_values = router_features.map_region(
                observation.density, observation.valid, observation.forward_affine, tile
            )
            width_fraction = (tile.core_x1 - tile.core_x0) / width
            height_fraction = (tile.core_y1 - tile.core_y0) / height
            base = [
                *observation.global_features.tolist(),
                math.log1p(len(observation.points)),
                math.log1p(len(core_points)),
                len(core_points) / max(len(observation.points), 1),
                (tile.core_x0 + tile.core_x1) / (2.0 * width),
                (tile.core_y0 + tile.core_y1) / (2.0 * height),
                width_fraction,
                height_fraction,
                width_fraction * height_fraction,
                tile.row / max(max_row, 1),
                tile.column / max(max_column, 1),
                float(
                    tile.core_x0 == 0
                    or tile.core_y0 == 0
                    or tile.core_x1 == width
                    or (tile.core_y1 == height)
                ),
                *router_features.distribution_features(core_points, core_scores, tile),
                *router_features.map_features(probability_values, probability_total),
                *router_features.map_features(density_values, density_total),
                float(
                    len(probability_values)
                    / max(
                        (tile.core_x1 - tile.core_x0)
                        * (tile.core_y1 - tile.core_y0)
                        / 4.0,
                        1.0,
                    )
                ),
            ]
            rows.append(
                {
                    "tile_id": tile.tile_id,
                    "row": tile.row,
                    "column": tile.column,
                    "center": np.asarray(base[15:17], np.float32),
                    "lr_count": int(len(core_points)),
                    "base": np.asarray(base, np.float32),
                    "lr_points": core_points,
                    "lr_scores": core_scores,
                }
            )
        return rows

    @torch.inference_mode()
    def _predict_residual(
        self, feature: np.ndarray, lr_count: int, candidate_count: int
    ) -> dict[str, object]:
        checkpoint = self._residual_checkpoint
        normalized = (
            (feature - checkpoint["feature_mean"]) / checkpoint["feature_std"]
        ).astype(np.float32)
        output = self._residual(torch.from_numpy(normalized[None]).to(self.device))
        delta = output["delta"].detach().cpu().numpy()
        error = float(np.expm1(np.clip(output["log_error"].item(), 0.0, 10.0)))
        fused = int(
            residual_features.decode_numpy(
                np.asarray([lr_count]), delta, np.asarray([candidate_count])
            )[0]
        )
        accepted = error <= float(checkpoint["fallback_error_threshold"])
        return {
            "count": fused if accepted else lr_count,
            "raw_count": fused,
            "error": error,
            "accepted": accepted,
        }

    @torch.inference_mode()
    def _run_tile(self, image: Image.Image, tile) -> dict[str, object]:
        item = _make_tile_item(image, tile, self.input_size)
        rich = {
            "feature": np.zeros(REGION_FEATURE_DIM, np.float32),
            "candidate_native_xy": np.empty((0, 2), np.float32),
            "candidate_scores": np.empty(0, np.float32),
            "candidates": np.empty((0, 2), np.float32),
            "scores": np.empty(0, np.float32),
        }
        tensor = item["image"].to(self.device)
        valid = item["valid_image_mask"].to(self.device)
        outputs = self._density(tensor[None], valid[None])
        decoded = decode_points(
            outputs,
            score_threshold=1e-06,
            topk=4096,
            local_max_kernel=3,
            output_stride=self._density.output_stride,
        )[0]
        density_map = F.softplus(outputs["density_logits"].float())
        bounds = item["target"]["core_bounds_xyxy"].to(self.device)
        owned_density = geometry.rect_mask(
            valid, bounds, density_map.shape[-2], density_map.shape[-1], self.input_size
        )
        mass = float(density_map[0, 0][owned_density].sum())
        density_count = max(0, int(math.floor(mass + 0.5)))
        points = decoded["points"].detach().cpu().numpy().astype(np.float32)
        scores = decoded["scores"].detach().cpu().numpy().astype(np.float32)
        x0, y0, x1, y1 = item["target"]["core_bounds_xyxy"].numpy().tolist()
        owned = (
            (points[:, 0] >= x0)
            & (points[:, 0] < x1)
            & (points[:, 1] >= y0)
            & (points[:, 1] < y1)
        )
        points, scores = (points[owned], scores[owned])
        order = np.argsort(-scores, kind="stable")
        points, scores = (points[order], scores[order])
        native = geometry.to_native(
            points,
            item["target"]["inverse_affine"].numpy(),
            item["target"]["context_origin_xy"].numpy(),
        )
        return {
            "rich_feature": rich["feature"],
            "rich_candidates": rich["candidate_native_xy"],
            "rich_scores": rich["candidate_scores"],
            "density_candidates": native,
            "density_scores": scores,
            "density_mass": mass,
            "density_count": min(density_count, len(native)),
        }

    def _attach_tile_prediction(
        self, core: dict, tile_output: dict, lr_total: int
    ) -> None:
        feature = np.concatenate(
            (
                tile_output["rich_feature"],
                np.asarray(
                    [
                        math.log1p(core["lr_count"]),
                        math.log1p(lr_total),
                        core["lr_count"] / max(lr_total, 1),
                        math.log1p(len(tile_output["rich_candidates"])),
                    ],
                    np.float32,
                ),
            )
        )
        residual = self._predict_residual(
            feature, core["lr_count"], len(tile_output["rich_candidates"])
        )
        core.update(tile_output)
        core["fusion_feature"] = feature
        core["hr_count"] = int(residual["count"])
        core["hr_delta"] = int(residual["count"]) - int(core["lr_count"])
        core["hr_predicted_error"] = float(residual["error"])

    def _router_utility(self, features: np.ndarray) -> np.ndarray:
        payload = self._router_payload
        target_dim = int(payload["feature_mean"].shape[0])
        if features.shape[1] < target_dim:
            _pad = np.zeros(
                (features.shape[0], target_dim - features.shape[1]), np.float32
            )
            features = np.concatenate([features, _pad], axis=1)
        elif features.shape[1] > target_dim:
            features = features[:, :target_dim]
        normalized = (
            (features - payload["feature_mean"]) / payload["feature_std"]
        ).astype(np.float32)
        with torch.inference_mode():
            encoded = self._router(torch.from_numpy(normalized).to(self.device))
        from .models.router import decode_utility

        return decode_utility(encoded).cpu().numpy()

    def _sparse_counting(
        self, image: Image.Image, observation: LRObservation, tiles, cores
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, int, dict[str, object]]:
        policy = self._router_payload["policy"]
        selected: list[int] = []
        utilities: list[float] = []
        _budget = int(__import__("os").environ.get("FORCE_CALLS", "0") or 0)
        _cap = (
            _budget
            if _budget >= 0 and "FORCE_CALLS" in __import__("os").environ
            else int(policy["maximum_calls"])
        )
        force_no_stop = os.environ.get("FORCE_NO_STOP", "0") == "1"
        while len(selected) < min(_cap, len(cores)):
            remaining = [index for index in range(len(cores)) if index not in selected]
            features = np.stack(
                [
                    router_features.state_features(
                        {"lr_total": len(observation.points), "cores": cores},
                        tuple(selected),
                        index,
                        int(policy["maximum_calls"]),
                    )
                    for index in remaining
                ]
            )
            utility = self._router_utility(features)
            density_prior = np.log1p(
                np.asarray(
                    [cores[index]["lr_count"] for index in remaining], np.float32
                )
            )
            utility_z = (utility - utility.mean()) / (utility.std() + 1e-06)
            density_z = (density_prior - density_prior.mean()) / (
                density_prior.std() + 1e-06
            )
            score = (1.0 - float(policy["density_weight"])) * utility_z + float(
                policy["density_weight"]
            ) * density_z
            position = int(np.argmax(score))
            chosen = remaining[position]
            if not force_no_stop and float(utility[position]) <= float(
                policy["minimum_predicted_utility"]
            ):
                break
            output = self._run_tile(image, tiles[chosen])
            self._attach_tile_prediction(cores[chosen], output, len(observation.points))
            selected.append(chosen)
            utilities.append(float(utility[position]))
        if not selected:
            return (
                observation.points.copy(),
                observation.scores.copy(),
                np.empty((0, 2), np.float32),
                np.empty(0, np.float32),
                0,
                {"branch": "sparse_ahr", "selected_tile_ids": [], "utilities": []},
            )
        lr_total = len(observation.points)
        if lr_total <= 50:
            gain, floor = (0.5, 5)
        elif lr_total <= 100:
            gain, floor = (0.5, 5)
        elif lr_total <= 200:
            gain, floor = (0.625, 15)
        else:
            gain, floor = (0.375, 0)
        _g_ov = __import__("os").environ.get("CCF_GAIN")
        _f_ov = __import__("os").environ.get("CCF_FLOOR")
        if _g_ov is not None:
            gain = float(_g_ov)
        if _f_ov is not None:
            floor = int(_f_ov)
        if _g_ov is not None or _f_ov is not None:
            print("CCF OVERRIDE ACTIVE gain=%s floor=%s" % (gain, floor), flush=True)
        owners = assign_points_to_tiles(observation.points, tiles, strict=True)
        requested, candidates, scores = ({}, {}, {})
        reliability_parts = [
            observation.scores[~np.isin(owners, np.asarray(selected, np.int64))]
        ]
        saturated = 0
        for index in selected:
            core = cores[index]
            target = (
                fusion_ops.gain_count(core["lr_count"], core["density_count"], gain)
                if core["density_count"] >= floor
                else core["lr_count"]
            )
            target = min(int(target), len(core["density_candidates"]))
            saturated += int(
                target
                < (
                    fusion_ops.gain_count(core["lr_count"], core["density_count"], gain)
                    if core["density_count"] >= floor
                    else core["lr_count"]
                )
            )
            requested[index] = target
            candidates[index] = core["density_candidates"]
            scores[index] = core["density_scores"]
            tile = tiles[index]
            owned = (
                (core["density_candidates"][:, 0] >= tile.core_x0)
                & (core["density_candidates"][:, 0] < tile.core_x1)
                & (core["density_candidates"][:, 1] >= tile.core_y0)
                & (core["density_candidates"][:, 1] < tile.core_y1)
            )
            local_scores = core["density_scores"][owned]
            reliability_parts.append(np.sort(local_scores)[::-1][:target])
        fused = fuse_sparse_core_points(
            observation.points, tiles, selected, requested, candidates, scores
        )
        reliability = np.concatenate(reliability_parts).astype(np.float32)
        pool_points = np.concatenate(
            [cores[index]["density_candidates"] for index in selected]
        )
        pool_scores = np.concatenate(
            [cores[index]["density_scores"] for index in selected]
        )
        return (
            fused.points,
            reliability,
            pool_points,
            pool_scores,
            len(selected),
            {
                "branch": "sparse_ahr",
                "selected_tile_ids": selected,
                "utilities": utilities,
                "requested_counts_by_tile": {
                    str(key): int(value) for key, value in requested.items()
                },
                "candidate_saturation_events": saturated,
            },
        )

    def count(self, image: Image.Image, observation: LRObservation) -> CountingResult:
        self._ensure_counting_models()
        width, height = image.size
        tiles = make_core_halo_tiles(
            width, height, core_size=self.core_size, halo=self.halo
        )
        cores = self._base_cores(observation, tiles, width, height)
        raw = self._sparse_counting(image, observation, tiles, cores)
        points, reliability, candidates, candidate_scores, calls, diagnostic = raw
        diagnostic["tile_count"] = len(tiles)
        diagnostic["lr_count"] = len(observation.points)
        diagnostic["count_after_ccf"] = len(points)
        return CountingResult(
            points.astype(np.float32),
            reliability.astype(np.float32),
            candidates.astype(np.float32),
            candidate_scores.astype(np.float32),
            int(calls),
            observation.density.astype(np.float32),
            diagnostic,
        )
