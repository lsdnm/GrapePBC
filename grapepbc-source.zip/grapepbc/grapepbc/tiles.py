from __future__ import annotations
from dataclasses import asdict, dataclass
from typing import Sequence
import numpy as np


@dataclass(frozen=True, slots=True)
class CoreHaloTile:
    tile_id: int
    row: int
    column: int
    core_x0: int
    core_y0: int
    core_x1: int
    core_y1: int
    context_x0: int
    context_y0: int
    context_x1: int
    context_y1: int

    @property
    def core_area(self) -> int:
        return (self.core_x1 - self.core_x0) * (self.core_y1 - self.core_y0)

    @property
    def context_area(self) -> int:
        return (self.context_x1 - self.context_x0) * (self.context_y1 - self.context_y0)

    def owns(self, x: float, y: float) -> bool:
        return self.core_x0 <= x < self.core_x1 and self.core_y0 <= y < self.core_y1

    def to_dict(self) -> dict[str, int]:
        return asdict(self)


def _positive_int(value: int, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError(f"{name} must be a positive integer")
    return value


def make_core_halo_tiles(
    width: int, height: int, *, core_size: int, halo: int
) -> tuple[CoreHaloTile, ...]:
    width = _positive_int(width, "width")
    height = _positive_int(height, "height")
    core_size = _positive_int(core_size, "core_size")
    if isinstance(halo, bool) or not isinstance(halo, int) or halo < 0:
        raise ValueError("halo must be a non-negative integer")
    tiles: list[CoreHaloTile] = []
    tile_id = 0
    for row, core_y0 in enumerate(range(0, height, core_size)):
        core_y1 = min(core_y0 + core_size, height)
        for column, core_x0 in enumerate(range(0, width, core_size)):
            core_x1 = min(core_x0 + core_size, width)
            tiles.append(
                CoreHaloTile(
                    tile_id=tile_id,
                    row=row,
                    column=column,
                    core_x0=core_x0,
                    core_y0=core_y0,
                    core_x1=core_x1,
                    core_y1=core_y1,
                    context_x0=max(0, core_x0 - halo),
                    context_y0=max(0, core_y0 - halo),
                    context_x1=min(width, core_x1 + halo),
                    context_y1=min(height, core_y1 + halo),
                )
            )
            tile_id += 1
    validate_core_partition(tiles, width=width, height=height)
    return tuple(tiles)


def validate_core_partition(
    tiles: Sequence[CoreHaloTile], *, width: int, height: int
) -> None:
    width = _positive_int(width, "width")
    height = _positive_int(height, "height")
    if not tiles:
        raise ValueError("tiles cannot be empty")
    expected_ids = list(range(len(tiles)))
    if [tile.tile_id for tile in tiles] != expected_ids:
        raise ValueError("tile IDs must be unique, contiguous and row-major")
    total_core_area = 0
    for tile in tiles:
        if not (
            0 <= tile.core_x0 < tile.core_x1 <= width
            and 0 <= tile.core_y0 < tile.core_y1 <= height
        ):
            raise ValueError(f"tile {tile.tile_id} has an invalid core rectangle")
        if not (
            0 <= tile.context_x0 <= tile.core_x0
            and tile.core_x1 <= tile.context_x1 <= width
            and (0 <= tile.context_y0 <= tile.core_y0)
            and (tile.core_y1 <= tile.context_y1 <= height)
        ):
            raise ValueError(f"tile {tile.tile_id} has an invalid context rectangle")
        total_core_area += tile.core_area
    if total_core_area != width * height:
        raise ValueError("tile cores do not cover exactly one image area")
    for first_index, first in enumerate(tiles):
        for second in tiles[first_index + 1 :]:
            overlap_width = min(first.core_x1, second.core_x1) - max(
                first.core_x0, second.core_x0
            )
            overlap_height = min(first.core_y1, second.core_y1) - max(
                first.core_y0, second.core_y0
            )
            if overlap_width > 0 and overlap_height > 0:
                raise ValueError(
                    f"tile cores {first.tile_id} and {second.tile_id} overlap"
                )


def _point_array(points_xy: np.ndarray | Sequence[Sequence[float]]) -> np.ndarray:
    points = np.asarray(points_xy, dtype=np.float64)
    if points.size == 0:
        return np.empty((0, 2), dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 2:
        raise ValueError(f"points must have shape (N, 2), got {points.shape}")
    if not np.isfinite(points).all():
        raise ValueError("points must be finite")
    return points


def assign_points_to_tiles(
    points_xy: np.ndarray | Sequence[Sequence[float]],
    tiles: Sequence[CoreHaloTile],
    *,
    strict: bool = True,
) -> np.ndarray:
    points = _point_array(points_xy)
    owners = np.full(len(points), -1, dtype=np.int64)
    for tile in tiles:
        owned = (
            (points[:, 0] >= tile.core_x0)
            & (points[:, 0] < tile.core_x1)
            & (points[:, 1] >= tile.core_y0)
            & (points[:, 1] < tile.core_y1)
        )
        if np.any(owned & (owners >= 0)):
            raise ValueError("a point is owned by more than one core")
        owners[owned] = tile.tile_id
    if strict and np.any(owners < 0):
        bad = np.flatnonzero(owners < 0)[:5].tolist()
        raise ValueError(f"points outside the core partition at indices {bad}")
    return owners
