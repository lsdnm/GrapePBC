"""Train GeoPrivNet with training-only geometry supervision.

Validation is kept separate on purpose. Peak-threshold ablations tune their
score threshold on validation predictions only; density-guided ablations use a
fully fixed Top-K decoder. Every checkpoint stores its exact decoder contract.
"""

from __future__ import annotations

import argparse
from copy import deepcopy
from contextlib import nullcontext
from dataclasses import asdict
import json
import math
from pathlib import Path
import random
import time
from typing import Any, Mapping, Sequence

import numpy as np
import torch
from torch.utils.data import DataLoader

from geopriv.data import PrivilegedManifestDataset, collate_privileged_samples
from geopriv.data.hash_utils import file_sha256
from geopriv.metrics import aggregate_count_metrics, maximum_cardinality_point_matches
from geopriv.models import (
    DEFAULT_CANDIDATE_SCORE_FLOOR,
    GeoPrivNet,
    decode_points,
    decode_points_by_mode,
)
from geopriv.training import GeoPrivLossWeights, build_geopriv_targets, geopriv_loss


def seed_everything(seed: int) -> None:
    """Seed Python, NumPy, and Torch without forcing slow deterministic kernels."""

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def atomic_torch_save(payload: dict[str, object], path: Path) -> None:
    """Persist a checkpoint without exposing a partially written target file."""

    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temporary)
    temporary.replace(path)


def atomic_json_write(payload: dict[str, object], path: Path) -> None:
    """Persist JSON progress metadata atomically for interruption-safe resumes."""

    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False, default=str) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def source_sha256_manifest() -> dict[str, str]:
    """Hash executable training sources so formal runs remain auditable."""

    project_root = Path(__file__).resolve().parents[1]
    paths = [Path(__file__).resolve()]
    paths.extend(sorted((project_root / "src/geopriv").rglob("*.py")))
    return {
        path.relative_to(project_root).as_posix(): file_sha256(path) for path in paths
    }


def capture_rng_state(data_loader_generator: torch.Generator) -> dict[str, object]:
    """Capture all random streams needed for an exact same-host resume."""

    return {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch_cpu": torch.get_rng_state(),
        "torch_cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [],
        "data_loader_generator": data_loader_generator.get_state(),
    }


def restore_rng_state(
    state: dict[str, object], data_loader_generator: torch.Generator
) -> None:
    """Restore random streams saved by :func:`capture_rng_state`."""

    required = {
        "python",
        "numpy",
        "torch_cpu",
        "torch_cuda",
        "data_loader_generator",
    }
    missing = required.difference(state)
    if missing:
        raise ValueError(f"checkpoint RNG state is missing fields: {sorted(missing)}")
    random.setstate(state["python"])  # type: ignore[arg-type]
    np.random.set_state(state["numpy"])  # type: ignore[arg-type]
    torch.set_rng_state(state["torch_cpu"])  # type: ignore[arg-type]
    cuda_states = state["torch_cuda"]
    if torch.cuda.is_available() and cuda_states:
        torch.cuda.set_rng_state_all(cuda_states)  # type: ignore[arg-type]
    data_loader_generator.set_state(state["data_loader_generator"])  # type: ignore[arg-type]


_RESUME_MUTABLE_CONFIG_FIELDS = {"epochs", "output", "resume"}


def _canonical_config_value(value: object) -> object:
    if isinstance(value, Path):
        return str(value.resolve())
    if isinstance(value, Mapping):
        return {
            str(key): _canonical_config_value(item)
            for key, item in sorted(value.items(), key=lambda pair: str(pair[0]))
        }
    if isinstance(value, (list, tuple)):
        return tuple(_canonical_config_value(item) for item in value)
    return value


def validate_resume_config(
    args: argparse.Namespace, checkpoint_config: object
) -> None:
    """Reject silent protocol changes when continuing a formal run.

    Only the target epoch count and file locations may change.  The new target
    may extend, but never shorten, the epoch budget recorded in the checkpoint.
    """

    if not isinstance(checkpoint_config, Mapping):
        raise ValueError("resume checkpoint config must be a mapping")
    current = vars(args)
    current_keys = set(current).difference(_RESUME_MUTABLE_CONFIG_FIELDS)
    stored_keys = set(checkpoint_config).difference(_RESUME_MUTABLE_CONFIG_FIELDS)
    missing = sorted(current_keys - stored_keys)
    unknown = sorted(stored_keys - current_keys)
    mismatches: list[str] = []
    for name in sorted(current_keys & stored_keys):
        current_value = _canonical_config_value(current[name])
        stored_value = _canonical_config_value(checkpoint_config[name])
        if current_value != stored_value:
            mismatches.append(
                f"{name}: checkpoint={stored_value!r}, current={current_value!r}"
            )
    if missing:
        mismatches.append(f"missing from checkpoint: {missing}")
    if unknown:
        mismatches.append(f"unsupported checkpoint fields: {unknown}")

    stored_epochs = checkpoint_config.get("epochs")
    if isinstance(stored_epochs, bool) or not isinstance(stored_epochs, int):
        mismatches.append("checkpoint epochs is not an integer")
    elif args.epochs < stored_epochs:
        mismatches.append(
            f"epochs cannot decrease: checkpoint={stored_epochs}, current={args.epochs}"
        )
    if mismatches:
        raise ValueError("resume configuration mismatch: " + "; ".join(mismatches))


def validation_metric_key(metrics: dict[str, object], primary: str) -> tuple[float, float]:
    """Return a minimization key with a deterministic secondary criterion."""

    f1 = float(metrics["f1_at_8"])
    mae = float(metrics["mae"])
    if primary == "f1":
        return -f1, mae
    if primary == "mae":
        return mae, -f1
    raise ValueError(f"unsupported primary metric: {primary}")


def threshold_grid(start: float, stop: float, step: float) -> list[float]:
    """Build an inclusive, stable threshold grid."""

    if not (0.0 < start <= stop < 1.0):
        raise ValueError("thresholds must satisfy 0 < start <= stop < 1")
    if not step > 0:
        raise ValueError("threshold step must be positive")
    count = int(math.floor((stop - start) / step + 1e-9)) + 1
    values = [round(start + index * step, 10) for index in range(count)]
    if values[-1] < stop - 1e-9:
        values.append(round(stop, 10))
    return values


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Train GeoPrivNet; tune score thresholds on validation data only."
    )
    parser.add_argument("--train-manifest", type=Path, required=True)
    parser.add_argument("--train-root", type=Path, required=True)
    parser.add_argument("--train-split", default="train")
    parser.add_argument("--val-manifest", type=Path, required=True)
    parser.add_argument("--val-root", type=Path, required=True)
    parser.add_argument("--val-split", default="val")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-train-samples", type=int)
    parser.add_argument("--max-val-samples", type=int)

    parser.add_argument("--image-size", type=int, default=768)
    parser.add_argument("--fpn-channels", type=int, default=64)
    parser.add_argument("--pretrained", action="store_true")
    parser.add_argument("--decoder-norm", choices=("batch", "group"), default="group")
    parser.add_argument(
        "--freeze-backbone-bn",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Keep MobileNet BatchNorm in eval mode (recommended for small batches).",
    )

    parser.add_argument("--epochs", type=int, default=120)
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--gradient-clip", type=float, default=5.0)
    parser.add_argument("--seed", type=int, default=20260917)
    parser.add_argument(
        "--train-augmentation",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Enable seeded horizontal flip and light color jitter for training only.",
    )
    parser.add_argument(
        "--augmentation-seed",
        type=int,
        help="Augmentation seed (defaults to --seed).",
    )
    parser.add_argument("--horizontal-flip-probability", type=float, default=0.5)
    parser.add_argument("--color-jitter-probability", type=float, default=0.8)
    parser.add_argument("--brightness-jitter", type=float, default=0.1)
    parser.add_argument("--contrast-jitter", type=float, default=0.1)
    parser.add_argument("--saturation-jitter", type=float, default=0.05)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--eval-every", type=int, default=5)
    parser.add_argument("--resume", type=Path)
    parser.add_argument("--no-amp", action="store_true")

    parser.add_argument("--gaussian-radius", type=int, default=1)
    parser.add_argument("--density-sigma", type=float, default=1.0)
    parser.add_argument(
        "--density-sigma-mode",
        choices=("fixed", "privileged_radius"),
        default="fixed",
    )
    parser.add_argument("--density-radius-divisor", type=float, default=3.0)
    parser.add_argument("--density-sigma-min", type=float, default=0.5)
    parser.add_argument("--density-sigma-max", type=float, default=4.0)
    parser.add_argument("--center-weight", type=float, default=1.0)
    parser.add_argument("--offset-weight", type=float, default=1.0)
    parser.add_argument("--radius-weight", type=float, default=0.25)
    parser.add_argument("--density-weight", type=float, default=0.2)
    parser.add_argument("--count-conservation-weight", type=float, default=0.1)
    parser.add_argument(
        "--count-conservation-mode",
        choices=("relative_l1", "poisson_smooth_l1"),
        default="relative_l1",
    )

    parser.add_argument("--threshold-start", type=float, default=0.01)
    parser.add_argument("--threshold-stop", type=float, default=0.99)
    parser.add_argument("--threshold-step", type=float, default=0.01)
    parser.add_argument("--match-radius", type=float, default=8.0)
    parser.add_argument("--local-max-kernel", type=int, default=3)
    parser.add_argument("--topk", type=int, default=4096)
    parser.add_argument(
        "--count-mode",
        choices=("peak_threshold", "density_topk"),
        default="density_topk",
        help=(
            "Final count decoder. Use peak_threshold for A0/A1 and "
            "density_topk for A2/A3."
        ),
    )
    parser.add_argument(
        "--candidate-score-floor",
        type=float,
        default=DEFAULT_CANDIDATE_SCORE_FLOOR,
        help="Frozen numerical floor for density_topk center candidates.",
    )
    return parser


def validate_args(parser: argparse.ArgumentParser, args: argparse.Namespace) -> None:
    positive_ints = (
        "image_size",
        "fpn_channels",
        "epochs",
        "batch_size",
        "eval_every",
        "local_max_kernel",
        "topk",
    )
    for name in positive_ints:
        if getattr(args, name) <= 0:
            parser.error(f"--{name.replace('_', '-')} must be positive")
    if args.num_workers < 0:
        parser.error("--num-workers must be non-negative")
    for name in ("max_train_samples", "max_val_samples"):
        value = getattr(args, name)
        if value is not None and value <= 0:
            parser.error(f"--{name.replace('_', '-')} must be positive")
    if args.learning_rate <= 0:
        parser.error("--learning-rate must be positive")
    if args.weight_decay < 0:
        parser.error("--weight-decay must be non-negative")
    if args.gradient_clip < 0:
        parser.error("--gradient-clip must be non-negative")
    for name in ("horizontal_flip_probability", "color_jitter_probability"):
        if not 0.0 <= getattr(args, name) <= 1.0:
            parser.error(f"--{name.replace('_', '-')} must lie in [0, 1]")
    for name in ("brightness_jitter", "contrast_jitter", "saturation_jitter"):
        if not 0.0 <= getattr(args, name) <= 1.0:
            parser.error(f"--{name.replace('_', '-')} must lie in [0, 1]")
    if args.gaussian_radius < 0:
        parser.error("--gaussian-radius must be non-negative")
    if args.density_sigma <= 0:
        parser.error("--density-sigma must be positive")
    if not math.isfinite(args.density_radius_divisor) or args.density_radius_divisor <= 0:
        parser.error("--density-radius-divisor must be finite and positive")
    if not math.isfinite(args.density_sigma_min) or args.density_sigma_min <= 0:
        parser.error("--density-sigma-min must be finite and positive")
    if (
        not math.isfinite(args.density_sigma_max)
        or args.density_sigma_max < args.density_sigma_min
    ):
        parser.error("--density-sigma-max must be finite and at least --density-sigma-min")
    if args.match_radius < 0:
        parser.error("--match-radius must be non-negative")
    if args.local_max_kernel % 2 == 0:
        parser.error("--local-max-kernel must be odd")
    if not math.isfinite(args.candidate_score_floor) or not (
        0.0 <= args.candidate_score_floor <= 1.0
    ):
        parser.error("--candidate-score-floor must be finite and lie in [0, 1]")
    try:
        threshold_grid(args.threshold_start, args.threshold_stop, args.threshold_step)
        weights = loss_weights_from_args(args)
    except ValueError as error:
        parser.error(str(error))
    if not any(asdict(weights).values()):
        parser.error("at least one loss weight must be positive")
    if (
        args.count_mode == "density_topk"
        and weights.density == 0.0
        and weights.count_conservation == 0.0
    ):
        parser.error(
            "--count-mode=density_topk requires a positive --density-weight "
            "or --count-conservation-weight"
        )


def loss_weights_from_args(args: argparse.Namespace) -> GeoPrivLossWeights:
    return GeoPrivLossWeights(
        center=args.center_weight,
        offset=args.offset_weight,
        radius=args.radius_weight,
        density=args.density_weight,
        count_conservation=args.count_conservation_weight,
    )


def augmentation_config_from_args(args: argparse.Namespace) -> dict[str, object]:
    """Return the effective, checkpoint-safe training augmentation contract."""

    seed = getattr(args, "augmentation_seed", None)
    if seed is None:
        seed = getattr(args, "seed", 0)
    return {
        "enabled": bool(getattr(args, "train_augmentation", False)),
        "seed": int(seed),
        "horizontal_flip_probability": float(
            getattr(args, "horizontal_flip_probability", 0.0)
        ),
        "color_jitter_probability": float(
            getattr(args, "color_jitter_probability", 0.0)
        ),
        "brightness_jitter": float(getattr(args, "brightness_jitter", 0.0)),
        "contrast_jitter": float(getattr(args, "contrast_jitter", 0.0)),
        "saturation_jitter": float(getattr(args, "saturation_jitter", 0.0)),
        "validation_augmentation": False,
        "geometric_transforms": ["horizontal_flip"],
        "excluded_geometric_transforms": ["rotation", "crop"],
    }


def density_target_config_from_args(args: argparse.Namespace) -> dict[str, object]:
    """Return the exact density-target and count-loss protocol."""

    return {
        "sigma_mode": str(getattr(args, "density_sigma_mode", "fixed")),
        "fixed_sigma": float(getattr(args, "density_sigma", 1.0)),
        "radius_divisor": float(getattr(args, "density_radius_divisor", 3.0)),
        "sigma_min": float(getattr(args, "density_sigma_min", 0.5)),
        "sigma_max": float(getattr(args, "density_sigma_max", 4.0)),
        "privileged_sigma_formula": "equivalent_radius_input_px / output_stride / radius_divisor",
        "per_instance_mass": 1.0,
        "count_conservation_mode": str(
            getattr(args, "count_conservation_mode", "relative_l1")
        ),
    }


def decoder_protocol_from_args(
    args: argparse.Namespace,
    *,
    output_stride: int,
    validation_metrics: Mapping[str, object] | None = None,
    validation_epoch: int | None = None,
    objective: str | None = None,
) -> dict[str, object]:
    """Return the frozen, checkpoint-safe count decoder contract."""

    count_mode = str(getattr(args, "count_mode", "peak_threshold"))
    protocol: dict[str, object] = {
        "count_mode": count_mode,
        "local_max_kernel": int(getattr(args, "local_max_kernel", 3)),
        "topk": int(getattr(args, "topk", 4096)),
        "candidate_score_floor": float(
            getattr(args, "candidate_score_floor", DEFAULT_CANDIDATE_SCORE_FLOOR)
        ),
        "density_rounding": "half_up_nonnegative",
        "valid_region": "valid_image_mask_projected_with_adaptive_max_pool",
        "output_stride": int(output_stride),
        "frozen_for_checkpoint": validation_metrics is not None,
    }
    if validation_epoch is not None:
        protocol["validation_epoch"] = int(validation_epoch)
    if objective is not None:
        protocol["selection_objective"] = objective
    if count_mode == "peak_threshold" and validation_metrics is not None:
        protocol["score_threshold"] = float(validation_metrics["threshold"])
        protocol["threshold_source"] = "validation_only"
    else:
        protocol["score_threshold"] = None
        protocol["threshold_source"] = "not_applicable"
    return protocol


def incremental_match_table(
    predicted_xy: np.ndarray,
    scores: np.ndarray,
    target_xy: np.ndarray,
    thresholds: Sequence[float],
    radius: float,
) -> dict[float, tuple[int, int]]:
    """Return ``threshold -> (true positives, prediction count)`` efficiently.

    Threshold sets are nested.  Processing them from high to low lets each new
    prediction run one augmenting-path update, rather than solving 99 matching
    problems from scratch.  The result is still maximum-cardinality matching
    for every threshold.
    """

    prediction = np.asarray(predicted_xy, dtype=np.float32).reshape(-1, 2)
    confidence = np.asarray(scores, dtype=np.float32).reshape(-1)
    target = np.asarray(target_xy, dtype=np.float32).reshape(-1, 2)
    if len(prediction) != len(confidence):
        raise ValueError("predicted_xy and scores must have equal length")
    if radius < 0:
        raise ValueError("radius must be non-negative")
    ordered_thresholds = sorted({float(value) for value in thresholds}, reverse=True)
    order = np.argsort(-confidence, kind="stable")
    prediction = prediction[order]
    confidence = confidence[order]
    radius_squared = radius * radius
    adjacency = [
        np.flatnonzero(np.sum((target - point) ** 2, axis=1) <= radius_squared)
        for point in prediction
    ]
    match_left = np.full(len(prediction), -1, dtype=np.int64)
    match_right = np.full(len(target), -1, dtype=np.int64)
    active_count = matched_count = 0
    table: dict[float, tuple[int, int]] = {}

    for threshold in ordered_thresholds:
        while active_count < len(prediction) and confidence[active_count] >= threshold:
            start = active_count
            active_count += 1
            if matched_count == len(target):
                continue
            parent_right = np.full(len(target), -1, dtype=np.int64)
            seen_left = np.zeros(active_count, dtype=np.bool_)
            seen_left[start] = True
            queue = [start]
            queue_index = 0
            free_right = -1
            while queue_index < len(queue) and free_right < 0:
                left = queue[queue_index]
                queue_index += 1
                for right_value in adjacency[left]:
                    right = int(right_value)
                    if parent_right[right] >= 0:
                        continue
                    parent_right[right] = left
                    paired_left = int(match_right[right])
                    if paired_left < 0:
                        free_right = right
                        break
                    if not seen_left[paired_left]:
                        seen_left[paired_left] = True
                        queue.append(paired_left)
            if free_right < 0:
                continue
            right = free_right
            while right >= 0:
                left = int(parent_right[right])
                previous_right = int(match_left[left])
                match_left[left] = right
                match_right[right] = left
                right = previous_right
            matched_count += 1
        table[threshold] = (matched_count, active_count)
    return table


def select_validation_metrics(
    candidates: Sequence[dict[str, object]],
) -> dict[str, dict[str, object]]:
    """Select independent validation operating points for localization and count.

    A score threshold that maximizes localization F1 is not necessarily the one
    that minimizes count MAE.  Keeping both selections prevents the counting
    checkpoint from silently inheriting an F1-tuned operating point.
    """

    if not candidates:
        raise ValueError("at least one validation candidate is required")
    best_f1 = min(candidates, key=lambda item: validation_metric_key(item, "f1"))
    best_mae = min(candidates, key=lambda item: validation_metric_key(item, "mae"))
    return {
        "f1": {
            **best_f1,
            "threshold_objective": "maximum_f1_at_8_then_minimum_mae",
        },
        "mae": {
            **best_mae,
            "threshold_objective": "minimum_mae_then_maximum_f1_at_8",
        },
    }


@torch.no_grad()
def evaluate_validation(
    model: GeoPrivNet,
    loader: DataLoader,
    device: torch.device,
    thresholds: Sequence[float],
    *,
    count_mode: str = "peak_threshold",
    matching_radius: float,
    local_max_kernel: int,
    topk: int,
    candidate_score_floor: float = DEFAULT_CANDIDATE_SCORE_FLOOR,
) -> dict[str, dict[str, object]]:
    """Evaluate one frozen decoder and select epoch objectives on validation.

    ``peak_threshold`` searches only this validation cache and returns
    independently selected F1/MAE operating points. ``density_topk`` has no
    score threshold to tune; its one fixed decode is copied into both objective
    records so the training loop can still select best-F1 and best-MAE epochs.
    """

    if count_mode not in {"peak_threshold", "density_topk"}:
        raise ValueError(f"unsupported count_mode: {count_mode!r}")
    if count_mode == "peak_threshold" and not thresholds:
        raise ValueError("at least one validation threshold is required")
    was_training = model.training
    model.eval()
    minimum_threshold = float(min(thresholds)) if thresholds else 0.0
    cached: list[
        tuple[np.ndarray, np.ndarray, np.ndarray, dict[str, int | float | bool]]
    ] = []
    for batch in loader:
        images = batch["images"].to(device, non_blocking=True)
        masks = batch["valid_image_masks"].to(device, non_blocking=True)
        outputs = model(images, masks)
        if count_mode == "peak_threshold":
            predictions = decode_points(
                outputs,
                score_threshold=minimum_threshold,
                topk=topk,
                local_max_kernel=local_max_kernel,
                output_stride=model.output_stride,
            )
        else:
            predictions = decode_points_by_mode(
                outputs,
                count_mode="density_topk",
                topk=topk,
                local_max_kernel=local_max_kernel,
                candidate_score_floor=candidate_score_floor,
                valid_mask=masks,
                output_stride=model.output_stride,
            )
        for prediction, target in zip(predictions, batch["targets"]):
            diagnostics = {
                name: prediction[name]
                for name in (
                    "density_count_raw",
                    "requested_k",
                    "candidate_count",
                    "candidate_shortfall",
                    "topk_saturation",
                )
                if name in prediction
            }
            cached.append(
                (
                    prediction["points"].detach().cpu().numpy(),
                    prediction["scores"].detach().cpu().numpy(),
                    target["points_xy"].detach().cpu().numpy(),
                    diagnostics,  # type: ignore[arg-type]
                )
            )

    if count_mode == "density_topk":
        predicted_counts: list[int] = []
        target_counts: list[int] = []
        density_count_raw: list[float] = []
        true_positive = false_positive = false_negative = 0
        candidate_shortfall_total = 0
        candidate_shortfall_images = 0
        topk_saturation_images = 0
        for points, _scores, target, diagnostics in cached:
            prediction_count = len(points)
            target_count = len(target)
            tp, fp, fn = maximum_cardinality_point_matches(
                points, target, matching_radius
            )
            predicted_counts.append(prediction_count)
            target_counts.append(target_count)
            true_positive += tp
            false_positive += fp
            false_negative += fn
            raw = float(diagnostics["density_count_raw"])
            shortfall = int(diagnostics["candidate_shortfall"])
            density_count_raw.append(raw)
            candidate_shortfall_total += shortfall
            candidate_shortfall_images += int(shortfall > 0)
            topk_saturation_images += int(bool(diagnostics["topk_saturation"]))

        count_metrics = aggregate_count_metrics(predicted_counts, target_counts)
        precision = true_positive / max(true_positive + false_positive, 1)
        recall = true_positive / max(true_positive + false_negative, 1)
        f1 = 2 * precision * recall / max(precision + recall, 1e-12)
        density_bias = float(
            np.mean(np.asarray(density_count_raw) - np.asarray(target_counts))
        )
        fixed_metrics: dict[str, object] = {
            "count_mode": "density_topk",
            **count_metrics,
            "precision_at_8": precision,
            "recall_at_8": recall,
            "f1_at_8": f1,
            "true_positive": true_positive,
            "false_positive": false_positive,
            "false_negative": false_negative,
            "samples": len(cached),
            "threshold": None,
            "threshold_source": "not_applicable_fixed_density_decoder",
            "candidate_score_floor": float(candidate_score_floor),
            "candidate_shortfall_total": candidate_shortfall_total,
            "candidate_shortfall_images": candidate_shortfall_images,
            "topk_saturation_images": topk_saturation_images,
            "density_count_raw_bias": density_bias,
        }
        if was_training:
            model.train()
        return {
            "f1": {
                **fixed_metrics,
                "threshold_objective": (
                    "fixed_density_decoder_maximum_f1_at_8_then_minimum_mae_across_epochs"
                ),
            },
            "mae": {
                **fixed_metrics,
                "threshold_objective": (
                    "fixed_density_decoder_minimum_mae_then_maximum_f1_at_8_across_epochs"
                ),
            },
        }

    match_tables = [
        (
            incremental_match_table(points, scores, target, thresholds, matching_radius),
            len(target),
        )
        for points, scores, target, _diagnostics in cached
    ]
    candidates: list[dict[str, object]] = []
    for threshold in thresholds:
        predicted_counts: list[int] = []
        target_counts: list[int] = []
        true_positive = false_positive = false_negative = 0
        for table, target_count in match_tables:
            tp, prediction_count = table[float(threshold)]
            fp = prediction_count - tp
            fn = target_count - tp
            predicted_counts.append(prediction_count)
            target_counts.append(target_count)
            true_positive += tp
            false_positive += fp
            false_negative += fn
        count_metrics = aggregate_count_metrics(predicted_counts, target_counts)
        precision = true_positive / max(true_positive + false_positive, 1)
        recall = true_positive / max(true_positive + false_negative, 1)
        f1 = 2 * precision * recall / max(precision + recall, 1e-12)
        candidate: dict[str, object] = {
            "threshold": float(threshold),
            **count_metrics,
            "precision_at_8": precision,
            "recall_at_8": recall,
            "f1_at_8": f1,
            "true_positive": true_positive,
            "false_positive": false_positive,
            "false_negative": false_negative,
            "samples": len(cached),
            "threshold_source": "validation_only",
        }
        candidates.append(candidate)
    if was_training:
        model.train()
    return select_validation_metrics(candidates)


def checkpoint_payload(
    model: GeoPrivNet,
    optimizer: torch.optim.Optimizer,
    scaler: torch.amp.GradScaler,
    *,
    epoch: int,
    args: argparse.Namespace,
    weights: GeoPrivLossWeights,
    training_losses: dict[str, float],
    selection: str,
    validation_metrics: dict[str, object],
    validation_epoch: int,
    validation_metrics_by_objective: dict[str, dict[str, object]] | None = None,
    selected_threshold_objective: str = "f1",
    manifest_sha256: dict[str, dict[str, str]] | None = None,
    source_sha256: dict[str, str] | None = None,
    rng_state: dict[str, object] | None = None,
    best_records: dict[str, dict[str, object] | None] | None = None,
) -> dict[str, object]:
    """Serialize enough state and provenance to reproduce an ablation run."""

    decoder_config = decoder_protocol_from_args(
        args,
        output_stride=model.output_stride,
        validation_metrics=validation_metrics,
        validation_epoch=validation_epoch,
        objective=selected_threshold_objective,
    )
    count_mode = str(decoder_config["count_mode"])
    payload: dict[str, object] = {
        "schema_version": 2,
        "model": model.state_dict(),
        "optimizer": optimizer.state_dict(),
        "scaler": scaler.state_dict(),
        "epoch": epoch,
        "config": vars(args).copy(),
        "model_config": {
            "fpn_channels": args.fpn_channels,
            "decoder_norm": args.decoder_norm,
            "freeze_backbone_bn": args.freeze_backbone_bn,
        },
        "output_stride": model.output_stride,
        "loss_weights": asdict(weights),
        "augmentation_config": augmentation_config_from_args(args),
        "density_target_config": density_target_config_from_args(args),
        "training_losses": dict(training_losses),
        "selection": selection,
        "validation_metrics": dict(validation_metrics),
        "validation_metrics_by_objective": deepcopy(
            validation_metrics_by_objective
            if validation_metrics_by_objective is not None
            else {selected_threshold_objective: validation_metrics}
        ),
        "selected_threshold_objective": selected_threshold_objective,
        "decoder_config": decoder_config,
        "decoder_selection": {
            "source": (
                "validation_only"
                if count_mode == "peak_threshold"
                else "training_config_fixed"
            ),
            "validation_epoch": validation_epoch,
            "frozen_for_checkpoint": True,
            "objective": selected_threshold_objective,
        },
        "manifest_sha256": deepcopy(manifest_sha256),
        "source_sha256": deepcopy(source_sha256),
        "rng_state": rng_state,
        "best_records": deepcopy(best_records),
    }
    if count_mode == "peak_threshold":
        selected_threshold = float(validation_metrics["threshold"])
        payload["selected_threshold"] = selected_threshold
        payload["threshold_selection"] = {
            "source": "validation_only",
            "validation_epoch": validation_epoch,
            "frozen_for_checkpoint": True,
            "objective": selected_threshold_objective,
        }
    return payload


def _mean_losses(totals: dict[str, float], batches: int) -> dict[str, float]:
    return {name: value / batches for name, value in totals.items()}


def main(argv: Sequence[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    validate_args(parser, args)
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise SystemExit("CUDA is unavailable")
    seed_everything(args.seed)
    if args.augmentation_seed is None:
        args.augmentation_seed = args.seed
    args.output.mkdir(parents=True, exist_ok=True)

    manifest_sha256 = {
        "train": {
            "path": str(args.train_manifest.resolve()),
            "sha256": file_sha256(args.train_manifest),
        },
        "validation": {
            "path": str(args.val_manifest.resolve()),
            "sha256": file_sha256(args.val_manifest),
        },
    }
    source_sha256 = source_sha256_manifest()

    augmentation_config = augmentation_config_from_args(args)

    train_dataset = PrivilegedManifestDataset(
        args.train_manifest,
        args.train_root,
        split=args.train_split,
        image_size=args.image_size,
        max_samples=args.max_train_samples,
        augmentation=bool(augmentation_config["enabled"]),
        augmentation_seed=int(augmentation_config["seed"]),
        horizontal_flip_probability=float(
            augmentation_config["horizontal_flip_probability"]
        ),
        color_jitter_probability=float(
            augmentation_config["color_jitter_probability"]
        ),
        brightness_jitter=float(augmentation_config["brightness_jitter"]),
        contrast_jitter=float(augmentation_config["contrast_jitter"]),
        saturation_jitter=float(augmentation_config["saturation_jitter"]),
    )
    val_dataset = PrivilegedManifestDataset(
        args.val_manifest,
        args.val_root,
        split=args.val_split,
        image_size=args.image_size,
        max_samples=args.max_val_samples,
        augmentation=False,
    )
    generator = torch.Generator().manual_seed(args.seed)
    loader_options = {
        "num_workers": args.num_workers,
        "collate_fn": collate_privileged_samples,
        "pin_memory": device.type == "cuda",
        # Workers are recreated for each epoch so that ``set_epoch`` below is
        # visible under Windows' spawn multiprocessing as well as fork.
        "persistent_workers": False,
    }
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        generator=generator,
        **loader_options,
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        **loader_options,
    )
    model = GeoPrivNet(
        fpn_channels=args.fpn_channels,
        pretrained=args.pretrained,
        decoder_norm=args.decoder_norm,
        freeze_backbone_bn=args.freeze_backbone_bn,
    ).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay
    )
    amp_enabled = device.type == "cuda" and not args.no_amp
    scaler = torch.amp.GradScaler(device.type, enabled=amp_enabled)
    weights = loss_weights_from_args(args)
    thresholds = threshold_grid(
        args.threshold_start, args.threshold_stop, args.threshold_step
    )

    start_epoch = 1
    best_f1_record: dict[str, object] | None = None
    best_mae_record: dict[str, object] | None = None
    latest_validation_by_objective: dict[str, dict[str, object]] | None = None
    latest_validation_epoch: int | None = None
    if args.resume is not None:
        checkpoint = torch.load(args.resume, map_location="cpu", weights_only=False)
        validate_resume_config(args, checkpoint.get("config"))
        stored_manifest_sha256 = checkpoint.get("manifest_sha256")
        if not isinstance(stored_manifest_sha256, dict):
            raise ValueError(
                "resume checkpoint has no manifest hashes; start a new formal run"
            )
        stored_hash_values = {
            role: item.get("sha256")
            for role, item in stored_manifest_sha256.items()
            if isinstance(item, dict)
        }
        current_hash_values = {
            role: item["sha256"] for role, item in manifest_sha256.items()
        }
        if stored_hash_values != current_hash_values:
            raise ValueError(
                "resume manifest hashes differ from the checkpoint provenance"
            )
        if checkpoint.get("source_sha256") != source_sha256:
            raise ValueError(
                "resume source hashes differ from the checkpoint provenance"
            )
        model.load_state_dict(checkpoint["model"])
        if "optimizer" in checkpoint:
            optimizer.load_state_dict(checkpoint["optimizer"])
        if "scaler" in checkpoint:
            scaler.load_state_dict(checkpoint["scaler"])
        start_epoch = int(checkpoint["epoch"]) + 1
        latest_validation_by_objective = checkpoint.get(
            "validation_metrics_by_objective"
        )
        decoder_selection = checkpoint.get("decoder_selection")
        if isinstance(decoder_selection, Mapping):
            latest_validation_epoch = decoder_selection.get("validation_epoch")  # type: ignore[assignment]
        else:
            threshold_selection = checkpoint.get("threshold_selection")
            if isinstance(threshold_selection, Mapping):
                latest_validation_epoch = threshold_selection.get(  # type: ignore[assignment]
                    "validation_epoch"
                )
        stored_best_records = checkpoint.get("best_records")
        if not isinstance(stored_best_records, dict):
            raise ValueError(
                "resume checkpoint has no historical best records; "
                "start a new formal run"
            )
        best_f1_record = deepcopy(stored_best_records.get("f1"))
        best_mae_record = deepcopy(stored_best_records.get("mae"))
        stored_rng_state = checkpoint.get("rng_state")
        if not isinstance(stored_rng_state, dict):
            raise ValueError(
                "resume checkpoint has no RNG state; start a new formal run"
            )
        restore_rng_state(stored_rng_state, generator)
        print(f"resumed training state from {args.resume.resolve()}", flush=True)
    if start_epoch > args.epochs:
        raise SystemExit(
            f"resume checkpoint is already at epoch {start_epoch - 1}, "
            f"but --epochs={args.epochs}"
        )

    history_path = args.output / "history.jsonl"
    history_mode = "a" if start_epoch > 1 and history_path.exists() else "w"
    started = time.monotonic()
    last_training_losses: dict[str, float] = {}
    with history_path.open(history_mode, encoding="utf-8") as history:
        for epoch in range(start_epoch, args.epochs + 1):
            train_dataset.set_epoch(epoch)
            model.train()
            totals = {
                "loss": 0.0,
                "center_loss": 0.0,
                "offset_loss": 0.0,
                "radius_loss": 0.0,
                "density_loss": 0.0,
                "count_conservation_loss": 0.0,
            }
            collisions = valid_points = 0
            for batch in train_loader:
                images = batch["images"].to(device, non_blocking=True)
                masks = batch["valid_image_masks"].to(device, non_blocking=True)
                # Dense targets are constructed on CPU.  The builder performs
                # per-instance scalar indexing; doing that work on CUDA would
                # introduce a synchronization for every berry.
                points = [target["points_xy"] for target in batch["targets"]]
                radii = [
                    None
                    if target["equivalent_radius"] is None
                    else target["equivalent_radius"]
                    for target in batch["targets"]
                ]
                completeness = [
                    None
                    if target["frame_boundary_completeness"] is None
                    else target["frame_boundary_completeness"]
                    for target in batch["targets"]
                ]
                geometry_available = [
                    target["geometry_available"] for target in batch["targets"]
                ]
                optimizer.zero_grad(set_to_none=True)
                context = (
                    torch.amp.autocast(device_type=device.type, dtype=torch.float16)
                    if amp_enabled
                    else nullcontext()
                )
                with context:
                    outputs = model(images, masks)
                    cpu_targets = build_geopriv_targets(
                        points,
                        equivalent_radius=radii,
                        frame_boundary_completeness=completeness,
                        geometry_available=geometry_available,
                        valid_image_mask=batch["valid_image_masks"],
                        output_height=outputs["center_logits"].shape[-2],
                        output_width=outputs["center_logits"].shape[-1],
                        stride=model.output_stride,
                        gaussian_radius=args.gaussian_radius,
                        density_sigma=args.density_sigma,
                        density_sigma_mode=args.density_sigma_mode,
                        density_radius_divisor=args.density_radius_divisor,
                        density_sigma_min=args.density_sigma_min,
                        density_sigma_max=args.density_sigma_max,
                        device="cpu",
                    )
                    targets = {
                        name: value.to(device, non_blocking=True)
                        for name, value in cpu_targets.items()
                    }
                    losses = geopriv_loss(
                        outputs,
                        targets,
                        weights=weights,
                        count_conservation_mode=args.count_conservation_mode,
                    )
                if not torch.isfinite(losses["loss"]):
                    raise FloatingPointError(
                        f"non-finite GeoPriv loss at epoch {epoch}: "
                        + ", ".join(
                            f"{name}={float(value.detach())}"
                            for name, value in losses.items()
                        )
                    )
                scaler.scale(losses["loss"]).backward()
                scaler.unscale_(optimizer)
                if args.gradient_clip > 0:
                    torch.nn.utils.clip_grad_norm_(model.parameters(), args.gradient_clip)
                scaler.step(optimizer)
                scaler.update()
                for name in totals:
                    totals[name] += float(losses[name].detach())
                collisions += int(cpu_targets["collision_count"])
                valid_points += int(cpu_targets["valid_point_count"])

            last_training_losses = _mean_losses(totals, len(train_loader))
            row: dict[str, Any] = {
                "epoch": epoch,
                **last_training_losses,
                "collision_rate": collisions / max(valid_points, 1),
                "elapsed_seconds": time.monotonic() - started,
            }
            should_validate = (
                epoch == start_epoch
                or epoch % args.eval_every == 0
                or epoch == args.epochs
            )
            if should_validate:
                latest_validation_by_objective = evaluate_validation(
                    model,
                    val_loader,
                    device,
                    thresholds,
                    count_mode=args.count_mode,
                    matching_radius=args.match_radius,
                    local_max_kernel=args.local_max_kernel,
                    topk=args.topk,
                    candidate_score_floor=args.candidate_score_floor,
                )
                latest_validation_epoch = epoch
                current_f1_metrics = latest_validation_by_objective["f1"]
                current_mae_metrics = latest_validation_by_objective["mae"]
                # Keep the historical field as the default F1 objective while
                # recording both independently selected epoch objectives.
                row["validation_metrics"] = current_f1_metrics
                row["validation_metrics_by_objective"] = (
                    latest_validation_by_objective
                )

                improved_f1 = best_f1_record is None or validation_metric_key(
                    current_f1_metrics, "f1"
                ) < validation_metric_key(best_f1_record["metrics"], "f1")  # type: ignore[arg-type]
                improved_mae = best_mae_record is None or validation_metric_key(
                    current_mae_metrics, "mae"
                ) < validation_metric_key(best_mae_record["metrics"], "mae")  # type: ignore[arg-type]
                if improved_f1:
                    best_f1_record = {
                        "epoch": epoch,
                        "metrics": dict(current_f1_metrics),
                    }
                if improved_mae:
                    best_mae_record = {
                        "epoch": epoch,
                        "metrics": dict(current_mae_metrics),
                    }
                best_records = {
                    "f1": best_f1_record,
                    "mae": best_mae_record,
                }
                rng_state = capture_rng_state(generator)

                if improved_f1:
                    atomic_torch_save(
                        checkpoint_payload(
                            model,
                            optimizer,
                            scaler,
                            epoch=epoch,
                            args=args,
                            weights=weights,
                            training_losses=last_training_losses,
                            selection="maximum_validation_f1_at_8_then_minimum_validation_mae",
                            validation_metrics=current_f1_metrics,
                            validation_epoch=epoch,
                            validation_metrics_by_objective=(
                                latest_validation_by_objective
                            ),
                            selected_threshold_objective="f1",
                            manifest_sha256=manifest_sha256,
                            source_sha256=source_sha256,
                            rng_state=rng_state,
                            best_records=best_records,
                        ),
                        args.output / "best_val_f1.pt",
                    )
                if improved_mae:
                    atomic_torch_save(
                        checkpoint_payload(
                            model,
                            optimizer,
                            scaler,
                            epoch=epoch,
                            args=args,
                            weights=weights,
                            training_losses=last_training_losses,
                            selection="minimum_validation_mae_then_maximum_validation_f1_at_8",
                            validation_metrics=current_mae_metrics,
                            validation_epoch=epoch,
                            validation_metrics_by_objective=(
                                latest_validation_by_objective
                            ),
                            selected_threshold_objective="mae",
                            manifest_sha256=manifest_sha256,
                            source_sha256=source_sha256,
                            rng_state=rng_state,
                            best_records=best_records,
                        ),
                        args.output / "best_val_mae.pt",
                    )

            assert (
                latest_validation_by_objective is not None
                and latest_validation_epoch is not None
            )
            best_records = {"f1": best_f1_record, "mae": best_mae_record}
            atomic_torch_save(
                checkpoint_payload(
                    model,
                    optimizer,
                    scaler,
                    epoch=epoch,
                    args=args,
                    weights=weights,
                    training_losses=last_training_losses,
                    selection="last_epoch_with_latest_validation_decoder",
                    validation_metrics=latest_validation_by_objective["f1"],
                    validation_epoch=latest_validation_epoch,
                    validation_metrics_by_objective=latest_validation_by_objective,
                    selected_threshold_objective="f1",
                    manifest_sha256=manifest_sha256,
                    source_sha256=source_sha256,
                    rng_state=capture_rng_state(generator),
                    best_records=best_records,
                ),
                args.output / "last.pt",
            )
            history.write(json.dumps(row, default=str, ensure_ascii=False) + "\n")
            history.flush()
            atomic_json_write(
                {
                    "schema_version": 1,
                    "status": "training",
                    "last_completed_epoch": epoch,
                    "requested_epochs": args.epochs,
                    "latest_validation_epoch": latest_validation_epoch,
                    "best_val_f1": best_f1_record,
                    "best_val_mae": best_mae_record,
                    "last_checkpoint": str(args.output / "last.pt"),
                    "best_val_f1_checkpoint": str(args.output / "best_val_f1.pt"),
                    "best_val_mae_checkpoint": str(args.output / "best_val_mae.pt"),
                    "history": str(history_path),
                },
                args.output / "progress.json",
            )
            print(json.dumps(row, ensure_ascii=False), flush=True)

    assert (
        latest_validation_by_objective is not None
        and latest_validation_epoch is not None
    )
    summary = {
        "epochs": args.epochs,
        "train_samples": len(train_dataset),
        "validation_samples": len(val_dataset),
        "parameters": sum(parameter.numel() for parameter in model.parameters()),
        "model_config": {
            "fpn_channels": args.fpn_channels,
            "decoder_norm": args.decoder_norm,
            "freeze_backbone_bn": args.freeze_backbone_bn,
        },
        "loss_weights": asdict(weights),
        "augmentation_config": augmentation_config,
        "density_target_config": density_target_config_from_args(args),
        "manifest_sha256": manifest_sha256,
        "source_sha256": source_sha256,
        "decoder_protocol": decoder_protocol_from_args(
            args,
            output_stride=model.output_stride,
            validation_metrics=latest_validation_by_objective["f1"],
            validation_epoch=latest_validation_epoch,
            objective="f1",
        ),
        "threshold_search": (
            {
                "active": True,
                "source": "validation_only",
                "start": args.threshold_start,
                "stop": args.threshold_stop,
                "step": args.threshold_step,
                "default_inference_objective": "f1",
                "objectives": {
                    "f1": "maximum_f1_at_8_then_minimum_mae",
                    "mae": "minimum_mae_then_maximum_f1_at_8",
                },
            }
            if args.count_mode == "peak_threshold"
            else {
                "active": False,
                "source": "not_applicable_fixed_density_decoder",
            }
        ),
        "latest_validation": {
            "epoch": latest_validation_epoch,
            "default_objective": "f1",
            "metrics": latest_validation_by_objective["f1"],
        },
        "latest_validation_by_objective": {
            "epoch": latest_validation_epoch,
            "metrics": latest_validation_by_objective,
        },
        "checkpoints": {
            "last": {"path": "last.pt", "epoch": args.epochs},
            "best_val_f1": {"path": "best_val_f1.pt", **(best_f1_record or {})},
            "best_val_mae": {"path": "best_val_mae.pt", **(best_mae_record or {})},
        },
        "peak_cuda_memory_mib": (
            round(torch.cuda.max_memory_allocated() / 2**20, 2)
            if device.type == "cuda"
            else 0
        ),
        "elapsed_seconds": time.monotonic() - started,
    }
    atomic_json_write(summary, args.output / "summary.json")
    atomic_json_write(
        {
            "schema_version": 1,
            "status": "complete",
            "last_completed_epoch": args.epochs,
            "requested_epochs": args.epochs,
            "latest_validation_epoch": latest_validation_epoch,
            "best_val_f1": best_f1_record,
            "best_val_mae": best_mae_record,
            "last_checkpoint": str(args.output / "last.pt"),
            "best_val_f1_checkpoint": str(args.output / "best_val_f1.pt"),
            "best_val_mae_checkpoint": str(args.output / "best_val_mae.pt"),
            "history": str(history_path),
            "summary": str(args.output / "summary.json"),
        },
        args.output / "progress.json",
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
