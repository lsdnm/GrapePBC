"""Five-fold OOF anchor-aware heatmap refiner for precise berry centres."""
from __future__ import annotations

import json
from pathlib import Path
import random
import sys
import time

import numpy as np
from sklearn.model_selection import GroupKFold
import torch
from torch import nn
from torch.nn import functional as F


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

from geopriv.data.hash_utils import file_sha256  # noqa: E402
from run_vivid_hr_core_calibration import atomic_json, atomic_npz  # noqa: E402
import train_rgb_point_center_refiner as base  # noqa: E402
import train_rgb_center_refiner_development_oof_v4 as v4  # noqa: E402
import calibrate_oof_geometry_gate_v4 as geometry  # noqa: E402


EXP = PROJECT / "experiments" / "cru_detail_v1"
OUT = EXP / "vivid_anchor_heatmap_center_refiner_oof_v5"
SEED = 20261023
FOLDS = 5
EPOCHS = 4
GRID = 32
HALF = 40.0
MAX_SHIFT = 24.0
VERSION = "vivid-anchor-heatmap-center-refiner-oof-v5"


class ResidualBlock(nn.Module):
    def __init__(self, channels: int, dilation: int = 1) -> None:
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=dilation, dilation=dilation, bias=False),
            nn.GroupNorm(8, channels), nn.SiLU(),
            nn.Conv2d(channels, channels, 3, padding=1, bias=False),
            nn.GroupNorm(8, channels),
        )

    def forward(self, value: torch.Tensor) -> torch.Tensor:
        return F.silu(value + self.body(value))


class AnchorHeatmapRefiner(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv2d(6, 32, 3, padding=1, bias=False), nn.GroupNorm(8, 32), nn.SiLU(),
            nn.Conv2d(32, 64, 3, stride=2, padding=1, bias=False), nn.GroupNorm(8, 64), nn.SiLU(),
        )
        self.blocks = nn.Sequential(ResidualBlock(64, 1), ResidualBlock(64, 2), ResidualBlock(64, 1))
        self.heatmap = nn.Conv2d(64, 1, 1)
        self.confidence = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(64, 1))

    def coordinates(self, rgb: torch.Tensor) -> torch.Tensor:
        axis = torch.linspace(-1.0, 1.0, rgb.shape[-1], device=rgb.device, dtype=rgb.dtype)
        yy, xx = torch.meshgrid(axis, axis, indexing="ij")
        radial = torch.exp(-(xx.square() + yy.square()) / (2.0 * 0.12 ** 2))
        extra = torch.stack((xx, yy, radial), dim=0)[None].expand(len(rgb), -1, -1, -1)
        return torch.cat((rgb, extra), dim=1)

    def forward(self, rgb: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        feature = self.blocks(self.stem(self.coordinates(rgb)))
        return self.heatmap(feature)[:, 0], self.confidence(feature)[:, 0]


def target_distribution(offset: torch.Tensor) -> torch.Tensor:
    axis = torch.linspace(-HALF, HALF, GRID, device=offset.device, dtype=offset.dtype)
    yy, xx = torch.meshgrid(axis, axis, indexing="ij")
    distance2 = ((xx[None] - offset[:, 0, None, None]).square()
                 + (yy[None] - offset[:, 1, None, None]).square())
    value = torch.exp(-distance2 / (2.0 * 1.15 ** 2))
    return value / value.sum(dim=(1, 2), keepdim=True).clamp_min(1e-8)


def heatmap_offset(logits: torch.Tensor) -> torch.Tensor:
    """Sub-grid centre from a 3x3 soft neighbourhood around the peak."""
    batch = len(logits)
    flat_index = logits.flatten(1).argmax(dim=1)
    peak_y = flat_index // GRID
    peak_x = flat_index % GRID
    axis = torch.linspace(-HALF, HALF, GRID, device=logits.device, dtype=logits.dtype)
    outputs = []
    for index in range(batch):
        x0 = max(int(peak_x[index]) - 1, 0); x1 = min(int(peak_x[index]) + 2, GRID)
        y0 = max(int(peak_y[index]) - 1, 0); y1 = min(int(peak_y[index]) + 2, GRID)
        local = logits[index, y0:y1, x0:x1].flatten()
        weight = torch.softmax(local / 0.35, dim=0)
        yy, xx = torch.meshgrid(axis[y0:y1], axis[x0:x1], indexing="ij")
        outputs.append(torch.stack(((weight * xx.flatten()).sum(),
                                    (weight * yy.flatten()).sum())))
    return torch.stack(outputs)


def epoch_pass(model: nn.Module, records: list[dict], optimizer, device: torch.device,
               *, epoch: int) -> dict:
    model.train()
    rng = np.random.default_rng(SEED + epoch)
    order = rng.permutation(len(records))
    totals = {"loss": 0.0, "heatmap": 0.0, "coordinate": 0.0,
              "confidence": 0.0, "samples": 0, "positive": 0, "closer": 0}
    for position, record_index in enumerate(order):
        record = records[int(record_index)]
        image, truth = base.record_payload(record)
        anchors, offsets, point_spacing, valid = v4.current_point_anchors(
            record, truth, epoch=epoch, validation=False)
        if not len(anchors):
            continue
        scale = 1024.0 / max(int(record["width"]), int(record["height"]))
        for start in range(0, len(anchors), 128):
            end = min(start + 128, len(anchors))
            patch = base.sample_patches(image, anchors[start:end], scale, device)
            target_offset = torch.from_numpy(offsets[start:end]).to(device)
            target_valid = torch.from_numpy(valid[start:end]).to(device)
            if rng.random() < 0.5:
                patch = torch.flip(patch, dims=(3,)); target_offset[:, 0] *= -1.0
            if rng.random() < 0.5:
                patch = torch.flip(patch, dims=(2,)); target_offset[:, 1] *= -1.0
            patch = patch * float(rng.uniform(0.90, 1.10)) + float(rng.uniform(-0.08, 0.08))
            logits, confidence = model(patch)
            positive = target_valid > 0.5
            if positive.any():
                distribution = target_distribution(target_offset[positive])
                log_probability = torch.log_softmax(logits[positive].flatten(1), dim=1).reshape(-1, GRID, GRID)
                heatmap_loss = -(distribution * log_probability).sum(dim=(1, 2)).mean()
                predicted_offset = heatmap_offset(logits[positive])
                coordinate_loss = F.smooth_l1_loss(predicted_offset / 8.0,
                                                    target_offset[positive] / 8.0)
            else:
                heatmap_loss = logits.sum() * 0.0
                coordinate_loss = logits.sum() * 0.0
            confidence_loss = F.binary_cross_entropy_with_logits(confidence, target_valid)
            loss = heatmap_loss + 0.35 * coordinate_loss + 0.20 * confidence_loss
            optimizer.zero_grad(set_to_none=True); loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0); optimizer.step()
            count = end - start
            totals["loss"] += float(loss) * count
            totals["heatmap"] += float(heatmap_loss) * count
            totals["coordinate"] += float(coordinate_loss) * count
            totals["confidence"] += float(confidence_loss) * count
            totals["samples"] += count
            if positive.any():
                before = torch.linalg.norm(target_offset[positive], dim=1)
                after = torch.linalg.norm(target_offset[positive] - predicted_offset, dim=1)
                totals["closer"] += int((after < before).sum())
                totals["positive"] += int(positive.sum())
        if (position + 1) % 100 == 0:
            print(f"heatmap e{epoch} {position + 1}/{len(order)}", flush=True)
    samples = max(int(totals["samples"]), 1)
    return {name: totals[name] / samples for name in ("loss", "heatmap", "coordinate", "confidence")} | {
        "samples": int(totals["samples"]), "positive": int(totals["positive"]),
        "positive_closer_fraction": totals["closer"] / max(int(totals["positive"]), 1)}


def save_checkpoint(path: Path, payload: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temporary); temporary.replace(path)


def fit(model: nn.Module, records: list[dict], device: torch.device,
        folder: Path, *, fold: int) -> list[dict]:
    folder.mkdir(parents=True, exist_ok=True)
    optimizer = torch.optim.AdamW(model.parameters(), lr=3.0e-4, weight_decay=1.0e-4)
    history = []
    for local_epoch in range(1, EPOCHS + 1):
        started = time.monotonic()
        metrics = epoch_pass(model, records, optimizer, device,
                             epoch=fold * 100 + local_epoch)
        row = {"fold": fold, "epoch": local_epoch, "training": metrics,
               "elapsed_seconds": time.monotonic() - started}
        history.append(row)
        with (folder / "history.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")
        save_checkpoint(folder / "last.pt", {"fold": fold, "epoch": local_epoch,
                                              "model": model.state_dict(),
                                              "optimizer": optimizer.state_dict(),
                                              "row": row})
        atomic_json(folder / "progress.json", {"status": "TRAINING" if local_epoch < EPOCHS else "COMPLETE",
                                                "fold": fold, "last_epoch": local_epoch,
                                                "router_b_used": False, "sealed_test_used": False})
        print(json.dumps(row, ensure_ascii=False), flush=True)
    return history


@torch.inference_mode()
def infer(model: nn.Module, records: list[dict], device: torch.device,
          folder: Path) -> list[dict]:
    model.eval(); result = []
    for record in records:
        points, truth, reliability = v4.baseline_payload(record)
        image_size = (int(record["width"]), int(record["height"]))
        scale = 1024.0 / max(image_size)
        point_spacing = base.spacing(points, scale)
        offsets, confidences = [], []
        if len(points):
            image = base.load_rgb(base.ROOT / record["image_path"])
            for start in range(0, len(points), 128):
                patch = base.sample_patches(image, points[start:start + 128], scale, device)
                logits, confidence = model(patch)
                offsets.append(heatmap_offset(logits).cpu().numpy())
                confidences.append(torch.sigmoid(confidence).cpu().numpy())
            offset = np.concatenate(offsets).astype(np.float32)
            confidence = np.concatenate(confidences).astype(np.float32)
        else:
            offset = np.empty((0, 2), np.float32); confidence = np.empty(0, np.float32)
        filename = record["sample_id"].replace(":", "_") + ".npz"
        atomic_npz(folder / filename, offset=offset, confidence=confidence)
        result.append({"sample_id": record["sample_id"], "image_size": image_size,
                       "scale": scale, "points": points, "truth": truth,
                       "reliability": reliability, "point_spacing": point_spacing,
                       "offset": offset, "confidence": confidence})
    return result


def calibrate(cached: list[dict]) -> tuple[dict, list[dict]]:
    configs = []
    for alpha in (0.50, 0.75, 1.00):
        for confidence in (0.30, 0.50, 0.65, 0.80):
            for spacing_minimum in (8.0, 12.0, 16.0, 20.0, 24.0, 28.0, 32.0):
                for fraction in (0.10, 0.20, 0.30):
                    for limit in (4.0, 8.0, 12.0):
                        predictions = [geometry.apply(
                            item, alpha=alpha, confidence_threshold=confidence,
                            minimum_spacing=spacing_minimum, fraction=fraction,
                            absolute_limit=limit) for item in cached]
                        report = base.evaluate(cached, predictions)
                        configs.append({"alpha": alpha, "confidence_threshold": confidence,
                                        "minimum_spacing": spacing_minimum,
                                        "spacing_fraction": fraction, "absolute_limit": limit,
                                        "eligible": geometry.strict(report), **report})
    eligible = [row for row in configs if row["eligible"]]
    selected = max(eligible or configs, key=lambda row: (
        row["image_gains"]["4"]["net_tp"], row["image_gains"]["8"]["net_tp"],
        row["image_gains"]["16"]["net_tp"], -row["image_gains"]["4"]["worsened"]))
    return selected, configs


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    base.HALF_NORM = HALF; base.MAX_SHIFT = MAX_SHIFT
    torch.manual_seed(SEED); np.random.seed(SEED); random.seed(SEED)
    records = base.rows(base.DEV_MANIFEST)
    groups = np.asarray([row.get("capture_group_id") or row["sample_id"] for row in records])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    protocol = {"version": VERSION, "seed": SEED, "folds": FOLDS,
                "epochs_per_fold": EPOCHS, "patch": base.PATCH, "heatmap_grid": GRID,
                "half_window_normalized_px": HALF, "max_shift_normalized_px": MAX_SHIFT,
                "count_conserving": True, "development_selected": True,
                "independent_confirmation": False, "router_b_used": False,
                "sealed_test_used": False, "source_sha256": file_sha256(Path(__file__))}
    atomic_json(OUT / "protocol.json", protocol)
    oof_cache = OUT / "oof_inference_cache"; oof_cache.mkdir(exist_ok=True)
    cached = []; fold_rows = []
    splitter = GroupKFold(FOLDS)
    for fold, (fit_index, held_index) in enumerate(splitter.split(np.arange(len(records)), groups=groups)):
        fit_records = [records[int(index)] for index in fit_index]
        held_records = [records[int(index)] for index in held_index]
        model = AnchorHeatmapRefiner().to(device)
        history = fit(model, fit_records, device, OUT / f"fold_{fold}", fold=fold)
        cached.extend(infer(model, held_records, device, oof_cache))
        fold_rows.append({"fold": fold, "train_images": len(fit_records),
                          "held_images": len(held_records), "history": history})
        print(f"heatmap fold {fold} complete", flush=True)
    by_id = {item["sample_id"]: item for item in cached}
    cached = [by_id[record["sample_id"]] for record in records]
    selected, configs = calibrate(cached)
    predictions = [geometry.apply(
        item, alpha=float(selected["alpha"]),
        confidence_threshold=float(selected["confidence_threshold"]),
        minimum_spacing=float(selected["minimum_spacing"]),
        fraction=float(selected["spacing_fraction"]),
        absolute_limit=float(selected["absolute_limit"])) for item in cached]
    point_out = OUT / "oof_development_points"; point_out.mkdir(exist_ok=True)
    for item, points in zip(cached, predictions, strict=True):
        atomic_npz(point_out / (item["sample_id"].replace(":", "_") + ".npz"),
                   cru=points, truth=item["truth"], reliability=item["reliability"])
    deploy_model = AnchorHeatmapRefiner().to(device)
    deploy_history = fit(deploy_model, records, device, OUT / "deploy_refit", fold=FOLDS)
    deploy_checkpoint = torch.load(OUT / "deploy_refit" / "last.pt", map_location="cpu", weights_only=False)
    deploy_checkpoint["protocol"] = protocol
    save_checkpoint(OUT / "deploy_model.pt", deploy_checkpoint)
    eligible_count = sum(bool(row["eligible"]) for row in configs)
    summary = {"status": "COMPLETE_OPEN_DEVELOPMENT_GROUP_OOF",
               "selected": selected, "eligible_configs": eligible_count,
               "configs_evaluated": len(configs), "folds": fold_rows,
               "deploy_history": deploy_history,
               "model_parameters": sum(parameter.numel() for parameter in deploy_model.parameters()),
               "oof_point_files": len(predictions),
               "deploy_model_sha256": file_sha256(OUT / "deploy_model.pt"),
               "independent_confirmation": False, "router_b_used": False,
               "sealed_test_used": False}
    atomic_json(OUT / "summary.json", summary)
    atomic_json(OUT / "all_configs.json", configs)
    atomic_json(OUT / "progress.json", {"status": "COMPLETE", "selected": selected,
                                         "router_b_used": False, "sealed_test_used": False})
    print(json.dumps({key: summary[key] for key in (
        "status", "selected", "eligible_configs", "configs_evaluated",
        "model_parameters", "oof_point_files", "deploy_model_sha256")},
        ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
