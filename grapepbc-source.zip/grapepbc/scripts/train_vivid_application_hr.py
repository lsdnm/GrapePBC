"""Train the clean ViViD high-resolution expert without opening Router-B/test.

The run is deliberately isolated from the historical HR trials.  It starts
from generic non-grape weights, learns only from clean Expert-A crops, chooses
its checkpoint/decoder only on clean development validation, and publishes an
atomic complete-epoch recovery state.
"""

from __future__ import annotations

import argparse
from contextlib import nullcontext
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import random
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

from geopriv.data import collate_cru_crops
from geopriv.data.hash_utils import file_sha256
from geopriv.data.manifest import read_manifest
from geopriv.models import GeoPrivNet, RichDetailExpert
from geopriv.training import GeoPrivLossWeights, build_geopriv_targets, geopriv_loss
from hr_repair_data import ImageBalancedTileSampler
from train_cru_local_expert import evaluate_local_expert
from train_geopriv import threshold_grid
from vivid_detail_runtime import (
    atomic_checkpoint,
    publish_epoch,
    repair_epoch,
    restore_rng,
    rng_state,
    safe_load,
)
from vivid_hr_application_data import ApplicationHRCropDataset


WEIGHTS = GeoPrivLossWeights(
    center=1.0,
    offset=1.0,
    radius=0.0,
    density=0.0,
    count_conservation=0.0,
)


def atomic_json(path: Path, payload: object) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, default=str) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def seed_all(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def source_hashes() -> dict[str, str]:
    relative_paths = (
        "scripts/train_vivid_application_hr.py",
        "scripts/vivid_hr_application_data.py",
        "scripts/hr_repair_data.py",
        "scripts/train_cru_local_expert.py",
        "scripts/vivid_detail_runtime.py",
        "src/geopriv/models/rich_detail_expert.py",
        "src/geopriv/models/litepoint.py",
        "src/geopriv/data/cru_crop_dataset.py",
        "src/geopriv/training/geopriv_targets.py",
        "src/geopriv/training/losses.py",
    )
    return {name: file_sha256(PROJECT / name) for name in relative_paths}


def prepare(args: argparse.Namespace) -> None:
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"non-empty output already exists: {output}")
    output.mkdir(parents=True, exist_ok=True)
    train_manifest = args.train_manifest.resolve()
    val_manifest = args.val_manifest.resolve()
    root = args.root.resolve()
    initial = args.initial_checkpoint.resolve()
    backbone = args.deep_backbone_checkpoint.resolve()

    train_records = read_manifest(train_manifest)
    val_records = read_manifest(val_manifest)
    if not train_records or not val_records:
        raise ValueError("empty training or validation manifest")
    if any(record.split != "train" or record.external_test for record in train_records):
        raise ValueError("training manifest contains a non-train/test record")
    if any(record.split != "val" or record.external_test for record in val_records):
        raise ValueError("validation manifest contains a non-val/test record")
    train_ids = {record.sample_id for record in train_records}
    val_ids = {record.sample_id for record in val_records}
    if train_ids & val_ids:
        raise ValueError("training and validation sample IDs overlap")
    train_groups = {record.capture_group_id for record in train_records}
    val_groups = {record.capture_group_id for record in val_records}
    shared_groups = (train_groups & val_groups) - {None}
    if shared_groups:
        raise ValueError(f"capture groups overlap: {sorted(shared_groups)[:5]}")

    generic = safe_load(initial)
    if int(generic.get("grape_training_images_seen", -1)) != 0:
        raise ValueError("initial checkpoint is not certified as zero-grape generic")
    base = GeoPrivNet(decoder_norm="group", freeze_backbone_bn=True)
    base.load_state_dict(generic["model"], strict=True)

    protocol: dict[str, object] = {
        "version": "vivid-application-rich-hr-v1",
        "status": "PREPARED",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "root": str(root),
        "train_manifest": str(train_manifest),
        "val_manifest": str(val_manifest),
        "initial_checkpoint": str(initial),
        "deep_backbone_checkpoint": str(backbone),
        "train_manifest_sha256": file_sha256(train_manifest),
        "val_manifest_sha256": file_sha256(val_manifest),
        "initial_checkpoint_sha256": file_sha256(initial),
        "deep_backbone_checkpoint_sha256": file_sha256(backbone),
        "source_sha256": source_hashes(),
        "seed": 20261001,
        "train_images": len(train_records),
        "validation_images": len(val_records),
        "input_size": 768,
        "core_size": 1024,
        "halo": 128,
        "epochs": 40,
        "batch_size": 2,
        "num_workers": 2,
        "learning_rate": 0.0001,
        "weight_decay": 0.0001,
        "gradient_clip": 5.0,
        "amp_enabled": False,
        "thresholds": threshold_grid(0.05, 0.95, 0.02),
        "match_radius": 8.0,
        "local_max_kernel": 3,
        "topk": 4096,
        "horizontal_flip_probability": 0.5,
        "color_jitter_probability": 0.8,
        "brightness_jitter": 0.25,
        "contrast_jitter": 0.25,
        "saturation_jitter": 0.20,
        "sampling": "one tile per Expert-A image then source/image-balanced random tiles to exhaustive epoch length",
        "loss_weights": WEIGHTS.__dict__,
        "selection": "minimum whole-source-image development MAE; F1 secondary",
        "initialization": "generic non-grape GeoPrivNet plus public ImageNet MobileNetV3-Small deep stages",
        "architecture": "GeoPrivNet FPN64 plus dilation-1/2 local detail and stride-32 semantic residuals",
        "router_B_used": False,
        "sealed_test_used": False,
    }
    atomic_json(output / "protocol.json", protocol)
    atomic_json(
        output / "stage.json",
        {
            "status": "PREPARED",
            "router_B_used": False,
            "sealed_test_used": False,
        },
    )
    print(json.dumps(protocol, ensure_ascii=False), flush=True)


def verify(output: Path) -> dict[str, object]:
    protocol = json.loads((output / "protocol.json").read_text(encoding="utf-8"))
    for name, expected in protocol["source_sha256"].items():
        if file_sha256(PROJECT / name) != expected:
            raise ValueError(f"source drift: {name}")
    for key in (
        "train_manifest",
        "val_manifest",
        "initial_checkpoint",
        "deep_backbone_checkpoint",
    ):
        if file_sha256(Path(protocol[key])) != protocol[f"{key}_sha256"]:
            raise ValueError(f"artifact drift: {key}")
    if protocol["router_B_used"] or protocol["sealed_test_used"]:
        raise ValueError("sealed roles are forbidden")
    return protocol


def make_model(protocol: dict[str, object]) -> RichDetailExpert:
    seed_all(int(protocol["seed"]))
    model = RichDetailExpert(
        decoder_norm="group",
        freeze_backbone_bn=True,
        deep_backbone_checkpoint=str(protocol["deep_backbone_checkpoint"]),
    )
    model.load_base_state(safe_load(protocol["initial_checkpoint"])["model"])
    return model.cuda()


def make_loaders(protocol: dict[str, object]):
    train = ApplicationHRCropDataset(protocol, augment=True)
    val = ApplicationHRCropDataset(protocol, augment=False)
    sampler = ImageBalancedTileSampler(train.base, int(protocol["seed"]))
    common = {
        "collate_fn": collate_cru_crops,
        "pin_memory": True,
        "num_workers": int(protocol["num_workers"]),
        "persistent_workers": False,
    }
    train_loader = DataLoader(
        train,
        batch_size=int(protocol["batch_size"]),
        sampler=sampler,
        **common,
    )
    val_loader = DataLoader(val, batch_size=1, shuffle=False, **common)
    if len(train.records) != int(protocol["train_images"]):
        raise ValueError("training membership changed")
    if len(val.records) != int(protocol["validation_images"]):
        raise ValueError("validation membership changed")
    return train, val, train_loader, val_loader, sampler


def optimizer_for(model: torch.nn.Module, protocol: dict[str, object]):
    return torch.optim.AdamW(
        model.parameters(),
        lr=float(protocol["learning_rate"]),
        weight_decay=float(protocol["weight_decay"]),
    )


def training_step(
    model: RichDetailExpert,
    optimizer: torch.optim.Optimizer,
    scaler: torch.amp.GradScaler,
    batch: dict[str, object],
    protocol: dict[str, object],
) -> dict[str, float]:
    model.train()
    optimizer.zero_grad(set_to_none=True)
    images = batch["images"].cuda(non_blocking=True)
    masks = batch["valid_image_masks"].cuda(non_blocking=True)
    amp_enabled = bool(protocol["amp_enabled"])
    context = (
        torch.amp.autocast("cuda", dtype=torch.float16)
        if amp_enabled
        else nullcontext()
    )
    with context:
        outputs = model(images, masks)
        cpu_targets = build_geopriv_targets(
            [target["points_xy"] for target in batch["targets"]],
            output_height=outputs["center_logits"].shape[-2],
            output_width=outputs["center_logits"].shape[-1],
            stride=model.output_stride,
            gaussian_radius=1,
            density_sigma=1.0,
            equivalent_radius=[None] * len(batch["targets"]),
            frame_boundary_completeness=[None] * len(batch["targets"]),
            geometry_available=[False] * len(batch["targets"]),
            valid_image_mask=batch["valid_image_masks"],
            device="cpu",
        )
        targets = {key: value.cuda(non_blocking=True) for key, value in cpu_targets.items()}
        losses = geopriv_loss(outputs, targets, weights=WEIGHTS)
    if not torch.isfinite(losses["loss"]):
        raise FloatingPointError("non-finite HR training loss")
    scaler.scale(losses["loss"]).backward()
    scaler.unscale_(optimizer)
    grad_norm = torch.nn.utils.clip_grad_norm_(
        model.parameters(), float(protocol["gradient_clip"]), error_if_nonfinite=True
    )
    scaler.step(optimizer)
    scaler.update()
    result = {key: float(value.detach()) for key, value in losses.items()}
    result["gradient_norm"] = float(grad_norm)
    return result


def smoke(output: Path, protocol: dict[str, object]) -> None:
    _, _, train_loader, _, _ = make_loaders(protocol)
    batch = next(iter(train_loader))
    base = GeoPrivNet(decoder_norm="group", freeze_backbone_bn=True).cuda().eval()
    base.load_state_dict(safe_load(protocol["initial_checkpoint"])["model"], strict=True)
    rich = make_model(protocol).eval()
    with torch.inference_mode():
        images = batch["images"][:1].cuda()
        masks = batch["valid_image_masks"][:1].cuda()
        expected = base(images, masks)
        actual = rich(images, masks)
        parity = max(
            float((expected[key] - actual[key]).abs().max())
            for key in ("center_logits", "offsets", "log_radius", "density_logits")
        )
    if parity != 0.0:
        raise ValueError(f"zero-residual parity failed: {parity}")
    del base, expected, actual, images, masks
    torch.cuda.empty_cache()

    optimizer = optimizer_for(rich, protocol)
    scaler = torch.amp.GradScaler("cuda", enabled=bool(protocol["amp_enabled"]))
    first = training_step(rich, optimizer, scaler, batch, protocol)
    checkpoint = {
        "model": rich.state_dict(),
        "optimizer": optimizer.state_dict(),
        "scaler": scaler.state_dict(),
        "rng": rng_state(),
    }
    atomic_checkpoint(output / "engineering_smoke.pt", checkpoint)
    second = training_step(rich, optimizer, scaler, batch, protocol)
    expected_state = {
        key: value.detach().cpu().clone() for key, value in rich.state_dict().items()
    }
    del rich, optimizer, scaler, checkpoint
    torch.cuda.empty_cache()

    restored = make_model(protocol)
    loaded = safe_load(output / "engineering_smoke.pt")
    restored.load_state_dict(loaded["model"], strict=True)
    restored_optimizer = optimizer_for(restored, protocol)
    restored_optimizer.load_state_dict(loaded["optimizer"])
    restored_scaler = torch.amp.GradScaler(
        "cuda", enabled=bool(protocol["amp_enabled"])
    )
    restored_scaler.load_state_dict(loaded["scaler"])
    restore_rng(loaded["rng"])
    resumed = training_step(
        restored, restored_optimizer, restored_scaler, batch, protocol
    )
    state_difference = max(
        float((expected_state[key] - value.detach().cpu()).abs().max())
        for key, value in restored.state_dict().items()
    )
    if state_difference != 0.0 or abs(second["loss"] - resumed["loss"]) > 1e-7:
        raise ValueError(
            f"resume parity failed: state={state_difference}, "
            f"loss={second['loss'] - resumed['loss']}"
        )
    report = {
        "status": "PASS",
        "initial_output_max_abs_difference": parity,
        "resume_state_max_abs_difference": state_difference,
        "losses": [first["loss"], second["loss"], resumed["loss"]],
        "base_parameters": sum(p.numel() for p in GeoPrivNet().parameters()),
        "rich_parameters": sum(p.numel() for p in restored.parameters()),
        "peak_allocated_mib": torch.cuda.max_memory_allocated() / 2**20,
        "router_B_used": False,
        "sealed_test_used": False,
    }
    atomic_json(output / "engineering_smoke.json", report)
    print(json.dumps(report), flush=True)


def train(output: Path, protocol: dict[str, object]) -> None:
    if json.loads((output / "engineering_smoke.json").read_text())["status"] != "PASS":
        raise ValueError("passing engineering smoke is required")
    _, _, train_loader, val_loader, sampler = make_loaders(protocol)
    model = make_model(protocol)
    optimizer = optimizer_for(model, protocol)
    scaler = torch.amp.GradScaler("cuda", enabled=bool(protocol["amp_enabled"]))
    start_epoch = 1
    history: list[dict[str, object]] = []
    best_epoch = 0
    best_metrics: dict[str, object] | None = None
    best_model: dict[str, torch.Tensor] | None = None
    last_path = output / "last.pt"
    if last_path.exists():
        checkpoint = safe_load(last_path)
        if checkpoint["protocol"] != protocol:
            raise ValueError("resume protocol mismatch")
        model.load_state_dict(checkpoint["model"], strict=True)
        optimizer.load_state_dict(checkpoint["optimizer"])
        scaler.load_state_dict(checkpoint["scaler"])
        restore_rng(checkpoint["rng"])
        start_epoch = int(checkpoint["epoch"]) + 1
        history = checkpoint["history"]
        best_epoch = int(checkpoint["best_epoch"])
        best_metrics = checkpoint["best_metrics"]
        best_model = checkpoint["best_model"]
        repair_epoch(output, checkpoint)
    else:
        initial_validation = evaluate_local_expert(
            model,
            val_loader,
            torch.device("cuda"),
            protocol["thresholds"],
            matching_radius=float(protocol["match_radius"]),
            local_max_kernel=int(protocol["local_max_kernel"]),
            topk=int(protocol["topk"]),
        )
        best_metrics = initial_validation["mae"]
        best_model = {
            key: value.detach().cpu().clone() for key, value in model.state_dict().items()
        }
        atomic_json(output / "initial_validation.json", initial_validation)
        publish_epoch(
            output,
            {
                "model": model.state_dict(),
                "optimizer": optimizer.state_dict(),
                "scaler": scaler.state_dict(),
                "rng": rng_state(),
                "epoch": 0,
                "protocol": protocol,
                "variant": "rich_hr",
                "history": history,
                "best_epoch": 0,
                "best_metrics": best_metrics,
                "best_model": best_model,
            },
        )
    assert best_metrics is not None and best_model is not None

    for epoch in range(start_epoch, int(protocol["epochs"]) + 1):
        sampler.set_epoch(epoch)
        seed_all(int(protocol["seed"]) + epoch)
        model.train()
        totals: dict[str, float] = {}
        started = time.monotonic()
        torch.cuda.reset_peak_memory_stats()
        for index, batch in enumerate(train_loader):
            losses = training_step(model, optimizer, scaler, batch, protocol)
            for key, value in losses.items():
                totals[key] = totals.get(key, 0.0) + value
            if index % 25 == 0:
                atomic_json(
                    output / "live_progress.json",
                    {
                        "status": "training",
                        "pid": os.getpid(),
                        "epoch": epoch,
                        "last_completed_epoch": epoch - 1,
                        "completed_batches": index + 1,
                        "total_batches": len(train_loader),
                        "loss": losses["loss"],
                    },
                )
        validation = evaluate_local_expert(
            model,
            val_loader,
            torch.device("cuda"),
            protocol["thresholds"],
            matching_radius=float(protocol["match_radius"]),
            local_max_kernel=int(protocol["local_max_kernel"]),
            topk=int(protocol["topk"]),
        )
        current = validation["mae"]
        current_key = (float(current["mae"]), -float(current["f1_at_8"]))
        best_key = (float(best_metrics["mae"]), -float(best_metrics["f1_at_8"]))
        if current_key < best_key:
            best_metrics = current
            best_epoch = epoch
            best_model = {
                key: value.detach().cpu().clone()
                for key, value in model.state_dict().items()
            }
        row: dict[str, object] = {
            "epoch": epoch,
            "training_losses": {
                key: value / len(train_loader) for key, value in totals.items()
            },
            "validation": current,
            "best_epoch": best_epoch,
            "elapsed_seconds": time.monotonic() - started,
            "peak_allocated_mib": torch.cuda.max_memory_allocated() / 2**20,
        }
        history.append(row)
        checkpoint = {
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scaler": scaler.state_dict(),
            "rng": rng_state(),
            "epoch": epoch,
            "protocol": protocol,
            "variant": "rich_hr",
            "history": history,
            "best_epoch": best_epoch,
            "best_metrics": best_metrics,
            "best_model": best_model,
        }
        publish_epoch(output, checkpoint)
        atomic_json(output / f"validation_epoch_{epoch:02d}.json", validation)
        print(json.dumps(row), flush=True)

    summary = {
        "status": "COMPLETE_REVIEW_REQUIRED",
        "model": "RichDetailExpert",
        "parameters": sum(parameter.numel() for parameter in model.parameters()),
        "best_epoch": best_epoch,
        "best_validation": best_metrics,
        "train_images": int(protocol["train_images"]),
        "validation_images": int(protocol["validation_images"]),
        "router_B_used": False,
        "sealed_test_used": False,
        "claim_boundary": "development selection only; not independent test evidence",
    }
    atomic_json(output / "summary.json", summary)
    atomic_json(output / "stage.json", summary)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("prepare", "smoke", "train"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--train-manifest", type=Path)
    parser.add_argument("--val-manifest", type=Path)
    parser.add_argument("--root", type=Path)
    parser.add_argument("--initial-checkpoint", type=Path)
    parser.add_argument("--deep-backbone-checkpoint", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    if args.mode == "prepare":
        required = (
            "train_manifest",
            "val_manifest",
            "root",
            "initial_checkpoint",
            "deep_backbone_checkpoint",
        )
        if any(getattr(args, name) is None for name in required):
            parser.error("prepare requires all dataset and initialization paths")
        prepare(args)
        return
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)
    protocol = verify(output)
    import msvcrt

    with (output / "worker.lock").open("a+b") as lock:
        if lock.tell() == 0:
            lock.write(b"0")
            lock.flush()
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        try:
            if args.mode == "smoke":
                smoke(output, protocol)
            else:
                atomic_json(
                    output / "stage.json",
                    {
                        "status": "RUNNING",
                        "pid": os.getpid(),
                        "router_B_used": False,
                        "sealed_test_used": False,
                    },
                )
                train(output, protocol)
        except BaseException as exc:
            atomic_json(
                output / "stage.json",
                {
                    "status": "FAILED_OR_INTERRUPTED",
                    "error": repr(exc),
                    "router_B_used": False,
                    "sealed_test_used": False,
                },
            )
            raise


if __name__ == "__main__":
    main()
