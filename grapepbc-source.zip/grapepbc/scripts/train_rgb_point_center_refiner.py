"""Train a small RGB patch refiner for berry-centre coordinates.

Training uses Expert-A only.  Development is used after training as an open
engineering gate.  The model predicts an offset and a confidence from a local
RGB patch centred on an existing point.  It never changes the point count.
"""
from __future__ import annotations

import json
from pathlib import Path
import random
import sys
import time

import cv2
import numpy as np
from scipy.spatial import cKDTree
from sklearn.model_selection import GroupKFold
import torch
from torch import nn
from torch.nn import functional as F


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

from audit_vivid_error_taxonomy import match_indices  # noqa: E402
from geopriv.data.hash_utils import file_sha256  # noqa: E402
from run_vivid_hr_core_calibration import atomic_json, atomic_npz  # noqa: E402


EXP = PROJECT / "experiments" / "cru_detail_v1"
OUT = EXP / "vivid_rgb_point_center_refiner_v1"
TRAIN_MANIFEST = EXP / "vivid_application_lr_repair_inputs_v1" / "expert_A_clean.jsonl"
DEV_MANIFEST = EXP / "vivid_application_lr_repair_inputs_v1" / "development_val_clean.jsonl"
BASE = EXP / "vivid_far_dense_repair_final_v2" / "oof_development_points"
ROOT = Path(r"D:\ViViD-5K_已下载数据")
SEED = 20261019
PATCH = 64
HALF_NORM = 24.0
MAX_SHIFT = 12.0
RADII = (4.0, 8.0, 16.0)


class RGBPointCenterRefiner(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 16, 5, stride=2, padding=2), nn.GroupNorm(4, 16), nn.SiLU(),
            nn.Conv2d(16, 32, 3, stride=2, padding=1), nn.GroupNorm(8, 32), nn.SiLU(),
            nn.Conv2d(32, 64, 3, stride=2, padding=1), nn.GroupNorm(8, 64), nn.SiLU(),
            nn.Conv2d(64, 64, 3, padding=1), nn.GroupNorm(8, 64), nn.SiLU(),
        )
        self.head = nn.Sequential(nn.Linear(64 * 8 * 8 + 1, 128), nn.SiLU(), nn.Dropout(0.08), nn.Linear(128, 3))

    def forward(self, patch: torch.Tensor, spacing: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        feature = self.features(patch).flatten(1)
        value = self.head(torch.cat((feature, spacing[:, None]), dim=1))
        return torch.tanh(value[:, :2]) * MAX_SHIFT, value[:, 2]


def rows(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]


def load_rgb(path: Path) -> np.ndarray:
    bgr = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if bgr is None:
        raise FileNotFoundError(path)
    return cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)


def spacing(points: np.ndarray, scale: float) -> np.ndarray:
    if len(points) < 2:
        return np.full(len(points), 48.0, dtype=np.float32)
    value = cKDTree(points * scale).query(points * scale, k=2)[0][:, 1]
    return np.clip(value, 2.0, 64.0).astype(np.float32)


def make_anchors(record: dict, truth: np.ndarray, *, epoch: int, validation: bool) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    width, height = int(record["width"]), int(record["height"])
    scale = 1024.0 / max(width, height)
    truth_spacing = spacing(truth, scale)
    strata = np.where(truth_spacing < 12.0, 0, np.where(truth_spacing < 24.0, 1, 2))
    rng = np.random.default_rng(SEED + epoch * 10007 + int(record["sha256"][:8], 16))
    selected = []
    for stratum in range(3):
        available = np.flatnonzero(strata == stratum)
        if len(available) > 32:
            available = rng.choice(available, 32, replace=False)
        selected.extend(int(index) for index in available)
    anchors, offsets, anchor_spacing, valid = [], [], [], []
    truth_tree = cKDTree(truth * scale) if len(truth) else None
    for index in selected:
        center = truth[index]
        local_spacing = float(truth_spacing[index])
        anchors.append(center.copy()); offsets.append([0.0, 0.0]); anchor_spacing.append(local_spacing); valid.append(1.0)
        maximum = min(MAX_SHIFT, 0.42 * local_spacing)
        if maximum >= 1.0:
            angle = rng.uniform(0.0, 2.0 * np.pi)
            magnitude = rng.uniform(0.8, maximum)
            delta_norm = np.asarray([np.cos(angle), np.sin(angle)], dtype=np.float32) * magnitude
            anchor = center - delta_norm / scale
            if 0 <= anchor[0] < width and 0 <= anchor[1] < height:
                nearest = int(truth_tree.query(anchor * scale)[1])
                if nearest == index:
                    anchors.append(anchor); offsets.append(delta_norm); anchor_spacing.append(local_spacing); valid.append(1.0)
    negative_target = max(8, len(anchors) // 4)
    attempts = 0
    while len(valid) - int(np.sum(valid)) < negative_target and attempts < negative_target * 30:
        attempts += 1
        anchor = np.asarray([rng.uniform(0, width), rng.uniform(0, height)], dtype=np.float32)
        if truth_tree is None or float(truth_tree.query(anchor * scale)[0]) > 18.0:
            anchors.append(anchor); offsets.append([0.0, 0.0]); anchor_spacing.append(32.0); valid.append(0.0)
    return (np.asarray(anchors, dtype=np.float32).reshape(-1, 2),
            np.asarray(offsets, dtype=np.float32).reshape(-1, 2),
            np.asarray(anchor_spacing, dtype=np.float32), np.asarray(valid, dtype=np.float32))


def sample_patches(image: np.ndarray, anchors: np.ndarray, scale: float, device: torch.device) -> torch.Tensor:
    tensor = torch.from_numpy(image).to(device=device, dtype=torch.float32).permute(2, 0, 1)[None] / 255.0
    mean = torch.tensor([0.485, 0.456, 0.406], device=device)[:, None, None]
    std = torch.tensor([0.229, 0.224, 0.225], device=device)[:, None, None]
    tensor = (tensor[0] - mean) / std
    height, width = image.shape[:2]
    half_native = HALF_NORM / scale
    axis = torch.linspace(-half_native, half_native, PATCH, device=device)
    anchor = torch.from_numpy(anchors).to(device)
    xx = anchor[:, 0, None, None] + axis[None, None, :]
    yy = anchor[:, 1, None, None] + axis[None, :, None]
    xx = xx.expand(-1, PATCH, -1); yy = yy.expand(-1, -1, PATCH)
    grid = torch.stack((xx * (2.0 / max(width - 1, 1)) - 1.0, yy * (2.0 / max(height - 1, 1)) - 1.0), dim=-1)
    source = tensor[None].expand(len(anchors), -1, -1, -1)
    return F.grid_sample(source, grid, mode="bilinear", padding_mode="reflection", align_corners=True)


def record_payload(record: dict) -> tuple[np.ndarray, np.ndarray]:
    image = load_rgb(ROOT / record["image_path"])
    truth = np.load(ROOT / record["points_path"], allow_pickle=False).astype(np.float32)
    return image, truth


def epoch_pass(model, records, optimizer, device, *, epoch: int, validation: bool) -> dict:
    model.train(not validation)
    rng = np.random.default_rng(SEED + epoch)
    order = np.arange(len(records)) if validation else rng.permutation(len(records))
    total_loss = total_offset = total_confidence = samples = closer = positive_count = 0.0
    context = torch.inference_mode if validation else torch.enable_grad
    with context():
        for position, index in enumerate(order):
            record = records[int(index)]
            image, truth = record_payload(record)
            anchors, targets, point_spacing, valid = make_anchors(record, truth, epoch=0 if validation else epoch, validation=validation)
            if not len(anchors):
                continue
            scale = 1024.0 / max(int(record["width"]), int(record["height"]))
            for start in range(0, len(anchors), 192):
                end = min(start + 192, len(anchors))
                patches = sample_patches(image, anchors[start:end], scale, device)
                if not validation:
                    brightness = float(rng.uniform(0.9, 1.1)); contrast = float(rng.uniform(0.9, 1.1))
                    patches = patches * contrast + (brightness - 1.0)
                target = torch.from_numpy(targets[start:end]).to(device)
                truth_valid = torch.from_numpy(valid[start:end]).to(device)
                spacing_value = (np.log1p(point_spacing[start:end]) / np.log(65.0)).astype(np.float32)
                spacing_input = torch.from_numpy(spacing_value).to(device)
                predicted, confidence = model(patches, spacing_input)
                positive = truth_valid > 0.5
                offset_loss = F.smooth_l1_loss(predicted[positive], target[positive]) if positive.any() else confidence.sum() * 0.0
                confidence_loss = F.binary_cross_entropy_with_logits(confidence, truth_valid)
                loss = offset_loss + 0.20 * confidence_loss
                if not validation:
                    optimizer.zero_grad(set_to_none=True); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0); optimizer.step()
                batch = end - start
                total_loss += float(loss) * batch; total_offset += float(offset_loss) * batch; total_confidence += float(confidence_loss) * batch; samples += batch
                if positive.any():
                    before = torch.linalg.norm(target[positive], dim=1)
                    after = torch.linalg.norm(target[positive] - predicted[positive], dim=1)
                    closer += int((after < before).sum()); positive_count += int(positive.sum())
            if (position + 1) % 100 == 0:
                print(f"{'val' if validation else 'train'} e{epoch} {position + 1}/{len(order)}", flush=True)
    return {"loss": total_loss / max(samples, 1), "offset_loss": total_offset / max(samples, 1),
            "confidence_loss": total_confidence / max(samples, 1), "samples": int(samples),
            "positive_closer_fraction": closer / max(positive_count, 1)}


@torch.inference_mode()
def predict_offsets(model, image: np.ndarray, points: np.ndarray, point_spacing: np.ndarray, scale: float, device) -> tuple[np.ndarray, np.ndarray]:
    output, confidence = [], []
    for start in range(0, len(points), 192):
        patch = sample_patches(image, points[start:start + 192], scale, device)
        spacing_value = (np.log1p(point_spacing[start:start + 192]) / np.log(65.0)).astype(np.float32)
        spacing_input = torch.from_numpy(spacing_value).to(device)
        delta, score = model(patch, spacing_input)
        output.append(delta.cpu().numpy()); confidence.append(torch.sigmoid(score).cpu().numpy())
    return np.concatenate(output).astype(np.float32), np.concatenate(confidence).astype(np.float32)


def apply_offsets(points: np.ndarray, offset: np.ndarray, confidence: np.ndarray, point_spacing: np.ndarray,
                  image_size: tuple[int, int], *, alpha: float, threshold: float, fraction: float) -> np.ndarray:
    result = points.copy(); gate = confidence >= threshold
    shift = offset * alpha
    magnitude = np.linalg.norm(shift, axis=1)
    limit = np.minimum(MAX_SHIFT, fraction * point_spacing)
    factor = np.minimum(1.0, limit / np.maximum(magnitude, 1e-6))
    shift *= factor[:, None]
    scale = 1024.0 / max(image_size)
    result[gate] += shift[gate] / scale
    result[:, 0] = np.clip(result[:, 0], 0, image_size[0] - 1e-3)
    result[:, 1] = np.clip(result[:, 1], 0, image_size[1] - 1e-3)
    return result


def evaluate(cached: list[dict], predictions: list[np.ndarray]) -> dict:
    totals = {name: {radius: [0, 0, 0] for radius in RADII} for name in ("baseline", "repaired")}
    scale_hits = {name: {s: {r: [0, 0] for r in RADII} for s in ("far", "medium", "near")} for name in ("baseline", "repaired")}
    nearest = {name: {s: [] for s in ("far", "medium", "near")} for name in ("baseline", "repaired")}
    gains = {4.0: [], 8.0: [], 16.0: []}
    for item, repaired in zip(cached, predictions, strict=True):
        truth = item["truth"] * item["scale"]
        truth_spacing = spacing(item["truth"], item["scale"])
        labels = np.where(truth_spacing < 12.0, "far", np.where(truth_spacing < 24.0, "medium", "near"))
        per = {}
        for name, points in (("baseline", item["points"]), ("repaired", repaired)):
            normalized = points * item["scale"]
            for radius in RADII:
                pred_match, truth_match = match_indices(normalized, truth, radius)
                tp = int((truth_match >= 0).sum()); per[(name, radius)] = tp
                totals[name][radius][0] += tp; totals[name][radius][1] += len(points) - tp; totals[name][radius][2] += len(truth) - tp
                for stratum in ("far", "medium", "near"):
                    mask = labels == stratum
                    scale_hits[name][stratum][radius][0] += int(((truth_match >= 0) & mask).sum()); scale_hits[name][stratum][radius][1] += int(mask.sum())
            distance = cKDTree(normalized).query(truth)[0] if len(normalized) else np.full(len(truth), np.inf)
            for stratum in ("far", "medium", "near"):
                nearest[name][stratum].extend(distance[labels == stratum].tolist())
        for radius in RADII:
            gains[radius].append(per[("repaired", radius)] - per[("baseline", radius)])
    def f1(values):
        tp, fp, fn = values
        return float(2 * tp / max(2 * tp + fp + fn, 1))
    return {
        "f1": {name: {str(int(radius)): f1(totals[name][radius]) for radius in RADII} for name in totals},
        "scale_recall": {stratum: {str(int(radius)): {name: scale_hits[name][stratum][radius][0] / max(scale_hits[name][stratum][radius][1], 1) for name in totals} for radius in RADII} for stratum in ("far", "medium", "near")},
        "nearest_distance": {stratum: {name: {"median": float(np.median(nearest[name][stratum])), "p90": float(np.quantile(nearest[name][stratum], 0.9)), "mean_clipped_32": float(np.minimum(nearest[name][stratum], 32.0).mean())} for name in totals} for stratum in ("far", "medium", "near")},
        "image_gains": {str(int(radius)): {"improved": int((np.asarray(gains[radius]) > 0).sum()), "worsened": int((np.asarray(gains[radius]) < 0).sum()), "net_tp": int(np.sum(gains[radius]))} for radius in RADII},
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    train_records = rows(TRAIN_MANIFEST); dev_records = rows(DEV_MANIFEST)
    if any(row.get("external_test") for row in train_records + dev_records):
        raise ValueError("forbidden external role")
    groups = np.asarray([row.get("capture_group_id") or row["sample_id"] for row in train_records])
    fit_index, val_index = next(GroupKFold(5).split(np.arange(len(train_records)), groups=groups))
    fit_records = [train_records[int(i)] for i in fit_index]; val_records = [train_records[int(i)] for i in val_index]
    protocol = {"version": "vivid-rgb-point-center-refiner-v1", "seed": SEED, "patch": PATCH,
                "half_window_normalized_px": HALF_NORM, "max_shift_normalized_px": MAX_SHIFT,
                "train_images": len(fit_records), "validation_images": len(val_records), "epochs": 4,
                "model_role": "count-conserving point coordinate refinement", "development_selected": True,
                "train_manifest_sha256": file_sha256(TRAIN_MANIFEST), "development_manifest_sha256": file_sha256(DEV_MANIFEST),
                "router_b_used": False, "sealed_test_used": False, "source_sha256": file_sha256(Path(__file__))}
    atomic_json(OUT / "protocol.json", protocol)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    torch.manual_seed(SEED); np.random.seed(SEED); random.seed(SEED)
    model = RGBPointCenterRefiner().to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-4)
    history = []; best = None
    for epoch in range(1, 5):
        started = time.monotonic()
        training = epoch_pass(model, fit_records, optimizer, device, epoch=epoch, validation=False)
        validation = epoch_pass(model, val_records, None, device, epoch=epoch, validation=True)
        row = {"epoch": epoch, "training": training, "validation": validation, "elapsed_seconds": time.monotonic() - started}
        history.append(row)
        with (OUT / "history.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")
        checkpoint = {"epoch": epoch, "model": model.state_dict(), "optimizer": optimizer.state_dict(), "protocol": protocol, "row": row}
        temporary = OUT / "last.pt.tmp"; torch.save(checkpoint, temporary); temporary.replace(OUT / "last.pt")
        if best is None or validation["offset_loss"] < best["validation"]["offset_loss"]:
            best = row; temporary = OUT / "best_val_offset.pt.tmp"; torch.save(checkpoint, temporary); temporary.replace(OUT / "best_val_offset.pt")
        atomic_json(OUT / "progress.json", {"status": "TRAINING" if epoch < 4 else "TRAINING_COMPLETE", "last_epoch": epoch, "best_epoch": best["epoch"], "history": history, "router_b_used": False, "sealed_test_used": False})
        print(json.dumps(row, ensure_ascii=False), flush=True)
    checkpoint = torch.load(OUT / "best_val_offset.pt", map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model"]); model.eval()

    cached = []
    for position, record in enumerate(dev_records):
        filename = record["sample_id"].replace(":", "_") + ".npz"
        with np.load(BASE / filename, allow_pickle=False) as payload:
            points = payload["cru"].astype(np.float32); truth = payload["truth"].astype(np.float32); reliability = payload["reliability"].astype(np.float32)
        image = load_rgb(ROOT / record["image_path"])
        image_size = (int(record["width"]), int(record["height"])); scale = 1024.0 / max(image_size)
        point_spacing = spacing(points, scale)
        if len(points):
            offset, confidence = predict_offsets(model, image, points, point_spacing, scale, device)
        else:
            offset = np.empty((0, 2), dtype=np.float32); confidence = np.empty(0, dtype=np.float32)
        cached.append({"sample_id": record["sample_id"], "image_size": image_size, "scale": scale,
                       "points": points, "truth": truth, "reliability": reliability,
                       "point_spacing": point_spacing, "offset": offset, "confidence": confidence})
        if (position + 1) % 25 == 0:
            print(f"development inference {position + 1}/{len(dev_records)}", flush=True)
    configs = []
    for alpha in (0.25, 0.50, 0.75, 1.0):
        for threshold in (0.50, 0.65, 0.80, 0.90):
            for fraction in (0.25, 0.40):
                predictions = [apply_offsets(item["points"], item["offset"], item["confidence"], item["point_spacing"], item["image_size"], alpha=alpha, threshold=threshold, fraction=fraction) for item in cached]
                report = evaluate(cached, predictions)
                base = report["f1"]["baseline"]; repaired = report["f1"]["repaired"]
                recalls = report["scale_recall"]
                eligible = all(repaired[str(int(radius))] >= base[str(int(radius))] for radius in RADII)
                eligible &= all(recalls[s][str(int(radius))]["repaired"] >= recalls[s][str(int(radius))]["baseline"] for s in ("far", "medium", "near") for radius in RADII)
                configs.append({"alpha": alpha, "confidence_threshold": threshold, "spacing_fraction": fraction, "eligible": bool(eligible), **report})
    eligible = [row for row in configs if row["eligible"]]
    selected = max(eligible or configs, key=lambda row: (row["f1"]["repaired"]["4"] - row["f1"]["baseline"]["4"], row["image_gains"]["4"]["net_tp"], -row["image_gains"]["4"]["worsened"], row["f1"]["repaired"]["8"]))
    point_out = OUT / "development_points"; point_out.mkdir(exist_ok=True)
    final_predictions = [apply_offsets(item["points"], item["offset"], item["confidence"], item["point_spacing"], item["image_size"], alpha=float(selected["alpha"]), threshold=float(selected["confidence_threshold"]), fraction=float(selected["spacing_fraction"])) for item in cached]
    for item, points in zip(cached, final_predictions, strict=True):
        atomic_npz(point_out / (item["sample_id"].replace(":", "_") + ".npz"), cru=points.astype(np.float32), truth=item["truth"], reliability=item["reliability"])
    summary = {"status": "COMPLETE_OPEN_DEVELOPMENT_GATE", "best_epoch": int(checkpoint["epoch"]),
               "selected": selected, "eligible_configs": len(eligible), "configs": configs,
               "model_parameters": sum(parameter.numel() for parameter in model.parameters()),
               "point_files": len(list(point_out.glob("*.npz"))), "model_sha256": file_sha256(OUT / "best_val_offset.pt"),
               "independent_confirmation": False, "router_b_used": False, "sealed_test_used": False}
    atomic_json(OUT / "summary.json", summary); atomic_json(OUT / "progress.json", {"status": "COMPLETE", "best_epoch": int(checkpoint["epoch"]), "selected": selected, "router_b_used": False, "sealed_test_used": False})
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
