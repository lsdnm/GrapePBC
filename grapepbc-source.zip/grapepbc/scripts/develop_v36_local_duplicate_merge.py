"""Merge high-confidence duplicate pairs at their shared local Rich-HR centre.

Unlike V32R, this stage never searches for a distant replacement.  It replaces
two near-coincident hypotheses by their already-shared local Rich-HR candidate,
thereby reducing the count by one and producing exactly one centre mark for the
visible berry.  Pair confidence is the maximum of the two group-OOF V35 action
scores; all reported screening remains open-development evidence.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import asdict, dataclass
import json
from pathlib import Path
import sys

import joblib
import numpy as np
from scipy.spatial import cKDTree


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

import develop_cluster_aware_point_reallocation as helper  # noqa: E402
import develop_one_berry_one_point_v30 as metrics  # noqa: E402
import develop_v33_conservative_duplicate_deletion as geometry  # noqa: E402
import train_v35_oof_duplicate_action_classifier as v35  # noqa: E402
from audit_vivid_error_taxonomy import match_indices  # noqa: E402
from develop_cluster_aware_point_reallocation import (  # noqa: E402
    ensure_evaluation_box, load_candidates, make_boxes, owner_indices,
    read_rows, strict_candidate_owner,
)
from run_vivid_hr_core_calibration import atomic_json, atomic_npz  # noqa: E402


EXP = PROJECT / "experiments" / "cru_detail_v1"
MANIFEST = EXP / "vivid_application_lr_repair_inputs_v1" / "development_val_clean.jsonl"
PROPOSALS = EXP / "vivid_stage6_border_safe_zero_filter_v28b" / "development_proposals.jsonl"
POINTS = EXP / "vivid_v4_v17_hybrid_center_gate_v18" / "oof_development_points"
CANDIDATE_ROOT = EXP / "vivid_application_development_density_core_points_v2"
SEMANTIC_ROOT = EXP / "vivid_semantic_duplicate_deletion_v34" / "oof_semantic_scores"
V35 = EXP / "vivid_oof_duplicate_action_classifier_v35"
OUT = EXP / "vivid_local_duplicate_merge_v36"
SEED = 20261009


@dataclass(frozen=True)
class Policy:
    probability_threshold: float
    maximum_pair_distance_1024: float
    maximum_merges: int


POLICIES = tuple(
    Policy(probability, distance, maximum)
    for probability in (0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.925)
    for distance in (1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 6.0)
    for maximum in (1, 2, 3)
)


def prepare() -> tuple[list[dict], dict[str, list[dict]], dict[str, np.ndarray]]:
    records = read_rows(MANIFEST); manifest = {row["sample_id"]: row for row in records}
    proposals = {row["sample_id"]: row for row in read_rows(PROPOSALS)}
    index = json.loads((CANDIDATE_ROOT / "index.json").read_text(encoding="utf-8"))
    helper.CANDIDATE_ROOT = CANDIDATE_ROOT; pools = load_candidates(index, manifest)
    bases = []
    for number, sample_id in enumerate(sorted(manifest), start=1):
        record = manifest[sample_id]
        with np.load(POINTS / f"{sample_id.replace(':', '_')}.npz", allow_pickle=False) as payload:
            points = np.asarray(payload["cru"], np.float64); truth = np.asarray(payload["truth"], np.float64); reliability = np.asarray(payload["reliability"], np.float64)
        semantic = np.load(SEMANTIC_ROOT / f"{sample_id.replace(':', '_')}.npz", allow_pickle=False)["score"].astype(np.float64)
        image_size = (int(record["width"]), int(record["height"])); scale = 1024.0 / max(image_size)
        boxes, _ = ensure_evaluation_box(points, make_boxes(proposals[sample_id], "proposals"), image_size)
        owners = owner_indices(points, boxes, image_size); candidate_xy, candidate_scores = pools[sample_id]
        candidate_owner = strict_candidate_owner(candidate_xy, boxes); inside = candidate_owner >= 0
        point_nearest, local_counts = v35.local_geometry(points, scale)
        base = {
            "sample_id": sample_id, "group": str(record.get("capture_group_id") or sample_id),
            "points": points, "truth": truth, "reliability": reliability, "semantic_score": semantic,
            "image_size": image_size, "scale": scale, "boxes": boxes, "owners": owners,
            "candidates": candidate_xy[inside], "candidate_scores": candidate_scores[inside], "candidate_owner": candidate_owner[inside],
            "point_nearest": point_nearest, "local_counts": local_counts,
        }
        base["candidate_evidence"] = geometry.candidate_evidence(base); base["close_pairs"] = geometry.close_pairs(base)
        base["base_pred_match"], _ = match_indices(points * scale, truth * scale, 8.0)
        base["baseline"] = {"stats": metrics.point_stats(points, truth, image_size), "scale_recall": metrics.scale_recall(points, truth, image_size), "diagnostic": {"merges": 0}}
        base["candidate_cache"] = {}
        bases.append(base)
        if number % 30 == 0 or number == len(manifest): print(f"prepared {number}/{len(manifest)}", flush=True)

    actions_by_id = {base["sample_id"]: v35.make_actions(base) for base in bases}
    stored = json.loads((V35 / "oof_action_scores.json").read_text(encoding="utf-8"))
    queues: dict[tuple[str, int, int], list[float]] = defaultdict(list)
    for row in stored: queues[(row["sample_id"], int(row["delete"]), int(row["keep"]))].append(float(row["score"]))
    scores_by_id = {}
    for sample_id, actions in actions_by_id.items():
        values = []
        for action in actions:
            key = (sample_id, action["delete"], action["keep"])
            if not queues[key]: raise RuntimeError(f"missing OOF score for {key}")
            values.append(queues[key].pop(0))
        scores_by_id[sample_id] = np.asarray(values, np.float64)
    return bases, actions_by_id, scores_by_id


def unique_pairs(base: dict, actions: list[dict], scores: np.ndarray) -> list[dict]:
    combined: dict[tuple[int, int], dict] = {}
    nearest_candidate = base["candidate_evidence"][0]
    for action, score in zip(actions, scores):
        first, second = sorted((int(action["delete"]), int(action["keep"])))
        key = (first, second)
        row = combined.setdefault(key, {
            "first": first, "second": second, "distance": float(action["distance"]),
            "score": 0.0, "candidate_index": int(nearest_candidate[first]),
        })
        row["score"] = max(float(row["score"]), float(score))
    return list(combined.values())


def apply_policy(base: dict, pairs: list[dict], policy: Policy) -> tuple[np.ndarray, np.ndarray, dict]:
    eligible = sorted(
        (row for row in pairs if row["score"] >= policy.probability_threshold
         and row["distance"] <= policy.maximum_pair_distance_1024),
        key=lambda row: (-row["score"], row["distance"], row["first"]),
    )
    consumed: set[int] = set(); selected = []
    for row in eligible:
        if len(selected) >= policy.maximum_merges: break
        if row["first"] in consumed or row["second"] in consumed: continue
        candidate = int(row["candidate_index"])
        if candidate < 0: continue
        consumed.update((row["first"], row["second"])); selected.append(row)
    points = base["points"].copy(); reliability = base["reliability"].copy(); remove: set[int] = set(); diagnostics = []
    for row in selected:
        first, second, candidate = row["first"], row["second"], row["candidate_index"]
        keeper, dropped = min(first, second), max(first, second)
        old_first = points[first].copy(); old_second = points[second].copy()
        points[keeper] = base["candidates"][candidate]
        reliability[keeper] = max(reliability[first], reliability[second], base["candidate_scores"][candidate])
        remove.add(dropped)
        diagnostics.append({
            "kept_index": keeper, "dropped_index": dropped, "score": row["score"],
            "pair_distance_1024": row["distance"], "old_first_xy": old_first.tolist(),
            "old_second_xy": old_second.tolist(), "merged_xy": points[keeper].tolist(),
        })
    mask = np.ones(len(points), bool)
    if remove: mask[np.fromiter(sorted(remove), dtype=np.int64)] = False
    return points[mask], reliability[mask], {"merges": len(selected), "rows": diagnostics, "mask": mask}


def evaluate(bases: list[dict], pairs_by_id: dict[str, list[dict]], policy: Policy) -> tuple[list[dict], dict]:
    rows = []; clear_duplicate = distinct_pair = 0
    for base in bases:
        output, _, diagnostic = apply_policy(base, pairs_by_id[base["sample_id"]], policy)
        truth_tree = cKDTree(base["truth"] * base["scale"]) if len(base["truth"]) else None
        for item in diagnostic["rows"]:
            pair = base["points"][[item["kept_index"], item["dropped_index"]]] * base["scale"]
            nearest = truth_tree.query(pair)[1] if truth_tree else np.asarray((-1, -2))
            clear_duplicate += bool(nearest[0] == nearest[1])
            distinct_pair += bool(nearest[0] != nearest[1])
        signature = tuple((item["kept_index"], item["dropped_index"]) for item in diagnostic["rows"])
        if signature not in base["candidate_cache"]:
            base["candidate_cache"][signature] = {"stats": metrics.point_stats(output, base["truth"], base["image_size"]), "scale_recall": metrics.scale_recall(output, base["truth"], base["image_size"])}
        candidate = {**base["candidate_cache"][signature], "diagnostic": diagnostic}
        rows.append({
            "sample_id": base["sample_id"], "group": base["group"], "baseline": base["baseline"], "candidate": candidate,
            "baseline_error": abs(len(base["points"]) - len(base["truth"])), "candidate_error": abs(len(output) - len(base["truth"])),
        })
    baseline = metrics.aggregate(rows, "baseline"); candidate = metrics.aggregate(rows, "candidate")
    before = float(np.mean([row["baseline_error"] for row in rows])); after = float(np.mean([row["candidate_error"] for row in rows]))
    return rows, {
        "policy": asdict(policy), "baseline": baseline, "candidate": candidate,
        "merges": int(sum(row["candidate"]["diagnostic"]["merges"] for row in rows)),
        "images_changed": int(sum(row["candidate"]["diagnostic"]["merges"] > 0 for row in rows)),
        "same_nearest_truth_pairs": int(clear_duplicate), "different_nearest_truth_pairs": int(distinct_pair),
        "pair_precision_proxy": float(clear_duplicate / max(clear_duplicate + distinct_pair, 1)),
        "count_mae_before": before, "count_mae_after": after, "count_mae_gain": before - after,
        "f1_gain": {key: candidate["f1"][key] - baseline["f1"][key] for key in baseline["f1"]},
        "competition_reduction": baseline["competition_unmatched_within8"] - candidate["competition_unmatched_within8"],
        "collision_reduction": {key: baseline["collision_pairs"][key] - candidate["collision_pairs"][key] for key in baseline["collision_pairs"]},
    }


def bootstrap(rows: list[dict], draws: int = 10000) -> dict:
    groups: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(rows): groups[row["group"]].append(index)
    buckets = [np.asarray(value, np.int64) for value in groups.values()]; rng = np.random.default_rng(SEED)
    count = np.empty(draws); f1 = {key: np.empty(draws) for key in ("4", "8", "16")}
    for draw in range(draws):
        selected = rng.integers(0, len(buckets), len(buckets)); indices = np.concatenate([buckets[i] for i in selected])
        count[draw] = np.mean([rows[i]["baseline_error"] - rows[i]["candidate_error"] for i in indices])
        for radius in f1:
            before = np.sum([rows[i]["baseline"]["stats"]["triples"][radius] for i in indices], axis=0)
            after = np.sum([rows[i]["candidate"]["stats"]["triples"][radius] for i in indices], axis=0)
            f1[radius][draw] = metrics.f1(after) - metrics.f1(before)
    return {"count_mae_gain_95_ci": np.quantile(count, (0.025, 0.975)).tolist(), "f1_gain_95_ci": {key: np.quantile(value, (0.025, 0.975)).tolist() for key, value in f1.items()}}


def main() -> None:
    if OUT.exists(): raise SystemExit(f"refusing to overwrite existing experiment: {OUT}")
    OUT.mkdir(parents=True)
    bases, actions_by_id, scores_by_id = prepare()
    pairs_by_id = {base["sample_id"]: unique_pairs(base, actions_by_id[base["sample_id"]], scores_by_id[base["sample_id"]]) for base in bases}
    screening = []; selected = None
    for policy in POLICIES:
        rows, report = evaluate(bases, pairs_by_id, policy)
        eligible = (report["merges"] >= 5 and report["pair_precision_proxy"] >= 0.90
                    and all(value >= 0 for value in report["f1_gain"].values()) and report["count_mae_gain"] >= 0)
        report["eligible"] = bool(eligible); screening.append(report)
        if eligible:
            key = (report["pair_precision_proxy"], report["competition_reduction"], report["f1_gain"]["4"], report["f1_gain"]["8"], report["count_mae_gain"], -report["merges"])
            if selected is None or key > selected[0]: selected = (key, policy, rows, report)
    if selected is None:
        summary = {"status": "NO_STABLE_LOCAL_MERGE", "policies": len(POLICIES)}
    else:
        _, policy, rows, report = selected; point_root = OUT / "oof_development_points"; per_image = []
        for base in bases:
            output, reliability, diagnostic = apply_policy(base, pairs_by_id[base["sample_id"]], policy)
            atomic_npz(point_root / f"{base['sample_id'].replace(':', '_')}.npz", cru=output.astype(np.float32), truth=base["truth"].astype(np.float32), reliability=reliability.astype(np.float32))
            per_image.append({"sample_id": base["sample_id"], "diagnostic": {k: v for k, v in diagnostic.items() if k != "mask"}})
        atomic_json(OUT / "per_image.json", per_image)
        summary = {
            "status": "STABLE_LOCAL_MERGE_FOUND", "policies": len(POLICIES), "eligible": sum(item["eligible"] for item in screening),
            "selected": report, "bootstrap": bootstrap(rows), "point_cache": str(point_root.resolve()),
            "development_selected": True, "independent_confirmation": False, "sealed_test_used": False, "router_b_used": False,
        }
    atomic_json(OUT / "screening.json", screening); atomic_json(OUT / "summary.json", summary)
    atomic_json(OUT / "protocol.json", {
        "version": "vivid-local-duplicate-merge-v36", "source": "frozen V29/V18 points",
        "pair_score": "maximum of two held-group OOF V35 action scores",
        "merge_target": "the same local Rich-HR candidate already supporting both points",
        "never_relocates_to_distant_candidate": True, "annotations_used_at_runtime": False,
        "development_selected": True, "independent_confirmation": False, "sealed_test_used": False,
    })
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__": main()
