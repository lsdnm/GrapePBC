"""Calibrate a label-free, scale-aware gate for the frozen wide-context refiner.

The development labels are used only to select a fixed gate.  At runtime the
gate uses predicted point spacing, RGB patches, and refiner confidence; no
truth-derived scale label is available to the policy.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
import torch


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

from geopriv.data.hash_utils import file_sha256  # noqa: E402
from run_vivid_hr_core_calibration import atomic_json, atomic_npz  # noqa: E402
import train_rgb_point_center_refiner as base  # noqa: E402


EXP = PROJECT / "experiments" / "cru_detail_v1"
SOURCE = EXP / "vivid_rgb_point_center_refiner_wide_context_v3"
OUT = EXP / "vivid_rgb_point_center_refiner_scale_gate_v3"
CACHE = OUT / "inference_cache"
CHECKPOINT = SOURCE / "best_val_offset.pt"
VERSION = "vivid-rgb-point-center-refiner-scale-gate-v3"


def apply_scale_gate(item: dict, *, alpha: float, far_threshold: float,
                     medium_threshold: float, near_threshold: float,
                     fraction: float) -> np.ndarray:
    points = item["points"]
    if not len(points):
        return points.copy()
    point_spacing = item["point_spacing"]
    thresholds = np.where(
        point_spacing < 12.0,
        far_threshold,
        np.where(point_spacing < 24.0, medium_threshold, near_threshold),
    ).astype(np.float32)
    result = points.copy()
    gate = item["confidence"] >= thresholds
    shift = item["offset"] * alpha
    magnitude = np.linalg.norm(shift, axis=1)
    limit = np.minimum(base.MAX_SHIFT, fraction * point_spacing)
    shift *= np.minimum(1.0, limit / np.maximum(magnitude, 1e-6))[:, None]
    result[gate] += shift[gate] / item["scale"]
    width, height = item["image_size"]
    result[:, 0] = np.clip(result[:, 0], 0, width - 1e-3)
    result[:, 1] = np.clip(result[:, 1], 0, height - 1e-3)
    return result.astype(np.float32)


def load_or_infer() -> list[dict]:
    CACHE.mkdir(parents=True, exist_ok=True)
    records = base.rows(base.DEV_MANIFEST)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    base.HALF_NORM = 40.0
    base.MAX_SHIFT = 24.0
    checkpoint = torch.load(CHECKPOINT, map_location=device, weights_only=False)
    model = base.RGBPointCenterRefiner().to(device)
    model.load_state_dict(checkpoint["model"])
    model.eval()
    cached = []
    for position, record in enumerate(records):
        filename = record["sample_id"].replace(":", "_") + ".npz"
        cache_path = CACHE / filename
        with np.load(base.BASE / filename, allow_pickle=False) as payload:
            points = payload["cru"].astype(np.float32)
            truth = payload["truth"].astype(np.float32)
            reliability = payload["reliability"].astype(np.float32)
        image_size = (int(record["width"]), int(record["height"]))
        scale = 1024.0 / max(image_size)
        point_spacing = base.spacing(points, scale)
        if cache_path.exists():
            with np.load(cache_path, allow_pickle=False) as payload:
                offset = payload["offset"].astype(np.float32)
                confidence = payload["confidence"].astype(np.float32)
        elif len(points):
            image = base.load_rgb(base.ROOT / record["image_path"])
            offset, confidence = base.predict_offsets(model, image, points, point_spacing, scale, device)
            atomic_npz(cache_path, offset=offset, confidence=confidence)
        else:
            offset = np.empty((0, 2), np.float32)
            confidence = np.empty(0, np.float32)
            atomic_npz(cache_path, offset=offset, confidence=confidence)
        cached.append({"sample_id": record["sample_id"], "image_size": image_size,
                       "scale": scale, "points": points, "truth": truth,
                       "reliability": reliability, "point_spacing": point_spacing,
                       "offset": offset, "confidence": confidence})
        if (position + 1) % 25 == 0:
            print(f"inference {position + 1}/{len(records)}", flush=True)
    return cached


def eligible(report: dict) -> bool:
    baseline = report["f1"]["baseline"]
    repaired = report["f1"]["repaired"]
    if not all(repaired[str(int(radius))] >= baseline[str(int(radius))] for radius in base.RADII):
        return False
    recalls = report["scale_recall"]
    return all(
        recalls[scale][str(int(radius))]["repaired"]
        >= recalls[scale][str(int(radius))]["baseline"]
        for scale in ("far", "medium", "near") for radius in base.RADII
    )


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    cached = load_or_infer()
    configs = []
    total = 3 * 4 * 3 * 3 * 2
    done = 0
    for alpha in (0.50, 0.75, 1.00):
        for far_threshold in (0.65, 0.80, 0.90, 1.10):
            for medium_threshold in (0.50, 0.65, 0.80):
                for near_threshold in (0.50, 0.65, 0.80):
                    for fraction in (0.25, 0.40):
                        predictions = [apply_scale_gate(
                            item, alpha=alpha, far_threshold=far_threshold,
                            medium_threshold=medium_threshold,
                            near_threshold=near_threshold, fraction=fraction,
                        ) for item in cached]
                        report = base.evaluate(cached, predictions)
                        row = {"alpha": alpha, "far_threshold": far_threshold,
                               "medium_threshold": medium_threshold,
                               "near_threshold": near_threshold,
                               "spacing_fraction": fraction,
                               "eligible": eligible(report), **report}
                        configs.append(row)
                        done += 1
                        if done % 24 == 0:
                            print(f"gate {done}/{total}", flush=True)
    accepted = [row for row in configs if row["eligible"]]
    selected = max(
        accepted or configs,
        key=lambda row: (
            row["image_gains"]["4"]["net_tp"],
            row["image_gains"]["8"]["net_tp"],
            row["image_gains"]["16"]["net_tp"],
            -row["image_gains"]["4"]["worsened"],
        ),
    )
    point_out = OUT / "development_points"
    point_out.mkdir(exist_ok=True)
    predictions = [apply_scale_gate(
        item, alpha=float(selected["alpha"]),
        far_threshold=float(selected["far_threshold"]),
        medium_threshold=float(selected["medium_threshold"]),
        near_threshold=float(selected["near_threshold"]),
        fraction=float(selected["spacing_fraction"]),
    ) for item in cached]
    for item, points in zip(cached, predictions, strict=True):
        atomic_npz(
            point_out / (item["sample_id"].replace(":", "_") + ".npz"),
            cru=points, truth=item["truth"], reliability=item["reliability"],
        )
    protocol = {
        "version": VERSION,
        "role": "count-conserving scale-aware coordinate refinement",
        "runtime_scale": "predicted nearest-neighbour point spacing only",
        "truth_scale_runtime_use": False,
        "development_selected": True,
        "independent_confirmation": False,
        "router_b_used": False,
        "sealed_test_used": False,
        "checkpoint": str(CHECKPOINT),
        "checkpoint_sha256": file_sha256(CHECKPOINT),
        "source_sha256": file_sha256(Path(__file__)),
    }
    summary = {"status": "COMPLETE_OPEN_DEVELOPMENT_GATE",
               "selected": selected, "eligible_configs": len(accepted),
               "configs_evaluated": len(configs), "point_files": len(predictions),
               "protocol": protocol}
    atomic_json(OUT / "protocol.json", protocol)
    atomic_json(OUT / "summary.json", summary)
    atomic_json(OUT / "progress.json", {"status": "COMPLETE", "selected": selected,
                                         "router_b_used": False, "sealed_test_used": False})
    print(json.dumps({"status": summary["status"], "selected": selected,
                      "eligible_configs": len(accepted),
                      "configs_evaluated": len(configs)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
