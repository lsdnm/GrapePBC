"""Geometry-aware safety gate for frozen five-fold OOF centre offsets."""
from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

from geopriv.data.hash_utils import file_sha256  # noqa: E402
from run_vivid_hr_core_calibration import atomic_json, atomic_npz  # noqa: E402
import train_rgb_point_center_refiner as base  # noqa: E402


EXP = PROJECT / "experiments" / "cru_detail_v1"
SOURCE = EXP / "vivid_rgb_point_center_refiner_development_oof_v4"
OUT = EXP / "vivid_rgb_point_center_refiner_geometry_gate_v4"
VERSION = "vivid-rgb-point-center-refiner-geometry-gate-v4"


def load_cache() -> list[dict]:
    result = []
    for record in base.rows(base.DEV_MANIFEST):
        filename = record["sample_id"].replace(":", "_") + ".npz"
        with np.load(base.BASE / filename, allow_pickle=False) as payload:
            points = payload["cru"].astype(np.float32)
            truth = payload["truth"].astype(np.float32)
            reliability = payload["reliability"].astype(np.float32)
        with np.load(SOURCE / "oof_inference_cache" / filename, allow_pickle=False) as payload:
            offset = payload["offset"].astype(np.float32)
            confidence = payload["confidence"].astype(np.float32)
        image_size = (int(record["width"]), int(record["height"]))
        scale = 1024.0 / max(image_size)
        result.append({"sample_id": record["sample_id"], "image_size": image_size,
                       "scale": scale, "points": points, "truth": truth,
                       "reliability": reliability,
                       "point_spacing": base.spacing(points, scale),
                       "offset": offset, "confidence": confidence})
    return result


def apply(item: dict, *, alpha: float, confidence_threshold: float,
          minimum_spacing: float, fraction: float, absolute_limit: float) -> np.ndarray:
    result = item["points"].copy()
    if not len(result):
        return result
    gate = ((item["confidence"] >= confidence_threshold)
            & (item["point_spacing"] >= minimum_spacing))
    shift = item["offset"] * alpha
    magnitude = np.linalg.norm(shift, axis=1)
    limit = np.minimum(absolute_limit, fraction * item["point_spacing"])
    shift *= np.minimum(1.0, limit / np.maximum(magnitude, 1e-6))[:, None]
    result[gate] += shift[gate] / item["scale"]
    width, height = item["image_size"]
    result[:, 0] = np.clip(result[:, 0], 0, width - 1e-3)
    result[:, 1] = np.clip(result[:, 1], 0, height - 1e-3)
    return result.astype(np.float32)


def strict(report: dict) -> bool:
    if not all(report["f1"]["repaired"][str(int(radius))]
               >= report["f1"]["baseline"][str(int(radius))]
               for radius in base.RADII):
        return False
    return all(
        report["scale_recall"][scale][str(int(radius))]["repaired"]
        >= report["scale_recall"][scale][str(int(radius))]["baseline"]
        for scale in ("far", "medium", "near") for radius in base.RADII
    )


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    cached = load_cache()
    configs = []
    grids = [(a, c, s, f, l)
             for a in (0.50, 0.75, 1.00)
             for c in (0.50, 0.65, 0.80)
             for s in (12.0, 16.0, 20.0, 24.0, 28.0, 32.0, 40.0)
             for f in (0.10, 0.20, 0.30)
             for l in (4.0, 8.0, 12.0)]
    for index, (alpha, confidence, spacing_minimum, fraction, limit) in enumerate(grids):
        predictions = [apply(item, alpha=alpha, confidence_threshold=confidence,
                             minimum_spacing=spacing_minimum, fraction=fraction,
                             absolute_limit=limit) for item in cached]
        report = base.evaluate(cached, predictions)
        configs.append({"alpha": alpha, "confidence_threshold": confidence,
                        "minimum_spacing": spacing_minimum,
                        "spacing_fraction": fraction, "absolute_limit": limit,
                        "eligible": strict(report), **report})
        if (index + 1) % 84 == 0:
            print(f"geometry gate {index + 1}/{len(grids)}", flush=True)
    eligible = [row for row in configs if row["eligible"]]
    selected = max(eligible or configs, key=lambda row: (
        row["image_gains"]["4"]["net_tp"],
        row["image_gains"]["8"]["net_tp"],
        row["image_gains"]["16"]["net_tp"],
        -row["image_gains"]["4"]["worsened"],
    ))
    predictions = [apply(item, alpha=float(selected["alpha"]),
                         confidence_threshold=float(selected["confidence_threshold"]),
                         minimum_spacing=float(selected["minimum_spacing"]),
                         fraction=float(selected["spacing_fraction"]),
                         absolute_limit=float(selected["absolute_limit"]))
                   for item in cached]
    point_out = OUT / "oof_development_points"; point_out.mkdir(exist_ok=True)
    for item, points in zip(cached, predictions, strict=True):
        atomic_npz(point_out / (item["sample_id"].replace(":", "_") + ".npz"),
                   cru=points, truth=item["truth"], reliability=item["reliability"])
    protocol = {"version": VERSION,
                "runtime_inputs": ["RGB patch", "refiner confidence", "predicted point spacing"],
                "truth_used_at_runtime": False, "count_conserving": True,
                "source_oof": str(SOURCE), "source_sha256": file_sha256(Path(__file__)),
                "development_selected": True, "independent_confirmation": False,
                "router_b_used": False, "sealed_test_used": False}
    summary = {"status": "COMPLETE_OPEN_DEVELOPMENT_GROUP_OOF_GATE",
               "selected": selected, "eligible_configs": len(eligible),
               "configs_evaluated": len(configs), "protocol": protocol}
    atomic_json(OUT / "protocol.json", protocol)
    atomic_json(OUT / "summary.json", summary)
    atomic_json(OUT / "all_configs.json", configs)
    atomic_json(OUT / "progress.json", {"status": "COMPLETE", "selected": selected,
                                         "router_b_used": False, "sealed_test_used": False})
    print(json.dumps({"status": summary["status"], "selected": selected,
                      "eligible_configs": len(eligible),
                      "configs_evaluated": len(configs)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
