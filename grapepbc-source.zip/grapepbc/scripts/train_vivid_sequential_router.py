"""Train an adaptive sequential CRU router on the sealed Router-B role.

The router can observe only full-image LR outputs before a call.  After each
selected HR call, its state may additionally contain the correction returned
by that already-called expert.  Uncalled HR features and labels are never
router inputs.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import random
import sys
from typing import Iterable

import numpy as np
import torch
from torch.nn import functional as F

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

from geopriv.data.hash_utils import file_sha256
from geopriv.data.manifest import read_manifest
from geopriv.models.sequential_utility_router import (
    SequentialUtilityRouter,
    decode_utility,
    encode_utility,
)
from geopriv.routing import assign_points_to_tiles, make_core_halo_tiles
from run_vivid_hr_residual_fusion import predict as predict_residual


def atomic_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, default=str) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def atomic_checkpoint(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temporary)
    temporary.replace(path)


def append_jsonl(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(payload, ensure_ascii=False, default=str) + "\n")


def seed_all(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def source_family(sample_id: str) -> str:
    name = sample_id.split(":", 1)[-1].lower()
    if name.startswith("immature"):
        return "immature"
    if name.startswith("img_20"):
        return "phone_timestamp"
    if name.startswith("img"):
        return "img_camera"
    if "dsc" in name:
        return "dsc_camera"
    if name.isdigit() and len(name) >= 12:
        return "numeric_timestamp"
    if name.isdigit():
        return "numeric_short"
    return "other"


def count_bin(value: int) -> str:
    if value <= 50:
        return "01_le50"
    if value <= 100:
        return "02_51to100"
    if value <= 200:
        return "03_101to200"
    return "04_gt200"


def safe_name(sample_id: str) -> str:
    return sample_id.replace(":", "_")


def signed_log(value: float) -> float:
    return math.copysign(math.log1p(abs(value)), value) if value else 0.0


def summarize_counts(predicted: Iterable[int], truth: Iterable[int]) -> dict[str, float | int]:
    predicted_array = np.asarray(list(predicted), dtype=np.float64)
    truth_array = np.asarray(list(truth), dtype=np.float64)
    difference = predicted_array - truth_array
    return {
        "images": int(len(truth_array)),
        "mae": float(np.abs(difference).mean()),
        "rmse": float(np.sqrt(np.square(difference).mean())),
        "wape": float(np.abs(difference).sum() / max(truth_array.sum(), 1.0)),
        "mean_nae": float((np.abs(difference) / np.maximum(truth_array, 1.0)).mean()),
        "bias": float(difference.mean()),
    }


def prepare(args: argparse.Namespace) -> None:
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"non-empty output exists: {output}")
    output.mkdir(parents=True, exist_ok=True)
    inputs = args.inputs.resolve()
    input_summary = json.loads((inputs / "summary.json").read_text(encoding="utf-8"))
    input_protocol = json.loads((inputs / "protocol.json").read_text(encoding="utf-8"))
    if input_summary.get("status") != "COMPLETE_ROUTER_B_INPUTS":
        raise ValueError("Router-B inputs are incomplete")
    if not input_summary.get("router_B_used") or input_summary.get("sealed_test_used"):
        raise ValueError("unexpected data-role boundary")
    residual = args.residual_run.resolve()
    residual_summary = json.loads((residual / "summary.json").read_text(encoding="utf-8"))
    if residual_summary.get("router_B_used") or residual_summary.get("sealed_test_used"):
        raise ValueError("residual expert used a forbidden role")
    feature_names = [
        *(f"global_lr_{index}" for index in range(12)),
        "log1p_lr_image_count",
        "log1p_lr_core_count",
        "lr_core_share",
        "core_center_x",
        "core_center_y",
        "core_width_fraction",
        "core_height_fraction",
        "core_area_fraction",
        "core_row_fraction",
        "core_column_fraction",
        "touches_image_edge",
        "lr_score_mean",
        "lr_score_max",
        "lr_score_q25",
        "lr_score_q50",
        "lr_score_q75",
        "lr_point_mean_x",
        "lr_point_mean_y",
        "lr_point_std_x",
        "lr_point_std_y",
        "lr_point_boundary_fraction",
        "lr_point_grid_occupancy",
        "lr_point_grid_entropy",
        *(f"lr_point_grid_{index}" for index in range(16)),
        "log1p_probability_sum",
        "probability_mean",
        "probability_std",
        "probability_max",
        "probability_q90",
        "probability_share",
        "log1p_density_sum",
        "density_mean",
        "density_std",
        "density_max",
        "density_q90",
        "density_share",
        "valid_map_fraction",
        "state_current_count_signed_log",
        "state_delta_sum_signed_log",
        "state_delta_mean_signed_log",
        "state_delta_abs_mean_log",
        "state_positive_delta_fraction",
        "state_negative_delta_fraction",
        "state_calls_fraction",
        "state_remaining_fraction",
        "state_nearest_selected_distance",
        "state_mean_selected_distance",
        "state_same_row_selected_fraction",
        "state_same_column_selected_fraction",
    ]
    source_paths = (
        "scripts/train_vivid_sequential_router.py",
        "src/geopriv/models/sequential_utility_router.py",
        "scripts/run_vivid_hr_residual_fusion.py",
        "src/geopriv/routing/counterfactual.py",
    )
    protocol = {
        "version": "vivid-sequential-cru-router-v1",
        "status": "PREPARED",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "seed": 20261002,
        "inputs": str(inputs),
        "inputs_protocol_sha256": file_sha256(inputs / "protocol.json"),
        "inputs_summary_sha256": file_sha256(inputs / "summary.json"),
        "manifest": input_protocol["manifest"],
        "manifest_sha256": input_protocol["manifest_sha256"],
        "root": input_protocol["root"],
        "core_size": input_protocol["core_size"],
        "halo": input_protocol["halo"],
        "residual_checkpoint": str((residual / "best_val_mae.pt").resolve()),
        "residual_checkpoint_sha256": file_sha256(residual / "best_val_mae.pt"),
        "residual_protocol_sha256": file_sha256(residual / "protocol.json"),
        "feature_names": feature_names,
        "feature_dim": len(feature_names),
        "router": {
            "hidden_dim": 64,
            "bottleneck_dim": 32,
            "dropout": 0.10,
            "folds": 5,
            "max_epochs": 80,
            "early_stop_patience": 12,
            "batch_size": 512,
            "learning_rate": 0.0015,
            "weight_decay": 0.0002,
            "max_training_prefix_calls": 4,
            "random_prefix_orders": 3,
            "target": "state-dependent whole-image absolute-count-error reduction",
            "input_boundary": "LR-observable features plus outcomes from previously called HR cores only",
        },
        "policy_search": {
            "maximum_calls": [1, 2, 3, 4],
            "minimum_predicted_utility": [0.0, 0.25, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 5.0, 7.0, 10.0],
            "selection": "minimum Router-B grouped-OOF image MAE; ties prefer fewer calls",
        },
        "source_sha256": {path: file_sha256(PROJECT / path) for path in source_paths},
        "development_used_for_fitting": False,
        "router_B_used": True,
        "sealed_test_used": False,
    }
    atomic_json(output / "protocol.json", protocol)
    atomic_json(
        output / "progress.json",
        {"status": "PREPARED", "router_B_used": True, "sealed_test_used": False},
    )
    print(json.dumps(protocol, ensure_ascii=False, indent=2))


def verify(output: Path) -> dict[str, object]:
    protocol = json.loads((output / "protocol.json").read_text(encoding="utf-8"))
    for name, expected in protocol["source_sha256"].items():
        if file_sha256(PROJECT / name) != expected:
            raise ValueError(f"source drift: {name}")
    checks = (
        (Path(protocol["inputs"]) / "protocol.json", protocol["inputs_protocol_sha256"]),
        (Path(protocol["inputs"]) / "summary.json", protocol["inputs_summary_sha256"]),
        (Path(protocol["manifest"]), protocol["manifest_sha256"]),
        (Path(protocol["residual_checkpoint"]), protocol["residual_checkpoint_sha256"]),
    )
    for path, expected in checks:
        if file_sha256(path) != expected:
            raise ValueError(f"artifact drift: {path}")
    if not protocol["router_B_used"] or protocol["sealed_test_used"]:
        raise ValueError("unexpected role boundary")
    return protocol


def map_region(array: np.ndarray, valid: np.ndarray, affine: np.ndarray, tile) -> np.ndarray:
    corners = np.asarray(
        [[tile.core_x0, tile.core_y0, 1.0], [tile.core_x1, tile.core_y1, 1.0]],
        dtype=np.float32,
    )
    mapped = corners @ affine.T
    x0 = int(np.floor(min(mapped[:, 0]) / 2.0))
    x1 = int(np.ceil(max(mapped[:, 0]) / 2.0))
    y0 = int(np.floor(min(mapped[:, 1]) / 2.0))
    y1 = int(np.ceil(max(mapped[:, 1]) / 2.0))
    x0, x1 = max(x0, 0), min(x1, array.shape[1])
    y0, y1 = max(y0, 0), min(y1, array.shape[0])
    if x1 <= x0 or y1 <= y0:
        return np.empty(0, dtype=np.float32)
    region = array[y0:y1, x0:x1].astype(np.float32)
    mask = valid[y0:y1, x0:x1].astype(bool)
    return region[mask]


def distribution_features(points: np.ndarray, scores: np.ndarray, tile) -> list[float]:
    if len(points):
        x = np.clip((points[:, 0] - tile.core_x0) / max(tile.core_x1 - tile.core_x0, 1), 0.0, 1.0)
        y = np.clip((points[:, 1] - tile.core_y0) / max(tile.core_y1 - tile.core_y0, 1), 0.0, 1.0)
        grid_x = np.minimum((x * 4).astype(np.int64), 3)
        grid_y = np.minimum((y * 4).astype(np.int64), 3)
        histogram = np.bincount(grid_y * 4 + grid_x, minlength=16).astype(np.float32)
        histogram /= max(float(histogram.sum()), 1.0)
        nonzero = histogram[histogram > 0]
        entropy = float(-(nonzero * np.log(nonzero)).sum() / math.log(16.0))
        boundary = (x < 0.1) | (x > 0.9) | (y < 0.1) | (y > 0.9)
        spatial = [
            float(x.mean()), float(y.mean()), float(x.std()), float(y.std()),
            float(boundary.mean()), float((histogram > 0).mean()), entropy,
        ]
    else:
        histogram = np.zeros(16, dtype=np.float32)
        spatial = [0.5, 0.5, 0.0, 0.0, 0.0, 0.0, 0.0]
    if len(scores):
        score_stats = [
            float(scores.mean()), float(scores.max()),
            *[float(value) for value in np.quantile(scores, [0.25, 0.50, 0.75])],
        ]
    else:
        score_stats = [0.0] * 5
    return score_stats + spatial + histogram.tolist()


def map_features(values: np.ndarray, total: float) -> list[float]:
    if len(values):
        return [
            math.log1p(max(float(values.sum()), 0.0)),
            float(values.mean()), float(values.std()), float(values.max()),
            float(np.quantile(values, 0.90)),
            float(values.sum() / max(total, 1e-6)),
        ]
    return [0.0] * 6


def load_data(protocol: dict[str, object]) -> dict[str, dict[str, object]]:
    inputs = Path(protocol["inputs"])
    records = {record.sample_id: record for record in read_manifest(Path(protocol["manifest"]))}
    manifest_payloads = {
        row["sample_id"]: row
        for row in (
            json.loads(line)
            for line in Path(protocol["manifest"]).read_text(encoding="utf-8").splitlines()
            if line.strip()
        )
    }
    hr_rows = []
    for path in sorted((inputs / "hr").glob("*.npz")):
        with np.load(path, allow_pickle=False) as payload:
            hr_rows.append(
                {
                    "feature": payload["feature"].astype(np.float32),
                    "candidate_count": len(payload["candidate_native_xy"]),
                    "sample_id": str(payload["sample_id"]),
                    "tile_id": int(str(payload["tile_id"])),
                    "truth": int(payload["true_count"]),
                }
            )
    hr_lookup = {(row["sample_id"], row["tile_id"]): row for row in hr_rows}
    residual_features, residual_lr, residual_candidates, residual_keys = [], [], [], []
    images: dict[str, dict[str, object]] = {}
    for sample_id, record in sorted(records.items()):
        with np.load(inputs / "lr" / (safe_name(sample_id) + ".npz"), allow_pickle=False) as payload:
            lr_points = payload["lr"].astype(np.float32)
            lr_scores = payload["lr_scores"].astype(np.float32)
            global_features = payload["global_features"].astype(np.float32)
            probability = payload["center_probability"].astype(np.float32)
            density = payload["density"].astype(np.float32)
            valid = payload["valid_output"].astype(bool)
            affine = payload["forward_affine"].astype(np.float32)
            true_total = int(payload["true_count"])
        tiles = make_core_halo_tiles(
            record.width, record.height,
            core_size=int(protocol["core_size"]), halo=int(protocol["halo"]),
        )
        owners = assign_points_to_tiles(lr_points, tiles, strict=True)
        probability_total = float(probability[valid].sum())
        density_total = float(density[valid].sum())
        rows = []
        max_row = max(tile.row for tile in tiles)
        max_column = max(tile.column for tile in tiles)
        for tile in tiles:
            chosen = owners == tile.tile_id
            core_points = lr_points[chosen]
            core_scores = lr_scores[chosen]
            hr = hr_lookup[(sample_id, tile.tile_id)]
            width_fraction = (tile.core_x1 - tile.core_x0) / record.width
            height_fraction = (tile.core_y1 - tile.core_y0) / record.height
            probability_values = map_region(probability, valid, affine, tile)
            density_values = map_region(density, valid, affine, tile)
            base = [
                *global_features.tolist(),
                math.log1p(len(lr_points)), math.log1p(len(core_points)),
                len(core_points) / max(len(lr_points), 1),
                (tile.core_x0 + tile.core_x1) / (2.0 * record.width),
                (tile.core_y0 + tile.core_y1) / (2.0 * record.height),
                width_fraction, height_fraction, width_fraction * height_fraction,
                tile.row / max(max_row, 1), tile.column / max(max_column, 1),
                float(tile.core_x0 == 0 or tile.core_y0 == 0 or tile.core_x1 == record.width or tile.core_y1 == record.height),
                *distribution_features(core_points, core_scores, tile),
                *map_features(probability_values, probability_total),
                *map_features(density_values, density_total),
                float(len(probability_values) / max((tile.core_x1 - tile.core_x0) * (tile.core_y1 - tile.core_y0) / 4.0, 1.0)),
            ]
            rows.append(
                {
                    "tile_id": tile.tile_id,
                    "row": tile.row,
                    "column": tile.column,
                    "center": np.asarray(base[15:17], dtype=np.float32),
                    "lr_count": len(core_points),
                    "truth": int(hr["truth"]),
                    "base": np.asarray(base, dtype=np.float32),
                    "hr_feature": hr["feature"],
                    "candidate_count": int(hr["candidate_count"]),
                }
            )
            residual_features.append(
                np.concatenate(
                    (
                        hr["feature"],
                        np.asarray(
                            [math.log1p(len(core_points)), math.log1p(len(lr_points)),
                             len(core_points) / max(len(lr_points), 1), math.log1p(hr["candidate_count"])],
                            dtype=np.float32,
                        ),
                    )
                )
            )
            residual_lr.append(len(core_points))
            residual_candidates.append(hr["candidate_count"])
            residual_keys.append((sample_id, tile.tile_id))
        images[sample_id] = {
            "sample_id": sample_id,
            "capture_group_id": manifest_payloads[sample_id].get("capture_group_id") or sample_id,
            "source_family": source_family(sample_id),
            "true_total": true_total,
            "lr_total": len(lr_points),
            "cores": rows,
        }
    residual_data = {
        "features": np.stack(residual_features).astype(np.float32),
        "lr_counts": np.asarray(residual_lr, dtype=np.int64),
        "candidate_counts": np.asarray(residual_candidates, dtype=np.int64),
    }
    checkpoint = torch.load(protocol["residual_checkpoint"], map_location="cpu", weights_only=False)
    final, fused, accepted, predicted_delta, predicted_error = predict_residual(checkpoint, residual_data)
    for index, key in enumerate(residual_keys):
        sample_id, tile_id = key
        core = images[sample_id]["cores"][tile_id]
        core["hr_count"] = int(final[index])
        core["raw_hr_count"] = int(fused[index])
        core["hr_accepted"] = bool(accepted[index])
        core["hr_delta"] = int(final[index]) - int(core["lr_count"])
        core["hr_predicted_error"] = float(predicted_error[index])
        core["hr_predicted_delta"] = float(predicted_delta[index])
    if len(images) != 188 or sum(len(value["cores"]) for value in images.values()) != 1824:
        raise ValueError("Router-B cache cardinality mismatch")
    if sum(value["true_total"] for value in images.values()) != 21035:
        raise ValueError("Router-B truth cardinality mismatch")
    return images


def state_features(image: dict[str, object], selected: tuple[int, ...], candidate: int, max_calls: int) -> np.ndarray:
    cores = image["cores"]
    core = cores[candidate]
    deltas = np.asarray([cores[index]["hr_delta"] for index in selected], dtype=np.float32)
    calls = len(selected)
    delta_sum = float(deltas.sum()) if calls else 0.0
    current_count = int(image["lr_total"]) + int(delta_sum)
    if calls:
        distances = np.asarray(
            [np.linalg.norm(core["center"] - cores[index]["center"]) for index in selected],
            dtype=np.float32,
        )
        same_row = np.mean([core["row"] == cores[index]["row"] for index in selected])
        same_column = np.mean([core["column"] == cores[index]["column"] for index in selected])
        state = [
            signed_log(current_count), signed_log(delta_sum), signed_log(float(deltas.mean())),
            math.log1p(float(np.abs(deltas).mean())), float((deltas > 0).mean()),
            float((deltas < 0).mean()), calls / max(max_calls, 1),
            (len(cores) - calls) / len(cores), float(distances.min()), float(distances.mean()),
            float(same_row), float(same_column),
        ]
    else:
        state = [signed_log(current_count), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.5, 1.5, 0.0, 0.0]
    return np.concatenate((core["base"], np.asarray(state, dtype=np.float32))).astype(np.float32)


def marginal_utility(image: dict[str, object], selected: tuple[int, ...], candidate: int) -> float:
    current = int(image["lr_total"]) + sum(image["cores"][index]["hr_delta"] for index in selected)
    truth = int(image["true_total"])
    delta = int(image["cores"][candidate]["hr_delta"])
    return float(abs(current - truth) - abs(current + delta - truth))


def prefix_states(image: dict[str, object], max_calls: int, random_orders: int, seed: int) -> list[tuple[int, ...]]:
    cores = image["cores"]
    orders = []
    orders.append(sorted(range(len(cores)), key=lambda index: (-cores[index]["lr_count"], index)))
    orders.append(sorted(range(len(cores)), key=lambda index: (-abs(cores[index]["hr_delta"]), index)))
    greedy, selected = [], tuple()
    for _ in range(min(max_calls, len(cores))):
        remaining = [index for index in range(len(cores)) if index not in selected]
        best = max(remaining, key=lambda index: (marginal_utility(image, selected, index), -index))
        greedy.append(best)
        selected = tuple(greedy)
    orders.append(greedy)
    rng = np.random.default_rng(seed)
    for _ in range(random_orders):
        orders.append(rng.permutation(len(cores)).tolist())
    states = {tuple()}
    for order in orders:
        for length in range(1, min(max_calls, len(order)) + 1):
            states.add(tuple(sorted(order[:length])))
    return sorted(states, key=lambda value: (len(value), value))


def build_supervision(images: dict[str, dict[str, object]], sample_ids: set[str], protocol: dict[str, object]):
    features, targets, weights, row_images, row_states = [], [], [], [], []
    max_calls = int(protocol["router"]["max_training_prefix_calls"])
    random_orders = int(protocol["router"]["random_prefix_orders"])
    for image_number, sample_id in enumerate(sorted(sample_ids)):
        image = images[sample_id]
        states = prefix_states(image, max_calls, random_orders, int(protocol["seed"]) + image_number)
        image_rows = []
        for state_number, selected in enumerate(states):
            remaining = [index for index in range(len(image["cores"])) if index not in selected]
            if not remaining:
                continue
            state_weight = 1.0 / (len(states) * len(remaining))
            for candidate in remaining:
                features.append(state_features(image, selected, candidate, max_calls))
                targets.append(marginal_utility(image, selected, candidate))
                weights.append(state_weight)
                row_images.append(sample_id)
                row_states.append(f"{sample_id}|{state_number}")
                image_rows.append(len(features) - 1)
        if image_rows:
            scale = 1.0 / max(sum(weights[index] for index in image_rows), 1e-12)
            for index in image_rows:
                weights[index] *= scale
    return {
        "features": np.stack(features).astype(np.float32),
        "target": np.asarray(targets, dtype=np.float32),
        "weights": np.asarray(weights, dtype=np.float32),
        "sample_ids": np.asarray(row_images),
        "state_ids": np.asarray(row_states),
    }


def grouped_folds(images: dict[str, dict[str, object]], folds: int, seed: int) -> dict[str, int]:
    grouped: dict[str, list[str]] = defaultdict(list)
    for sample_id, image in images.items():
        grouped[str(image["capture_group_id"])].append(sample_id)
    strata: dict[tuple[str, str], list[str]] = defaultdict(list)
    for group_id, sample_ids in grouped.items():
        truth = sum(int(images[sample_id]["true_total"]) for sample_id in sample_ids)
        family = Counter(images[sample_id]["source_family"] for sample_id in sample_ids).most_common(1)[0][0]
        strata[(family, count_bin(int(round(truth / len(sample_ids)))))] .append(group_id)
    rng = np.random.default_rng(seed)
    load = np.zeros(folds, dtype=np.int64)
    group_assignment = {}
    for key in sorted(strata):
        values = sorted(strata[key])
        rng.shuffle(values)
        for group_id in values:
            fold = int(np.argmin(load))
            group_assignment[group_id] = fold
            load[fold] += len(grouped[group_id])
    return {
        sample_id: group_assignment[str(image["capture_group_id"])]
        for sample_id, image in images.items()
    }


def model_instance(protocol: dict[str, object]) -> SequentialUtilityRouter:
    return SequentialUtilityRouter(
        int(protocol["feature_dim"]), int(protocol["router"]["hidden_dim"]),
        int(protocol["router"]["bottleneck_dim"]), float(protocol["router"]["dropout"]),
    )


def train_model(
    folder: Path,
    protocol: dict[str, object],
    training: dict[str, np.ndarray],
    validation: dict[str, np.ndarray] | None,
    epochs: int,
    seed: int,
) -> dict[str, object]:
    seed_all(seed)
    device = torch.device("cuda")
    mean = training["features"].mean(axis=0).astype(np.float32)
    std = training["features"].std(axis=0).astype(np.float32)
    std[std < 1e-5] = 1.0
    train_x = ((training["features"] - mean) / std).astype(np.float32)
    val_x = None if validation is None else ((validation["features"] - mean) / std).astype(np.float32)
    model = model_instance(protocol).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=float(protocol["router"]["learning_rate"]),
        weight_decay=float(protocol["router"]["weight_decay"]),
    )
    rng = np.random.default_rng(seed)
    best_key = (float("inf"), float("inf"))
    best_state, best_epoch = None, 0
    patience = 0
    history_path = folder / "history.jsonl"
    history_path.parent.mkdir(parents=True, exist_ok=True)
    history_path.write_text("", encoding="utf-8")
    for epoch in range(1, epochs + 1):
        model.train()
        order = rng.permutation(len(train_x))
        losses = []
        for start in range(0, len(order), int(protocol["router"]["batch_size"])):
            chosen = order[start : start + int(protocol["router"]["batch_size"])]
            x = torch.from_numpy(train_x[chosen]).to(device)
            truth = torch.from_numpy(training["target"][chosen]).to(device)
            weight = torch.from_numpy(training["weights"][chosen]).to(device)
            predicted = model(x)
            loss_rows = F.smooth_l1_loss(predicted, encode_utility(truth), beta=0.35, reduction="none")
            loss = (loss_rows * weight).sum() / weight.sum().clamp_min(1e-8)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(float(loss.detach()))
        model.eval()
        if validation is not None:
            predictions = []
            with torch.inference_mode():
                for start in range(0, len(val_x), 2048):
                    encoded = model(torch.from_numpy(val_x[start : start + 2048]).to(device))
                    predictions.append(decode_utility(encoded).cpu().numpy())
            predicted_raw = np.concatenate(predictions)
            absolute = np.abs(predicted_raw - validation["target"])
            val_mae = float(np.average(absolute, weights=validation["weights"]))
            val_sign = float(np.mean((predicted_raw > 0) == (validation["target"] > 0)))
            key = (val_mae, -val_sign)
        else:
            val_mae, val_sign, key = float("nan"), float("nan"), (float(epoch), 0.0)
        row = {
            "epoch": epoch, "training_loss": float(np.mean(losses)),
            "validation_utility_mae": val_mae, "validation_utility_sign_accuracy": val_sign,
        }
        append_jsonl(history_path, row)
        checkpoint = {
            "epoch": epoch, "target_epochs": epochs, "model": model.state_dict(),
            "optimizer": optimizer.state_dict(), "feature_mean": mean, "feature_std": std,
            "feature_names": protocol["feature_names"], "protocol": protocol,
        }
        atomic_checkpoint(folder / "last.pt", checkpoint)
        atomic_json(folder / "progress.json", {"status": "TRAINING", "last_completed_epoch": epoch, "requested_epochs": epochs, "router_B_used": True, "sealed_test_used": False})
        improved = validation is None or key < best_key
        if improved:
            best_key, best_epoch = key, epoch
            best_state = {name: value.detach().cpu().clone() for name, value in model.state_dict().items()}
            atomic_checkpoint(folder / "best_val_mae.pt", checkpoint)
            patience = 0
        else:
            patience += 1
        if validation is not None and patience >= int(protocol["router"]["early_stop_patience"]):
            break
    assert best_state is not None
    atomic_json(folder / "progress.json", {"status": "COMPLETE", "last_completed_epoch": epoch, "best_epoch": best_epoch, "router_B_used": True, "sealed_test_used": False})
    return {"state": best_state, "mean": mean, "std": std, "best_epoch": best_epoch, "best_key": best_key}


def predict_utilities(model_payload: dict[str, object], protocol: dict[str, object], features: np.ndarray) -> np.ndarray:
    normalized = ((features - model_payload["mean"]) / model_payload["std"]).astype(np.float32)
    model = model_instance(protocol).cuda()
    model.load_state_dict(model_payload["state"], strict=True)
    model.eval()
    with torch.inference_mode():
        encoded = model(torch.from_numpy(normalized).cuda())
        return decode_utility(encoded).cpu().numpy()


def simulate(
    image: dict[str, object], model_payload: dict[str, object], protocol: dict[str, object],
    threshold: float, max_calls: int,
) -> dict[str, object]:
    selected: tuple[int, ...] = tuple()
    scores = []
    while len(selected) < min(max_calls, len(image["cores"])):
        remaining = [index for index in range(len(image["cores"])) if index not in selected]
        features = np.stack([state_features(image, selected, index, max_calls) for index in remaining])
        utility = predict_utilities(model_payload, protocol, features)
        best_position = int(np.argmax(utility))
        best_index = remaining[best_position]
        best_score = float(utility[best_position])
        if best_score <= threshold:
            break
        selected = (*selected, best_index)
        scores.append(best_score)
    predicted = int(image["lr_total"]) + sum(image["cores"][index]["hr_delta"] for index in selected)
    return {"predicted": predicted, "selected": list(selected), "scores": scores, "calls": len(selected)}


def matched_density(image: dict[str, object], calls: int) -> int:
    chosen = sorted(range(len(image["cores"])), key=lambda index: (-image["cores"][index]["lr_count"], index))[:calls]
    return int(image["lr_total"]) + sum(image["cores"][index]["hr_delta"] for index in chosen)


def oracle(image: dict[str, object], max_calls: int) -> tuple[int, int]:
    selected: tuple[int, ...] = tuple()
    for _ in range(min(max_calls, len(image["cores"]))):
        remaining = [index for index in range(len(image["cores"])) if index not in selected]
        values = [marginal_utility(image, selected, index) for index in remaining]
        best = int(np.argmax(values))
        if values[best] <= 0:
            break
        selected = (*selected, remaining[best])
    prediction = int(image["lr_total"]) + sum(image["cores"][index]["hr_delta"] for index in selected)
    return prediction, len(selected)


def run(output: Path, protocol: dict[str, object]) -> None:
    images = load_data(protocol)
    if any(len(image["cores"]) == 0 for image in images.values()):
        raise ValueError("image without candidate cores")
    if len(next(iter(images.values()))["cores"][0]["base"]) + 12 != int(protocol["feature_dim"]):
        raise ValueError("router feature dimension mismatch")
    assignment = grouped_folds(images, int(protocol["router"]["folds"]), int(protocol["seed"]))
    atomic_json(output / "fold_assignment.json", assignment)
    fold_models, fold_reports, best_epochs = {}, [], []
    for fold in range(int(protocol["router"]["folds"])):
        train_ids = {sample_id for sample_id, value in assignment.items() if value != fold}
        val_ids = {sample_id for sample_id, value in assignment.items() if value == fold}
        training = build_supervision(images, train_ids, protocol)
        validation = build_supervision(images, val_ids, protocol)
        result = train_model(
            output / "oof" / f"fold_{fold}", protocol, training, validation,
            int(protocol["router"]["max_epochs"]), int(protocol["seed"]) + fold,
        )
        fold_models[fold] = result
        best_epochs.append(int(result["best_epoch"]))
        report = {
            "fold": fold, "train_images": len(train_ids), "validation_images": len(val_ids),
            "train_rows": len(training["target"]), "validation_rows": len(validation["target"]),
            "best_epoch": result["best_epoch"], "best_validation_utility_mae": result["best_key"][0],
        }
        fold_reports.append(report)
        atomic_json(output / "oof_progress.json", {"status": "OOF_TRAINING", "completed_folds": fold + 1, "folds": int(protocol["router"]["folds"]), "reports": fold_reports, "router_B_used": True, "sealed_test_used": False})
        print(json.dumps(report), flush=True)
    search_rows, policy_cache = [], {}
    for max_calls in protocol["policy_search"]["maximum_calls"]:
        for threshold in protocol["policy_search"]["minimum_predicted_utility"]:
            rows = []
            for sample_id, image in images.items():
                result = simulate(image, fold_models[assignment[sample_id]], protocol, float(threshold), int(max_calls))
                rows.append({"sample_id": sample_id, "truth": image["true_total"], **result})
            metrics = summarize_counts((row["predicted"] for row in rows), (row["truth"] for row in rows))
            item = {
                "maximum_calls": int(max_calls), "threshold": float(threshold), **metrics,
                "mean_calls": float(np.mean([row["calls"] for row in rows])),
                "zero_call_fraction": float(np.mean([row["calls"] == 0 for row in rows])),
            }
            search_rows.append(item)
            policy_cache[(int(max_calls), float(threshold))] = rows
    selected = min(search_rows, key=lambda row: (row["mae"], row["mean_calls"], row["maximum_calls"], row["threshold"]))
    selected_rows = policy_cache[(selected["maximum_calls"], selected["threshold"])]
    lr = summarize_counts((image["lr_total"] for image in images.values()), (image["true_total"] for image in images.values()))
    density_predictions = [matched_density(images[row["sample_id"]], row["calls"]) for row in selected_rows]
    density = summarize_counts(density_predictions, (row["truth"] for row in selected_rows))
    full_predictions = [int(image["lr_total"]) + sum(core["hr_delta"] for core in image["cores"]) for image in images.values()]
    full = summarize_counts(full_predictions, (image["true_total"] for image in images.values()))
    oracle_rows = [oracle(image, selected["maximum_calls"]) for image in images.values()]
    oracle_metrics = summarize_counts((value[0] for value in oracle_rows), (image["true_total"] for image in images.values()))
    oracle_metrics["mean_calls"] = float(np.mean([value[1] for value in oracle_rows]))
    random_mae = []
    sample_order = [row["sample_id"] for row in selected_rows]
    for repeat in range(200):
        rng = np.random.default_rng(int(protocol["seed"]) + 1000 + repeat)
        predictions = []
        for row, sample_id in zip(selected_rows, sample_order, strict=True):
            image = images[sample_id]
            chosen = rng.choice(len(image["cores"]), size=row["calls"], replace=False) if row["calls"] else []
            predictions.append(int(image["lr_total"]) + sum(image["cores"][int(index)]["hr_delta"] for index in chosen))
        random_mae.append(summarize_counts(predictions, (row["truth"] for row in selected_rows))["mae"])
    comparison = {
        "lr_no_hr_calls": lr,
        "random_matched_calls": {"mae_mean": float(np.mean(random_mae)), "mae_std": float(np.std(random_mae)), "repeats": 200},
        "lr_density_matched_calls": density,
        "sequential_cru_oof": selected,
        "full_residual_hr_all_cores": full,
        "truth_informed_oracle_at_selected_max_calls": oracle_metrics,
    }
    atomic_json(output / "policy_search.json", search_rows)
    atomic_json(output / "oof_per_image.json", selected_rows)
    atomic_json(output / "oof_comparison.json", comparison)
    final_epochs = max(1, int(round(float(np.median(best_epochs)))))
    all_supervision = build_supervision(images, set(images), protocol)
    final = train_model(
        output, protocol, all_supervision, None, final_epochs, int(protocol["seed"]) + 900,
    )
    final_checkpoint = torch.load(output / "last.pt", map_location="cpu", weights_only=False)
    final_checkpoint["selected_policy"] = {"maximum_calls": selected["maximum_calls"], "threshold": selected["threshold"]}
    final_checkpoint["selection_source"] = "Router-B grouped five-fold OOF only"
    atomic_checkpoint(output / "last.pt", final_checkpoint)
    atomic_checkpoint(output / "best_val_mae.pt", final_checkpoint)
    summary = {
        "status": "COMPLETE_ROUTER_B_GROUPED_OOF_AND_FINAL_FIT",
        "images": len(images), "cores": sum(len(image["cores"]) for image in images.values()),
        "groups": len({image["capture_group_id"] for image in images.values()}),
        "supervision_rows": len(all_supervision["target"]), "feature_dim": int(protocol["feature_dim"]),
        "router_parameters": sum(value.numel() for value in final_checkpoint["model"].values()),
        "folds": fold_reports, "best_epochs": best_epochs, "final_epochs": final_epochs,
        "selected_policy": selected, "comparison": comparison,
        "development_used_for_fitting": False, "router_B_used": True, "sealed_test_used": False,
        "next_stage": "evaluate the frozen router once on the existing development role; keep the 336-image test sealed",
    }
    atomic_json(output / "summary.json", summary)
    atomic_json(output / "progress.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def smoke(output: Path, protocol: dict[str, object]) -> None:
    images = load_data(protocol)
    sample_ids = set(sorted(images)[:4])
    data = build_supervision(images, sample_ids, protocol)
    model = model_instance(protocol).cuda()
    with torch.inference_mode():
        value = model(torch.from_numpy(data["features"][:3]).cuda())
    report = {
        "status": "PASS", "images_loaded": len(images), "cores_loaded": sum(len(image["cores"]) for image in images.values()),
        "smoke_images": len(sample_ids), "smoke_rows": len(data["target"]),
        "feature_dim": data["features"].shape[1], "model_output_shape": list(value.shape),
        "finite_features": bool(np.isfinite(data["features"]).all()),
        "finite_targets": bool(np.isfinite(data["target"]).all()),
        "router_B_used": True, "sealed_test_used": False,
    }
    if report["feature_dim"] != int(protocol["feature_dim"]) or not report["finite_features"] or not report["finite_targets"]:
        raise ValueError("smoke verification failed")
    atomic_json(output / "engineering_smoke.json", report)
    print(json.dumps(report, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("prepare", "smoke", "run"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--inputs", type=Path)
    parser.add_argument("--residual-run", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    if args.mode == "prepare":
        if args.inputs is None or args.residual_run is None:
            parser.error("prepare requires --inputs and --residual-run")
        prepare(args)
        return
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    torch.set_num_threads(4)
    protocol = verify(output)
    if args.mode == "smoke":
        smoke(output, protocol)
    else:
        smoke_report = json.loads((output / "engineering_smoke.json").read_text(encoding="utf-8"))
        if smoke_report.get("status") != "PASS":
            raise ValueError("passing engineering smoke is required")
        run(output, protocol)


if __name__ == "__main__":
    main()
