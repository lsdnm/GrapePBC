"""Finite paired HR trial; fresh initialization per arm and exact-epoch resume."""
import argparse
import copy
import json
import os
from pathlib import Path
import random
import time

import numpy as np
import torch
from torch.utils.data import DataLoader

from vivid_detail_runtime import (
    safe_load, atomic_checkpoint, rng_state, restore_rng,
    publish_epoch, repair_epoch, evaluate_counts,
)
from audit_cru_detail_readiness import read_json, save_json, sha
from train_cru_local_expert import ImageGroupedSampler
from geopriv.data import (CRUContextCropDataset, collate_cru_crops,
                         PrivilegedManifestDataset, collate_privileged_samples)
from geopriv.models.detail_expert import DetailPointExpert
from geopriv.training import GeoPrivLossWeights, build_geopriv_targets, geopriv_loss

WEIGHTS = GeoPrivLossWeights(center=1., offset=1., radius=0., density=0., count_conservation=0.)


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def verify_protocol(folder):
    protocol = read_json(folder / "protocol.json")
    project = Path(__file__).resolve().parents[1]
    for relative, digest in protocol["source_sha256"].items():
        if sha(project / relative) != digest:
            raise ValueError("code drift: " + relative)
    for key in ("manifest", "initial"):
        path = protocol["manifest"] if key == "manifest" else protocol["initial_checkpoint"]
        if sha(path) != protocol[key + "_sha256"]:
            raise ValueError(key + " drift")
    if protocol["test_used"] or protocol["router_B_used"]:
        raise ValueError("sealed roles are forbidden")
    return protocol


def make_model(protocol, variant):
    seed_all(protocol["seed"])
    model = DetailPointExpert(detail=variant == "detail").cuda()
    model.load_counter_state(safe_load(protocol["initial_checkpoint"])["model"])
    return model


def make_loader(protocol, split):
    dataset = CRUContextCropDataset(
        protocol["manifest"], protocol["root"], split=split,
        image_size=protocol["input_size"], core_size=protocol["core_size"], halo=protocol["halo"])
    sampler = ImageGroupedSampler(dataset, protocol["seed"]) if split == "train" else None
    loader = DataLoader(dataset, batch_size=protocol["batch_size"] if sampler else 1,
                        sampler=sampler, collate_fn=collate_cru_crops, num_workers=0,
                        pin_memory=True)
    return dataset, loader, sampler


def step(model, optimizer, scaler, batch, *, amp_enabled):
    model.train()
    optimizer.zero_grad(set_to_none=True)
    with torch.amp.autocast("cuda", dtype=torch.float16, enabled=amp_enabled):
        outputs = model(batch["images"].cuda(), batch["valid_image_masks"].cuda())
        target = build_geopriv_targets(
            [t["points_xy"] for t in batch["targets"]],
            valid_image_mask=batch["valid_image_masks"],
            output_height=outputs["center_logits"].shape[-2],
            output_width=outputs["center_logits"].shape[-1],
            stride=2, gaussian_radius=1, density_sigma=1., device="cpu")
        target = {k: v.cuda() for k, v in target.items()}
        loss = geopriv_loss(outputs, target, weights=WEIGHTS)["loss"]
    if not torch.isfinite(loss):
        raise FloatingPointError("non-finite training loss")
    scaler.scale(loss).backward()
    scaler.unscale_(optimizer)
    norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 5., error_if_nonfinite=True)
    scaler.step(optimizer)
    scaler.update()
    return float(loss.detach()), float(norm)


def optimizer_for(model, protocol):
    return torch.optim.AdamW(model.parameters(), lr=protocol["learning_rate"],
                             weight_decay=protocol["weight_decay"])


def smoke(folder, protocol):
    _, loader, _ = make_loader(protocol, "train")
    batch = next(iter(loader))
    control, detail = make_model(protocol, "control"), make_model(protocol, "detail")
    control.eval()
    detail.eval()
    with torch.inference_mode():
        x, mask = batch["images"][:1].cuda(), batch["valid_image_masks"][:1].cuda()
        a, b = control(x, mask), detail(x, mask, return_features=True)
        parity = max(float((a[k]-b[k]).abs().max()) for k in ("center_logits", "offsets"))
        feature_shape = list(b["detail_features"].shape)
    if parity != 0:
        raise ValueError("initial arms are not numerically identical")
    parameter_counts = {n: sum(p.numel() for p in m.parameters())
                        for n, m in (("control", control), ("detail", detail))}
    del control, a, b, x, mask
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    optimizer = optimizer_for(detail, protocol)
    scaler = torch.amp.GradScaler("cuda", init_scale=protocol["amp_initial_scale"],
                                 enabled=protocol["amp_enabled"])
    started = time.monotonic()
    loss1, _ = step(detail, optimizer, scaler, batch, amp_enabled=protocol["amp_enabled"])
    state = {"model": detail.state_dict(), "optimizer": optimizer.state_dict(),
             "scaler": scaler.state_dict(), "rng": rng_state()}
    atomic_checkpoint(folder / "engineering_smoke.pt", state)
    loss2, _ = step(detail, optimizer, scaler, batch, amp_enabled=protocol["amp_enabled"])
    uninterrupted = {k: v.detach().cpu().clone() for k, v in detail.state_dict().items()}
    del state, detail, optimizer, scaler
    torch.cuda.empty_cache()
    restored = make_model(protocol, "detail")
    loaded = safe_load(folder / "engineering_smoke.pt")
    restored.load_state_dict(loaded["model"])
    opt2 = optimizer_for(restored, protocol)
    opt2.load_state_dict(loaded["optimizer"])
    scaler2 = torch.amp.GradScaler("cuda", init_scale=protocol["amp_initial_scale"],
                                  enabled=protocol["amp_enabled"])
    scaler2.load_state_dict(loaded["scaler"])
    restore_rng(loaded["rng"])
    resumed_loss, _ = step(restored, opt2, scaler2, batch, amp_enabled=protocol["amp_enabled"])
    difference = max(float((uninterrupted[k] - v.cpu()).abs().max())
                     for k, v in restored.state_dict().items())
    if difference > 1e-6 or abs(resumed_loss - loss2) > 1e-6:
        raise ValueError(f"resume parity failed: {difference}")
    report = {"status": "PASS", "initial_count_max_abs_difference": parity,
              "resume_max_abs_difference": difference, "losses": [loss1, loss2, resumed_loss],
              "parameters": parameter_counts, "feature_shape": feature_shape,
              "peak_allocated_mib": torch.cuda.max_memory_allocated()/2**20,
              "seconds": time.monotonic()-started, "test_used": False,
              "note": "engineering only; features not trained for cluster separation"}
    save_json(folder / "engineering_smoke.json", report)
    print(json.dumps(report), flush=True)


def train_variant(folder, protocol, variant):
    run = folder / variant
    run.mkdir(exist_ok=True)
    model = make_model(protocol, variant)
    optimizer = optimizer_for(model, protocol)
    scaler = torch.amp.GradScaler("cuda", init_scale=protocol["amp_initial_scale"],
                                 enabled=protocol["amp_enabled"])
    train, loader, sampler = make_loader(protocol, "train")
    val, val_loader, _ = make_loader(protocol, "val")
    if len(train.records) != protocol["train_images"] or len(val.records) != protocol["val_images"]:
        raise ValueError("data scope changed")
    start, history = 1, []
    last_path = run / "last.pt"
    if last_path.exists():
        checkpoint = safe_load(last_path)
        if checkpoint["protocol"] != protocol or checkpoint["variant"] != variant:
            raise ValueError("resume protocol mismatch")
        model.load_state_dict(checkpoint["model"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        scaler.load_state_dict(checkpoint["scaler"])
        restore_rng(checkpoint["rng"])
        repair_epoch(run, checkpoint)
        start, history = checkpoint["epoch"] + 1, checkpoint["history"]
        best_metrics, best_epoch = checkpoint["best_metrics"], checkpoint["best_epoch"]
        best_model = checkpoint["best_model"]
        del checkpoint
    else:
        initial_path = folder / "initial_hr_validation.json"
        if initial_path.exists():
            initial = read_json(initial_path)
        else:
            initial = evaluate_counts(model, val_loader, protocol["thresholds"], core=True,
                                      heartbeat=run / "live_progress.json")
            save_json(initial_path, initial)
        best_metrics, best_epoch = initial["selected"], 0
        best_model = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        publish_epoch(run, dict(model=model.state_dict(), optimizer=optimizer.state_dict(),
            scaler=scaler.state_dict(), rng=rng_state(), epoch=0, protocol=protocol,
            variant=variant, history=[], best_epoch=0, best_metrics=best_metrics, best_model=best_model))
    for epoch in range(start, protocol["epochs"] + 1):
        if (folder / "STOP_AFTER_EPOCH").exists():
            return False
        sampler.set_epoch(epoch)
        # No dropout or random augmentation, but reset loader RNG explicitly for
        # identical paired data order independent of architecture initialization.
        seed_all(protocol["seed"] + epoch)
        torch.cuda.reset_peak_memory_stats()
        started = time.monotonic()
        total, batches = 0., 0
        for index, batch in enumerate(loader):
            loss, grad_norm = step(model, optimizer, scaler, batch, amp_enabled=protocol["amp_enabled"])
            total, batches = total + loss, batches + 1
            if index % 20 == 0:
                save_json(run / "live_progress.json", dict(status="training", epoch=epoch,
                    completed_batches=index+1, total_batches=len(loader), loss=loss,
                    gradient_norm=grad_norm, pid=os.getpid()))
        metrics = evaluate_counts(model, val_loader, protocol["thresholds"], core=True,
                                  heartbeat=run / "live_progress.json")
        save_json(run / f"validation_epoch_{epoch:02d}.json", metrics)
        selected = metrics["selected"]
        key = lambda m: (m["mae"], m["rmse"], m["threshold"])
        if key(selected) < key(best_metrics):
            best_metrics, best_epoch = selected, epoch
            best_model = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        row = dict(epoch=epoch, train_loss=total/batches, validation=selected,
                   best_epoch=best_epoch, seconds=time.monotonic()-started,
                   peak_allocated_mib=torch.cuda.max_memory_allocated()/2**20)
        history.append(row)
        publish_epoch(run, dict(model=model.state_dict(), optimizer=optimizer.state_dict(),
            scaler=scaler.state_dict(), rng=rng_state(), epoch=epoch, protocol=protocol,
            variant=variant, history=history, best_epoch=best_epoch,
            best_metrics=best_metrics, best_model=best_model))
        print(json.dumps({"variant": variant, **row}), flush=True)
    return True


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--trial", required=True, type=Path)
    p.add_argument("--mode", choices=["smoke", "train"], required=True)
    args = p.parse_args()
    folder = args.trial.resolve()
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA required for this frozen pilot")
    protocol = verify_protocol(folder)
    # OS lock releases on interruption; a stale filename cannot block recovery.
    import msvcrt
    with (folder / "worker.lock").open("a+b") as lock:
        if lock.tell() == 0:
            lock.write(b"0")
            lock.flush()
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        try:
            if args.mode == "smoke":
                smoke(folder, protocol)
            else:
                if read_json(folder / "engineering_smoke.json")["status"] != "PASS":
                    raise ValueError("engineering smoke required")
                if read_json(folder / "stage.json")["status"] not in (
                    "AUDIT_AND_LR_BASELINE_COMPLETE", "RUNNING", "FAILED_OR_INTERRUPTED",
                    "PAUSED_AFTER_EPOCH", "PILOT_COMPLETE_REVIEW_REQUIRED"):
                    raise ValueError("baseline stage incomplete")
                save_json(folder / "stage.json", dict(status="RUNNING", pid=os.getpid(),
                    scope="two arms x 3 epochs; no automatic router/boxes/test", test_used=False))
                # Re-evaluate LR under the identical deterministic execution policy.
                if not (folder / "lr_baseline.json").exists():
                    low = make_model(protocol, "control")
                    ds = PrivilegedManifestDataset(protocol["manifest"], protocol["root"],
                        split="val", image_size=protocol["lr_input_size"], augmentation=False)
                    dl = DataLoader(ds, batch_size=1, collate_fn=collate_privileged_samples)
                    lr_result = evaluate_counts(low, dl, [protocol["lr_threshold"]], core=False,
                                                heartbeat=folder / "baseline_live.json")
                    save_json(folder / "lr_baseline.json", lr_result)
                    del low, dl, ds
                    torch.cuda.empty_cache()
                for variant in protocol["variants"]:
                    if not train_variant(folder, protocol, variant):
                        save_json(folder / "stage.json", dict(status="PAUSED_AFTER_EPOCH", test_used=False))
                        return
                    torch.cuda.empty_cache()
                save_json(folder / "stage.json", dict(
                    status="PILOT_COMPLETE_REVIEW_REQUIRED", test_used=False,
                    results={v: read_json(folder/v/"progress.json") for v in protocol["variants"]}))
        except BaseException as exc:
            save_json(folder / "failure.json", {"mode": args.mode, "error": repr(exc),
                                               "test_used": False})
            if args.mode == "train":
                save_json(folder / "stage.json", dict(status="FAILED_OR_INTERRUPTED", error=repr(exc)))
            raise


if __name__ == "__main__":
    main()
