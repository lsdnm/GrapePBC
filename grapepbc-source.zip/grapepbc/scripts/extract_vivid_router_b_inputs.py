"""Resume-safe frozen LR and rich-HR extraction for clean Router-B only."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import sys
import time

import joblib
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

from evaluate_geopriv import restore_model
from geopriv.data import CRUContextCropDataset, PointManifestDataset, collate_point_samples
from geopriv.data.hash_utils import file_sha256
from geopriv.data.manifest import read_manifest
from geopriv.metrics import aggregate_count_metrics
from geopriv.models import decode_points
import run_vivid_hr_core_calibration as hr_stage


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    temporary.replace(path)


def atomic_npz(path: Path, **arrays: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("wb") as stream:
        np.savez_compressed(stream, **arrays)
    temporary.replace(path)


def round_half_up(value: float) -> int:
    if not math.isfinite(value):
        raise ValueError("non-finite calibrated count")
    return max(0, int(math.floor(value + 0.5)))


def to_native(points: np.ndarray, inverse: np.ndarray) -> np.ndarray:
    points = np.asarray(points, dtype=np.float32).reshape(-1, 2)
    if not len(points):
        return points.copy()
    homogeneous = np.column_stack((points, np.ones(len(points), dtype=np.float32)))
    mapped = homogeneous @ np.asarray(inverse, dtype=np.float32).T
    return (mapped[:, :2] / mapped[:, 2:3]).astype(np.float32)


def prepare(args: argparse.Namespace) -> None:
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"non-empty output exists: {output}")
    output.mkdir(parents=True, exist_ok=True)
    manifest = args.manifest.resolve()
    records = read_manifest(manifest)
    if len(records) != 188 or sum(record.point_count for record in records) != 21035:
        raise ValueError("unexpected clean Router-B manifest")
    lr_source = json.loads(args.lr_protocol.read_text(encoding="utf-8"))
    hr_source = json.loads(args.hr_protocol.read_text(encoding="utf-8"))
    if lr_source.get("router_B_used") or lr_source.get("sealed_test_used"):
        raise ValueError("LR source protocol is contaminated")
    if hr_source.get("router_B_used") or hr_source.get("sealed_test_used"):
        raise ValueError("HR source protocol is contaminated")
    protocol = {
        "version": "vivid-router-b-frozen-inputs-v1",
        "status": "PREPARED",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "manifest": str(manifest),
        "manifest_sha256": file_sha256(manifest),
        "root": str(args.root.resolve()),
        "images": len(records),
        "points": sum(record.point_count for record in records),
        "lr_source_protocol": str(args.lr_protocol.resolve()),
        "lr_source_protocol_sha256": file_sha256(args.lr_protocol),
        "lr_checkpoint": lr_source["checkpoint"],
        "lr_checkpoint_sha256": lr_source["checkpoint_sha256"],
        "lr_calibrator": lr_source["calibrator"],
        "lr_calibrator_sha256": lr_source["calibrator_sha256"],
        "lr_calibration_report": lr_source["calibration_report"],
        "lr_calibration_report_sha256": lr_source["calibration_report_sha256"],
        "hr_source_protocol": str(args.hr_protocol.resolve()),
        "hr_source_protocol_sha256": file_sha256(args.hr_protocol),
        "hr_checkpoint": hr_source["hr_checkpoint"],
        "hr_checkpoint_sha256": hr_source["hr_checkpoint_sha256"],
        "deep_backbone_checkpoint": hr_source["deep_backbone_checkpoint"],
        "deep_backbone_checkpoint_sha256": hr_source["deep_backbone_checkpoint_sha256"],
        "input_size": hr_source["input_size"],
        "core_size": hr_source["core_size"],
        "halo": hr_source["halo"],
        "candidate_score_floor": hr_source["candidate_score_floor"],
        "candidate_limit": hr_source["candidate_limit"],
        "local_max_kernel": hr_source["local_max_kernel"],
        "score_thresholds": hr_source["score_thresholds"],
        "feature_names": hr_source["feature_names"],
        "feature_dim": hr_source["feature_dim"],
        "source_sha256": {
            "scripts/extract_vivid_router_b_inputs.py": file_sha256(Path(__file__)),
            "scripts/run_vivid_hr_core_calibration.py": file_sha256(PROJECT / "scripts/run_vivid_hr_core_calibration.py"),
        },
        "router_B_used": True,
        "sealed_test_used": False,
    }
    atomic_json(output / "protocol.json", protocol)
    atomic_json(output / "progress.json", {"status": "PREPARED", "router_B_used": True, "sealed_test_used": False})
    print(json.dumps(protocol, ensure_ascii=False, indent=2), flush=True)


def verify(output: Path) -> dict[str, object]:
    protocol = json.loads((output / "protocol.json").read_text(encoding="utf-8"))
    for path_key, hash_key in (
        ("manifest", "manifest_sha256"),
        ("lr_source_protocol", "lr_source_protocol_sha256"),
        ("lr_checkpoint", "lr_checkpoint_sha256"),
        ("lr_calibrator", "lr_calibrator_sha256"),
        ("lr_calibration_report", "lr_calibration_report_sha256"),
        ("hr_source_protocol", "hr_source_protocol_sha256"),
        ("hr_checkpoint", "hr_checkpoint_sha256"),
        ("deep_backbone_checkpoint", "deep_backbone_checkpoint_sha256"),
    ):
        if file_sha256(Path(protocol[path_key])) != protocol[hash_key]:
            raise ValueError(f"artifact drift: {path_key}")
    for name, expected in protocol["source_sha256"].items():
        if file_sha256(PROJECT / name) != expected:
            raise ValueError(f"source drift: {name}")
    if not protocol["router_B_used"] or protocol["sealed_test_used"]:
        raise ValueError("role boundary drift")
    return protocol


@torch.inference_mode()
def extract_lr(output: Path, protocol: dict[str, object]) -> dict[str, object]:
    report = json.loads(Path(protocol["lr_calibration_report"]).read_text(encoding="utf-8"))
    thresholds = [float(value) for value in report["peak_thresholds"]]
    calibrator = joblib.load(protocol["lr_calibrator"])
    checkpoint = torch.load(protocol["lr_checkpoint"], map_location="cpu", weights_only=False)
    model, kind, _ = restore_model(checkpoint, "geopriv")
    if kind != "geopriv":
        raise ValueError("enhanced LR requires GeoPrivNet")
    model = model.cuda().eval()
    dataset = PointManifestDataset(protocol["manifest"], protocol["root"], split="train", image_size=1024)
    loader = DataLoader(dataset, batch_size=1, shuffle=False, num_workers=0, collate_fn=collate_point_samples, pin_memory=True)
    predicted, target_counts = [], []
    started = time.monotonic()
    for index, batch in enumerate(loader):
        sample_id = str(batch["targets"][0]["sample_id"])
        destination = output / "lr" / f"{sample_id.replace(':', '_')}.npz"
        if destination.exists():
            with np.load(destination, allow_pickle=False) as cached:
                predicted.append(len(cached["lr"]))
                target_counts.append(int(cached["true_count"]))
            continue
        images = batch["images"].cuda(non_blocking=True)
        masks = batch["valid_image_masks"].cuda(non_blocking=True)
        outputs = model(images, masks)
        probability = outputs["center_logits"].float().sigmoid()
        mask4d = masks[:, None] if masks.ndim == 3 else masks
        valid = F.interpolate(mask4d.float(), size=probability.shape[-2:], mode="nearest").bool()
        probability = probability.masked_fill(~valid, 0.0)
        density = F.softplus(outputs["density_logits"].float()).masked_fill(~valid, 0.0)
        local = probability * (probability == F.max_pool2d(probability, 3, 1, 1))
        peaks = [int(((local[0, 0] >= threshold) & valid[0, 0]).sum()) for threshold in thresholds]
        global_features = np.asarray(
            [
                np.log1p(float(density.sum())),
                np.log1p(float(probability.sum())),
                np.log1p(int(valid[0, 0].sum())),
                *[np.log1p(value) for value in peaks],
            ],
            dtype=np.float32,
        )
        requested = round_half_up(float(np.expm1(calibrator.predict(global_features[None].astype(np.float64))[0])))
        candidates = decode_points(outputs, score_threshold=1e-6, topk=4096, local_max_kernel=3, output_stride=model.output_stride)[0]
        count = min(requested, len(candidates["points"]), 4096)
        native = to_native(candidates["points"][:count].cpu().numpy(), batch["targets"][0]["inverse_affine"].numpy())
        true_count = int(batch["targets"][0]["count"])
        atomic_npz(
            destination,
            lr=native,
            lr_scores=candidates["scores"][:count].cpu().numpy().astype(np.float32),
            true_count=np.asarray(true_count, dtype=np.int64),
            requested_k=np.asarray(requested, dtype=np.int64),
            global_features=global_features,
            center_probability=probability[0, 0].cpu().numpy().astype(np.float16),
            density=density[0, 0].cpu().numpy().astype(np.float16),
            valid_output=valid[0, 0].cpu().numpy().astype(np.uint8),
            forward_affine=batch["targets"][0]["forward_affine"].numpy().astype(np.float32),
        )
        predicted.append(len(native))
        target_counts.append(true_count)
        if (index + 1) % 10 == 0 or index + 1 == len(dataset):
            atomic_json(
                output / "progress.json",
                {
                    "status": "EXTRACTING_ROUTER_B_LR",
                    "completed_images": index + 1,
                    "total_images": len(dataset),
                    "elapsed_seconds": time.monotonic() - started,
                    "router_B_used": True,
                    "sealed_test_used": False,
                },
            )
    summary = {"status": "COMPLETE", "images": len(dataset), "metrics": aggregate_count_metrics(predicted, target_counts)}
    atomic_json(output / "lr_summary.json", summary)
    del model
    torch.cuda.empty_cache()
    return summary


@torch.inference_mode()
def extract_hr(output: Path, protocol: dict[str, object]) -> dict[str, object]:
    dataset = CRUContextCropDataset(
        protocol["manifest"],
        protocol["root"],
        split="train",
        image_size=int(protocol["input_size"]),
        core_size=int(protocol["core_size"]),
        halo=int(protocol["halo"]),
        cache_images=2,
    )
    model = hr_stage.make_expert(protocol)
    started = time.monotonic()
    for index in range(len(dataset)):
        destination = output / "hr" / f"{index:06d}.npz"
        if destination.exists():
            continue
        row = hr_stage.extract_item(model, dataset[index], protocol)
        atomic_npz(
            destination,
            feature=row["feature"],
            candidate_native_xy=row["candidate_native_xy"],
            candidate_scores=row["candidate_scores"],
            sample_id=np.asarray(row["sample_id"]),
            tile_id=np.asarray(row["tile_id"]),
            true_count=np.asarray(row["true_count"], dtype=np.int64),
        )
        if (index + 1) % 20 == 0 or index + 1 == len(dataset):
            atomic_json(
                output / "progress.json",
                {
                    "status": "EXTRACTING_ROUTER_B_HR",
                    "completed_tiles": index + 1,
                    "total_tiles": len(dataset),
                    "elapsed_seconds": time.monotonic() - started,
                    "router_B_used": True,
                    "sealed_test_used": False,
                },
            )
    files = sorted((output / "hr").glob("*.npz"))
    if len(files) != len(dataset):
        raise ValueError("incomplete HR cache")
    total_truth = 0
    image_ids = set()
    for path in files:
        with np.load(path, allow_pickle=False) as item:
            total_truth += int(item["true_count"])
            image_ids.add(str(item["sample_id"]))
    if len(image_ids) != int(protocol["images"]) or total_truth != int(protocol["points"]):
        raise ValueError("HR core ownership audit failed")
    summary = {"status": "COMPLETE", "images": len(image_ids), "tiles": len(files), "owned_truth_points": total_truth}
    atomic_json(output / "hr_summary.json", summary)
    del model
    torch.cuda.empty_cache()
    return summary


def run(output: Path, protocol: dict[str, object]) -> None:
    atomic_json(output / "stage.json", {"status": "RUNNING", "pid": os.getpid(), "router_B_used": True, "sealed_test_used": False})
    lr_summary = extract_lr(output, protocol)
    hr_summary = extract_hr(output, protocol)
    summary = {
        "status": "COMPLETE_ROUTER_B_INPUTS",
        "lr": lr_summary,
        "hr": hr_summary,
        "router_B_used": True,
        "sealed_test_used": False,
    }
    atomic_json(output / "summary.json", summary)
    atomic_json(output / "stage.json", summary)
    atomic_json(output / "progress.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("prepare", "run"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--root", type=Path)
    parser.add_argument("--lr-protocol", type=Path)
    parser.add_argument("--hr-protocol", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    if args.mode == "prepare":
        if None in (args.manifest, args.root, args.lr_protocol, args.hr_protocol):
            parser.error("prepare requires manifest, root, LR protocol, and HR protocol")
        prepare(args)
        return
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    run(output, verify(output))


if __name__ == "__main__":
    main()
