"""Freeze a robust density-prior fusion for the small sequential CRU router."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

import numpy as np
import torch

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

import train_vivid_sequential_router as base
from geopriv.data.hash_utils import file_sha256
from geopriv.models.sequential_utility_router import decode_utility


def load_model(path: Path, protocol: dict[str, object]) -> dict[str, object]:
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    model = base.model_instance(protocol).cuda()
    model.load_state_dict(checkpoint["model"], strict=True)
    model.eval()
    return {
        "model": model,
        "mean": checkpoint["feature_mean"],
        "std": checkpoint["feature_std"],
    }


def predict(model: dict[str, object], features: np.ndarray) -> np.ndarray:
    normalized = ((features - model["mean"]) / model["std"]).astype(np.float32)
    with torch.inference_mode():
        encoded = model["model"](torch.from_numpy(normalized).cuda())
    return decode_utility(encoded).cpu().numpy()


def simulate(
    image: dict[str, object],
    model: dict[str, object],
    maximum_calls: int,
    threshold: float,
    density_weight: float,
) -> dict[str, object]:
    selected: list[int] = []
    predicted_utilities: list[float] = []
    while len(selected) < min(maximum_calls, len(image["cores"])):
        remaining = [index for index in range(len(image["cores"])) if index not in selected]
        features = np.stack(
            [base.state_features(image, tuple(selected), index, maximum_calls) for index in remaining]
        )
        utility = predict(model, features)
        density = np.log1p(
            np.asarray([image["cores"][index]["lr_count"] for index in remaining], dtype=np.float32)
        )
        utility_z = (utility - utility.mean()) / (utility.std() + 1e-6)
        density_z = (density - density.mean()) / (density.std() + 1e-6)
        score = (1.0 - density_weight) * utility_z + density_weight * density_z
        chosen_position = int(np.argmax(score))
        chosen = remaining[chosen_position]
        if float(utility[chosen_position]) <= threshold:
            break
        selected.append(chosen)
        predicted_utilities.append(float(utility[chosen_position]))
    predicted = int(image["lr_total"]) + sum(
        int(image["cores"][index]["hr_delta"]) for index in selected
    )
    return {
        "predicted": predicted,
        "selected": selected,
        "predicted_utilities": predicted_utilities,
        "calls": len(selected),
    }


def group_bootstrap(
    rows: list[dict[str, object]],
    value_key: str,
    groups: dict[str, str],
    repeats: int,
    seed: int,
) -> dict[str, float]:
    grouped: dict[str, list[float]] = {}
    for row in rows:
        group_id = groups[row["sample_id"]]
        grouped.setdefault(group_id, []).append(float(row[value_key]))
    group_ids = sorted(grouped)
    rng = np.random.default_rng(seed)
    values = np.empty(repeats, dtype=np.float64)
    for repeat in range(repeats):
        chosen = rng.choice(group_ids, size=len(group_ids), replace=True)
        sample = [item for group_id in chosen for item in grouped[group_id]]
        values[repeat] = float(np.mean(sample))
    return {
        "estimate": float(np.mean([row[value_key] for row in rows])),
        "group_bootstrap_95_ci_low": float(np.quantile(values, 0.025)),
        "group_bootstrap_95_ci_high": float(np.quantile(values, 0.975)),
        "bootstrap_repeats": repeats,
        "groups": len(group_ids),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--router-run", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    router_run = args.router_run.resolve()
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"non-empty output exists: {output}")
    output.mkdir(parents=True, exist_ok=True)
    protocol = json.loads((router_run / "protocol.json").read_text(encoding="utf-8"))
    if not protocol.get("router_B_used") or protocol.get("sealed_test_used"):
        raise ValueError("unexpected router role boundary")
    inputs_summary = json.loads((Path(protocol["inputs"]) / "summary.json").read_text(encoding="utf-8"))
    if inputs_summary.get("sealed_test_used"):
        raise ValueError("input cache touched sealed test")
    assignment = json.loads((router_run / "fold_assignment.json").read_text(encoding="utf-8"))
    images = base.load_data(protocol)
    fold_models = {
        fold: load_model(router_run / "oof" / f"fold_{fold}" / "best_val_mae.pt", protocol)
        for fold in range(int(protocol["router"]["folds"]))
    }
    search = []
    cached: dict[tuple[float, int, float], list[dict[str, object]]] = {}
    for density_weight in np.linspace(0.0, 1.0, 11):
        for maximum_calls in (1, 2, 3, 4):
            for threshold in (-0.25, -0.10, 0.0, 0.05, 0.10, 0.20, 0.30, 0.50):
                rows = []
                for sample_id, image in images.items():
                    result = simulate(
                        image, fold_models[int(assignment[sample_id])], maximum_calls,
                        threshold, float(density_weight),
                    )
                    rows.append(
                        {
                            "sample_id": sample_id,
                            "true_count": int(image["true_total"]),
                            "lr_count": int(image["lr_total"]),
                            **result,
                        }
                    )
                metrics = base.summarize_counts(
                    (row["predicted"] for row in rows),
                    (row["true_count"] for row in rows),
                )
                item = {
                    "density_weight": float(density_weight),
                    "maximum_calls": maximum_calls,
                    "threshold": threshold,
                    **metrics,
                    "mean_calls": float(np.mean([row["calls"] for row in rows])),
                    "zero_call_fraction": float(np.mean([row["calls"] == 0 for row in rows])),
                }
                search.append(item)
                cached[(float(density_weight), maximum_calls, threshold)] = rows
    selected = min(
        search,
        key=lambda row: (
            row["mae"], row["mean_calls"], row["maximum_calls"],
            abs(row["density_weight"] - 0.5), row["threshold"],
        ),
    )
    key = (
        selected["density_weight"], selected["maximum_calls"], selected["threshold"]
    )
    rows = cached[key]
    rng_mae = []
    for repeat in range(500):
        rng = np.random.default_rng(int(protocol["seed"]) + 5000 + repeat)
        predictions = []
        for row in rows:
            image = images[row["sample_id"]]
            chosen = (
                rng.choice(len(image["cores"]), size=row["calls"], replace=False)
                if row["calls"] else []
            )
            predictions.append(
                int(image["lr_total"])
                + sum(int(image["cores"][int(index)]["hr_delta"]) for index in chosen)
            )
        rng_mae.append(
            base.summarize_counts(predictions, (row["true_count"] for row in rows))["mae"]
        )
    density_prediction = [
        base.matched_density(images[row["sample_id"]], int(row["calls"])) for row in rows
    ]
    density_metrics = base.summarize_counts(
        density_prediction, (row["true_count"] for row in rows)
    )
    lr_metrics = base.summarize_counts(
        (row["lr_count"] for row in rows), (row["true_count"] for row in rows)
    )
    full_prediction = [
        int(image["lr_total"]) + sum(int(core["hr_delta"]) for core in image["cores"])
        for image in images.values()
    ]
    full_metrics = base.summarize_counts(
        full_prediction, (image["true_total"] for image in images.values())
    )
    for index, row in enumerate(rows):
        truth = int(row["true_count"])
        row["absolute_error"] = abs(int(row["predicted"]) - truth)
        row["lr_absolute_error"] = abs(int(row["lr_count"]) - truth)
        row["density_matched_count"] = int(density_prediction[index])
        row["density_absolute_error"] = abs(int(density_prediction[index]) - truth)
        row["improvement_vs_lr"] = row["lr_absolute_error"] - row["absolute_error"]
        row["improvement_vs_density"] = row["density_absolute_error"] - row["absolute_error"]
    groups = {sample_id: str(image["capture_group_id"]) for sample_id, image in images.items()}
    uncertainty = {
        "paired_improvement_vs_lr": group_bootstrap(rows, "improvement_vs_lr", groups, 10000, int(protocol["seed"]) + 7000),
        "paired_improvement_vs_density": group_bootstrap(rows, "improvement_vs_density", groups, 10000, int(protocol["seed"]) + 8000),
    }
    comparison = {
        "lr_no_hr_calls": lr_metrics,
        "random_matched_calls": {
            "mae_mean": float(np.mean(rng_mae)),
            "mae_std": float(np.std(rng_mae)),
            "repeats": len(rng_mae),
        },
        "density_matched_calls": density_metrics,
        "sequential_density_prior_cru": selected,
        "full_residual_hr_all_cores": full_metrics,
    }
    final_checkpoint = torch.load(router_run / "best_val_mae.pt", map_location="cpu", weights_only=False)
    final_checkpoint["selected_policy"] = {
        "density_weight": selected["density_weight"],
        "maximum_calls": selected["maximum_calls"],
        "minimum_predicted_utility": selected["threshold"],
        "selection_source": "Router-B grouped five-fold OOF only",
    }
    final_checkpoint["claim_boundary"] = "development and sealed test not used for policy selection"
    base.atomic_checkpoint(output / "router_package.pt", final_checkpoint)
    frozen_protocol = {
        "version": "vivid-sequential-density-prior-cru-v3",
        "status": "FROZEN_AFTER_ROUTER_B_GROUPED_OOF",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "router_run": str(router_run),
        "router_protocol_sha256": file_sha256(router_run / "protocol.json"),
        "router_checkpoint_sha256": file_sha256(router_run / "best_val_mae.pt"),
        "inputs_summary_sha256": file_sha256(Path(protocol["inputs"]) / "summary.json"),
        "selected_policy": final_checkpoint["selected_policy"],
        "fusion": "z-scored learned marginal utility and log1p LR core count",
        "source_sha256": {
            "scripts/select_vivid_router_density_fusion.py": file_sha256(Path(__file__)),
            "scripts/train_vivid_sequential_router.py": file_sha256(PROJECT / "scripts/train_vivid_sequential_router.py"),
            "src/geopriv/models/sequential_utility_router.py": file_sha256(PROJECT / "src/geopriv/models/sequential_utility_router.py"),
        },
        "development_used_for_fitting": False,
        "router_B_used": True,
        "sealed_test_used": False,
    }
    base.atomic_json(output / "protocol.json", frozen_protocol)
    base.atomic_json(output / "policy_search.json", search)
    base.atomic_json(output / "oof_per_image.json", rows)
    base.atomic_json(output / "oof_uncertainty.json", uncertainty)
    summary = {
        "status": "FROZEN_AFTER_ROUTER_B_GROUPED_OOF",
        "images": len(images),
        "groups": len(set(groups.values())),
        "selected_policy": selected,
        "comparison": comparison,
        "uncertainty": uncertainty,
        "router_parameters": sum(value.numel() for value in final_checkpoint["model"].values()),
        "development_used_for_fitting": False,
        "router_B_used": True,
        "sealed_test_used": False,
        "next_stage": "one-time existing-development evaluation before any sealed-test decision",
    }
    base.atomic_json(output / "summary.json", summary)
    base.atomic_json(output / "progress.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
