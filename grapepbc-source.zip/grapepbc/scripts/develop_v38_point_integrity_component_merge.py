"""Collapse high-confidence local duplicate components to one berry centre.

V36 merges disjoint pairs.  That is insufficient when three or more point
hypotheses compete for the same berry, because one point can remain after a
single pair is merged.  This stage groups accepted pair edges by their shared
Rich-HR candidate and collapses every connected component to that candidate.
The operation therefore enforces one output point per accepted local duplicate
component while retaining neighbouring points that lack shared semantic and
local-candidate evidence.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass
import json
from pathlib import Path
import sys

import numpy as np
from scipy.spatial import cKDTree


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

import develop_v36_local_duplicate_merge as v36  # noqa: E402
from run_vivid_hr_core_calibration import atomic_json  # noqa: E402


OUT = PROJECT / "experiments" / "cru_detail_v1" / "vivid_point_integrity_component_v38"


@dataclass(frozen=True)
class Policy:
    probability_threshold: float
    maximum_pair_distance_1024: float
    ultra_local_probability_threshold: float | None = None
    ultra_local_maximum_pair_distance_1024: float | None = None


POLICIES = tuple(
    Policy(probability_threshold=p, maximum_pair_distance_1024=d)
    for p in (0.70, 0.75, 0.80, 0.85)
    for d in (4.0, 6.0)
)


def candidate_components(pairs: list[dict], policy: Policy) -> list[dict]:
    """Return connected duplicate groups, keeping each HR candidate separate."""
    by_candidate: dict[int, list[dict]] = {}
    for row in pairs:
        primary_gate = (
            row["score"] >= policy.probability_threshold
            and row["distance"] <= policy.maximum_pair_distance_1024
        )
        ultra_local_gate = (
            policy.ultra_local_probability_threshold is not None
            and policy.ultra_local_maximum_pair_distance_1024 is not None
            and row["score"] >= policy.ultra_local_probability_threshold
            and row["distance"] <= policy.ultra_local_maximum_pair_distance_1024
        )
        if ((primary_gate or ultra_local_gate)
                and int(row["candidate_index"]) >= 0):
            by_candidate.setdefault(int(row["candidate_index"]), []).append(row)

    groups = []
    for candidate, edges in by_candidate.items():
        adjacency: dict[int, set[int]] = {}
        for row in edges:
            first, second = int(row["first"]), int(row["second"])
            adjacency.setdefault(first, set()).add(second)
            adjacency.setdefault(second, set()).add(first)
        unseen = set(adjacency)
        while unseen:
            seed = min(unseen); stack = [seed]; members = set()
            while stack:
                node = stack.pop()
                if node in members:
                    continue
                members.add(node); unseen.discard(node)
                stack.extend(adjacency.get(node, ()))
            component_edges = [
                row for row in edges
                if int(row["first"]) in members and int(row["second"]) in members
            ]
            groups.append({
                "candidate_index": candidate,
                "members": sorted(members),
                "score": max(float(row["score"]) for row in component_edges),
                "mean_score": float(np.mean([row["score"] for row in component_edges])),
                "maximum_edge_distance_1024": max(float(row["distance"]) for row in component_edges),
            })
    return sorted(groups, key=lambda row: (-row["score"], -row["mean_score"], row["maximum_edge_distance_1024"]))


def apply_policy(base: dict, pairs: list[dict], policy: Policy) -> tuple[np.ndarray, np.ndarray, dict]:
    consumed: set[int] = set(); selected = []
    for group in candidate_components(pairs, policy):
        members = [index for index in group["members"] if index not in consumed]
        if len(members) < 2:
            continue
        consumed.update(members)
        selected.append({**group, "members": members})

    points = base["points"].copy(); reliability = base["reliability"].copy()
    remove: set[int] = set(); diagnostics = []
    for group in selected:
        members = group["members"]; keeper = min(members); candidate = int(group["candidate_index"])
        old_points = points[members].copy()
        points[keeper] = base["candidates"][candidate]
        reliability[keeper] = max(float(np.max(reliability[members])), float(base["candidate_scores"][candidate]))
        removed = [index for index in members if index != keeper]
        remove.update(removed)
        diagnostics.append({
            "kept_index": keeper, "removed_indices": removed,
            "member_indices": members, "score": group["score"],
            "mean_score": group["mean_score"],
            "maximum_edge_distance_1024": group["maximum_edge_distance_1024"],
            "old_points_xy": old_points.tolist(), "merged_xy": points[keeper].tolist(),
            "candidate_index": candidate,
        })
    mask = np.ones(len(points), bool)
    if remove:
        mask[np.fromiter(sorted(remove), dtype=np.int64)] = False
    return points[mask], reliability[mask], {
        "components": len(selected), "merges": len(remove), "rows": diagnostics, "mask": mask,
    }


def evaluate(bases: list[dict], pairs_by_id: dict[str, list[dict]], policy: Policy) -> tuple[list[dict], dict]:
    rows = []; safe_removals = unsafe_removals = all_same_components = mixed_components = 0
    for base in bases:
        output, _, diagnostic = apply_policy(base, pairs_by_id[base["sample_id"]], policy)
        tree = cKDTree(base["truth"] * base["scale"]) if len(base["truth"]) else None
        for item in diagnostic["rows"]:
            member_truth = tree.query(base["points"][item["member_indices"]] * base["scale"])[1] if tree else np.arange(len(item["member_indices"]))
            target_truth = int(tree.query(np.asarray(item["merged_xy"]) * base["scale"])[1]) if tree else -1
            counts = Counter(int(value) for value in member_truth)
            all_same_components += int(len(counts) == 1 and next(iter(counts)) == target_truth)
            mixed_components += int(not (len(counts) == 1 and next(iter(counts)) == target_truth))
            kept_target = int(member_truth[item["member_indices"].index(item["kept_index"])])
            for index, truth_index in zip(item["member_indices"], member_truth):
                if index == item["kept_index"]:
                    continue
                safe_removals += int(int(truth_index) == target_truth == kept_target)
                unsafe_removals += int(not (int(truth_index) == target_truth == kept_target))

        stats = v36.metrics.point_stats(output, base["truth"], base["image_size"])
        candidate = {
            "stats": stats,
            "scale_recall": v36.metrics.scale_recall(output, base["truth"], base["image_size"]),
            "diagnostic": diagnostic,
        }
        rows.append({
            "sample_id": base["sample_id"], "group": base["group"],
            "baseline": base["baseline"], "candidate": candidate,
            "baseline_error": abs(len(base["points"]) - len(base["truth"])),
            "candidate_error": abs(len(output) - len(base["truth"])),
        })

    baseline = v36.metrics.aggregate(rows, "baseline")
    candidate = v36.metrics.aggregate(rows, "candidate")
    before = float(np.mean([row["baseline_error"] for row in rows]))
    after = float(np.mean([row["candidate_error"] for row in rows]))
    return rows, {
        "policy": asdict(policy), "baseline": baseline, "candidate": candidate,
        "components": int(sum(row["candidate"]["diagnostic"]["components"] for row in rows)),
        "merges": int(sum(row["candidate"]["diagnostic"]["merges"] for row in rows)),
        "images_changed": int(sum(row["candidate"]["diagnostic"]["merges"] > 0 for row in rows)),
        "all_same_truth_components": int(all_same_components),
        "mixed_truth_components": int(mixed_components),
        "safe_removals": int(safe_removals), "unsafe_removals": int(unsafe_removals),
        "removal_precision_proxy": float(safe_removals / max(safe_removals + unsafe_removals, 1)),
        "count_mae_before": before, "count_mae_after": after, "count_mae_gain": before - after,
        "f1_gain": {key: candidate["f1"][key] - baseline["f1"][key] for key in baseline["f1"]},
        "competition_reduction": baseline["competition_unmatched_within8"] - candidate["competition_unmatched_within8"],
        "collision_reduction": {key: baseline["collision_pairs"][key] - candidate["collision_pairs"][key] for key in baseline["collision_pairs"]},
        "symmetric_clipped32_change": candidate["symmetric_clipped32"] - baseline["symmetric_clipped32"],
    }


def main() -> None:
    if OUT.exists():
        raise SystemExit(f"refusing to overwrite existing experiment: {OUT}")
    OUT.mkdir(parents=True)
    bases, actions_by_id, scores_by_id = v36.prepare()
    pairs_by_id = {
        base["sample_id"]: v36.unique_pairs(base, actions_by_id[base["sample_id"]], scores_by_id[base["sample_id"]])
        for base in bases
    }
    reports = []; eligible_rows = []
    for policy in POLICIES:
        rows, report = evaluate(bases, pairs_by_id, policy)
        report["point_integrity_eligible"] = bool(
            report["merges"] >= 40
            and report["removal_precision_proxy"] >= 0.98
            and report["competition_reduction"] >= 35
            and all(value >= 0 for value in report["f1_gain"].values())
        )
        reports.append(report)
        if report["point_integrity_eligible"]:
            eligible_rows.append((rows, report))
        print(json.dumps({
            "policy": report["policy"], "components": report["components"],
            "merges": report["merges"], "removal_precision_proxy": report["removal_precision_proxy"],
            "competition_reduction": report["competition_reduction"], "f1_gain": report["f1_gain"],
            "count_mae_gain": report["count_mae_gain"], "eligible": report["point_integrity_eligible"],
        }, ensure_ascii=False), flush=True)

    eligible_rows.sort(key=lambda item: (
        item[1]["competition_reduction"], item[1]["removal_precision_proxy"],
        item[1]["f1_gain"]["4"], item[1]["f1_gain"]["8"], item[1]["f1_gain"]["16"],
    ), reverse=True)
    selected_rows, selected = eligible_rows[0] if eligible_rows else (None, None)
    summary = {
        "status": "POINT_INTEGRITY_COMPONENT_POLICY_FOUND" if selected else "NO_ACCEPTABLE_POLICY",
        "selected": selected,
        "bootstrap": v36.bootstrap(selected_rows) if selected_rows else None,
        "screened_policies": len(reports), "eligible_policies": len(eligible_rows),
        "development_selected": True, "independent_confirmation": False,
        "sealed_test_used": False,
    }
    atomic_json(OUT / "screening.json", reports)
    atomic_json(OUT / "summary.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
