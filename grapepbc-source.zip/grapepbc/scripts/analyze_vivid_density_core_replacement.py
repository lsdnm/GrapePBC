"""Select a bounded callable core replacement before adaptive routing.

Development chooses one fixed LR-to-density interpolation gain.  Router-B is
reported only after that choice and is not used to tune the callable expert.
The sealed test is never opened.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

from geopriv.data.hash_utils import file_sha256
import evaluate_vivid_sequential_router_development as development_loader
import train_vivid_sequential_router as router_loader


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def load_density(path: Path) -> dict[tuple[str, int], dict[str, float | int]]:
    summary = json.loads((path / "summary.json").read_text(encoding="utf-8"))
    if summary.get("status") != "COMPLETE_DENSITY_CORE_COUNT_CACHE":
        raise ValueError(f"incomplete density cache: {path}")
    with np.load(path / "density_core_counts.npz", allow_pickle=False) as payload:
        rows = {
            (str(sample_id), int(tile_id)): {
                "density": int(count), "mass": float(mass), "truth": int(truth),
            }
            for sample_id, tile_id, count, mass, truth in zip(
                payload["sample_ids"], payload["tile_ids"], payload["density_count"],
                payload["mass"], payload["truth"], strict=True,
            )
        }
    if len(rows) != int(summary["tiles"]):
        raise ValueError("density cache key cardinality mismatch")
    return rows


def attach_density(
    images: dict[str, dict[str, object]],
    density: dict[tuple[str, int], dict[str, float | int]],
) -> None:
    seen = 0
    for sample_id, image in images.items():
        for core in image["cores"]:
            key = (sample_id, int(core["tile_id"]))
            row = density[key]
            if int(row["truth"]) != int(core["truth"]):
                raise ValueError(f"truth drift: {key}")
            core["density_count"] = int(row["density"])
            core["density_mass"] = float(row["mass"])
            seen += 1
    if seen != len(density):
        raise ValueError("unused density rows")


def metric(predicted: np.ndarray, truth: np.ndarray) -> dict[str, float | int]:
    difference = predicted.astype(np.float64) - truth.astype(np.float64)
    return {
        "n": int(len(truth)),
        "mae": float(np.abs(difference).mean()),
        "rmse": float(np.sqrt(np.square(difference).mean())),
        "bias": float(difference.mean()),
    }


def gain_count(lr: int, density: int, gain: float) -> int:
    return max(0, int(np.floor(lr + gain * (density - lr) + 0.5)))


def summarize(
    images: dict[str, dict[str, object]], gains: list[float], thresholds: list[int]
) -> dict[str, object]:
    cores = [core for image in images.values() for core in image["cores"]]
    truth_core = np.asarray([core["truth"] for core in cores], dtype=np.int64)
    lr_core = np.asarray([core["lr_count"] for core in cores], dtype=np.int64)
    residual_core = np.asarray([core["hr_count"] for core in cores], dtype=np.int64)
    density_core = np.asarray([core["density_count"] for core in cores], dtype=np.int64)
    core_metrics: dict[str, object] = {
        "lr": metric(lr_core, truth_core),
        "residual_hr": metric(residual_core, truth_core),
        "density_hr": metric(density_core, truth_core),
    }
    image_truth = np.asarray([image["true_total"] for image in images.values()], dtype=np.int64)
    image_lr = np.asarray([image["lr_total"] for image in images.values()], dtype=np.int64)
    image_metrics: dict[str, object] = {"lr": metric(image_lr, image_truth)}
    image_residual = np.asarray(
        [sum(int(core["hr_count"]) for core in image["cores"]) for image in images.values()],
        dtype=np.int64,
    )
    image_density = np.asarray(
        [sum(int(core["density_count"]) for core in image["cores"]) for image in images.values()],
        dtype=np.int64,
    )
    image_metrics["residual_hr_all_cores"] = metric(image_residual, image_truth)
    image_metrics["density_hr_all_cores"] = metric(image_density, image_truth)
    for gain in gains:
        name = f"density_gain_{gain:.2f}"
        core_prediction = np.asarray(
            [gain_count(int(lr), int(density), gain) for lr, density in zip(lr_core, density_core, strict=True)],
            dtype=np.int64,
        )
        image_prediction = np.asarray(
            [
                sum(gain_count(int(core["lr_count"]), int(core["density_count"]), gain) for core in image["cores"])
                for image in images.values()
            ],
            dtype=np.int64,
        )
        core_metrics[name] = metric(core_prediction, truth_core)
        image_metrics[name] = metric(image_prediction, image_truth)
    gated = {}
    for threshold in thresholds:
        for gain in gains:
            name = f"density_ge_{threshold}_gain_{gain:.2f}"
            core_prediction = np.asarray(
                [
                    gain_count(int(lr), int(density), gain)
                    if int(density) >= threshold else int(lr)
                    for lr, density in zip(lr_core, density_core, strict=True)
                ],
                dtype=np.int64,
            )
            image_prediction = np.asarray(
                [
                    sum(
                        gain_count(int(core["lr_count"]), int(core["density_count"]), gain)
                        if int(core["density_count"]) >= threshold else int(core["lr_count"])
                        for core in image["cores"]
                    )
                    for image in images.values()
                ],
                dtype=np.int64,
            )
            gated[name] = {
                "threshold": threshold,
                "gain": gain,
                "core": metric(core_prediction, truth_core),
                "image_all_cores": metric(image_prediction, image_truth),
                "eligible_core_fraction": float((density_core >= threshold).mean()),
            }
    bins = {}
    for label, mask in {
        "truth_0_10": truth_core <= 10,
        "truth_11_30": (truth_core > 10) & (truth_core <= 30),
        "truth_31_60": (truth_core > 30) & (truth_core <= 60),
        "truth_gt60": truth_core > 60,
    }.items():
        bins[label] = {
            "lr": metric(lr_core[mask], truth_core[mask]),
            "residual_hr": metric(residual_core[mask], truth_core[mask]),
            "density_hr": metric(density_core[mask], truth_core[mask]),
        }
    return {
        "core": core_metrics,
        "image_all_cores": image_metrics,
        "gated_callable_candidates": gated,
        "core_truth_bins": bins,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--router-run", type=Path, required=True)
    parser.add_argument("--router-inputs", type=Path, required=True)
    parser.add_argument("--router-density", type=Path, required=True)
    parser.add_argument("--development-inputs", type=Path, required=True)
    parser.add_argument("--development-density", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"non-empty output exists: {output}")
    output.mkdir(parents=True, exist_ok=True)
    router_protocol = json.loads((args.router_run / "protocol.json").read_text(encoding="utf-8"))
    router_images = router_loader.load_data(router_protocol)
    development_images = development_loader.load_development(router_protocol, args.development_inputs)
    attach_density(router_images, load_density(args.router_density))
    attach_density(development_images, load_density(args.development_density))
    gains = [0.25, 0.50, 0.75, 1.00]
    thresholds = [10, 20, 30, 40, 50, 60, 80, 100]
    development = summarize(development_images, gains, thresholds)
    # Callable expert is fixed only from development. Prefer lower all-core
    # image MAE, then lower core MAE, then lower gain and higher threshold.
    chosen_name, chosen = min(
        development["gated_callable_candidates"].items(),
        key=lambda item: (
            item[1]["image_all_cores"]["mae"], item[1]["core"]["mae"],
            item[1]["gain"], -item[1]["threshold"], item[0],
        ),
    )
    router_b = summarize(router_images, gains, thresholds)
    summary = {
        "status": "COMPLETE_CALLABLE_CORE_REPLACEMENT_SELECTION",
        "selection_role": "development only",
        "selected_callable_rule_name": chosen_name,
        "selected_callable_rule": chosen,
        "selection_rule": "minimum development all-core image MAE, then core MAE, then lower gain and higher threshold",
        "development": development,
        "router_b_descriptive_after_freeze": router_b,
        "artifacts": {
            "router_protocol_sha256": file_sha256(args.router_run / "protocol.json"),
            "router_density_sha256": file_sha256(args.router_density / "density_core_counts.npz"),
            "development_density_sha256": file_sha256(args.development_density / "density_core_counts.npz"),
            "source_sha256": file_sha256(Path(__file__)),
        },
        "expert_weights_updated": False,
        "development_used_for_selection": True,
        "router_B_used_for_selection": False,
        "router_B_used_for_descriptive_audit": True,
        "sealed_test_used": False,
        "next_stage": "train grouped-OOF adaptive router on Router-B with the frozen callable density gain",
    }
    atomic_json(output / "summary.json", summary)
    atomic_json(output / "progress.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
