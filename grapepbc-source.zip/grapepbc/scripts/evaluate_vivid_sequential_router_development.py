"""One-time evaluation of the frozen sequential router on existing development."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys

import numpy as np
import torch

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

import train_vivid_sequential_router as base
import select_vivid_router_density_fusion as fusion
from geopriv.data.hash_utils import file_sha256
from geopriv.data.manifest import read_manifest
from geopriv.routing import assign_points_to_tiles, make_core_halo_tiles
from run_vivid_hr_residual_fusion import predict as predict_residual


def load_development(
    router_protocol: dict[str, object], inputs: Path
) -> dict[str, dict[str, object]]:
    input_protocol = json.loads((inputs / "protocol.json").read_text(encoding="utf-8"))
    records = {record.sample_id: record for record in read_manifest(Path(input_protocol["manifest"]))}
    raw_records = {
        row["sample_id"]: row
        for row in (
            json.loads(line)
            for line in Path(input_protocol["manifest"]).read_text(encoding="utf-8").splitlines()
            if line.strip()
        )
    }
    hr_lookup = {}
    for path in sorted((inputs / "hr").glob("*.npz")):
        with np.load(path, allow_pickle=False) as payload:
            key = (str(payload["sample_id"]), int(str(payload["tile_id"])))
            hr_lookup[key] = {
                "feature": payload["feature"].astype(np.float32),
                "candidate_count": len(payload["candidate_native_xy"]),
                "truth": int(payload["true_count"]),
            }
    images = {}
    residual_features, residual_lr, residual_candidates, residual_keys = [], [], [], []
    for sample_id, record in sorted(records.items()):
        with np.load(inputs / "lr" / f"{base.safe_name(sample_id)}.npz", allow_pickle=False) as payload:
            lr_points = payload["lr"].astype(np.float32)
            lr_scores = payload["lr_scores"].astype(np.float32)
            global_features = payload["global_features"].astype(np.float32)
            probability = payload["center_probability"].astype(np.float32)
            density = payload["density"].astype(np.float32)
            valid = payload["valid_output"].astype(bool)
            affine = payload["forward_affine"].astype(np.float32)
            true_total = int(payload["true_count"])
        tiles = make_core_halo_tiles(
            record.width, record.height,
            core_size=int(router_protocol["core_size"]),
            halo=int(router_protocol["halo"]),
        )
        owners = assign_points_to_tiles(lr_points, tiles, strict=True)
        probability_total = float(probability[valid].sum())
        density_total = float(density[valid].sum())
        max_row = max(tile.row for tile in tiles)
        max_column = max(tile.column for tile in tiles)
        cores = []
        for tile in tiles:
            chosen = owners == tile.tile_id
            core_points = lr_points[chosen]
            core_scores = lr_scores[chosen]
            hr = hr_lookup[(sample_id, tile.tile_id)]
            width_fraction = (tile.core_x1 - tile.core_x0) / record.width
            height_fraction = (tile.core_y1 - tile.core_y0) / record.height
            probability_values = base.map_region(probability, valid, affine, tile)
            density_values = base.map_region(density, valid, affine, tile)
            feature = [
                *global_features.tolist(),
                math.log1p(len(lr_points)), math.log1p(len(core_points)),
                len(core_points) / max(len(lr_points), 1),
                (tile.core_x0 + tile.core_x1) / (2.0 * record.width),
                (tile.core_y0 + tile.core_y1) / (2.0 * record.height),
                width_fraction, height_fraction, width_fraction * height_fraction,
                tile.row / max(max_row, 1), tile.column / max(max_column, 1),
                float(tile.core_x0 == 0 or tile.core_y0 == 0 or tile.core_x1 == record.width or tile.core_y1 == record.height),
                *base.distribution_features(core_points, core_scores, tile),
                *base.map_features(probability_values, probability_total),
                *base.map_features(density_values, density_total),
                float(len(probability_values) / max((tile.core_x1 - tile.core_x0) * (tile.core_y1 - tile.core_y0) / 4.0, 1.0)),
            ]
            cores.append(
                {
                    "tile_id": tile.tile_id,
                    "row": tile.row,
                    "column": tile.column,
                    "center": np.asarray(feature[15:17], dtype=np.float32),
                    "lr_count": len(core_points),
                    "truth": int(hr["truth"]),
                    "base": np.asarray(feature, dtype=np.float32),
                    "candidate_count": int(hr["candidate_count"]),
                }
            )
            residual_features.append(
                np.concatenate(
                    (
                        hr["feature"],
                        np.asarray(
                            [math.log1p(len(core_points)), math.log1p(len(lr_points)),
                             len(core_points) / max(len(lr_points), 1), math.log1p(hr["candidate_count"])],
                            dtype=np.float32,
                        ),
                    )
                )
            )
            residual_lr.append(len(core_points))
            residual_candidates.append(hr["candidate_count"])
            residual_keys.append((sample_id, tile.tile_id))
        images[sample_id] = {
            "sample_id": sample_id,
            "capture_group_id": raw_records[sample_id].get("capture_group_id") or sample_id,
            "source_family": base.source_family(sample_id),
            "true_total": true_total,
            "lr_total": len(lr_points),
            "cores": cores,
        }
    residual_data = {
        "features": np.stack(residual_features).astype(np.float32),
        "lr_counts": np.asarray(residual_lr, dtype=np.int64),
        "candidate_counts": np.asarray(residual_candidates, dtype=np.int64),
    }
    residual_checkpoint = torch.load(
        router_protocol["residual_checkpoint"], map_location="cpu", weights_only=False
    )
    final, fused, accepted, predicted_delta, predicted_error = predict_residual(
        residual_checkpoint, residual_data
    )
    for index, (sample_id, tile_id) in enumerate(residual_keys):
        core = images[sample_id]["cores"][tile_id]
        core["hr_count"] = int(final[index])
        core["raw_hr_count"] = int(fused[index])
        core["hr_accepted"] = bool(accepted[index])
        core["hr_delta"] = int(final[index]) - int(core["lr_count"])
        core["hr_predicted_error"] = float(predicted_error[index])
        core["hr_predicted_delta"] = float(predicted_delta[index])
    if len(images) != int(input_protocol["images"]):
        raise ValueError("development image cardinality mismatch")
    if sum(len(image["cores"]) for image in images.values()) != int(input_protocol["hr_cache_files"]):
        raise ValueError("development core cardinality mismatch")
    if sum(int(image["true_total"]) for image in images.values()) != int(input_protocol["points"]):
        raise ValueError("development truth cardinality mismatch")
    return images


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--router-run", type=Path, required=True)
    parser.add_argument("--frozen-package", type=Path, required=True)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"non-empty output exists: {output}")
    output.mkdir(parents=True, exist_ok=True)
    router_run = args.router_run.resolve()
    frozen_package = args.frozen_package.resolve()
    inputs = args.inputs.resolve()
    protocol = json.loads((router_run / "protocol.json").read_text(encoding="utf-8"))
    frozen_protocol = json.loads((frozen_package / "protocol.json").read_text(encoding="utf-8"))
    input_summary = json.loads((inputs / "summary.json").read_text(encoding="utf-8"))
    if frozen_protocol.get("development_used_for_fitting") or frozen_protocol.get("sealed_test_used"):
        raise ValueError("frozen package has an invalid boundary")
    if input_summary.get("status") != "COMPLETE_EXISTING_DEVELOPMENT_INPUTS":
        raise ValueError("development inputs incomplete")
    package_checkpoint = torch.load(
        frozen_package / "router_package.pt", map_location="cpu", weights_only=False
    )
    policy = package_checkpoint["selected_policy"]
    images = load_development(protocol, inputs)
    model = fusion.load_model(frozen_package / "router_package.pt", protocol)
    rows = []
    for sample_id, image in images.items():
        result = fusion.simulate(
            image, model,
            int(policy["maximum_calls"]),
            float(policy["minimum_predicted_utility"]),
            float(policy["density_weight"]),
        )
        rows.append(
            {
                "sample_id": sample_id,
                "true_count": int(image["true_total"]),
                "lr_count": int(image["lr_total"]),
                **result,
            }
        )
    density_prediction = [
        base.matched_density(images[row["sample_id"]], int(row["calls"])) for row in rows
    ]
    for index, row in enumerate(rows):
        truth = int(row["true_count"])
        row["absolute_error"] = abs(int(row["predicted"]) - truth)
        row["lr_absolute_error"] = abs(int(row["lr_count"]) - truth)
        row["density_matched_count"] = int(density_prediction[index])
        row["density_absolute_error"] = abs(int(density_prediction[index]) - truth)
        row["improvement_vs_lr"] = row["lr_absolute_error"] - row["absolute_error"]
        row["improvement_vs_density"] = row["density_absolute_error"] - row["absolute_error"]
    metrics = base.summarize_counts(
        (row["predicted"] for row in rows), (row["true_count"] for row in rows)
    )
    metrics["mean_calls"] = float(np.mean([row["calls"] for row in rows]))
    metrics["zero_call_fraction"] = float(np.mean([row["calls"] == 0 for row in rows]))
    lr_metrics = base.summarize_counts(
        (row["lr_count"] for row in rows), (row["true_count"] for row in rows)
    )
    density_metrics = base.summarize_counts(
        density_prediction, (row["true_count"] for row in rows)
    )
    full_prediction = [
        int(image["lr_total"]) + sum(int(core["hr_delta"]) for core in image["cores"])
        for image in images.values()
    ]
    full_metrics = base.summarize_counts(
        full_prediction, (image["true_total"] for image in images.values())
    )
    rng_mae = []
    for repeat in range(500):
        rng = np.random.default_rng(int(protocol["seed"]) + 9000 + repeat)
        predictions = []
        for row in rows:
            image = images[row["sample_id"]]
            chosen = (
                rng.choice(len(image["cores"]), size=row["calls"], replace=False)
                if row["calls"] else []
            )
            predictions.append(
                int(image["lr_total"])
                + sum(int(image["cores"][int(index)]["hr_delta"]) for index in chosen)
            )
        rng_mae.append(
            base.summarize_counts(predictions, (row["true_count"] for row in rows))["mae"]
        )
    groups = {
        sample_id: str(image["capture_group_id"]) for sample_id, image in images.items()
    }
    uncertainty = {
        "paired_improvement_vs_lr": fusion.group_bootstrap(
            rows, "improvement_vs_lr", groups, 10000, int(protocol["seed"]) + 10000
        ),
        "paired_improvement_vs_density": fusion.group_bootstrap(
            rows, "improvement_vs_density", groups, 10000, int(protocol["seed"]) + 11000
        ),
    }
    summary = {
        "status": "COMPLETE_FROZEN_ROUTER_EXISTING_DEVELOPMENT_EVALUATION",
        "policy": policy,
        "comparison": {
            "lr_no_hr_calls": lr_metrics,
            "random_matched_calls": {
                "mae_mean": float(np.mean(rng_mae)),
                "mae_std": float(np.std(rng_mae)),
                "repeats": len(rng_mae),
            },
            "density_matched_calls": density_metrics,
            "frozen_sequential_density_prior_cru": metrics,
            "full_residual_hr_all_cores": full_metrics,
        },
        "uncertainty": uncertainty,
        "improved_images_vs_lr": int(sum(row["improvement_vs_lr"] > 0 for row in rows)),
        "worsened_images_vs_lr": int(sum(row["improvement_vs_lr"] < 0 for row in rows)),
        "ties_vs_lr": int(sum(row["improvement_vs_lr"] == 0 for row in rows)),
        "router_frozen_before_development": True,
        "development_used_for_fitting": False,
        "development_used_for_evaluation": True,
        "router_B_used_for_fitting": True,
        "sealed_test_used": False,
        "claim_boundary": "existing development gate; not an independent confirmatory test",
    }
    audit = {
        "router_protocol_sha256": file_sha256(router_run / "protocol.json"),
        "frozen_package_protocol_sha256": file_sha256(frozen_package / "protocol.json"),
        "frozen_router_package_sha256": file_sha256(frozen_package / "router_package.pt"),
        "development_inputs_summary_sha256": file_sha256(inputs / "summary.json"),
        "source_sha256": file_sha256(Path(__file__)),
        "sealed_test_used": False,
    }
    base.atomic_json(output / "audit.json", audit)
    base.atomic_json(output / "per_image.json", rows)
    base.atomic_json(output / "summary.json", summary)
    base.atomic_json(output / "progress.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
