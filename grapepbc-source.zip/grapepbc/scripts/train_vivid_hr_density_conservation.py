"""Fine-tune the frozen-best rich HR expert with an explicit density count loss.

The previous expert was trained only for center heatmaps and offsets.  This
stage continues from its best checkpoint, keeps those objectives, and learns a
non-negative density map whose mass is constrained to the annotated count.
The decoder sums density only inside each non-overlapping owned core and uses
that count to retain the best localized candidate peaks.
"""

from __future__ import annotations

import argparse
from contextlib import nullcontext
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import random
import sys
import time

import numpy as np
import torch
from torch.nn import functional as F

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

from geopriv.data.hash_utils import file_sha256
from geopriv.metrics import aggregate_count_metrics, maximum_cardinality_point_matches
from geopriv.models import decode_points
from geopriv.training import GeoPrivLossWeights, build_geopriv_targets, geopriv_loss
import run_vivid_hr_core_calibration as core_stage
import train_vivid_application_hr as base_train
from vivid_detail_runtime import atomic_checkpoint, safe_load


WEIGHTS = GeoPrivLossWeights(center=1.0, offset=0.5, radius=0.0, density=1.0, count_conservation=0.002)


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    temporary.replace(path)


def seed_all(seed: int) -> None:
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)


def prepare(args: argparse.Namespace) -> None:
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(output)
    output.mkdir(parents=True, exist_ok=True)
    parent = args.parent_run.resolve()
    parent_protocol = json.loads((parent / "protocol.json").read_text(encoding="utf-8"))
    checkpoint = safe_load(parent / "best_val_mae.pt")
    if parent_protocol.get("router_B_used") or parent_protocol.get("sealed_test_used"):
        raise ValueError("parent crossed a sealed boundary")
    protocol = {
        **parent_protocol,
        "version": "vivid-rich-hr-density-conservation-v1",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "parent_run": str(parent), "parent_checkpoint": str((parent / "best_val_mae.pt").resolve()),
        "parent_checkpoint_sha256": file_sha256(parent / "best_val_mae.pt"),
        "parent_best_epoch": int(checkpoint["epoch"]),
        "seed": 20261014, "epochs": 4, "batch_size": 4, "num_workers": 2,
        "learning_rate": 0.00002, "weight_decay": 0.0001, "gradient_clip": 5.0,
        "amp_enabled": False, "loss_weights": WEIGHTS.__dict__,
        "count_conservation_mode": "poisson_smooth_l1",
        "decoder": "round owned-core density mass, then retain that many score-ranked center candidates",
        "selection": "minimum whole-image development density-count MAE; F1 secondary",
        "source_sha256_density_script": file_sha256(Path(__file__)),
        "router_B_used": False, "sealed_test_used": False,
    }
    atomic_json(output / "protocol.json", protocol)
    atomic_json(output / "stage.json", {"status": "PREPARED", "router_B_used": False, "sealed_test_used": False})
    print(json.dumps(protocol, ensure_ascii=False, indent=2))


def verify(output: Path) -> dict[str, object]:
    protocol = json.loads((output / "protocol.json").read_text(encoding="utf-8"))
    if file_sha256(Path(protocol["parent_checkpoint"])) != protocol["parent_checkpoint_sha256"]:
        raise ValueError("parent checkpoint drift")
    if file_sha256(Path(__file__)) != protocol["source_sha256_density_script"]:
        raise ValueError("training source drift")
    if protocol.get("router_B_used") or protocol.get("sealed_test_used"):
        raise ValueError("sealed role boundary")
    return protocol


def make_model(protocol: dict[str, object]):
    model = base_train.make_model(protocol)
    checkpoint = safe_load(Path(protocol["parent_checkpoint"]))
    model.load_state_dict(checkpoint["model"], strict=True)
    return model


def training_step(model, optimizer, scaler, batch, protocol):
    model.train(); optimizer.zero_grad(set_to_none=True)
    images = batch["images"].cuda(non_blocking=True)
    masks = batch["valid_image_masks"].cuda(non_blocking=True)
    context = torch.amp.autocast("cuda", dtype=torch.float16) if protocol["amp_enabled"] else nullcontext()
    with context:
        outputs = model(images, masks)
        cpu_targets = build_geopriv_targets(
            [target["points_xy"] for target in batch["targets"]],
            output_height=outputs["center_logits"].shape[-2], output_width=outputs["center_logits"].shape[-1],
            stride=model.output_stride, gaussian_radius=1, density_sigma=1.0,
            equivalent_radius=[None] * len(batch["targets"]),
            frame_boundary_completeness=[None] * len(batch["targets"]),
            geometry_available=[False] * len(batch["targets"]),
            valid_image_mask=batch["valid_image_masks"], device="cpu",
        )
        targets = {key: value.cuda(non_blocking=True) for key, value in cpu_targets.items()}
        losses = geopriv_loss(outputs, targets, weights=WEIGHTS, count_conservation_mode="poisson_smooth_l1")
    if not torch.isfinite(losses["loss"]): raise FloatingPointError("non-finite loss")
    scaler.scale(losses["loss"]).backward(); scaler.unscale_(optimizer)
    grad = torch.nn.utils.clip_grad_norm_(model.parameters(), float(protocol["gradient_clip"]), error_if_nonfinite=True)
    scaler.step(optimizer); scaler.update()
    row = {key: float(value.detach()) for key, value in losses.items()}; row["gradient_norm"] = float(grad)
    return row


@torch.inference_mode()
def evaluate(model, loader, protocol):
    model.eval()
    per_image_prediction = {}; per_image_truth = {}
    tp = fp = fn = 0
    core_density = []
    for batch in loader:
        images = batch["images"].cuda(non_blocking=True); masks = batch["valid_image_masks"].cuda(non_blocking=True)
        outputs = model(images, masks)
        decoded = decode_points(outputs, score_threshold=1e-6, topk=4096, local_max_kernel=3, output_stride=model.output_stride)
        density = F.softplus(outputs["density_logits"].float())
        for index, (prediction, target) in enumerate(zip(decoded, batch["targets"], strict=True)):
            valid = masks[index]
            bounds = target["core_bounds_xyxy"].cuda()
            owned_density = core_stage.rect_mask(valid, bounds, density.shape[-2], density.shape[-1], int(protocol["input_size"]))
            mass = float(density[index, 0][owned_density].sum())
            requested = max(0, int(math.floor(mass + 0.5)))
            points = prediction["points"].detach().cpu().numpy(); scores = prediction["scores"].detach().cpu().numpy()
            x0, y0, x1, y1 = target["core_bounds_xyxy"].numpy().tolist()
            owned = (points[:,0]>=x0)&(points[:,0]<x1)&(points[:,1]>=y0)&(points[:,1]<y1)
            points, scores = points[owned], scores[owned]
            if len(scores):
                order = np.argsort(-scores, kind="stable")[:requested]
                points = points[order]
            else:
                points = points[:0]
            truth = target["core_points_xy"].numpy()
            a,b,c = maximum_cardinality_point_matches(points, truth, float(protocol["match_radius"]))
            tp += a; fp += b; fn += c
            sid = str(target["sample_id"])
            per_image_prediction[sid] = per_image_prediction.get(sid,0) + len(points)
            per_image_truth[sid] = per_image_truth.get(sid,0) + len(truth)
            core_density.append({"sample_id":sid,"tile_id":int(target["tile_id"]),"mass":mass,"requested":requested,"truth":len(truth)})
    ids = sorted(per_image_truth)
    result = aggregate_count_metrics([per_image_prediction.get(sid,0) for sid in ids],[per_image_truth[sid] for sid in ids])
    precision=tp/max(tp+fp,1); recall=tp/max(tp+fn,1)
    result.update({"precision_at_8":precision,"recall_at_8":recall,"f1_at_8":2*precision*recall/max(precision+recall,1e-12),
                   "tp":tp,"fp":fp,"fn":fn,"images":len(ids),"tiles":len(core_density)})
    return result, core_density


def run(output: Path, protocol: dict[str, object]) -> None:
    seed_all(int(protocol["seed"])); _, _, train_loader, val_loader, sampler = base_train.make_loaders(protocol)
    model = make_model(protocol)
    optimizer = torch.optim.AdamW(model.parameters(), lr=float(protocol["learning_rate"]), weight_decay=float(protocol["weight_decay"]))
    scaler = torch.amp.GradScaler("cuda", enabled=bool(protocol["amp_enabled"]))
    start = 1; history=[]; best_epoch=0; best_metrics, _ = evaluate(model,val_loader,protocol)
    best_model={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
    if (output/"last.pt").exists():
        checkpoint=safe_load(output/"last.pt"); model.load_state_dict(checkpoint["model"]); optimizer.load_state_dict(checkpoint["optimizer"]); scaler.load_state_dict(checkpoint["scaler"])
        start=int(checkpoint["epoch"])+1; history=checkpoint["history"]; best_epoch=int(checkpoint["best_epoch"]); best_metrics=checkpoint["best_metrics"]; best_model=checkpoint["best_model"]
    else:
        atomic_json(output/"initial_validation.json",best_metrics)
    for epoch in range(start,int(protocol["epochs"])+1):
        sampler.set_epoch(epoch); seed_all(int(protocol["seed"])+epoch); totals={}; began=time.monotonic(); model.train()
        for batch_index,batch in enumerate(train_loader):
            losses=training_step(model,optimizer,scaler,batch,protocol)
            for key,value in losses.items(): totals[key]=totals.get(key,0.0)+value
            if batch_index%25==0:
                atomic_json(output/"live_progress.json",{"status":"training","epoch":epoch,"completed_batches":batch_index+1,"total_batches":len(train_loader),"loss":losses["loss"],"router_B_used":False,"sealed_test_used":False})
        validation, core_rows=evaluate(model,val_loader,protocol)
        if (validation["mae"],-validation["f1_at_8"]) < (best_metrics["mae"],-best_metrics["f1_at_8"]):
            best_epoch=epoch;best_metrics=validation;best_model={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
        row={"epoch":epoch,"training_losses":{k:v/len(train_loader) for k,v in totals.items()},"validation":validation,"best_epoch":best_epoch,"elapsed_seconds":time.monotonic()-began}
        history.append(row)
        payload={"model":model.state_dict(),"optimizer":optimizer.state_dict(),"scaler":scaler.state_dict(),"epoch":epoch,"protocol":protocol,"history":history,"best_epoch":best_epoch,"best_metrics":best_metrics,"best_model":best_model}
        atomic_checkpoint(output/"last.pt",payload); atomic_checkpoint(output/"best_val_mae.pt",{**payload,"model":best_model,"epoch":best_epoch})
        atomic_json(output/"history.json",history); atomic_json(output/f"validation_epoch_{epoch:02d}.json",validation); atomic_json(output/f"density_rows_epoch_{epoch:02d}.json",core_rows)
        atomic_json(output/"progress.json",row); print(json.dumps(row),flush=True)
    summary={"status":"COMPLETE_REVIEW_REQUIRED","best_epoch":best_epoch,"best_validation":best_metrics,"loss_weights":WEIGHTS.__dict__,"router_B_used":False,"sealed_test_used":False}
    atomic_json(output/"summary.json",summary);atomic_json(output/"stage.json",summary)


def main() -> None:
    parser=argparse.ArgumentParser();parser.add_argument("--mode",choices=("prepare","run"),required=True);parser.add_argument("--output",type=Path,required=True);parser.add_argument("--parent-run",type=Path)
    args=parser.parse_args();output=args.output.resolve()
    if args.mode=="prepare":
        if args.parent_run is None: parser.error("prepare requires --parent-run")
        prepare(args);return
    if not torch.cuda.is_available(): raise RuntimeError("CUDA required")
    os.environ["CUBLAS_WORKSPACE_CONFIG"]=":4096:8";torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
    protocol=verify(output);atomic_json(output/"stage.json",{"status":"RUNNING","pid":os.getpid(),"router_B_used":False,"sealed_test_used":False})
    try: run(output,protocol)
    except BaseException as exc:
        atomic_json(output/"stage.json",{"status":"FAILED_OR_INTERRUPTED","error":repr(exc),"router_B_used":False,"sealed_test_used":False});raise


if __name__=="__main__": main()
