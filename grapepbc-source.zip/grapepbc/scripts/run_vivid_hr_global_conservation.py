"""Conservative whole-image count conservation for the frozen LR/HR experts.

LR remains the stable whole-image count prior.  The rich HR expert supplies
better-localised candidate points and local residual counts.  This stage learns
only an image-level correction from Expert-A and then enforces that count on
the HR candidate set.  Router-B and the sealed test are deliberately excluded.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import sys

import joblib
import numpy as np
import torch
from sklearn.ensemble import GradientBoostingRegressor

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

from geopriv.data.hash_utils import file_sha256
from geopriv.metrics import aggregate_count_metrics, maximum_cardinality_point_matches
import run_vivid_hr_core_calibration as absolute_stage
import run_vivid_hr_residual_fusion as residual_stage


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def atomic_joblib(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    joblib.dump(value, temporary)
    temporary.replace(path)


def source_hashes() -> dict[str, str]:
    names = (
        "scripts/run_vivid_hr_global_conservation.py",
        "scripts/run_vivid_hr_residual_fusion.py",
        "scripts/run_vivid_hr_core_calibration.py",
    )
    return {name: file_sha256(PROJECT / name) for name in names}


def prepare(args: argparse.Namespace) -> None:
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"non-empty output exists: {output}")
    output.mkdir(parents=True, exist_ok=True)
    residual = args.residual_run.resolve()
    absolute = args.absolute_run.resolve()
    residual_summary = json.loads((residual / "summary.json").read_text(encoding="utf-8"))
    absolute_summary = json.loads((absolute / "summary.json").read_text(encoding="utf-8"))
    for name, summary in (("residual", residual_summary), ("absolute", absolute_summary)):
        if summary.get("status") != "COMPLETE_DEVELOPMENT_REVIEW_REQUIRED":
            raise ValueError(f"{name} stage is incomplete")
        if summary.get("router_B_used") or summary.get("sealed_test_used"):
            raise ValueError(f"{name} stage crossed a sealed boundary")
    protocol = {
        "version": "vivid-lr-hr-global-count-conservation-v1",
        "status": "PREPARED",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "seed": 20261003,
        "residual_run": str(residual),
        "residual_protocol": str((residual / "protocol.json").resolve()),
        "residual_protocol_sha256": file_sha256(residual / "protocol.json"),
        "residual_checkpoint": str((residual / "best_val_mae.pt").resolve()),
        "residual_checkpoint_sha256": file_sha256(residual / "best_val_mae.pt"),
        "absolute_run": str(absolute),
        "absolute_protocol": str((absolute / "protocol.json").resolve()),
        "absolute_protocol_sha256": file_sha256(absolute / "protocol.json"),
        "absolute_checkpoint": str((absolute / "best_val_mae.pt").resolve()),
        "absolute_checkpoint_sha256": file_sha256(absolute / "best_val_mae.pt"),
        "model_candidates": [
            {"max_depth": 1, "n_estimators": 120, "learning_rate": 0.03, "min_samples_leaf": 15},
            {"max_depth": 2, "n_estimators": 120, "learning_rate": 0.03, "min_samples_leaf": 15},
            {"max_depth": 2, "n_estimators": 200, "learning_rate": 0.03, "min_samples_leaf": 10},
            {"max_depth": 3, "n_estimators": 120, "learning_rate": 0.03, "min_samples_leaf": 15},
        ],
        "alpha_candidates": [0.0, 0.25, 0.5, 0.75, 1.0],
        "target": "(true whole-image count - enhanced LR count) / sqrt(LR count + 1)",
        "selection": "five-fold grouped Expert-A OOF only; ties prefer smaller alpha and shallower model",
        "roles": {
            "LR": "stable whole-image count prior and no-HR fallback",
            "HR": "local detail, candidate localisation, and signed regional correction",
            "global_conservation": "conservative whole-image correction and exact point-count enforcement",
        },
        "development_gate": "MAE < enhanced LR and F1@8 >= enhanced LR - 0.01",
        "development_used_for_fitting": False,
        "router_B_used": False,
        "sealed_test_used": False,
        "source_sha256": source_hashes(),
    }
    atomic_json(output / "protocol.json", protocol)
    atomic_json(
        output / "progress.json",
        {"status": "PREPARED", "router_B_used": False, "sealed_test_used": False},
    )
    print(json.dumps(protocol, ensure_ascii=False, indent=2), flush=True)


def verify(output: Path) -> dict[str, object]:
    protocol = json.loads((output / "protocol.json").read_text(encoding="utf-8"))
    for name, expected in protocol["source_sha256"].items():
        if file_sha256(PROJECT / name) != expected:
            raise ValueError(f"source drift: {name}")
    for path_key, hash_key in (
        ("residual_protocol", "residual_protocol_sha256"),
        ("residual_checkpoint", "residual_checkpoint_sha256"),
        ("absolute_protocol", "absolute_protocol_sha256"),
        ("absolute_checkpoint", "absolute_checkpoint_sha256"),
    ):
        if file_sha256(Path(protocol[path_key])) != protocol[hash_key]:
            raise ValueError(f"artifact drift: {path_key}")
    if protocol["router_B_used"] or protocol["sealed_test_used"]:
        raise ValueError("sealed roles are forbidden")
    return protocol


def load_components(protocol: dict[str, object], split: str) -> dict[str, object]:
    residual_output = Path(protocol["residual_run"])
    residual_protocol = residual_stage.verify(residual_output)
    data = residual_stage.build_data(residual_protocol, split)
    residual_checkpoint = torch.load(
        Path(protocol["residual_checkpoint"]), map_location="cpu", weights_only=False
    )
    residual_count, _, _, _, residual_error = residual_stage.predict(residual_checkpoint, data)
    absolute_checkpoint = torch.load(
        Path(protocol["absolute_checkpoint"]), map_location="cpu", weights_only=False
    )
    absolute_count, occupancy, log_count = absolute_stage.predict_head(
        absolute_checkpoint,
        data["features"][:, : int(residual_protocol["base_feature_dim"])],
        data["candidate_counts"],
    )
    cache_folder = Path(residual_protocol[f"{split}_feature_cache"])
    score_arrays = []
    for path in sorted(cache_folder.glob("*.npz")):
        with np.load(path, allow_pickle=False) as payload:
            score_arrays.append(payload["candidate_scores"].astype(np.float32))
    if len(score_arrays) != len(data["features"]):
        raise ValueError(f"candidate-score cache mismatch for {split}")
    return {
        **data,
        "residual_count": residual_count.astype(np.int64),
        "residual_error": residual_error.astype(np.float32),
        "absolute_count": absolute_count.astype(np.int64),
        "absolute_occupancy": occupancy.astype(np.float32),
        "absolute_log_count": log_count.astype(np.float32),
        "candidate_scores": score_arrays,
    }


def distribution_stats(values: np.ndarray) -> list[float]:
    values = np.asarray(values, dtype=np.float64).reshape(-1)
    if not len(values):
        return [0.0] * 7
    return [
        float(values.mean()),
        float(values.std()),
        float(values.min()),
        float(np.quantile(values, 0.25)),
        float(np.median(values)),
        float(np.quantile(values, 0.75)),
        float(values.max()),
    ]


def make_image_table(data: dict[str, object]) -> dict[str, object]:
    rows, ids, targets, lr_totals, residual_totals = [], [], [], [], []
    base = data["features"][:, :349]
    block_bounds = ((0, 64), (64, 128), (128, 224), (224, 320), (320, 349))
    for sample_id in sorted(data["records"]):
        chosen = np.flatnonzero(data["sample_ids"] == sample_id)
        if not len(chosen):
            raise ValueError(f"missing tiles for {sample_id}")
        lr_core = data["lr_counts"][chosen].astype(np.float64)
        residual_core = data["residual_count"][chosen].astype(np.float64)
        absolute_core = data["absolute_count"][chosen].astype(np.float64)
        candidate_core = data["candidate_counts"][chosen].astype(np.float64)
        residual_uncertainty = data["residual_error"][chosen].astype(np.float64)
        occupancy = data["absolute_occupancy"][chosen].astype(np.float64)
        record = data["records"][sample_id]
        lr_total = int(lr_core.sum())
        residual_total = int(residual_core.sum())
        absolute_total = int(absolute_core.sum())
        feature = [
            math.log1p(lr_total),
            math.log1p(residual_total),
            math.log1p(absolute_total),
            (residual_total - lr_total) / math.sqrt(lr_total + 1.0),
            (absolute_total - lr_total) / math.sqrt(lr_total + 1.0),
            math.log1p(len(chosen)),
            math.log1p(record.width),
            math.log1p(record.height),
            record.width / max(record.height, 1),
        ]
        for values in (
            lr_core,
            residual_core,
            absolute_core,
            candidate_core,
            residual_core - lr_core,
            absolute_core - lr_core,
            residual_uncertainty,
            occupancy,
        ):
            feature.extend(distribution_stats(values))
        # Rich feature blocks are compressed to robust image-level moments;
        # no filename/source-family cue is used, keeping inference portable.
        for start, stop in block_bounds:
            tile_summary = np.column_stack(
                (
                    base[chosen, start:stop].mean(axis=1),
                    base[chosen, start:stop].std(axis=1),
                    base[chosen, start:stop].max(axis=1),
                )
            )
            feature.extend(distribution_stats(tile_summary[:, 0]))
            feature.extend(distribution_stats(tile_summary[:, 1]))
            feature.extend(distribution_stats(tile_summary[:, 2]))
        rows.append(feature)
        ids.append(sample_id)
        targets.append(int(data["target"][chosen].sum()))
        lr_totals.append(lr_total)
        residual_totals.append(residual_total)
    return {
        "features": np.asarray(rows, dtype=np.float32),
        "sample_ids": np.asarray(ids),
        "target": np.asarray(targets, dtype=np.int64),
        "lr_total": np.asarray(lr_totals, dtype=np.int64),
        "residual_total": np.asarray(residual_totals, dtype=np.int64),
    }


def make_folds(table: dict[str, object], data: dict[str, object], folds: int, seed: int) -> np.ndarray:
    tile_folds = residual_stage.grouped_folds(
        data["sample_ids"], data["target"], folds, seed
    )
    mapping = {}
    for sample_id in table["sample_ids"]:
        values = np.unique(tile_folds[data["sample_ids"] == sample_id])
        if len(values) != 1:
            raise ValueError(f"image split across folds: {sample_id}")
        mapping[str(sample_id)] = int(values[0])
    return np.asarray([mapping[str(value)] for value in table["sample_ids"]], dtype=np.int64)


def model_from_config(config: dict[str, object], seed: int) -> GradientBoostingRegressor:
    return GradientBoostingRegressor(
        loss="huber",
        alpha=0.85,
        random_state=seed,
        max_depth=int(config["max_depth"]),
        n_estimators=int(config["n_estimators"]),
        learning_rate=float(config["learning_rate"]),
        min_samples_leaf=int(config["min_samples_leaf"]),
        subsample=0.85,
        max_features="sqrt",
    )


def correction_target(table: dict[str, object]) -> np.ndarray:
    return (
        (table["target"] - table["lr_total"])
        / np.sqrt(table["lr_total"].astype(np.float64) + 1.0)
    )


def decode_total(table: dict[str, object], normalized_delta: np.ndarray, alpha: float) -> np.ndarray:
    raw = table["lr_total"] + np.rint(
        alpha * normalized_delta * np.sqrt(table["lr_total"] + 1.0)
    ).astype(np.int64)
    return np.maximum(raw, 0)


def select_oof(
    protocol: dict[str, object], table: dict[str, object], data: dict[str, object], output: Path
) -> tuple[dict[str, object], np.ndarray]:
    folds = make_folds(table, data, 5, int(protocol["seed"]))
    target = correction_target(table)
    reports = []
    best_key = None
    best = None
    best_oof = None
    for config_index, config in enumerate(protocol["model_candidates"]):
        oof = np.zeros(len(target), dtype=np.float64)
        for fold in range(5):
            train_index = folds != fold
            val_index = folds == fold
            model = model_from_config(config, int(protocol["seed"]) + config_index * 10 + fold)
            model.fit(table["features"][train_index], target[train_index])
            oof[val_index] = model.predict(table["features"][val_index])
            atomic_json(
                output / "progress.json",
                {
                    "status": "EXPERT_A_OOF",
                    "completed_configuration": config_index,
                    "completed_fold": fold + 1,
                    "router_B_used": False,
                    "sealed_test_used": False,
                },
            )
        for alpha in protocol["alpha_candidates"]:
            count = decode_total(table, oof, float(alpha))
            mae = float(np.abs(count - table["target"]).mean())
            rmse = float(np.sqrt(np.square(count - table["target"]).mean()))
            row = {
                "config_index": config_index,
                "config": config,
                "alpha": float(alpha),
                "mae": mae,
                "rmse": rmse,
                "bias": float((count - table["target"]).mean()),
                "mean_absolute_correction": float(np.abs(count - table["lr_total"]).mean()),
            }
            reports.append(row)
            key = (mae, rmse, float(alpha), int(config["max_depth"]), int(config["n_estimators"]))
            if best_key is None or key < best_key:
                best_key, best, best_oof = key, row, oof.copy()
    assert best is not None and best_oof is not None
    atomic_json(
        output / "expert_A_oof.json",
        {
            "status": "COMPLETE_EXPERT_A_GROUPED_OOF",
            "rows": reports,
            "selected": best,
            "development_used": False,
            "router_B_used": False,
            "sealed_test_used": False,
        },
    )
    return best, best_oof


def conserve_points(
    candidates: list[np.ndarray],
    scores: list[np.ndarray],
    local_counts: np.ndarray,
    requested_total: int,
) -> tuple[np.ndarray, int, bool]:
    selected_points, selected_scores, unused_points, unused_scores = [], [], [], []
    for points, point_scores, count in zip(candidates, scores, local_counts):
        count = max(0, min(int(count), len(points)))
        if count:
            selected_points.append(points[:count])
            selected_scores.append(point_scores[:count])
        if count < len(points):
            unused_points.append(points[count:])
            unused_scores.append(point_scores[count:])
    selected = np.concatenate(selected_points) if selected_points else np.empty((0, 2), np.float32)
    selected_score = np.concatenate(selected_scores) if selected_scores else np.empty(0, np.float32)
    unused = np.concatenate(unused_points) if unused_points else np.empty((0, 2), np.float32)
    unused_score = np.concatenate(unused_scores) if unused_scores else np.empty(0, np.float32)
    available = len(selected) + len(unused)
    requested = max(0, int(requested_total))
    realised = min(requested, available)
    if realised <= len(selected):
        order = np.argsort(-selected_score, kind="stable")[:realised]
        result = selected[order]
    else:
        need = realised - len(selected)
        order = np.argsort(-unused_score, kind="stable")[:need]
        result = np.concatenate((selected, unused[order]))
    return result.astype(np.float32), available, realised < requested


def summarize(rows: list[dict[str, object]]) -> dict[str, object]:
    tp = sum(int(row["tp"]) for row in rows)
    fp = sum(int(row["fp"]) for row in rows)
    fn = sum(int(row["fn"]) for row in rows)
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    return {
        "images": len(rows),
        **aggregate_count_metrics(
            [int(row["predicted_count"]) for row in rows],
            [int(row["true_count"]) for row in rows],
        ),
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "precision_at_8": precision,
        "recall_at_8": recall,
        "f1_at_8": 2 * precision * recall / max(precision + recall, 1e-12),
    }


def evaluate(
    output: Path,
    protocol: dict[str, object],
    model: GradientBoostingRegressor,
    selected: dict[str, object],
    table: dict[str, object],
    data: dict[str, object],
) -> dict[str, object]:
    normalized = model.predict(table["features"])
    requested = decode_total(table, normalized, float(selected["alpha"]))
    index_by_sample = {str(sample_id): index for index, sample_id in enumerate(table["sample_ids"])}
    rows = []
    point_dir = output / "development_points"
    point_dir.mkdir(exist_ok=True)
    for sample_id in sorted(data["records"]):
        tile_indices = np.flatnonzero(data["sample_ids"] == sample_id)
        image_index = index_by_sample[sample_id]
        points, available, saturated = conserve_points(
            [data["candidates"][index] for index in tile_indices],
            [data["candidate_scores"][index] for index in tile_indices],
            data["residual_count"][tile_indices],
            int(requested[image_index]),
        )
        record = data["records"][sample_id]
        truth = np.load(Path(residual_stage.verify(Path(protocol["residual_run"]))["root"]) / record.points_path, allow_pickle=False).astype(np.float32)
        scale = 1024.0 / max(record.width, record.height)
        tp, fp, fn = maximum_cardinality_point_matches(points * scale, truth * scale, 8.0)
        rows.append(
            {
                "sample_id": sample_id,
                "true_count": len(truth),
                "lr_count": int(table["lr_total"][image_index]),
                "residual_hr_count": int(table["residual_total"][image_index]),
                "requested_count": int(requested[image_index]),
                "predicted_count": len(points),
                "absolute_error": abs(len(points) - len(truth)),
                "signed_error": len(points) - len(truth),
                "tp": tp,
                "fp": fp,
                "fn": fn,
                "candidate_capacity": available,
                "candidate_saturated": saturated,
                "count_bin": residual_stage.count_bin(len(truth)),
                "source_family": residual_stage.source_family(sample_id),
            }
        )
        np.savez_compressed(
            point_dir / (sample_id.replace(":", "_") + ".npz"),
            truth=truth,
            global_conserved_hr=points,
        )
    metrics = summarize(rows)
    residual_summary = json.loads(
        (Path(protocol["residual_run"]) / "summary.json").read_text(encoding="utf-8")
    )
    lr = residual_summary["enhanced_lr"]
    residual = residual_summary["development"]
    gate = metrics["mae"] < lr["mae"] and metrics["f1_at_8"] >= lr["f1_at_8"] - 0.01
    by_count: dict[str, list[dict[str, object]]] = defaultdict(list)
    by_source: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        by_count[row["count_bin"]].append(row)
        by_source[row["source_family"]].append(row)
    summary = {
        "status": "COMPLETE_DEVELOPMENT_REVIEW_REQUIRED",
        "development": metrics,
        "enhanced_lr": lr,
        "residual_hr": residual,
        "selected_expert_A_oof": selected,
        "promotion_gate_passed": bool(gate),
        "candidate_saturated_images": sum(bool(row["candidate_saturated"]) for row in rows),
        "by_count": {key: summarize(value) for key, value in sorted(by_count.items())},
        "by_source": {key: summarize(value) for key, value in sorted(by_source.items())},
        "development_used_for_fitting": False,
        "router_B_used": False,
        "sealed_test_used": False,
        "claim_boundary": "post-development bounded repair; not independent evidence",
    }
    atomic_json(output / "development_per_image.json", rows)
    atomic_json(output / "development_summary.json", summary)
    return summary


def smoke(output: Path, protocol: dict[str, object]) -> None:
    train = load_components(protocol, "train")
    table = make_image_table(train)
    sample = str(table["sample_ids"][0])
    chosen = np.flatnonzero(train["sample_ids"] == sample)
    points, capacity, saturated = conserve_points(
        [train["candidates"][index] for index in chosen],
        [train["candidate_scores"][index] for index in chosen],
        train["residual_count"][chosen],
        int(table["lr_total"][0]),
    )
    report = {
        "status": "PASS",
        "train_images": len(table["sample_ids"]),
        "train_cores": len(train["target"]),
        "image_feature_dim": table["features"].shape[1],
        "sample_requested": int(table["lr_total"][0]),
        "sample_realised": len(points),
        "sample_capacity": capacity,
        "sample_saturated": saturated,
        "router_B_used": False,
        "sealed_test_used": False,
    }
    if not np.isfinite(table["features"]).all():
        raise ValueError("non-finite image features")
    if len(points) != min(int(table["lr_total"][0]), capacity):
        raise ValueError("count conservation failed")
    atomic_json(output / "engineering_smoke.json", report)
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)


def run(output: Path, protocol: dict[str, object]) -> None:
    smoke_report = json.loads((output / "engineering_smoke.json").read_text(encoding="utf-8"))
    if smoke_report.get("status") != "PASS":
        raise ValueError("passing smoke is required")
    train = load_components(protocol, "train")
    train_table = make_image_table(train)
    selected, _ = select_oof(protocol, train_table, train, output)
    target = correction_target(train_table)
    model = model_from_config(selected["config"], int(protocol["seed"]) + 900)
    model.fit(train_table["features"], target)
    model_artifact = {
        "model": model,
        "selected": selected,
        "feature_dim": int(train_table["features"].shape[1]),
        "selection_source": "Expert-A grouped OOF only",
        "roles": protocol["roles"],
    }
    atomic_joblib(output / "global_count_model.joblib", model_artifact)
    atomic_json(
        output / "progress.json",
        {
            "status": "FINAL_MODEL_FIT",
            "model_sha256": file_sha256(output / "global_count_model.joblib"),
            "router_B_used": False,
            "sealed_test_used": False,
        },
    )
    development = load_components(protocol, "development")
    development_table = make_image_table(development)
    summary = evaluate(output, protocol, model, selected, development_table, development)
    summary["model_sha256"] = file_sha256(output / "global_count_model.joblib")
    atomic_json(output / "summary.json", summary)
    atomic_json(output / "progress.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("prepare", "smoke", "run"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--residual-run", type=Path)
    parser.add_argument("--absolute-run", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    if args.mode == "prepare":
        if args.residual_run is None or args.absolute_run is None:
            parser.error("prepare requires --residual-run and --absolute-run")
        prepare(args)
    else:
        protocol = verify(output)
        if args.mode == "smoke":
            smoke(output, protocol)
        else:
            run(output, protocol)


if __name__ == "__main__":
    main()
