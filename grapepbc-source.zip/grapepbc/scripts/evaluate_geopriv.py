"""Evaluate a frozen GeoPriv/LitePoint checkpoint without test-set tuning.

New checkpoints restore a complete decoder contract. Peak-threshold legacy
checkpoints remain supported, while density-guided checkpoints use the stored
density integral and Top-K protocol without a test-set score threshold.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import platform
import statistics
import time
from typing import Any, Mapping, Sequence

import numpy as np
import torch
from torch.utils.data import DataLoader

from geopriv.data import PointManifestDataset, collate_point_samples
from geopriv.metrics import aggregate_count_metrics, maximum_cardinality_point_matches
from geopriv.models import (
    DEFAULT_CANDIDATE_SCORE_FLOOR,
    GeoPrivNet,
    LitePointB0,
    decode_points_by_mode,
)


MODEL_KINDS = ("auto", "geopriv", "litepoint")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Evaluate one checkpoint at its frozen validation threshold; no "
            "threshold search is performed on the evaluation split."
        )
    )
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--split", default="test")
    parser.add_argument(
        "--allow-non-test-split",
        action="store_true",
        help="Explicitly acknowledge evaluation on a split other than test.",
    )
    parser.add_argument("--model-type", choices=MODEL_KINDS, default="auto")
    parser.add_argument(
        "--threshold",
        type=float,
        help=(
            "Explicit score-threshold override. If omitted, the checkpoint's "
            "frozen selected_threshold is used."
        ),
    )
    parser.add_argument(
        "--image-size",
        type=int,
        help="Override input size; otherwise restore checkpoint config.image_size.",
    )
    parser.add_argument("--match-radius", type=float)
    parser.add_argument("--local-max-kernel", type=int)
    parser.add_argument("--topk", type=int)
    parser.add_argument(
        "--candidate-score-floor",
        type=float,
        help="Explicit density candidate-floor override for sensitivity analysis.",
    )
    parser.add_argument("--max-samples", type=int)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--warmup-iterations", type=int, default=5)
    parser.add_argument("--device", default="cuda")
    return parser


def _finite_probability(value: object, *, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a finite number in [0, 1]")
    result = float(value)
    if not math.isfinite(result) or not 0.0 <= result <= 1.0:
        raise ValueError(f"{name} must be a finite number in [0, 1]")
    return result


def resolve_threshold(
    checkpoint: Mapping[str, object], override: float | None
) -> tuple[float, dict[str, object]]:
    """Resolve one fixed threshold and preserve its provenance.

    A default is accepted only when the checkpoint both stores a top-level
    ``selected_threshold`` and marks it as frozen.  Legacy checkpoints remain
    evaluable with an explicit override, but their training-set metric is never
    silently treated as a frozen validation threshold.
    """

    checkpoint_value: float | None = None
    checkpoint_source: str | None = None
    if "selected_threshold" in checkpoint:
        checkpoint_value = _finite_probability(
            checkpoint["selected_threshold"], name="checkpoint selected_threshold"
        )
        checkpoint_source = "checkpoint.selected_threshold"
        selection = checkpoint.get("threshold_selection")
        if not isinstance(selection, Mapping) or selection.get(
            "frozen_for_checkpoint"
        ) is not True:
            raise ValueError(
                "checkpoint selected_threshold is not marked frozen_for_checkpoint"
            )
        if selection.get("source") != "validation_only":
            raise ValueError(
                "checkpoint selected_threshold must have source='validation_only'"
            )
        validation_metrics = checkpoint.get("validation_metrics")
        if isinstance(validation_metrics, Mapping) and "threshold" in validation_metrics:
            validation_value = _finite_probability(
                validation_metrics["threshold"],
                name="checkpoint validation_metrics.threshold",
            )
            if not math.isclose(
                checkpoint_value, validation_value, rel_tol=0.0, abs_tol=1e-12
            ):
                raise ValueError(
                    "checkpoint selected_threshold conflicts with validation_metrics.threshold"
                )

    if override is not None:
        value = _finite_probability(override, name="--threshold")
        return value, {
            "value": value,
            "source": "cli_override",
            "overridden": True,
            "checkpoint_value": checkpoint_value,
            "checkpoint_source": checkpoint_source,
            "test_set_search_performed": False,
        }
    if checkpoint_value is None or checkpoint_source is None:
        raise ValueError(
            "checkpoint has no frozen selected_threshold; pass --threshold "
            "explicitly (the evaluator will record the override)"
        )

    selection = checkpoint.get("threshold_selection")
    selection_provenance = dict(selection) if isinstance(selection, Mapping) else None
    return checkpoint_value, {
        "value": checkpoint_value,
        "source": checkpoint_source,
        "overridden": False,
        "checkpoint_threshold_selection": selection_provenance,
        "test_set_search_performed": False,
    }


def resolve_decoder_protocol(
    checkpoint: Mapping[str, object],
    *,
    threshold_override: float | None,
    candidate_score_floor_override: float | None,
) -> tuple[dict[str, object], dict[str, object]]:
    """Restore one frozen decoder, falling back to legacy peak checkpoints."""

    raw = checkpoint.get("decoder_config")
    if raw is None:
        threshold, threshold_report = resolve_threshold(checkpoint, threshold_override)
        if candidate_score_floor_override is not None:
            raise ValueError(
                "--candidate-score-floor applies only to density_topk checkpoints"
            )
        return (
            {
                "count_mode": "peak_threshold",
                "score_threshold": threshold,
                "candidate_score_floor": DEFAULT_CANDIDATE_SCORE_FLOOR,
            },
            {
                "source": "legacy_peak_checkpoint",
                "frozen_for_checkpoint": True,
                "threshold": threshold_report,
                "overridden": bool(threshold_report["overridden"]),
                "test_set_search_performed": False,
            },
        )
    if not isinstance(raw, Mapping):
        raise ValueError("checkpoint decoder_config must be a mapping")
    if raw.get("frozen_for_checkpoint") is not True:
        raise ValueError("checkpoint decoder_config is not marked frozen_for_checkpoint")
    count_mode = raw.get("count_mode")
    if count_mode not in {"peak_threshold", "density_topk"}:
        raise ValueError(f"unsupported checkpoint decoder count_mode: {count_mode!r}")
    stored_stride = raw.get("output_stride")
    checkpoint_stride = checkpoint.get("output_stride")
    if stored_stride is not None and stored_stride != checkpoint_stride:
        raise ValueError(
            "checkpoint decoder_config.output_stride conflicts with output_stride"
        )

    if count_mode == "peak_threshold":
        if candidate_score_floor_override is not None:
            raise ValueError(
                "--candidate-score-floor applies only to density_topk checkpoints"
            )
        threshold, threshold_report = resolve_threshold(checkpoint, threshold_override)
        return (
            {
                "count_mode": count_mode,
                "score_threshold": threshold,
                "candidate_score_floor": DEFAULT_CANDIDATE_SCORE_FLOOR,
            },
            {
                "source": "checkpoint.decoder_config",
                "frozen_for_checkpoint": True,
                "threshold": threshold_report,
                "overridden": bool(threshold_report["overridden"]),
                "test_set_search_performed": False,
            },
        )

    if threshold_override is not None:
        raise ValueError("--threshold is not applicable to density_topk checkpoints")
    if raw.get("density_rounding") != "half_up_nonnegative":
        raise ValueError(
            "unsupported checkpoint decoder_config.density_rounding; "
            "expected 'half_up_nonnegative'"
        )
    if raw.get("valid_region") != "valid_image_mask_projected_with_adaptive_max_pool":
        raise ValueError("unsupported checkpoint decoder_config.valid_region")
    stored_floor = _finite_probability(
        raw.get("candidate_score_floor", DEFAULT_CANDIDATE_SCORE_FLOOR),
        name="checkpoint decoder_config.candidate_score_floor",
    )
    if candidate_score_floor_override is None:
        floor = stored_floor
        floor_source = "checkpoint.decoder_config.candidate_score_floor"
        overridden = False
    else:
        floor = _finite_probability(
            candidate_score_floor_override, name="--candidate-score-floor"
        )
        floor_source = "cli_override"
        overridden = True
    return (
        {
            "count_mode": count_mode,
            "score_threshold": None,
            "candidate_score_floor": floor,
        },
        {
            "source": "checkpoint.decoder_config",
            "frozen_for_checkpoint": True,
            "threshold": {
                "value": None,
                "source": "not_applicable_density_topk",
                "overridden": False,
                "test_set_search_performed": False,
            },
            "candidate_score_floor": {
                "value": floor,
                "source": floor_source,
                "checkpoint_value": stored_floor,
            },
            "overridden": overridden,
            "test_set_search_performed": False,
        },
    )


def _required_int(value: object, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError(f"{name} must be a positive integer")
    return value


def _required_bool(value: object, *, name: str) -> bool:
    if not isinstance(value, bool):
        raise ValueError(f"{name} must be boolean")
    return value


def _required_norm(value: object, *, name: str) -> str:
    if value not in {"batch", "group"}:
        raise ValueError(f"{name} must be 'batch' or 'group'")
    return str(value)


def detect_model_kind(state_dict: Mapping[str, object]) -> str:
    geometry_prefixes = ("log_radius_head.", "density_head.")
    present = [
        any(name.startswith(prefix) for name in state_dict)
        for prefix in geometry_prefixes
    ]
    if all(present):
        return "geopriv"
    if any(present):
        raise ValueError("checkpoint has an incomplete GeoPriv head set")
    return "litepoint"


def _mapping(value: object, *, name: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise ValueError(f"checkpoint {name} must be a mapping")
    return value


def restore_model(
    checkpoint: Mapping[str, object], requested_kind: str = "auto"
) -> tuple[torch.nn.Module, str, dict[str, object]]:
    """Strictly reconstruct architecture and load every state-dict entry."""

    if requested_kind not in MODEL_KINDS:
        raise ValueError(f"unsupported model type: {requested_kind!r}")
    state_dict = _mapping(checkpoint.get("model"), name="model")
    detected = detect_model_kind(state_dict)
    if requested_kind != "auto" and requested_kind != detected:
        raise ValueError(
            f"--model-type={requested_kind} conflicts with checkpoint weights ({detected})"
        )
    kind = detected
    raw_config = _mapping(checkpoint.get("model_config"), name="model_config")

    if kind == "geopriv":
        required = {
            "fpn_channels",
            "decoder_norm",
            "freeze_backbone_bn",
        }
        missing = required.difference(raw_config)
        unknown = set(raw_config).difference(required)
        if missing or unknown:
            raise ValueError(
                "GeoPriv model_config must exactly contain "
                f"{sorted(required)}; missing={sorted(missing)}, unknown={sorted(unknown)}"
            )
        config: dict[str, object] = {
            "fpn_channels": _required_int(
                raw_config["fpn_channels"], name="model_config.fpn_channels"
            ),
            "decoder_norm": _required_norm(
                raw_config["decoder_norm"], name="model_config.decoder_norm"
            ),
            "freeze_backbone_bn": _required_bool(
                raw_config["freeze_backbone_bn"],
                name="model_config.freeze_backbone_bn",
            ),
        }
        model: torch.nn.Module = GeoPrivNet(pretrained=False, **config)
    else:
        # Current LitePoint checkpoints predate serialization of fpn_channels.
        # Infer only that missing architecture value from the exact weight
        # tensor, while restoring every serialized option strictly.
        required = {"decoder_norm", "freeze_backbone_bn"}
        allowed = required | {"fpn_channels"}
        missing = required.difference(raw_config)
        unknown = set(raw_config).difference(allowed)
        if missing or unknown:
            raise ValueError(
                "LitePoint model_config is incomplete or unsupported; "
                f"missing={sorted(missing)}, unknown={sorted(unknown)}"
            )
        lateral = state_dict.get("encoder.lateral2.weight")
        if not isinstance(lateral, torch.Tensor) or lateral.ndim != 4:
            raise ValueError("cannot infer LitePoint fpn_channels from checkpoint weights")
        inferred_channels = int(lateral.shape[0])
        serialized_channels = raw_config.get("fpn_channels", inferred_channels)
        fpn_channels = _required_int(
            serialized_channels, name="model_config.fpn_channels"
        )
        if fpn_channels != inferred_channels:
            raise ValueError(
                "model_config.fpn_channels conflicts with encoder.lateral2.weight"
            )
        config = {
            "fpn_channels": fpn_channels,
            "decoder_norm": _required_norm(
                raw_config["decoder_norm"], name="model_config.decoder_norm"
            ),
            "freeze_backbone_bn": _required_bool(
                raw_config["freeze_backbone_bn"],
                name="model_config.freeze_backbone_bn",
            ),
        }
        model = LitePointB0(pretrained=False, **config)

    saved_stride = checkpoint.get("output_stride")
    if isinstance(saved_stride, bool) or not isinstance(saved_stride, int):
        raise ValueError("checkpoint output_stride must be an integer")
    if saved_stride != model.output_stride:
        raise ValueError(
            f"checkpoint output_stride={saved_stride} does not match "
            f"{kind} output_stride={model.output_stride}"
        )
    model.load_state_dict(state_dict, strict=True)
    return model, kind, config


def _checkpoint_setting(
    checkpoint: Mapping[str, object], name: str, fallback: object
) -> tuple[object, str]:
    config = checkpoint.get("config")
    if isinstance(config, Mapping) and config.get(name) is not None:
        return config[name], f"checkpoint.config.{name}"
    return fallback, "evaluator_default"


def _checkpoint_decoder_setting(
    checkpoint: Mapping[str, object], name: str
) -> tuple[object | None, str | None]:
    config = checkpoint.get("decoder_config")
    if isinstance(config, Mapping) and config.get(name) is not None:
        return config[name], f"checkpoint.decoder_config.{name}"
    return None, None


def resolve_evaluation_settings(
    args: argparse.Namespace, checkpoint: Mapping[str, object]
) -> dict[str, object]:
    settings: dict[str, object] = {}
    sources: dict[str, str] = {}
    defaults = {
        "image_size": None,
        "match_radius": 8.0,
        "local_max_kernel": 3,
        "topk": 4096,
    }
    for name, fallback in defaults.items():
        override = getattr(args, name)
        if override is not None:
            value, source = override, "cli_override"
        else:
            value = source = None
            if name in {"local_max_kernel", "topk"}:
                value, source = _checkpoint_decoder_setting(checkpoint, name)
            if source is None:
                value, source = _checkpoint_setting(checkpoint, name, fallback)
        if value is None:
            raise ValueError(
                f"--{name.replace('_', '-')} is required because it is absent "
                "from the checkpoint config"
            )
        settings[name] = value
        sources[name] = source

    settings["image_size"] = _required_int(
        settings["image_size"], name="image_size"
    )
    settings["topk"] = _required_int(settings["topk"], name="topk")
    settings["local_max_kernel"] = _required_int(
        settings["local_max_kernel"], name="local_max_kernel"
    )
    if int(settings["local_max_kernel"]) % 2 == 0:
        raise ValueError("local_max_kernel must be odd")
    radius = settings["match_radius"]
    if isinstance(radius, bool) or not isinstance(radius, (int, float)):
        raise ValueError("match_radius must be a finite non-negative number")
    radius = float(radius)
    if not math.isfinite(radius) or radius < 0:
        raise ValueError("match_radius must be a finite non-negative number")
    settings["match_radius"] = radius
    settings["sources"] = sources
    return settings


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _synchronize(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)


def _forward(
    model: torch.nn.Module,
    kind: str,
    images: torch.Tensor,
    masks: torch.Tensor,
) -> dict[str, torch.Tensor]:
    return model(images, masks)  # type: ignore[call-arg,return-value]


def _latency_summary(values: Sequence[float], warmup_iterations: int) -> dict[str, object]:
    data = np.asarray(values, dtype=np.float64)
    mean = float(np.mean(data))
    return {
        "definition": "model_forward_plus_point_decode; excludes image I/O and host-to-device transfer",
        "unit": "ms_per_image",
        "warmup_iterations": warmup_iterations,
        "measured_images": len(values),
        "mean": mean,
        "median": float(statistics.median(values)),
        "p95": float(np.percentile(data, 95)),
        "minimum": float(np.min(data)),
        "maximum": float(np.max(data)),
        "throughput_images_per_second_from_mean": 1000.0 / mean if mean > 0 else None,
    }


@torch.inference_mode()
def evaluate(
    model: torch.nn.Module,
    kind: str,
    loader: DataLoader,
    warmup_batch: dict[str, Any],
    device: torch.device,
    *,
    count_mode: str,
    threshold: float | None,
    candidate_score_floor: float,
    output_stride: int,
    match_radius: float,
    local_max_kernel: int,
    topk: int,
    warmup_iterations: int,
) -> tuple[dict[str, object], list[dict[str, object]], dict[str, object]]:
    model.eval()
    if count_mode == "peak_threshold" and threshold is None:
        raise ValueError("peak_threshold evaluation requires a score threshold")
    if count_mode not in {"peak_threshold", "density_topk"}:
        raise ValueError(f"unsupported count_mode: {count_mode!r}")

    def decode(
        outputs: Mapping[str, torch.Tensor], masks: torch.Tensor
    ) -> list[dict[str, torch.Tensor | int | float | bool]]:
        return decode_points_by_mode(
            outputs,
            count_mode=count_mode,  # type: ignore[arg-type]
            score_threshold=float(threshold if threshold is not None else 0.25),
            topk=topk,
            local_max_kernel=local_max_kernel,
            candidate_score_floor=candidate_score_floor,
            valid_mask=masks,
            output_stride=output_stride,
        )

    warm_images = warmup_batch["images"].to(device, non_blocking=True)
    warm_masks = warmup_batch["valid_image_masks"].to(device, non_blocking=True)
    for _ in range(warmup_iterations):
        warm_outputs = _forward(model, kind, warm_images, warm_masks)
        decode(warm_outputs, warm_masks)
    _synchronize(device)
    if warmup_iterations:
        del warm_outputs
    del warm_images, warm_masks
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)

    predicted_counts: list[int] = []
    target_counts: list[int] = []
    latencies: list[float] = []
    sample_rows: list[dict[str, object]] = []
    true_positive = false_positive = false_negative = 0
    density_count_raw_values: list[float] = []
    candidate_shortfall_total = 0
    candidate_shortfall_images = 0
    topk_saturation_images = 0

    for batch in loader:
        images = batch["images"].to(device, non_blocking=True)
        masks = batch["valid_image_masks"].to(device, non_blocking=True)
        _synchronize(device)
        started_ns = time.perf_counter_ns()
        outputs = _forward(model, kind, images, masks)
        predictions = decode(outputs, masks)
        _synchronize(device)
        elapsed_ms = (time.perf_counter_ns() - started_ns) / 1_000_000.0

        # Loader batch size is deliberately one so timing remains per image.
        prediction = predictions[0]
        target = batch["targets"][0]
        predicted_count = int(prediction["count"])
        true_count = int(target["count"])
        tp, fp, fn = maximum_cardinality_point_matches(
            prediction["points"].detach().cpu().numpy(),
            target["points_xy"].detach().cpu().numpy(),
            match_radius,
        )
        predicted_counts.append(predicted_count)
        target_counts.append(true_count)
        latencies.append(elapsed_ms)
        true_positive += tp
        false_positive += fp
        false_negative += fn
        error = predicted_count - true_count
        row: dict[str, object] = {
            "sample_id": str(target["sample_id"]),
            "true_count": true_count,
            "predicted_count": predicted_count,
            "error": error,
            "absolute_error": abs(error),
            "true_positive": tp,
            "false_positive": fp,
            "false_negative": fn,
            "latency_ms": elapsed_ms,
        }
        if count_mode == "density_topk":
            density_count_raw = float(prediction["density_count_raw"])
            candidate_shortfall = int(prediction["candidate_shortfall"])
            topk_saturation = bool(prediction["topk_saturation"])
            density_count_raw_values.append(density_count_raw)
            candidate_shortfall_total += candidate_shortfall
            candidate_shortfall_images += int(candidate_shortfall > 0)
            topk_saturation_images += int(topk_saturation)
            row.update(
                {
                    "density_count_raw": density_count_raw,
                    "requested_k": int(prediction["requested_k"]),
                    "candidate_count": int(prediction["candidate_count"]),
                    "candidate_shortfall": candidate_shortfall,
                    "topk_saturation": topk_saturation,
                }
            )
        sample_rows.append(row)

    count_metrics = aggregate_count_metrics(predicted_counts, target_counts)
    precision = true_positive / max(true_positive + false_positive, 1)
    recall = true_positive / max(true_positive + false_negative, 1)
    f1 = 2.0 * precision * recall / max(precision + recall, 1e-12)
    metrics: dict[str, object] = {
        "count": count_metrics,
        "localization": {
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "true_positive": true_positive,
            "false_positive": false_positive,
            "false_negative": false_negative,
            "matching": "maximum_cardinality_one_to_one",
            "radius_pixels_in_model_input": match_radius,
        },
    }
    if count_mode == "density_topk":
        density_errors = np.asarray(density_count_raw_values) - np.asarray(
            target_counts, dtype=np.float64
        )
        metrics["density_decoder"] = {
            "density_count_raw_bias": float(np.mean(density_errors)),
            "density_count_raw_mae": float(np.mean(np.abs(density_errors))),
            "candidate_shortfall_total": candidate_shortfall_total,
            "candidate_shortfall_images": candidate_shortfall_images,
            "topk_saturation_images": topk_saturation_images,
        }
    performance = {
        "latency": _latency_summary(latencies, warmup_iterations),
        "peak_cuda_memory_bytes": (
            int(torch.cuda.max_memory_allocated(device)) if device.type == "cuda" else 0
        ),
        "peak_cuda_memory_mib": (
            float(torch.cuda.max_memory_allocated(device) / 2**20)
            if device.type == "cuda"
            else 0.0
        ),
    }
    return metrics, sample_rows, performance


def _load_checkpoint(path: Path) -> Mapping[str, object]:
    if not path.is_file():
        raise FileNotFoundError(path)
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    if not isinstance(checkpoint, Mapping):
        raise ValueError("checkpoint root must be a mapping")
    return checkpoint


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.max_samples is not None and args.max_samples <= 0:
        parser.error("--max-samples must be positive")
    if args.num_workers < 0:
        parser.error("--num-workers must be non-negative")
    if args.warmup_iterations < 0:
        parser.error("--warmup-iterations must be non-negative")
    if args.split != "test" and not args.allow_non_test_split:
        parser.error(
            "non-test evaluation requires --allow-non-test-split; the default "
            "publication protocol is split=test"
        )

    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise SystemExit("CUDA is unavailable")
    checkpoint_path = args.checkpoint.resolve()
    checkpoint = _load_checkpoint(checkpoint_path)
    decoder, decoder_report = resolve_decoder_protocol(
        checkpoint,
        threshold_override=args.threshold,
        candidate_score_floor_override=args.candidate_score_floor,
    )
    settings = resolve_evaluation_settings(args, checkpoint)
    model, model_kind, model_config = restore_model(checkpoint, args.model_type)
    if decoder["count_mode"] == "density_topk" and model_kind != "geopriv":
        raise ValueError("density_topk requires a GeoPriv checkpoint with a density head")
    model = model.to(device)

    dataset = PointManifestDataset(
        args.manifest,
        args.root,
        split=args.split,
        image_size=int(settings["image_size"]),
    )
    if args.max_samples is not None:
        dataset.records = dataset.records[: args.max_samples]
    loader = DataLoader(
        dataset,
        batch_size=1,
        shuffle=False,
        num_workers=args.num_workers,
        collate_fn=collate_point_samples,
        pin_memory=device.type == "cuda",
        persistent_workers=args.num_workers > 0,
    )
    warmup_batch = collate_point_samples([dataset[0]])
    metrics, samples, performance = evaluate(
        model,
        model_kind,
        loader,
        warmup_batch,
        device,
        count_mode=str(decoder["count_mode"]),
        threshold=(
            None
            if decoder["score_threshold"] is None
            else float(decoder["score_threshold"])
        ),
        candidate_score_floor=float(decoder["candidate_score_floor"]),
        output_stride=model.output_stride,
        match_radius=float(settings["match_radius"]),
        local_max_kernel=int(settings["local_max_kernel"]),
        topk=int(settings["topk"]),
        warmup_iterations=args.warmup_iterations,
    )

    total_parameters = sum(parameter.numel() for parameter in model.parameters())
    trainable_parameters = sum(
        parameter.numel() for parameter in model.parameters() if parameter.requires_grad
    )
    report: dict[str, object] = {
        "schema_version": 2,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "evaluation_protocol": {
            "split": args.split,
            "sample_count": len(dataset),
            "decoder": decoder_report,
            "threshold": decoder_report["threshold"],
            "test_time_adaptation": False,
            "threshold_search_on_evaluated_split": False,
        },
        "checkpoint": {
            "path": str(checkpoint_path),
            "sha256": _sha256(checkpoint_path),
            "epoch": checkpoint.get("epoch"),
            "selection": checkpoint.get("selection"),
        },
        "data": {
            "manifest": str(args.manifest.resolve()),
            "manifest_sha256": _sha256(args.manifest.resolve()),
            "root": str(args.root.resolve()),
            "split": args.split,
            "image_size": int(settings["image_size"]),
            "max_samples": args.max_samples,
        },
        "model": {
            "type": model_kind,
            "class": type(model).__name__,
            "config": model_config,
            "output_stride": model.output_stride,
            "parameters_total": total_parameters,
            "parameters_trainable": trainable_parameters,
        },
        "decoder": {
            "count_mode": decoder["count_mode"],
            "score_threshold": decoder["score_threshold"],
            "candidate_score_floor": decoder["candidate_score_floor"],
            "topk": int(settings["topk"]),
            "local_max_kernel": int(settings["local_max_kernel"]),
            "setting_sources": settings["sources"],
        },
        "metrics": metrics,
        "performance": performance,
        "environment": {
            "device": str(device),
            "device_name": (
                torch.cuda.get_device_name(device) if device.type == "cuda" else platform.processor()
            ),
            "python": platform.python_version(),
            "torch": torch.__version__,
            "numpy": np.__version__,
        },
        "samples": samples,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.output.with_suffix(args.output.suffix + ".tmp")
    temporary.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    temporary.replace(args.output)
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)
    return report


if __name__ == "__main__":
    main()
