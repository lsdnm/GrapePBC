"""Stacked group-OOF RGB selector over original and learned centre candidates."""
from __future__ import annotations

import json
from pathlib import Path
import random
import sys
import time

import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.spatial import distance_matrix
from sklearn.model_selection import GroupKFold
import torch
from torch import nn
from torch.nn import functional as F


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

from geopriv.data.hash_utils import file_sha256  # noqa: E402
from run_vivid_hr_core_calibration import atomic_json, atomic_npz  # noqa: E402
import train_rgb_point_center_refiner as base  # noqa: E402
import train_rgb_center_refiner_development_oof_v4 as v4  # noqa: E402
import calibrate_oof_geometry_gate_v4 as geometry  # noqa: E402


EXP = PROJECT / "experiments" / "cru_detail_v1"
OUT = EXP / "vivid_center_candidate_selector_oof_v7"
SOURCE_NAMES = ("original", "v4", "v6", "heatmap_v5")
SOURCE_ROOTS = {
    "v4": EXP / "vivid_rgb_point_center_refiner_development_oof_v4" / "oof_inference_cache",
    "v6": EXP / "vivid_misaligned_only_center_refiner_oof_v6" / "oof_inference_cache",
    "heatmap_v5": EXP / "vivid_anchor_heatmap_center_refiner_oof_v5" / "oof_inference_cache",
}
SEED = 20261025
FOLDS = 5
EPOCHS = 3
PATCH = 32
HALVES = (16.0, 36.0)
GEOMETRY_DIM = 11
VERSION = "vivid-center-candidate-selector-oof-v7"
REPAIR_BALANCE_RATIO: float | None = None
FLIP_AUGMENTATION = True
SPATIAL_POOL = 1


class CandidateSelector(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.visual = nn.Sequential(
            nn.Conv2d(6, 24, 5, stride=2, padding=2, bias=False), nn.GroupNorm(6, 24), nn.SiLU(),
            nn.Conv2d(24, 48, 3, stride=2, padding=1, bias=False), nn.GroupNorm(8, 48), nn.SiLU(),
            nn.Conv2d(48, 64, 3, stride=2, padding=1, bias=False), nn.GroupNorm(8, 64), nn.SiLU(),
            nn.Conv2d(64, 64, 3, padding=1, bias=False), nn.GroupNorm(8, 64), nn.SiLU(),
            nn.AdaptiveAvgPool2d(SPATIAL_POOL), nn.Flatten(),
        )
        self.score = nn.Sequential(nn.Linear(64 * SPATIAL_POOL * SPATIAL_POOL + GEOMETRY_DIM, 128), nn.SiLU(),
                                   nn.Dropout(0.08), nn.Linear(128, 1))

    def forward(self, patches: torch.Tensor, features: torch.Tensor) -> torch.Tensor:
        return self.score(torch.cat((self.visual(patches), features), dim=1))[:, 0]


def source_payload(record: dict) -> dict:
    points, truth, reliability = v4.baseline_payload(record)
    filename = record["sample_id"].replace(":", "_") + ".npz"
    offsets = [np.zeros_like(points, dtype=np.float32)]
    confidences = [np.ones(len(points), dtype=np.float32)]
    for name in SOURCE_NAMES[1:]:
        with np.load(SOURCE_ROOTS[name] / filename, allow_pickle=False) as payload:
            offsets.append(payload["offset"].astype(np.float32))
            confidences.append(payload["confidence"].astype(np.float32))
    return {"points": points, "truth": truth, "reliability": reliability,
            "offsets": np.stack(offsets, axis=1),
            "confidences": np.stack(confidences, axis=1)}


def candidate_geometry(payload: dict, scale: float) -> tuple[np.ndarray, np.ndarray]:
    points = payload["points"]
    offsets = payload["offsets"]
    candidates = points[:, None, :] + offsets / scale
    spacing = base.spacing(points, scale)
    median_offset = np.median(offsets, axis=1, keepdims=True)
    source_one_hot = np.eye(len(SOURCE_NAMES), dtype=np.float32)[None].repeat(len(points), axis=0)
    magnitude = np.linalg.norm(offsets, axis=2)
    disagreement = np.linalg.norm(offsets - median_offset, axis=2)
    reliability = payload["reliability"]
    if reliability.ndim > 1:
        reliability = reliability.mean(axis=tuple(range(1, reliability.ndim)))
    reliability = np.resize(reliability.astype(np.float32), len(points)) if len(points) else np.empty(0, np.float32)
    common = np.stack((
        np.log1p(spacing) / np.log(65.0),
        reliability,
    ), axis=1)[:, None, :].repeat(len(SOURCE_NAMES), axis=1)
    feature = np.concatenate((
        source_one_hot,
        offsets / 24.0,
        (magnitude / 24.0)[..., None],
        payload["confidences"][..., None],
        (disagreement / 24.0)[..., None],
        common,
    ), axis=2).astype(np.float32)
    if feature.shape[2] != GEOMETRY_DIM:
        raise RuntimeError(f"geometry feature drift: {feature.shape}")
    return candidates.astype(np.float32), feature


def truth_targets(payload: dict, scale: float) -> tuple[np.ndarray, np.ndarray]:
    points, truth = payload["points"], payload["truth"]
    candidates, _ = candidate_geometry(payload, scale)
    if not len(points) or not len(truth):
        return np.empty(0, np.int64), np.empty(0, np.int64)
    cost = distance_matrix(points * scale, truth * scale)
    point_index, truth_index = linear_sum_assignment(cost)
    accepted = cost[point_index, truth_index] <= 32.0
    point_index = point_index[accepted]; truth_index = truth_index[accepted]
    candidate_distance = np.linalg.norm(
        (candidates[point_index] - truth[truth_index, None]) * scale, axis=2)
    target = candidate_distance.argmin(axis=1).astype(np.int64)
    improvement = candidate_distance[:, 0] - candidate_distance[np.arange(len(target)), target]
    target[improvement < 0.75] = 0
    return point_index.astype(np.int64), target


def sample_patches(image: np.ndarray, candidates: np.ndarray, scale: float,
                   device: torch.device) -> torch.Tensor:
    flat = candidates.reshape(-1, 2)
    rgb = torch.from_numpy(image).to(device=device, dtype=torch.float32).permute(2, 0, 1) / 255.0
    mean = torch.tensor([0.485, 0.456, 0.406], device=device)[:, None, None]
    std = torch.tensor([0.229, 0.224, 0.225], device=device)[:, None, None]
    rgb = (rgb - mean) / std
    height, width = image.shape[:2]
    anchors = torch.from_numpy(flat).to(device)
    views = []
    for half in HALVES:
        native = half / scale
        axis = torch.linspace(-native, native, PATCH, device=device)
        xx = anchors[:, 0, None, None] + axis[None, None, :]
        yy = anchors[:, 1, None, None] + axis[None, :, None]
        xx = xx.expand(-1, PATCH, -1); yy = yy.expand(-1, -1, PATCH)
        grid = torch.stack((xx * (2.0 / max(width - 1, 1)) - 1.0,
                            yy * (2.0 / max(height - 1, 1)) - 1.0), dim=-1)
        source = rgb[None].expand(len(flat), -1, -1, -1)
        views.append(F.grid_sample(source, grid, mode="bilinear",
                                   padding_mode="reflection", align_corners=True))
    return torch.cat(views, dim=1)


def epoch_pass(model: nn.Module, records: list[dict], optimizer,
               device: torch.device, *, epoch: int) -> dict:
    model.train(); rng = np.random.default_rng(SEED + epoch)
    totals = {"loss": 0.0, "correct": 0, "samples": 0,
              "target": np.zeros(len(SOURCE_NAMES), dtype=np.int64),
              "predicted_correct": np.zeros(len(SOURCE_NAMES), dtype=np.int64)}
    for position, record_index in enumerate(rng.permutation(len(records))):
        record = records[int(record_index)]
        payload = source_payload(record)
        image_size = (int(record["width"]), int(record["height"]))
        scale = 1024.0 / max(image_size)
        point_index, target = truth_targets(payload, scale)
        if not len(point_index):
            continue
        candidates, features = candidate_geometry(payload, scale)
        # Bound per-image dominance while retaining every target class.
        selected = []
        if REPAIR_BALANCE_RATIO is not None:
            repair = np.flatnonzero(target > 0)
            if len(repair) > 192:
                repair = rng.choice(repair, 192, replace=False)
            original = np.flatnonzero(target == 0)
            original_limit = max(8, int(np.ceil(REPAIR_BALANCE_RATIO * max(len(repair), 1))))
            if len(original) > original_limit:
                original = rng.choice(original, original_limit, replace=False)
            selected.extend(int(value) for value in original)
            selected.extend(int(value) for value in repair)
        else:
            for target_class in range(len(SOURCE_NAMES)):
                available = np.flatnonzero(target == target_class)
                if len(available) > 96:
                    available = rng.choice(available, 96, replace=False)
                selected.extend(int(value) for value in available)
        selected = np.asarray(selected, dtype=np.int64); rng.shuffle(selected)
        point_index = point_index[selected]; target = target[selected]
        image = base.load_rgb(base.ROOT / record["image_path"])
        for start in range(0, len(point_index), 48):
            end = min(start + 48, len(point_index))
            ids = point_index[start:end]
            patches = sample_patches(image, candidates[ids], scale, device)
            geometry_feature = torch.from_numpy(features[ids].reshape(-1, GEOMETRY_DIM)).to(device)
            if FLIP_AUGMENTATION and rng.random() < 0.5:
                patches = torch.flip(patches, dims=(3,))
            patches = patches * float(rng.uniform(0.92, 1.08)) + float(rng.uniform(-0.05, 0.05))
            score = model(patches, geometry_feature).reshape(-1, len(SOURCE_NAMES))
            target_tensor = torch.from_numpy(target[start:end]).to(device)
            loss = F.cross_entropy(score, target_tensor)
            optimizer.zero_grad(set_to_none=True); loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0); optimizer.step()
            count = end - start
            totals["loss"] += float(loss) * count
            prediction = score.argmax(dim=1)
            totals["correct"] += int((prediction == target_tensor).sum())
            totals["samples"] += count
            for target_class in range(len(SOURCE_NAMES)):
                mask = target_tensor == target_class
                totals["target"][target_class] += int(mask.sum())
                totals["predicted_correct"][target_class] += int(((prediction == target_tensor) & mask).sum())
        if (position + 1) % 60 == 0:
            print(f"selector e{epoch} {position + 1}/{len(records)}", flush=True)
    return {"loss": totals["loss"] / max(totals["samples"], 1),
            "accuracy": totals["correct"] / max(totals["samples"], 1),
            "samples": int(totals["samples"]),
            "class_recall": {SOURCE_NAMES[index]: float(totals["predicted_correct"][index]
                                                               / max(totals["target"][index], 1))
                             for index in range(len(SOURCE_NAMES))},
            "class_samples": {SOURCE_NAMES[index]: int(totals["target"][index])
                              for index in range(len(SOURCE_NAMES))}}


def save_checkpoint(path: Path, payload: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temporary); temporary.replace(path)


def fit(model: nn.Module, records: list[dict], device: torch.device,
        folder: Path, *, fold: int) -> list[dict]:
    folder.mkdir(parents=True, exist_ok=True)
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-4)
    history = []
    for local_epoch in range(1, EPOCHS + 1):
        started = time.monotonic()
        metrics = epoch_pass(model, records, optimizer, device,
                             epoch=fold * 100 + local_epoch)
        row = {"fold": fold, "epoch": local_epoch, "training": metrics,
               "elapsed_seconds": time.monotonic() - started}
        history.append(row)
        with (folder / "history.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")
        save_checkpoint(folder / "last.pt", {"fold": fold, "epoch": local_epoch,
                                              "model": model.state_dict(),
                                              "optimizer": optimizer.state_dict(),
                                              "row": row})
        atomic_json(folder / "progress.json", {"status": "TRAINING" if local_epoch < EPOCHS else "COMPLETE",
                                                "fold": fold, "last_epoch": local_epoch,
                                                "router_b_used": False, "sealed_test_used": False})
        print(json.dumps(row, ensure_ascii=False), flush=True)
    return history


@torch.inference_mode()
def infer(model: nn.Module, records: list[dict], device: torch.device,
          folder: Path) -> list[dict]:
    model.eval(); output = []
    for record in records:
        payload = source_payload(record)
        image_size = (int(record["width"]), int(record["height"]))
        scale = 1024.0 / max(image_size)
        candidates, features = candidate_geometry(payload, scale)
        scores = []
        if len(payload["points"]):
            image = base.load_rgb(base.ROOT / record["image_path"])
            for start in range(0, len(candidates), 48):
                end = min(start + 48, len(candidates))
                patches = sample_patches(image, candidates[start:end], scale, device)
                geometry_feature = torch.from_numpy(features[start:end].reshape(-1, GEOMETRY_DIM)).to(device)
                scores.append(model(patches, geometry_feature).reshape(-1, len(SOURCE_NAMES)).cpu().numpy())
            logits = np.concatenate(scores).astype(np.float32)
        else:
            logits = np.empty((0, len(SOURCE_NAMES)), np.float32)
        filename = record["sample_id"].replace(":", "_") + ".npz"
        atomic_npz(folder / filename, logits=logits)
        output.append({"sample_id": record["sample_id"], "image_size": image_size,
                       "scale": scale, "points": payload["points"], "truth": payload["truth"],
                       "reliability": payload["reliability"],
                       "point_spacing": base.spacing(payload["points"], scale),
                       "offsets": payload["offsets"], "logits": logits})
    return output


def apply(item: dict, *, alpha: float, margin: float, minimum_spacing: float,
          fraction: float, absolute_limit: float) -> np.ndarray:
    result = item["points"].copy()
    if not len(result):
        return result
    choice = item["logits"].argmax(axis=1)
    best = item["logits"][np.arange(len(choice)), choice]
    advantage = best - item["logits"][:, 0]
    active = ((choice > 0) & (advantage >= margin)
              & (item["point_spacing"] >= minimum_spacing))
    shift = item["offsets"][np.arange(len(choice)), choice] * alpha
    magnitude = np.linalg.norm(shift, axis=1)
    limit = np.minimum(absolute_limit, fraction * item["point_spacing"])
    shift *= np.minimum(1.0, limit / np.maximum(magnitude, 1e-6))[:, None]
    result[active] += shift[active] / item["scale"]
    width, height = item["image_size"]
    result[:, 0] = np.clip(result[:, 0], 0, width - 1e-3)
    result[:, 1] = np.clip(result[:, 1], 0, height - 1e-3)
    return result.astype(np.float32)


def calibrate(cached: list[dict]) -> tuple[dict, list[dict]]:
    configs = []
    for alpha in (0.50, 0.75, 1.00):
        for margin in (0.00, 0.15, 0.30, 0.50):
            for spacing_minimum in (8.0, 12.0, 16.0, 20.0, 24.0):
                for fraction in (0.10, 0.20, 0.30):
                    for limit in (4.0, 8.0, 12.0):
                        predictions = [apply(item, alpha=alpha, margin=margin,
                                             minimum_spacing=spacing_minimum,
                                             fraction=fraction,
                                             absolute_limit=limit) for item in cached]
                        report = base.evaluate(cached, predictions)
                        configs.append({"alpha": alpha, "margin": margin,
                                        "minimum_spacing": spacing_minimum,
                                        "spacing_fraction": fraction,
                                        "absolute_limit": limit,
                                        "eligible": geometry.strict(report), **report})
    eligible = [row for row in configs if row["eligible"]]
    selected = max(eligible or configs, key=lambda row: (
        row["image_gains"]["4"]["net_tp"], row["image_gains"]["8"]["net_tp"],
        row["image_gains"]["16"]["net_tp"], -row["image_gains"]["4"]["worsened"]))
    return selected, configs


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    torch.manual_seed(SEED); np.random.seed(SEED); random.seed(SEED)
    records = base.rows(base.DEV_MANIFEST)
    groups = np.asarray([row.get("capture_group_id") or row["sample_id"] for row in records])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    protocol = {"version": VERSION, "seed": SEED, "folds": FOLDS,
                "epochs_per_fold": EPOCHS, "candidate_sources": list(SOURCE_NAMES),
                "patch": PATCH, "normalized_half_widths": list(HALVES),
                "stacked_oof": True, "count_conserving": True,
                "development_selected": True, "independent_confirmation": False,
                "router_b_used": False, "sealed_test_used": False,
                "source_sha256": file_sha256(Path(__file__))}
    atomic_json(OUT / "protocol.json", protocol)
    oof_cache = OUT / "oof_selector_cache"; oof_cache.mkdir(exist_ok=True)
    cached = []; fold_rows = []
    for fold, (fit_index, held_index) in enumerate(GroupKFold(FOLDS).split(np.arange(len(records)), groups=groups)):
        fit_records = [records[int(index)] for index in fit_index]
        held_records = [records[int(index)] for index in held_index]
        model = CandidateSelector().to(device)
        history = fit(model, fit_records, device, OUT / f"fold_{fold}", fold=fold)
        cached.extend(infer(model, held_records, device, oof_cache))
        fold_rows.append({"fold": fold, "train_images": len(fit_records),
                          "held_images": len(held_records), "history": history})
        print(f"selector fold {fold} complete", flush=True)
    by_id = {item["sample_id"]: item for item in cached}
    cached = [by_id[record["sample_id"]] for record in records]
    selected, configs = calibrate(cached)
    predictions = [apply(item, alpha=float(selected["alpha"]), margin=float(selected["margin"]),
                         minimum_spacing=float(selected["minimum_spacing"]),
                         fraction=float(selected["spacing_fraction"]),
                         absolute_limit=float(selected["absolute_limit"])) for item in cached]
    point_out = OUT / "oof_development_points"; point_out.mkdir(exist_ok=True)
    for item, points in zip(cached, predictions, strict=True):
        atomic_npz(point_out / (item["sample_id"].replace(":", "_") + ".npz"),
                   cru=points, truth=item["truth"], reliability=item["reliability"])
    deploy_model = CandidateSelector().to(device)
    deploy_history = fit(deploy_model, records, device, OUT / "deploy_refit", fold=FOLDS)
    checkpoint = torch.load(OUT / "deploy_refit" / "last.pt", map_location="cpu", weights_only=False)
    checkpoint["protocol"] = protocol; save_checkpoint(OUT / "deploy_model.pt", checkpoint)
    summary = {"status": "COMPLETE_OPEN_DEVELOPMENT_STACKED_GROUP_OOF",
               "selected": selected,
               "eligible_configs": sum(bool(row["eligible"]) for row in configs),
               "configs_evaluated": len(configs), "folds": fold_rows,
               "deploy_history": deploy_history,
               "model_parameters": sum(parameter.numel() for parameter in deploy_model.parameters()),
               "oof_point_files": len(predictions),
               "deploy_model_sha256": file_sha256(OUT / "deploy_model.pt"),
               "independent_confirmation": False, "router_b_used": False,
               "sealed_test_used": False}
    atomic_json(OUT / "summary.json", summary); atomic_json(OUT / "all_configs.json", configs)
    atomic_json(OUT / "progress.json", {"status": "COMPLETE", "selected": selected,
                                         "router_b_used": False, "sealed_test_used": False})
    print(json.dumps({key: summary[key] for key in (
        "status", "selected", "eligible_configs", "configs_evaluated",
        "model_parameters", "oof_point_files", "deploy_model_sha256")},
        ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
