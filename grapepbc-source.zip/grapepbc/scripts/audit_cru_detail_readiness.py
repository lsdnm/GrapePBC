"""Isolated, train/validation-only readiness audit for the detail-expert CRU.

Never trains a model, repairs source labels, or opens held-out image/point files.
Geometry-derived ownership is diagnostic, NOT human instance-ID ground truth.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, WindowsPath
import shutil
import zipfile

import cv2
import numpy as np


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def read_rows(path):
    return [json.loads(s) for s in Path(path).read_text(encoding='utf-8-sig').splitlines() if s.strip()]


def save_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temp.replace(path)


def save_rows(path, rows):
    path = Path(path)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in rows), encoding='utf-8')
    temp.replace(path)


def development_only(row):
    if row.get('split') not in ('train', 'val') or row.get('external_test') or row.get('final_test'):
        raise ValueError('sealed/non-development row rejected')


def source_path(root, relative):
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError('source path escapes dataset root')
    return path


def cultivar_target(row):
    # The two datasets do not have interchangeable cultivar supervision.
    if row.get('dataset') != 'gbisc':
        return None
    value = row.get('extra', {}).get('variety')
    if value not in ('Kyoho', 'Shine Muscat', 'Summer Black'):
        raise ValueError('missing/unrecognized GBISC cultivar')
    return value


def membership_audit(points, instances, width, height):
    points = np.asarray(points)
    if points.ndim != 2 or points.shape[1] != 2 or not np.isfinite(points).all():
        raise ValueError('invalid points')
    if np.any(points < 0) or np.any(points >= [width, height]):
        raise ValueError('point outside image')
    xy = np.floor(points).astype(np.int64)
    memberships = np.zeros(len(points), dtype=np.int32)
    boxes = []
    seen = set()
    for ann in instances:
        cid = ann['cluster_id']
        if cid in seen:
            raise ValueError('duplicate cluster ID within image')
        seen.add(cid)
        contours = []
        for polygon in ann['polygons_xy']:
            polygon = np.asarray(polygon, dtype=np.float64).reshape(-1, 2)
            if len(polygon) < 3 or not np.isfinite(polygon).all():
                raise ValueError('invalid polygon')
            if np.any(polygon < 0) or np.any(polygon > [width, height]):
                raise ValueError('polygon outside image')
            contours.append(np.rint(polygon).astype(np.int32))
        if not contours:
            raise ValueError('empty instance')
        mask = np.zeros((height, width), dtype=np.uint8)
        # Separate polygon components are unioned, not parity-filled together.
        for contour in contours:
            cv2.fillPoly(mask, [contour], 1)
        if not mask.any():
            raise ValueError('zero raster area')
        memberships += mask[xy[:, 1], xy[:, 0]]
        joined = np.concatenate(contours)
        x0, y0 = joined.min(axis=0)
        x1, y1 = joined.max(axis=0)
        boxes.append({'cluster_id': cid, 'bbox_xyxy': [int(x0), int(y0), int(x1), int(y1)],
                      'source': 'existing_cluster_polygon_envelope'})
    return {'points': len(points), 'no_mask': int((memberships == 0).sum()),
            'one_mask': int((memberships == 1).sum()),
            'multiple_masks': int((memberships > 1).sum()), 'boxes': boxes}


def preserve(project, out):
    paths = []
    for folder in ('cru_local_expert_full_v1', 'formal_gbisc_ablation_v1/A0_point_only_seed20260917'):
        for name in ('best_val_mae.pt', 'last.pt', 'summary.json', 'history.jsonl'):
            paths.append(project / 'runs' / folder / name)
    paths += [project / 'manuscript' / name for name in (
        'CRU_GrapeCounting_Plants_Chinese_V6_OOF.docx',
        'CRU_GrapeCounting_Plants_Chinese_V8_ResourcePositioning.docx')]
    paths += [project / 'PROJECT_RESUME.md', project / 'CURRENT_MANUSCRIPT.txt',
              project / 'data/manifests/gbisc.jsonl']
    items = []
    for p in paths:
        if not p.is_file():
            raise FileNotFoundError(p)
        dest = out / 'preserved' / p.relative_to(project)
        dest.parent.mkdir(parents=True, exist_ok=True)
        original = sha(p)
        shutil.copy2(p, dest)
        if sha(dest) != original or sha(p) != original:
            raise RuntimeError('snapshot/source hash changed')
        items.append({'source': str(p), 'copy': str(dest), 'sha256': original, 'bytes': p.stat().st_size})
    code_files = []
    with zipfile.ZipFile(out / 'code_snapshot.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for folder in ('src', 'scripts', 'configs', 'tests'):
            for p in sorted((project / folder).rglob('*')):
                if p.is_file() and '__pycache__' not in p.parts and p.suffix in ('.py', '.json', '.yaml', '.yml', '.toml'):
                    archive.write(p, p.relative_to(project))
                    code_files.append({'path': str(p.relative_to(project)), 'sha256': sha(p)})
        for name in ('pyproject.toml', 'README.md'):
            p = project / name
            archive.write(p, name)
            code_files.append({'path': name, 'sha256': sha(p)})
    with zipfile.ZipFile(out / 'code_snapshot.zip') as archive:
        if archive.testzip() is not None:
            raise RuntimeError('bad code archive')
    save_json(out / 'preservation.json', {'artifacts': items, 'code_files': code_files,
        'code_snapshot_sha256': sha(out / 'code_snapshot.zip'),
        'scope': 'selected baseline weights/papers/records and code; NOT a full dataset/run backup'})
    return items


def run(project, legacy, out):
    if not out.resolve().is_relative_to((project / 'experiments/cru_detail_v1').resolve()):
        raise ValueError('output must be in isolated cru_detail_v1 experiment')
    if out.exists():
        raise FileExistsError('refusing to overwrite existing audit; use a new version')
    out.mkdir(parents=True)
    save_json(out / 'progress.json', {'status': 'SNAPSHOT', 'training_started': False})
    preserved = preserve(project, out)
    print('Baseline artifacts copied and verified', flush=True)
    import torch
    checkpoints = {}
    for item in preserved:
        if Path(item['source']).suffix == '.pt':
            with torch.serialization.safe_globals([WindowsPath, np.ndarray, np.dtype,
                    np._core.multiarray._reconstruct, type(np.dtype('uint32'))]):
                ck = torch.load(item['copy'], map_location='cpu', weights_only=True)
            checkpoints[item['source']] = {'epoch': ck.get('epoch'), 'keys': sorted(ck.keys())}
            del ck
    hist = read_rows(project / 'runs/cru_local_expert_full_v1/history.jsonl')
    selected = read_json(project / 'runs/cru_local_expert_full_v1/summary.json')['best_epoch']
    old_progress = read_json(project / 'runs/cru_local_expert_full_v1/progress.json')
    for p, meta in checkpoints.items():
        if 'cru_local_expert_full_v1' in p and meta['epoch'] != selected:
            raise ValueError('legacy expert checkpoint/summary mismatch')
    save_json(out / 'checkpoint_audit.json', {'checkpoints': checkpoints,
        'history_epochs': [r['epoch'] for r in hist], 'selected_epoch': selected,
        'progress_last_completed_epoch': old_progress['last_completed_epoch'],
        'exact_epoch20_resume_available': False,
        'runtime': {'torch': str(torch.__version__), 'cuda': torch.cuda.is_available(),
                    'gpu': torch.cuda.get_device_name(0) if torch.cuda.is_available() else None}})
    gbisc = [r for r in read_rows(project / 'data/manifests/gbisc.jsonl') if r['split'] in ('train', 'val')]
    gbisc_root = project / 'data/raw/gbisc'
    audited = []
    for r in gbisc:
        development_only(r)
        image = source_path(gbisc_root, r['image_path'])
        geometry = source_path(gbisc_root, r['points_path'])
        if sha(image) != r['sha256']:
            raise ValueError('GBISC image changed: ' + r['original_id'])
        with np.load(geometry, allow_pickle=False) as z:
            points = z['points_xy']
            if len(points) != r['point_count'] or not np.isfinite(points).all():
                raise ValueError('bad GBISC point geometry')
            if any(len(z[k]) != len(points) for k in ('equivalent_radius', 'axes', 'area_px')):
                raise ValueError('GBISC shape label length mismatch')
        audited.append({**r, 'root': str(gbisc_root), 'cultivar_target': cultivar_target(r),
                        'cultivar_supervision': True, 'cluster_assignment_supervision': False,
                        'geometry_sha256_current': sha(geometry)})
    save_rows(out / 'gbisc_trainval.jsonl', audited)
    # Raw train/val COCO is inspected only for metadata provenance, never test COCO.
    metadata_variety = Counter()
    for split in ('train', 'val'):
        coco = read_json(gbisc_root / f'annotations_COCO_{split}.json')
        for im in coco['images']:
            metadata_variety['explicit_field' if any(im.get(k) for k in ('variety', 'cultivar', 'grape_variety')) else 'filename_inferred'] += 1
    gb_summary = {'images': len(audited), 'splits': dict(Counter(r['split'] for r in audited)),
        'cultivars': dict(Counter(r['cultivar_target'] for r in audited)),
        'berries': sum(r['point_count'] for r in audited),
        'image_hashes_verified': True, 'cultivar_label_provenance': dict(metadata_variety),
        'cluster_masks_in_original_manifest': sum(bool(r['has_cluster_masks']) for r in audited),
        'new_independent_test': False}
    print('GBISC train/val checked: ' + str(gb_summary['images']), flush=True)
    freeze = legacy / 'r1_accuracy_recovery/development_freeze_v1'
    for name, expected in read_json(freeze / 'artifact_hashes.json').items():
        if sha(freeze / name) != expected:
            raise ValueError('legacy freeze changed: ' + name)
    annotations_path = legacy / 'trainval_lock/cluster_annotations.jsonl'
    if sha(annotations_path) != read_json(freeze / 'input_lock.json')['annotations']:
        raise ValueError('source annotation lock mismatch')
    vivid, groups = [], {}
    for role in ('expert_A', 'router_B', 'development_val'):
        for r in read_rows(freeze / (role + '.jsonl')):
            development_only(r)
            if not r['supervision_approved'] or r['role'] != role:
                raise ValueError('unapproved/wrong-role row')
            if r['group_id'] in groups and groups[r['group_id']] != role:
                raise ValueError('cross-role source group')
            groups[r['group_id']] = role
            vivid.append(r)
    if len({r['original_id'] for r in vivid}) != len(vivid):
        raise ValueError('duplicate ViViD rows')
    selected_names = {r['original_id'] for r in vivid}
    annotations = defaultdict(list)
    for a in read_rows(annotations_path):
        if a['image_name'] in selected_names:
            annotations[a['image_name']].append(a)
    root = legacy / 'trainval_data'
    results, manifests = [], []
    totals = Counter()
    for i, r in enumerate(vivid):
        image = source_path(root, r['image_path'])
        pp = source_path(root, r['points_path'])
        if sha(image) != r['sha256'] or sha(pp) != r['points_sha256']:
            raise ValueError('changed ViViD input: ' + r['original_id'])
        pts = np.load(pp, allow_pickle=False)
        instances = annotations[r['original_id']]
        if len(pts) != r['point_count'] or len(instances) != r['cluster_count']:
            raise ValueError('ViViD label counts changed')
        result = membership_audit(pts, instances, r['width'], r['height'])
        totals.update({k: result[k] for k in ('points', 'no_mask', 'one_mask', 'multiple_masks')})
        results.append({'image': r['original_id'], 'role': r['role'], **result,
                        'assignment_human_verified': False})
        manifests.append({**r, 'root': str(root), 'cultivar_target': None,
            'cultivar_supervision': False, 'cluster_boxes_available': True,
            'cluster_assignment_supervision': False,
            'assignment_status': 'geometry_audited_not_verified_ID_ground_truth'})
        if (i + 1) % 50 == 0 or i + 1 == len(vivid):
            save_json(out / 'progress.json', {'status': 'AUDITING_VIVID', 'completed': i+1,
                'total': len(vivid), 'training_started': False, 'test_payloads_opened': False})
            print(f'ViViD source/geometry audited {i+1}/{len(vivid)}', flush=True)
    save_rows(out / 'vivid_trainval.jsonl', manifests)
    save_rows(out / 'vivid_geometry_audit.jsonl', results)
    vivid_summary = {'images': len(results), 'roles': dict(Counter(r['role'] for r in vivid)),
        'clusters': sum(len(r['boxes']) for r in results), 'membership_counts': dict(totals),
        'images_with_uncovered_points': sum(r['no_mask'] > 0 for r in results),
        'images_with_ambiguous_points': sum(r['multiple_masks'] > 0 for r in results),
        'cultivar_labels_enabled': False, 'image_and_point_hashes_verified': True,
        'point_completeness_certified': False, 'assignment_human_verified': False,
        'row_membership_available': False, 'group_role_conflicts': 0}
    # Verify selected old artifacts were not changed by the audit.
    if any(sha(x['source']) != x['sha256'] for x in preserved):
        raise RuntimeError('old artifact changed during audit')
    summary = {'status': 'AUDIT_COMPLETE_WITH_LABEL_GAPS', 'timestamp': datetime.now(timezone.utc).isoformat(),
        'gbisc': gb_summary, 'vivid': vivid_summary, 'training_started': False,
        'test_payloads_opened': False, 'old_selected_artifacts_unchanged': True,
        'gates': {'gbisc_count_shape_development': 'structural_inputs_ready',
                  'gbisc_cultivar': 'filename_labels_require_provenance_and_shortcut_checks',
                  'vivid_boxes': 'source_polygon_envelopes_available',
                  'point_to_cluster': 'not_ready_as_verified_ground_truth',
                  'surveyed_row_metrics': 'missing_scope_labels'}}
    save_json(out / 'summary.json', summary)
    save_json(out / 'progress.json', {'status': summary['status'], 'completed': len(vivid),
        'training_started': False, 'test_payloads_opened': False})
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--legacy', type=Path, default=Path('D:/CRU_Adaptive_Multicluster_2026-09-26'))
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    try:
        run(args.project.resolve(), args.legacy.resolve(), args.output.resolve())
    except Exception as exc:
        # Do not overwrite an already completed audit on a duplicate invocation.
        if args.output.exists() and not (args.output / 'summary.json').exists() and not isinstance(exc, FileExistsError):
            save_json(args.output / 'failure.json', {'error': str(exc), 'training_started': False})
        raise
