"""Group-OOF centre-quality ranking over frozen CRU point candidates.

Unlike the earlier selector, this model learns the reusable visual question
"is the berry centre at the patch centre?" from exact annotations versus
synthetically displaced anchors.  At runtime it scores only frozen candidate
locations (original, v4, v6, and anchor-heatmap); it never sees labels and
never changes point cardinality.
"""
from __future__ import annotations

import json
from pathlib import Path
import random
import sys
import time

import numpy as np
from scipy.spatial import cKDTree
from sklearn.model_selection import GroupKFold
import torch
from torch import nn
from torch.nn import functional as F


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

from geopriv.data.hash_utils import file_sha256  # noqa: E402
from run_vivid_hr_core_calibration import atomic_json, atomic_npz  # noqa: E402
import train_rgb_point_center_refiner as base  # noqa: E402
import train_rgb_center_refiner_development_oof_v4 as v4  # noqa: E402
import train_center_candidate_selector_oof_v7 as candidates  # noqa: E402
import calibrate_oof_geometry_gate_v4 as geometry  # noqa: E402


EXP = PROJECT / "experiments" / "cru_detail_v1"
OUT = EXP / "vivid_synthetic_center_quality_selector_oof_v17"
SEED = 20261101
FOLDS = 5
EPOCHS = 3
PATCH = 40
HALVES = (18.0, 42.0)
SYNTHETIC_PER_TRUTH = 4
VERSION = "vivid-synthetic-center-quality-selector-oof-v17"


class CenterQualityNet(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv2d(9, 32, 5, stride=2, padding=2, bias=False),
            nn.GroupNorm(8, 32), nn.SiLU(),
            nn.Conv2d(32, 64, 3, stride=2, padding=1, bias=False),
            nn.GroupNorm(8, 64), nn.SiLU(),
            nn.Conv2d(64, 96, 3, stride=2, padding=1, bias=False),
            nn.GroupNorm(8, 96), nn.SiLU(),
            nn.Conv2d(96, 96, 3, padding=1, bias=False),
            nn.GroupNorm(8, 96), nn.SiLU(),
            nn.AdaptiveAvgPool2d(4), nn.Flatten(),
        )
        self.head = nn.Sequential(
            nn.Linear(96 * 4 * 4, 192), nn.SiLU(), nn.Dropout(0.12),
            nn.Linear(192, 1),
        )

    @staticmethod
    def coordinate_channels(value: torch.Tensor) -> torch.Tensor:
        axis = torch.linspace(-1.0, 1.0, value.shape[-1],
                              device=value.device, dtype=value.dtype)
        yy, xx = torch.meshgrid(axis, axis, indexing="ij")
        radial = torch.exp(-(xx.square() + yy.square()) / (2.0 * 0.22 ** 2))
        extra = torch.stack((xx, yy, radial), dim=0)[None].expand(len(value), -1, -1, -1)
        return torch.cat((value, extra), dim=1)

    def forward(self, patch: torch.Tensor) -> torch.Tensor:
        return self.head(self.stem(self.coordinate_channels(patch)))[:, 0]


def sample_patches(image: np.ndarray, anchors: np.ndarray, scale: float,
                   device: torch.device) -> torch.Tensor:
    old_patch, old_halves = candidates.PATCH, candidates.HALVES
    candidates.PATCH, candidates.HALVES = PATCH, HALVES
    try:
        return candidates.sample_patches(image, anchors, scale, device)
    finally:
        candidates.PATCH, candidates.HALVES = old_patch, old_halves


def choose_truth(truth: np.ndarray, scale: float, rng: np.random.Generator) -> np.ndarray:
    spacing = base.spacing(truth, scale)
    strata = np.where(spacing < 12.0, 0, np.where(spacing < 24.0, 1, 2))
    selected: list[int] = []
    for stratum in range(3):
        available = np.flatnonzero(strata == stratum)
        if len(available) > 32:
            available = rng.choice(available, 32, replace=False)
        selected.extend(int(index) for index in available)
    return np.asarray(selected, dtype=np.int64)


def synthetic_groups(record: dict, truth: np.ndarray, *, epoch: int) -> np.ndarray:
    width, height = int(record["width"]), int(record["height"])
    scale = 1024.0 / max(width, height)
    rng = np.random.default_rng(SEED + epoch * 10007 + int(record["sha256"][:8], 16))
    selected = choose_truth(truth, scale, rng)
    if not len(selected):
        return np.empty((0, SYNTHETIC_PER_TRUTH, 2), np.float32)
    tree = cKDTree(truth * scale)
    groups = []
    for index in selected:
        centre = truth[index].astype(np.float32)
        anchors = [centre]
        attempts = 0
        while len(anchors) < SYNTHETIC_PER_TRUTH and attempts < 40:
            attempts += 1
            angle = rng.uniform(0.0, 2.0 * np.pi)
            magnitude = rng.uniform(4.0, 16.0)
            delta = np.asarray((np.cos(angle), np.sin(angle)), np.float32) * magnitude
            anchor = centre + delta / scale
            if not (0 <= anchor[0] < width and 0 <= anchor[1] < height):
                continue
            distance, nearest = tree.query(anchor * scale)
            # Avoid creating a false negative that is actually centred on a
            # neighbouring berry in a dense bunch.
            if int(nearest) != int(index) or float(distance) < 3.0:
                continue
            anchors.append(anchor.astype(np.float32))
        if len(anchors) == SYNTHETIC_PER_TRUTH:
            groups.append(np.stack(anchors))
    return np.stack(groups).astype(np.float32) if groups else np.empty((0, SYNTHETIC_PER_TRUTH, 2), np.float32)


def epoch_pass(model: nn.Module, records: list[dict], optimizer,
               device: torch.device, *, epoch: int) -> dict:
    model.train()
    rng = np.random.default_rng(SEED + epoch)
    total_loss = total_correct = total_groups = 0.0
    for position, record_index in enumerate(rng.permutation(len(records))):
        record = records[int(record_index)]
        image, truth = base.record_payload(record)
        scale = 1024.0 / max(int(record["width"]), int(record["height"]))
        groups = synthetic_groups(record, truth, epoch=epoch)
        if not len(groups):
            continue
        order = rng.permutation(len(groups))
        for start in range(0, len(order), 32):
            batch_index = order[start:start + 32]
            anchors = groups[batch_index]
            patch = sample_patches(image, anchors, scale, device)
            if rng.random() < 0.5:
                patch = torch.flip(patch, dims=(3,))
            if rng.random() < 0.5:
                patch = torch.flip(patch, dims=(2,))
            patch = patch * float(rng.uniform(0.90, 1.10)) + float(rng.uniform(-0.07, 0.07))
            score = model(patch).reshape(-1, SYNTHETIC_PER_TRUTH)
            target = torch.zeros(len(batch_index), dtype=torch.long, device=device)
            ranking_loss = F.cross_entropy(score, target)
            # Keep the absolute score calibrated enough to support a runtime
            # safety threshold as well as within-group ranking.
            binary_target = torch.zeros_like(score); binary_target[:, 0] = 1.0
            calibration_loss = F.binary_cross_entropy_with_logits(score, binary_target)
            loss = ranking_loss + 0.25 * calibration_loss
            optimizer.zero_grad(set_to_none=True); loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0); optimizer.step()
            count = len(batch_index)
            total_loss += float(loss) * count
            total_correct += int((score.argmax(dim=1) == 0).sum())
            total_groups += count
        if (position + 1) % 60 == 0:
            print(f"centre-quality e{epoch} {position + 1}/{len(records)}", flush=True)
    return {"loss": total_loss / max(total_groups, 1),
            "ranking_accuracy": total_correct / max(total_groups, 1),
            "groups": int(total_groups)}


def save_checkpoint(path: Path, payload: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temporary); temporary.replace(path)


def fit(records: list[dict], device: torch.device, folder: Path,
        *, fold: int) -> tuple[nn.Module, list[dict]]:
    folder.mkdir(parents=True, exist_ok=True)
    torch.manual_seed(SEED + fold)
    model = CenterQualityNet().to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=2e-4)
    history = []
    for local_epoch in range(1, EPOCHS + 1):
        started = time.monotonic()
        metrics = epoch_pass(model, records, optimizer, device,
                             epoch=fold * 100 + local_epoch)
        row = {"fold": fold, "epoch": local_epoch, "training": metrics,
               "elapsed_seconds": time.monotonic() - started}
        history.append(row)
        with (folder / "history.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")
        save_checkpoint(folder / "last.pt", {
            "fold": fold, "epoch": local_epoch, "model": model.state_dict(),
            "optimizer": optimizer.state_dict(), "row": row,
        })
        atomic_json(folder / "progress.json", {
            "status": "TRAINING" if local_epoch < EPOCHS else "COMPLETE",
            "fold": fold, "last_epoch": local_epoch,
            "router_b_used": False, "sealed_test_used": False,
        })
        print(json.dumps(row, ensure_ascii=False), flush=True)
    return model, history


@torch.inference_mode()
def score_candidates(model: nn.Module, records: list[dict], device: torch.device,
                     folder: Path) -> list[dict]:
    model.eval(); output = []
    for record in records:
        payload = candidates.source_payload(record)
        image_size = (int(record["width"]), int(record["height"]))
        scale = 1024.0 / max(image_size)
        proposed, _ = candidates.candidate_geometry(payload, scale)
        proposed[:, :, 0] = np.clip(proposed[:, :, 0], 0, image_size[0] - 1e-3)
        proposed[:, :, 1] = np.clip(proposed[:, :, 1], 0, image_size[1] - 1e-3)
        scores = []
        if len(proposed):
            image = base.load_rgb(base.ROOT / record["image_path"])
            for start in range(0, len(proposed), 48):
                end = min(start + 48, len(proposed))
                patch = sample_patches(image, proposed[start:end], scale, device)
                scores.append(model(patch).reshape(-1, len(candidates.SOURCE_NAMES)).cpu().numpy())
            score = np.concatenate(scores).astype(np.float32)
        else:
            score = np.empty((0, len(candidates.SOURCE_NAMES)), np.float32)
        filename = record["sample_id"].replace(":", "_") + ".npz"
        atomic_npz(folder / filename, score=score)
        output.append({"sample_id": record["sample_id"], "image_size": image_size,
                       "scale": scale, "points": payload["points"],
                       "truth": payload["truth"], "reliability": payload["reliability"],
                       "point_spacing": base.spacing(payload["points"], scale),
                       "offsets": payload["offsets"], "scores": score})
    return output


def apply(item: dict, *, alpha: float, margin: float, absolute_score: float,
          minimum_spacing: float, fraction: float, absolute_limit: float) -> np.ndarray:
    result = item["points"].copy()
    if not len(result):
        return result
    choice = item["scores"].argmax(axis=1)
    row = np.arange(len(choice))
    best = item["scores"][row, choice]
    advantage = best - item["scores"][:, 0]
    active = ((choice > 0) & (advantage >= margin) & (best >= absolute_score)
              & (item["point_spacing"] >= minimum_spacing))
    shift = item["offsets"][row, choice] * alpha
    magnitude = np.linalg.norm(shift, axis=1)
    limit = np.minimum(absolute_limit, fraction * item["point_spacing"])
    shift *= np.minimum(1.0, limit / np.maximum(magnitude, 1e-6))[:, None]
    result[active] += shift[active] / item["scale"]
    width, height = item["image_size"]
    result[:, 0] = np.clip(result[:, 0], 0, width - 1e-3)
    result[:, 1] = np.clip(result[:, 1], 0, height - 1e-3)
    return result.astype(np.float32)


def calibrate(cached: list[dict]) -> tuple[dict, list[dict]]:
    configs = []
    grids = [(a, m, q, s, f, l)
             for a in (0.50, 0.75, 1.00)
             for m in (0.00, 0.20, 0.40, 0.60)
             for q in (-0.50, 0.00, 0.50)
             for s in (12.0, 16.0, 20.0, 24.0, 28.0)
             for f in (0.10, 0.20, 0.30)
             for l in (4.0, 8.0, 12.0)]
    for index, (alpha, margin, absolute_score, minimum_spacing, fraction, limit) in enumerate(grids):
        predictions = [apply(item, alpha=alpha, margin=margin,
                             absolute_score=absolute_score,
                             minimum_spacing=minimum_spacing, fraction=fraction,
                             absolute_limit=limit) for item in cached]
        report = base.evaluate(cached, predictions)
        configs.append({"alpha": alpha, "margin": margin,
                        "absolute_score": absolute_score,
                        "minimum_spacing": minimum_spacing,
                        "spacing_fraction": fraction, "absolute_limit": limit,
                        "eligible": geometry.strict(report), **report})
        if (index + 1) % 270 == 0:
            print(f"centre-quality gate {index + 1}/{len(grids)}", flush=True)
    eligible = [row for row in configs if row["eligible"]]
    selected = max(eligible or configs, key=lambda row: (
        row["image_gains"]["4"]["net_tp"],
        row["image_gains"]["8"]["net_tp"],
        row["image_gains"]["16"]["net_tp"],
        -row["image_gains"]["4"]["worsened"],
    ))
    return selected, configs


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    candidates.SOURCE_NAMES = ("original", "v4", "v6", "heatmap_v5")
    candidates.SOURCE_ROOTS = {
        "v4": EXP / "vivid_rgb_point_center_refiner_development_oof_v4" / "oof_inference_cache",
        "v6": EXP / "vivid_misaligned_only_center_refiner_oof_v6" / "oof_inference_cache",
        "heatmap_v5": EXP / "vivid_anchor_heatmap_center_refiner_oof_v5" / "oof_inference_cache",
    }
    torch.manual_seed(SEED); np.random.seed(SEED); random.seed(SEED)
    records = base.rows(base.DEV_MANIFEST)
    groups = np.asarray([row.get("capture_group_id") or row["sample_id"] for row in records])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    protocol = {
        "version": VERSION, "seed": SEED, "folds": FOLDS,
        "epochs_per_fold": EPOCHS, "patch": PATCH,
        "half_windows_normalized_px": list(HALVES),
        "training": "exact annotated centres ranked over synthetic displacements",
        "runtime_candidates": list(candidates.SOURCE_NAMES),
        "count_conserving": True, "development_selected": True,
        "independent_confirmation": False, "router_b_used": False,
        "sealed_test_used": False, "source_sha256": file_sha256(Path(__file__)),
    }
    atomic_json(OUT / "protocol.json", protocol)
    cache = OUT / "oof_selector_cache"; cache.mkdir(exist_ok=True)
    cached = []; fold_rows = []
    splitter = GroupKFold(FOLDS)
    for fold, (fit_index, held_index) in enumerate(
            splitter.split(np.arange(len(records)), groups=groups)):
        fit_records = [records[int(index)] for index in fit_index]
        held_records = [records[int(index)] for index in held_index]
        model, history = fit(fit_records, device, OUT / f"fold_{fold}", fold=fold)
        cached.extend(score_candidates(model, held_records, device, cache))
        fold_rows.append({"fold": fold, "fit_images": len(fit_records),
                          "held_images": len(held_records), "history": history})
        atomic_json(OUT / "progress.json", {
            "status": "OOF", "completed_folds": fold + 1,
            "router_b_used": False, "sealed_test_used": False,
        })
        print(f"centre-quality fold {fold} complete: {len(held_records)} held images", flush=True)
    by_id = {item["sample_id"]: item for item in cached}
    cached = [by_id[record["sample_id"]] for record in records]
    selected, configs = calibrate(cached)
    predictions = [apply(
        item, alpha=float(selected["alpha"]), margin=float(selected["margin"]),
        absolute_score=float(selected["absolute_score"]),
        minimum_spacing=float(selected["minimum_spacing"]),
        fraction=float(selected["spacing_fraction"]),
        absolute_limit=float(selected["absolute_limit"])) for item in cached]
    point_out = OUT / "oof_development_points"; point_out.mkdir(exist_ok=True)
    for item, points in zip(cached, predictions, strict=True):
        filename = item["sample_id"].replace(":", "_") + ".npz"
        atomic_npz(point_out / filename, cru=points, truth=item["truth"],
                   reliability=item["reliability"])
    summary = {
        "status": "COMPLETE_OPEN_DEVELOPMENT_GROUP_OOF",
        "selected": selected,
        "eligible_configs": len([row for row in configs if row["eligible"]]),
        "configs_evaluated": len(configs), "folds": fold_rows,
        "model_parameters": sum(parameter.numel() for parameter in model.parameters()),
        "images": len(cached), "protocol": protocol,
    }
    atomic_json(OUT / "summary.json", summary)
    atomic_json(OUT / "all_configs.json", configs)
    atomic_json(OUT / "progress.json", {"status": "COMPLETE", "selected": selected,
                                         "router_b_used": False, "sealed_test_used": False})
    print(json.dumps({"status": summary["status"], "selected": selected,
                      "eligible_configs": summary["eligible_configs"],
                      "configs_evaluated": len(configs),
                      "model_parameters": summary["model_parameters"]},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
