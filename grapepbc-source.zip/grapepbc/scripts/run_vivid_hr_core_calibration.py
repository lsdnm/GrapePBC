"""Fit and evaluate a core-owned count head on the frozen rich HR expert.

The expert checkpoint and all localization heads remain bit-for-bit frozen.
Expert-A supplies count-head fitting data, development is opened once for the
predeclared promotion gate, and Router-B plus sealed test remain inaccessible.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from datetime import datetime, timezone
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import random
import sys
import time

import numpy as np
import torch
from torch import Tensor
from torch.nn import functional as F

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

from geopriv.data import CRUContextCropDataset
from geopriv.data.hash_utils import file_sha256
from geopriv.data.manifest import read_manifest
from geopriv.metrics import aggregate_count_metrics, maximum_cardinality_point_matches
from geopriv.models import CoreCountHead, RichDetailExpert, decode_core_counts, decode_points
from vivid_detail_runtime import safe_load


SCORE_THRESHOLDS = (0.001, 0.003, 0.005, 0.01, 0.02, 0.03, 0.05, 0.07, 0.09, 0.11, 0.13, 0.15, 0.20, 0.30)
OCCUPANCY_THRESHOLDS = tuple(float(value) for value in np.arange(0.25, 0.751, 0.05))


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def atomic_checkpoint(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(value, temporary)
    temporary.replace(path)


def atomic_npz(path: Path, **arrays: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("wb") as stream:
        np.savez_compressed(stream, **arrays)
    temporary.replace(path)


def seed_all(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def source_family(sample_id: str) -> str:
    name = sample_id.split(":", 1)[-1].lower()
    if name.startswith("immature"):
        return "immature"
    if name.startswith("img_20"):
        return "phone_timestamp"
    if name.startswith("img"):
        return "img_camera"
    if "dsc" in name:
        return "dsc_camera"
    if name.isdigit() and len(name) >= 12:
        return "numeric_timestamp"
    if name.isdigit():
        return "numeric_short"
    return "other"


def count_bin(count: int) -> str:
    if count <= 50:
        return "01_le50"
    if count <= 100:
        return "02_51to100"
    if count <= 200:
        return "03_101to200"
    return "04_gt200"


def source_hashes() -> dict[str, str]:
    paths = (
        "scripts/run_vivid_hr_core_calibration.py",
        "src/geopriv/models/core_count_head.py",
        "src/geopriv/models/rich_detail_expert.py",
        "src/geopriv/models/litepoint.py",
        "src/geopriv/data/cru_crop_dataset.py",
    )
    return {name: file_sha256(PROJECT / name) for name in paths}


def feature_names() -> list[str]:
    names = [f"detail_mean_{index}" for index in range(64)]
    names += [f"detail_max_{index}" for index in range(64)]
    names += [f"semantic_mean_{index}" for index in range(96)]
    names += [f"semantic_max_{index}" for index in range(96)]
    names += [
        "log1p_center_probability_sum",
        "log1p_valid_core_cells",
        "log1p_candidate_count",
        "core_width_fraction",
        "core_height_fraction",
        "core_area_fraction",
        "valid_core_fraction",
        "candidate_score_max",
        "candidate_score_mean_top5",
        "candidate_score_mean_top20",
        "candidate_score_mean_top100",
        "candidate_score_q25",
        "candidate_score_q50",
        "candidate_score_q75",
        "candidate_score_q90",
    ]
    names += [f"log1p_peak_count_at_{value:.3f}" for value in SCORE_THRESHOLDS]
    return names


def prepare(args: argparse.Namespace) -> None:
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"non-empty output exists: {output}")
    output.mkdir(parents=True, exist_ok=True)
    run = args.hr_run.resolve()
    hr_protocol = json.loads((run / "protocol.json").read_text(encoding="utf-8"))
    hr_stage = json.loads((run / "stage.json").read_text(encoding="utf-8"))
    if hr_stage.get("status") != "USER_STOPPED_FOR_DIAGNOSIS":
        raise ValueError("rich HR run is not frozen for diagnosis")
    if hr_protocol.get("router_B_used") or hr_protocol.get("sealed_test_used"):
        raise ValueError("frozen HR run used a sealed role")
    checkpoint = safe_load(run / "best_val_mae.pt")
    if int(checkpoint["epoch"]) != 1:
        raise ValueError("expected frozen epoch-1 rich HR checkpoint")
    baseline = args.baseline_summary.resolve()
    baseline_payload = json.loads(baseline.read_text(encoding="utf-8"))
    if baseline_payload.get("boundary") != "development-only diagnosis; no Router-B/test access and no weight update":
        raise ValueError("unexpected baseline diagnostic boundary")
    names = feature_names()
    protocol = {
        "version": "vivid-rich-hr-core-count-calibration-v1",
        "status": "PREPARED",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "seed": 20261001,
        "hr_run": str(run),
        "hr_checkpoint": str((run / "best_val_mae.pt").resolve()),
        "hr_checkpoint_sha256": file_sha256(run / "best_val_mae.pt"),
        "hr_checkpoint_epoch": 1,
        "root": hr_protocol["root"],
        "train_manifest": hr_protocol["train_manifest"],
        "development_manifest": hr_protocol["val_manifest"],
        "train_manifest_sha256": hr_protocol["train_manifest_sha256"],
        "development_manifest_sha256": hr_protocol["val_manifest_sha256"],
        "deep_backbone_checkpoint": hr_protocol["deep_backbone_checkpoint"],
        "deep_backbone_checkpoint_sha256": hr_protocol["deep_backbone_checkpoint_sha256"],
        "baseline_summary": str(baseline),
        "baseline_summary_sha256": file_sha256(baseline),
        "input_size": int(hr_protocol["input_size"]),
        "core_size": int(hr_protocol["core_size"]),
        "halo": int(hr_protocol["halo"]),
        "candidate_score_floor": 1e-6,
        "candidate_limit": 2048,
        "local_max_kernel": 3,
        "score_thresholds": list(SCORE_THRESHOLDS),
        "feature_names": names,
        "feature_dim": len(names),
        "head": {
            "hidden_dim": 64,
            "bottleneck_dim": 32,
            "dropout": 0.10,
            "max_epochs": 100,
            "early_stop_patience": 15,
            "batch_size": 256,
            "learning_rate": 0.002,
            "weight_decay": 0.0001,
            "folds": 5,
            "selection": "Expert-A grouped OOF image MAE; fixed development promotion gate",
        },
        "promotion_gate": {
            "primary": "development whole-image MAE < enhanced LR MAE",
            "enhanced_lr_mae": float(baseline_payload["lr"]["mae"]),
            "uncalibrated_rich_hr_mae": float(baseline_payload["hr"]["mae"]),
        },
        "source_sha256": source_hashes(),
        "expert_weights_frozen": True,
        "expert_A_only_for_head_fitting": True,
        "development_used_for_fitting": False,
        "router_B_used": False,
        "sealed_test_used": False,
    }
    atomic_json(output / "protocol.json", protocol)
    atomic_json(
        output / "stage.json",
        {"status": "PREPARED", "router_B_used": False, "sealed_test_used": False},
    )
    print(json.dumps(protocol, ensure_ascii=False, indent=2), flush=True)


def verify(output: Path) -> dict[str, object]:
    protocol = json.loads((output / "protocol.json").read_text(encoding="utf-8"))
    for name, expected in protocol["source_sha256"].items():
        if file_sha256(PROJECT / name) != expected:
            raise ValueError(f"source drift: {name}")
    checks = (
        ("hr_checkpoint", "hr_checkpoint_sha256"),
        ("train_manifest", "train_manifest_sha256"),
        ("development_manifest", "development_manifest_sha256"),
        ("deep_backbone_checkpoint", "deep_backbone_checkpoint_sha256"),
        ("baseline_summary", "baseline_summary_sha256"),
    )
    for path_key, hash_key in checks:
        if file_sha256(Path(protocol[path_key])) != protocol[hash_key]:
            raise ValueError(f"artifact drift: {path_key}")
    if protocol["router_B_used"] or protocol["sealed_test_used"]:
        raise ValueError("sealed roles are forbidden")
    if not protocol["expert_weights_frozen"]:
        raise ValueError("expert must remain frozen")
    return protocol


def make_expert(protocol: dict[str, object]) -> RichDetailExpert:
    model = RichDetailExpert(
        decoder_norm="group",
        freeze_backbone_bn=True,
        deep_backbone_checkpoint=protocol["deep_backbone_checkpoint"],
    ).cuda()
    checkpoint = safe_load(Path(protocol["hr_checkpoint"]))
    model.load_state_dict(checkpoint["model"], strict=True)
    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    return model


def rect_mask(
    valid: Tensor,
    bounds: Tensor,
    height: int,
    width: int,
    input_size: int,
) -> Tensor:
    resized = F.interpolate(
        valid[None, None].float(), size=(height, width), mode="nearest"
    )[0, 0].bool()
    x0 = max(0, min(width - 1, int(math.floor(float(bounds[0]) * width / input_size))))
    y0 = max(0, min(height - 1, int(math.floor(float(bounds[1]) * height / input_size))))
    x1 = max(x0 + 1, min(width, int(math.ceil(float(bounds[2]) * width / input_size))))
    y1 = max(y0 + 1, min(height, int(math.ceil(float(bounds[3]) * height / input_size))))
    owned = torch.zeros_like(resized)
    owned[y0:y1, x0:x1] = True
    return resized & owned


def pooled_stats(feature: Tensor, mask: Tensor) -> tuple[Tensor, Tensor]:
    if feature.ndim != 3 or mask.shape != feature.shape[-2:]:
        raise ValueError("feature/mask shape mismatch")
    chosen = feature[:, mask]
    if chosen.shape[1] == 0:
        return torch.zeros(feature.shape[0], device=feature.device), torch.zeros(
            feature.shape[0], device=feature.device
        )
    return chosen.mean(dim=1), chosen.amax(dim=1)


def to_native(points: np.ndarray, inverse: np.ndarray, origin: np.ndarray) -> np.ndarray:
    points = np.asarray(points, dtype=np.float32).reshape(-1, 2)
    if not len(points):
        return points.copy()
    inverse = np.asarray(inverse, dtype=np.float32)
    homogeneous = np.column_stack((points, np.ones(len(points), dtype=np.float32)))
    if inverse.shape == (2, 3):
        mapped = homogeneous @ inverse.T
    elif inverse.shape == (3, 3):
        mapped_h = homogeneous @ inverse.T
        mapped = mapped_h[:, :2] / mapped_h[:, 2:3]
    else:
        raise ValueError(f"unsupported inverse affine: {inverse.shape}")
    return (mapped + np.asarray(origin, dtype=np.float32)).astype(np.float32)


@torch.inference_mode()
def extract_item(
    model: RichDetailExpert,
    item: dict[str, object],
    protocol: dict[str, object],
) -> dict[str, object]:
    image = item["image"].cuda(non_blocking=True)
    valid = item["valid_image_mask"].cuda(non_blocking=True)
    target = item["target"]
    outputs = model(image[None], valid[None], return_features=True)
    prediction = decode_points(
        outputs,
        score_threshold=float(protocol["candidate_score_floor"]),
        topk=int(protocol["candidate_limit"]),
        local_max_kernel=int(protocol["local_max_kernel"]),
        output_stride=2,
    )[0]
    points = prediction["points"].detach().cpu().numpy()
    scores = prediction["scores"].detach().cpu().numpy()
    bounds_cpu = target["core_bounds_xyxy"].numpy()
    owned = (
        (points[:, 0] >= bounds_cpu[0])
        & (points[:, 0] < bounds_cpu[2])
        & (points[:, 1] >= bounds_cpu[1])
        & (points[:, 1] < bounds_cpu[3])
    )
    points, scores = points[owned], scores[owned]
    native = to_native(
        points,
        target["inverse_affine"].numpy(),
        target["context_origin_xy"].numpy(),
    )
    bounds = target["core_bounds_xyxy"].cuda()
    detail = outputs["detail_features"][0]
    semantic = outputs["semantic_features"][0]
    detail_mask = rect_mask(valid, bounds, detail.shape[-2], detail.shape[-1], int(protocol["input_size"]))
    semantic_mask = rect_mask(valid, bounds, semantic.shape[-2], semantic.shape[-1], int(protocol["input_size"]))
    detail_mean, detail_max = pooled_stats(detail, detail_mask)
    semantic_mean, semantic_max = pooled_stats(semantic, semantic_mask)

    center_prob = outputs["center_logits"][0, 0].sigmoid()
    center_mask = rect_mask(valid, bounds, center_prob.shape[0], center_prob.shape[1], int(protocol["input_size"]))
    center_sum = float(center_prob[center_mask].sum())
    valid_cells = int(center_mask.sum())
    width = max(0.0, float(bounds_cpu[2] - bounds_cpu[0]))
    height = max(0.0, float(bounds_cpu[3] - bounds_cpu[1]))
    score_stats = [
        float(scores.max()) if len(scores) else 0.0,
        float(scores[:5].mean()) if len(scores) else 0.0,
        float(scores[:20].mean()) if len(scores) else 0.0,
        float(scores[:100].mean()) if len(scores) else 0.0,
    ]
    if len(scores):
        score_stats += [float(value) for value in np.quantile(scores, [0.25, 0.50, 0.75, 0.90])]
    else:
        score_stats += [0.0] * 4
    scalar = [
        math.log1p(center_sum),
        math.log1p(valid_cells),
        math.log1p(len(scores)),
        width / float(protocol["input_size"]),
        height / float(protocol["input_size"]),
        width * height / float(protocol["input_size"]) ** 2,
        float(valid_cells) / max(1, int(center_mask.numel())),
        *score_stats,
        *[math.log1p(int((scores >= threshold).sum())) for threshold in SCORE_THRESHOLDS],
    ]
    feature = torch.cat((detail_mean, detail_max, semantic_mean, semantic_max)).cpu().numpy()
    feature = np.concatenate((feature.astype(np.float32), np.asarray(scalar, dtype=np.float32)))
    if len(feature) != int(protocol["feature_dim"]):
        raise ValueError(f"feature size {len(feature)} != {protocol['feature_dim']}")
    return {
        "feature": feature,
        "candidate_native_xy": native,
        "candidate_scores": scores.astype(np.float32),
        "sample_id": str(target["sample_id"]),
        "tile_id": str(target["tile_id"]),
        "true_count": int(target["core_count"]),
    }


def cache_path(output: Path, split_name: str, index: int) -> Path:
    return output / "features" / split_name / f"{index:06d}.npz"


def extract_split(output: Path, protocol: dict[str, object], split_name: str) -> None:
    if split_name == "train":
        manifest, split = protocol["train_manifest"], "train"
    elif split_name == "development":
        manifest, split = protocol["development_manifest"], "val"
    else:
        raise ValueError(split_name)
    dataset = CRUContextCropDataset(
        manifest,
        protocol["root"],
        split=split,
        image_size=int(protocol["input_size"]),
        core_size=int(protocol["core_size"]),
        halo=int(protocol["halo"]),
        cache_images=2,
    )
    model = make_expert(protocol)
    started = time.monotonic()
    for index in range(len(dataset)):
        destination = cache_path(output, split_name, index)
        if destination.exists():
            continue
        row = extract_item(model, dataset[index], protocol)
        atomic_npz(
            destination,
            feature=row["feature"],
            candidate_native_xy=row["candidate_native_xy"],
            candidate_scores=row["candidate_scores"],
            sample_id=np.asarray(row["sample_id"]),
            tile_id=np.asarray(row["tile_id"]),
            true_count=np.asarray(row["true_count"], dtype=np.int64),
        )
        if (index + 1) % 25 == 0 or index + 1 == len(dataset):
            atomic_json(
                output / "progress.json",
                {
                    "status": "EXTRACTING_FROZEN_FEATURES",
                    "split": split_name,
                    "completed_tiles": index + 1,
                    "total_tiles": len(dataset),
                    "elapsed_seconds": time.monotonic() - started,
                    "router_B_used": False,
                    "sealed_test_used": False,
                },
            )
    files = sorted((output / "features" / split_name).glob("*.npz"))
    if len(files) != len(dataset):
        raise ValueError(f"incomplete {split_name} cache: {len(files)}/{len(dataset)}")
    atomic_json(
        output / f"{split_name}_cache.json",
        {
            "status": "COMPLETE",
            "split": split_name,
            "tiles": len(files),
            "images": len(dataset.records),
            "manifest": str(Path(manifest).resolve()),
            "manifest_sha256": file_sha256(Path(manifest)),
            "expert_checkpoint_sha256": protocol["hr_checkpoint_sha256"],
            "router_B_used": False,
            "sealed_test_used": False,
        },
    )
    del model
    torch.cuda.empty_cache()


def load_cache(output: Path, split_name: str) -> dict[str, object]:
    features, target, sample_ids, tile_ids, candidates, candidate_scores = [], [], [], [], [], []
    for path in sorted((output / "features" / split_name).glob("*.npz")):
        with np.load(path, allow_pickle=False) as item:
            features.append(item["feature"].astype(np.float32))
            target.append(int(item["true_count"]))
            sample_ids.append(str(item["sample_id"]))
            tile_ids.append(str(item["tile_id"]))
            candidates.append(item["candidate_native_xy"].astype(np.float32))
            candidate_scores.append(item["candidate_scores"].astype(np.float32))
    if not features:
        raise ValueError(f"empty {split_name} feature cache")
    return {
        "features": np.stack(features),
        "target": np.asarray(target, dtype=np.int64),
        "sample_ids": np.asarray(sample_ids),
        "tile_ids": np.asarray(tile_ids),
        "candidates": candidates,
        "candidate_scores": candidate_scores,
        "candidate_counts": np.asarray([len(value) for value in candidates], dtype=np.int64),
    }


def grouped_folds(sample_ids: np.ndarray, target: np.ndarray, folds: int, seed: int) -> np.ndarray:
    grouped: dict[str, list[int]] = defaultdict(list)
    for index, sample_id in enumerate(sample_ids):
        grouped[str(sample_id)].append(index)
    strata: dict[tuple[str, str], list[str]] = defaultdict(list)
    for sample_id, indices in grouped.items():
        strata[(source_family(sample_id), count_bin(int(target[indices].sum())))].append(sample_id)
    rng = np.random.default_rng(seed)
    assignment: dict[str, int] = {}
    fold_load = np.zeros(folds, dtype=np.int64)
    for key in sorted(strata):
        values = sorted(strata[key])
        rng.shuffle(values)
        for sample_id in values:
            chosen = int(np.argmin(fold_load))
            assignment[sample_id] = chosen
            fold_load[chosen] += 1
    return np.asarray([assignment[str(sample_id)] for sample_id in sample_ids], dtype=np.int64)


def image_mae(prediction: np.ndarray, target: np.ndarray, sample_ids: np.ndarray) -> float:
    error = []
    for sample_id in np.unique(sample_ids):
        chosen = sample_ids == sample_id
        error.append(abs(int(prediction[chosen].sum()) - int(target[chosen].sum())))
    return float(np.mean(error))


def decoded_numpy(
    occupancy_logits: np.ndarray,
    log_count: np.ndarray,
    candidate_counts: np.ndarray,
    threshold: float,
) -> np.ndarray:
    return decode_core_counts(
        torch.from_numpy(occupancy_logits),
        torch.from_numpy(log_count),
        torch.from_numpy(candidate_counts),
        occupancy_threshold=threshold,
    ).numpy()


def train_fold(
    features: np.ndarray,
    target: np.ndarray,
    sample_ids: np.ndarray,
    candidate_counts: np.ndarray,
    train_indices: np.ndarray,
    val_indices: np.ndarray,
    protocol: dict[str, object],
    seed: int,
) -> dict[str, object]:
    seed_all(seed)
    device = torch.device("cuda")
    mean = features[train_indices].mean(axis=0).astype(np.float32)
    std = features[train_indices].std(axis=0).astype(np.float32)
    std[std < 1e-5] = 1.0
    normalized = (features - mean) / std
    head = CoreCountHead(
        int(protocol["feature_dim"]),
        int(protocol["head"]["hidden_dim"]),
        int(protocol["head"]["bottleneck_dim"]),
        float(protocol["head"]["dropout"]),
    ).to(device)
    optimizer = torch.optim.AdamW(
        head.parameters(),
        lr=float(protocol["head"]["learning_rate"]),
        weight_decay=float(protocol["head"]["weight_decay"]),
    )
    positives = max(1, int((target[train_indices] > 0).sum()))
    negatives = max(1, int((target[train_indices] == 0).sum()))
    pos_weight = torch.tensor(min(4.0, max(0.25, negatives / positives)), device=device)
    best_key = (float("inf"), float("inf"))
    best_epoch = 0
    best_state = None
    best_outputs = None
    history = []
    patience = 0
    generator = np.random.default_rng(seed)
    batch_size = int(protocol["head"]["batch_size"])
    for epoch in range(1, int(protocol["head"]["max_epochs"]) + 1):
        head.train()
        order = train_indices.copy()
        generator.shuffle(order)
        losses = []
        for start in range(0, len(order), batch_size):
            chosen = order[start : start + batch_size]
            x = torch.from_numpy(normalized[chosen]).to(device)
            y = torch.from_numpy(target[chosen].astype(np.float32)).to(device)
            output = head(x)
            occupied = y > 0
            occupancy_loss = F.binary_cross_entropy_with_logits(
                output["occupancy_logits"], occupied.float(), pos_weight=pos_weight
            )
            if bool(occupied.any()):
                regression = F.smooth_l1_loss(
                    output["log_count"][occupied], torch.log1p(y[occupied])
                )
                predicted_count = torch.expm1(output["log_count"][occupied].clamp(0.0, 8.0))
                normalized_count = F.smooth_l1_loss(
                    predicted_count / torch.sqrt(y[occupied] + 1.0),
                    y[occupied] / torch.sqrt(y[occupied] + 1.0),
                )
            else:
                regression = output["log_count"].sum() * 0.0
                normalized_count = regression
            loss = occupancy_loss + regression + 0.10 * normalized_count
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(head.parameters(), 5.0)
            optimizer.step()
            losses.append(float(loss.detach()))
        head.eval()
        with torch.inference_mode():
            output = head(torch.from_numpy(normalized[val_indices]).to(device))
        occupancy_logits = output["occupancy_logits"].cpu().numpy()
        log_count = output["log_count"].cpu().numpy()
        decoded = decoded_numpy(
            occupancy_logits,
            log_count,
            candidate_counts[val_indices],
            0.5,
        )
        current_key = (
            image_mae(decoded, target[val_indices], sample_ids[val_indices]),
            float(np.abs(decoded - target[val_indices]).mean()),
        )
        history.append(
            {
                "epoch": epoch,
                "training_loss": float(np.mean(losses)),
                "validation_image_mae_at_0.5": current_key[0],
                "validation_core_mae_at_0.5": current_key[1],
            }
        )
        if current_key < best_key:
            best_key = current_key
            best_epoch = epoch
            best_state = {name: value.detach().cpu().clone() for name, value in head.state_dict().items()}
            best_outputs = (occupancy_logits.copy(), log_count.copy())
            patience = 0
        else:
            patience += 1
        if patience >= int(protocol["head"]["early_stop_patience"]):
            break
    assert best_state is not None and best_outputs is not None
    return {
        "best_epoch": best_epoch,
        "best_image_mae_at_0.5": best_key[0],
        "best_core_mae_at_0.5": best_key[1],
        "state": best_state,
        "mean": mean,
        "std": std,
        "occupancy_logits": best_outputs[0],
        "log_count": best_outputs[1],
        "history": history,
    }


def fit_final_head(
    output: Path,
    protocol: dict[str, object],
    features: np.ndarray,
    target: np.ndarray,
    epochs: int,
    occupancy_threshold: float,
) -> dict[str, object]:
    seed_all(int(protocol["seed"]) + 900)
    mean = features.mean(axis=0).astype(np.float32)
    std = features.std(axis=0).astype(np.float32)
    std[std < 1e-5] = 1.0
    normalized = ((features - mean) / std).astype(np.float32)
    device = torch.device("cuda")
    head = CoreCountHead(
        int(protocol["feature_dim"]),
        int(protocol["head"]["hidden_dim"]),
        int(protocol["head"]["bottleneck_dim"]),
        float(protocol["head"]["dropout"]),
    ).to(device)
    optimizer = torch.optim.AdamW(
        head.parameters(),
        lr=float(protocol["head"]["learning_rate"]),
        weight_decay=float(protocol["head"]["weight_decay"]),
    )
    positives = max(1, int((target > 0).sum()))
    negatives = max(1, int((target == 0).sum()))
    pos_weight = torch.tensor(min(4.0, max(0.25, negatives / positives)), device=device)
    rng = np.random.default_rng(int(protocol["seed"]) + 900)
    history = []
    history_path = output / "history.jsonl"
    history_path.write_text("", encoding="utf-8")
    for epoch in range(1, epochs + 1):
        head.train()
        order = rng.permutation(len(target))
        losses = []
        for start in range(0, len(order), int(protocol["head"]["batch_size"])):
            chosen = order[start : start + int(protocol["head"]["batch_size"])]
            x = torch.from_numpy(normalized[chosen]).to(device)
            y = torch.from_numpy(target[chosen].astype(np.float32)).to(device)
            prediction = head(x)
            occupied = y > 0
            occupancy_loss = F.binary_cross_entropy_with_logits(
                prediction["occupancy_logits"], occupied.float(), pos_weight=pos_weight
            )
            if bool(occupied.any()):
                regression = F.smooth_l1_loss(
                    prediction["log_count"][occupied], torch.log1p(y[occupied])
                )
                count = torch.expm1(prediction["log_count"][occupied].clamp(0.0, 8.0))
                normalized_count = F.smooth_l1_loss(
                    count / torch.sqrt(y[occupied] + 1.0),
                    y[occupied] / torch.sqrt(y[occupied] + 1.0),
                )
            else:
                regression = prediction["log_count"].sum() * 0.0
                normalized_count = regression
            loss = occupancy_loss + regression + 0.10 * normalized_count
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(head.parameters(), 5.0)
            optimizer.step()
            losses.append(float(loss.detach()))
        row = {"epoch": epoch, "training_loss": float(np.mean(losses))}
        history.append(row)
        checkpoint = {
            "epoch": epoch,
            "model": head.state_dict(),
            "optimizer": optimizer.state_dict(),
            "feature_mean": mean,
            "feature_std": std,
            "feature_names": protocol["feature_names"],
            "occupancy_threshold": occupancy_threshold,
            "protocol": protocol,
            "selection_source": "Expert-A grouped OOF only",
            "target_epochs": epochs,
            "history": history,
        }
        atomic_checkpoint(output / "last.pt", checkpoint)
        atomic_checkpoint(output / "best_val_mae.pt", checkpoint)
        atomic_json(
            output / "progress.json",
            {
                "status": "TRAINING_FINAL_CORE_COUNT_HEAD",
                "last_completed_epoch": epoch,
                "requested_epochs": epochs,
                "router_B_used": False,
                "sealed_test_used": False,
            },
        )
        with history_path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(row) + "\n")
    return checkpoint


def predict_head(
    checkpoint: dict[str, object], features: np.ndarray, candidate_counts: np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    device = torch.device("cuda")
    head = CoreCountHead(
        len(checkpoint["feature_names"]),
        int(checkpoint["protocol"]["head"]["hidden_dim"]),
        int(checkpoint["protocol"]["head"]["bottleneck_dim"]),
        float(checkpoint["protocol"]["head"]["dropout"]),
    ).to(device)
    head.load_state_dict(checkpoint["model"], strict=True)
    head.eval()
    normalized = (features - checkpoint["feature_mean"]) / checkpoint["feature_std"]
    outputs = []
    with torch.inference_mode():
        for start in range(0, len(features), 512):
            outputs.append(head(torch.from_numpy(normalized[start : start + 512].astype(np.float32)).to(device)))
    occupancy = np.concatenate([item["occupancy_logits"].cpu().numpy() for item in outputs])
    log_count = np.concatenate([item["log_count"].cpu().numpy() for item in outputs])
    decoded = decoded_numpy(
        occupancy,
        log_count,
        candidate_counts,
        float(checkpoint["occupancy_threshold"]),
    )
    return decoded, occupancy, log_count


def summarize_rows(rows: list[dict[str, object]], prefix: str) -> dict[str, object]:
    return {
        "images": len(rows),
        **aggregate_count_metrics(
            [int(row[f"{prefix}_count"]) for row in rows],
            [int(row["true_count"]) for row in rows],
        ),
        "tp": sum(int(row[f"{prefix}_tp"]) for row in rows),
        "fp": sum(int(row[f"{prefix}_fp"]) for row in rows),
        "fn": sum(int(row[f"{prefix}_fn"]) for row in rows),
    }


def grouped_summary(rows: list[dict[str, object]], field: str) -> dict[str, object]:
    grouped: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        grouped[str(row[field])].append(row)
    return {key: summarize_rows(values, "calibrated") for key, values in sorted(grouped.items())}


def evaluate_development(
    output: Path,
    protocol: dict[str, object],
    checkpoint: dict[str, object],
    development: dict[str, object],
) -> dict[str, object]:
    counts, occupancy, log_count = predict_head(
        checkpoint, development["features"], development["candidate_counts"]
    )
    points_by_image: dict[str, list[np.ndarray]] = defaultdict(list)
    saturation = 0
    core_rows = []
    for index, count in enumerate(counts):
        if int(count) == int(development["candidate_counts"][index]) and int(count) > 0:
            saturation += 1
        points_by_image[str(development["sample_ids"][index])].append(
            development["candidates"][index][: int(count)]
        )
        core_rows.append(
            {
                "sample_id": str(development["sample_ids"][index]),
                "tile_id": str(development["tile_ids"][index]),
                "true_count": int(development["target"][index]),
                "predicted_count": int(count),
                "candidate_count": int(development["candidate_counts"][index]),
                "occupancy_probability": float(
                    1.0 / (1.0 + np.exp(-np.clip(occupancy[index], -50.0, 50.0)))
                ),
                "raw_conditional_count": float(np.expm1(np.clip(log_count[index], 0.0, 10.0))),
            }
        )
    records = {record.sample_id: record for record in read_manifest(protocol["development_manifest"])}
    rows = []
    points_dir = output / "development_points"
    points_dir.mkdir(exist_ok=True)
    for sample_id in sorted(records):
        record = records[sample_id]
        truth = np.load(Path(protocol["root"]) / record.points_path, allow_pickle=False).astype(np.float32)
        pieces = points_by_image.get(sample_id, [])
        prediction = np.concatenate(pieces) if pieces else np.empty((0, 2), dtype=np.float32)
        scale = 1024.0 / max(record.width, record.height)
        tp, fp, fn = maximum_cardinality_point_matches(prediction * scale, truth * scale, 8.0)
        rows.append(
            {
                "sample_id": sample_id,
                "image_path": record.image_path,
                "true_count": len(truth),
                "calibrated_count": len(prediction),
                "absolute_error": abs(len(prediction) - len(truth)),
                "signed_error": len(prediction) - len(truth),
                "calibrated_tp": tp,
                "calibrated_fp": fp,
                "calibrated_fn": fn,
                "source_family": source_family(sample_id),
                "count_bin": count_bin(len(truth)),
            }
        )
        np.savez_compressed(points_dir / (sample_id.replace(":", "_") + ".npz"), truth=truth, calibrated=prediction)
    metrics = summarize_rows(rows, "calibrated")
    baseline = json.loads(Path(protocol["baseline_summary"]).read_text(encoding="utf-8"))
    gate = float(metrics["mae"]) < float(protocol["promotion_gate"]["enhanced_lr_mae"])
    summary = {
        "status": "COMPLETE_DEVELOPMENT_REVIEW_REQUIRED",
        "method": "frozen rich HR plus core-owned occupancy/count head and core top-K decoding",
        "development": metrics,
        "baselines": {"enhanced_lr": baseline["lr"], "uncalibrated_rich_hr": baseline["hr"]},
        "paired_count_only": {
            "calibrated_minus_enhanced_lr_mae": float(metrics["mae"]) - float(baseline["lr"]["mae"]),
            "calibrated_minus_uncalibrated_hr_mae": float(metrics["mae"]) - float(baseline["hr"]["mae"]),
        },
        "by_count": grouped_summary(rows, "count_bin"),
        "by_source": grouped_summary(rows, "source_family"),
        "cores": len(core_rows),
        "candidate_saturated_cores": saturation,
        "promotion_gate_passed": gate,
        "head_parameters": sum(value.numel() for value in checkpoint["model"].values()),
        "expert_weights_frozen": True,
        "development_used_for_fitting": False,
        "router_B_used": False,
        "sealed_test_used": False,
        "claim_boundary": "development-only component selection; not independent test evidence",
    }
    atomic_json(output / "development_summary.json", summary)
    atomic_json(output / "development_per_image.json", rows)
    with (output / "development_per_image.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    with (output / "development_core_rows.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(core_rows[0]))
        writer.writeheader()
        writer.writerows(core_rows)
    return summary


def fit_and_evaluate(output: Path, protocol: dict[str, object]) -> None:
    train = load_cache(output, "train")
    development = load_cache(output, "development")
    folds = grouped_folds(
        train["sample_ids"], train["target"], int(protocol["head"]["folds"]), int(protocol["seed"])
    )
    oof_occupancy = np.zeros(len(train["target"]), dtype=np.float32)
    oof_log_count = np.zeros(len(train["target"]), dtype=np.float32)
    fold_reports = []
    best_epochs = []
    for fold in range(int(protocol["head"]["folds"])):
        train_indices = np.flatnonzero(folds != fold)
        val_indices = np.flatnonzero(folds == fold)
        result = train_fold(
            train["features"],
            train["target"],
            train["sample_ids"],
            train["candidate_counts"],
            train_indices,
            val_indices,
            protocol,
            int(protocol["seed"]) + fold,
        )
        oof_occupancy[val_indices] = result["occupancy_logits"]
        oof_log_count[val_indices] = result["log_count"]
        best_epochs.append(int(result["best_epoch"]))
        fold_reports.append(
            {
                "fold": fold,
                "training_tiles": len(train_indices),
                "validation_tiles": len(val_indices),
                "best_epoch": result["best_epoch"],
                "best_image_mae_at_0.5": result["best_image_mae_at_0.5"],
                "best_core_mae_at_0.5": result["best_core_mae_at_0.5"],
                "history": result["history"],
            }
        )
        atomic_json(
            output / "oof_progress.json",
            {"status": "OOF_TRAINING", "completed_folds": fold + 1, "folds": int(protocol["head"]["folds"])},
        )
    threshold_rows = []
    for threshold in OCCUPANCY_THRESHOLDS:
        decoded = decoded_numpy(oof_occupancy, oof_log_count, train["candidate_counts"], threshold)
        threshold_rows.append(
            {
                "threshold": threshold,
                "image_mae": image_mae(decoded, train["target"], train["sample_ids"]),
                "core_mae": float(np.abs(decoded - train["target"]).mean()),
                "bias": float((decoded - train["target"]).mean()),
            }
        )
    selected = min(threshold_rows, key=lambda row: (row["image_mae"], row["core_mae"], abs(row["bias"])))
    final_epochs = max(1, int(round(float(np.median(best_epochs)))))
    oof_count = decoded_numpy(
        oof_occupancy,
        oof_log_count,
        train["candidate_counts"],
        float(selected["threshold"]),
    )
    oof_report = {
        "status": "COMPLETE_EXPERT_A_GROUPED_OOF",
        "folds": fold_reports,
        "occupancy_threshold_search": threshold_rows,
        "selected_occupancy_threshold": selected["threshold"],
        "selected_image_mae": selected["image_mae"],
        "selected_core_mae": selected["core_mae"],
        "selected_bias": selected["bias"],
        "best_epochs": best_epochs,
        "final_training_epochs": final_epochs,
        "images": len(np.unique(train["sample_ids"])),
        "tiles": len(train["target"]),
        "candidate_saturated_tiles": int(((oof_count == train["candidate_counts"]) & (oof_count > 0)).sum()),
        "development_used": False,
        "router_B_used": False,
        "sealed_test_used": False,
    }
    atomic_json(output / "expert_A_oof.json", oof_report)
    checkpoint = fit_final_head(
        output,
        protocol,
        train["features"],
        train["target"],
        final_epochs,
        float(selected["threshold"]),
    )
    summary = evaluate_development(output, protocol, checkpoint, development)
    atomic_json(output / "summary.json", summary)
    atomic_json(output / "stage.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


@torch.inference_mode()
def smoke(output: Path, protocol: dict[str, object]) -> None:
    model = make_expert(protocol)
    results = []
    for split_name, manifest, split in (
        ("train", protocol["train_manifest"], "train"),
        ("development", protocol["development_manifest"], "val"),
    ):
        dataset = CRUContextCropDataset(
            manifest,
            protocol["root"],
            split=split,
            image_size=int(protocol["input_size"]),
            core_size=int(protocol["core_size"]),
            halo=int(protocol["halo"]),
            max_images=1,
            cache_images=0,
        )
        row = extract_item(model, dataset[0], protocol)
        results.append(
            {
                "split": split_name,
                "feature_dim": len(row["feature"]),
                "candidates": len(row["candidate_native_xy"]),
                "true_count": row["true_count"],
            }
        )
    head = CoreCountHead(int(protocol["feature_dim"])).cuda()
    values = head(torch.zeros(2, int(protocol["feature_dim"]), device="cuda"))
    decoded = decode_core_counts(
        values["occupancy_logits"], values["log_count"], torch.tensor([5, 0], device="cuda")
    )
    report = {
        "status": "PASS",
        "items": results,
        "head_parameters": sum(parameter.numel() for parameter in head.parameters()),
        "decode_shape": list(decoded.shape),
        "expert_parameters_requiring_gradient": sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad),
        "router_B_used": False,
        "sealed_test_used": False,
    }
    if report["expert_parameters_requiring_gradient"] != 0:
        raise ValueError("frozen expert unexpectedly requires gradients")
    atomic_json(output / "engineering_smoke.json", report)
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)


def run(output: Path, protocol: dict[str, object]) -> None:
    smoke_report = json.loads((output / "engineering_smoke.json").read_text(encoding="utf-8"))
    if smoke_report.get("status") != "PASS":
        raise ValueError("passing engineering smoke is required")
    atomic_json(
        output / "stage.json",
        {"status": "RUNNING", "pid": os.getpid(), "router_B_used": False, "sealed_test_used": False},
    )
    extract_split(output, protocol, "train")
    extract_split(output, protocol, "development")
    fit_and_evaluate(output, protocol)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("prepare", "smoke", "run"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--hr-run", type=Path)
    parser.add_argument("--baseline-summary", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    if args.mode == "prepare":
        if args.hr_run is None or args.baseline_summary is None:
            parser.error("prepare requires --hr-run and --baseline-summary")
        prepare(args)
        return
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    protocol = verify(output)
    if args.mode == "smoke":
        smoke(output, protocol)
    else:
        run(output, protocol)


if __name__ == "__main__":
    main()
