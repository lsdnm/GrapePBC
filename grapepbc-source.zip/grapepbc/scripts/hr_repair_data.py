"""Opt-in HR repair data path: image-aware sampling and photometric augmentation.

Frozen legacy loaders remain unchanged. No label-dependent sample filtering.
"""
from collections import Counter, defaultdict
from pathlib import Path
import sys

import numpy as np
from PIL import Image, ImageEnhance
import torch
from torch.utils.data import Dataset, Sampler

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from geopriv.data import CRUContextCropDataset
from geopriv.data.point_dataset import IMAGENET_MEAN, IMAGENET_STD


def source_proxy(sample_id):
    name=sample_id.split(':',1)[-1].lower()
    return ('immature' if name.startswith('immature') else 'phone_timestamp' if name.startswith('img_20')
        else 'img_camera' if name.startswith('img') else 'dsc_camera' if 'dsc' in name
        else 'numeric_timestamp' if name.isdigit() and len(name)>=12
        else 'numeric_short' if name.isdigit() else 'other')


class ImageBalancedTileSampler(Sampler):
    """Every A image once, then capped source/image-balanced random tiles.

    Epoch length matches exhaustive cropping. Large images do not receive an
    automatically larger sampling weight just because they generate more tiles.
    Filename families are source proxies only and are never network inputs.
    """
    def __init__(self,dataset,seed):
        self.seed=int(seed);self.epoch=0;self.count=len(dataset)
        by_image=defaultdict(list)
        for i,(record_index,_) in enumerate(dataset.items):by_image[record_index].append(i)
        self.groups=[by_image[i] for i in range(len(dataset.records))]
        sources=[source_proxy(r.sample_id) for r in dataset.records];counts=Counter(sources)
        weights=np.array([min(5.,len(sources)/(len(counts)*counts[s])) for s in sources])
        self.image_probabilities=weights/weights.sum()
        self.source_counts=dict(counts)

    def set_epoch(self,epoch):self.epoch=int(epoch)
    def __len__(self):return self.count
    def __iter__(self):
        rng=np.random.default_rng(np.random.SeedSequence([self.seed,self.epoch]))
        chosen=[int(rng.choice(group)) for group in self.groups]
        for image_index in rng.choice(len(self.groups),self.count-len(chosen),p=self.image_probabilities):
            chosen.append(int(rng.choice(self.groups[int(image_index)])))
        chosen=np.asarray(chosen)[rng.permutation(self.count)]
        # Per-draw augmentation permits distinct views for a repeated tile.
        return iter((int(index),draw,self.epoch) for draw,index in enumerate(chosen))


class PhotometricCropDataset(Dataset):
    def __init__(self,protocol,*,augment=True):
        self.protocol=protocol;self.augment=augment;self._base=None

    @property
    def base(self):
        if self._base is None:
            p=self.protocol
            self._base=CRUContextCropDataset(p['manifest'],p['root'],split='train',
                image_size=p['input_size'],core_size=p['core_size'],halo=p['halo'],cache_images=8)
        return self._base

    def __getstate__(self):
        state=self.__dict__.copy();state['_base']=None;return state

    def __len__(self):return len(self.base)

    @property
    def records(self):return self.base.records

    def __getitem__(self,request):
        index,draw,epoch=request if isinstance(request,tuple) else (request,0,0)
        item=self.base[index]
        rng=np.random.default_rng(np.random.SeedSequence([self.protocol['seed'],epoch,index,draw]))
        if self.augment and rng.random()<.8:
            rgb=((item['image']*IMAGENET_STD+IMAGENET_MEAN).clamp(0,1)*255).round().byte().numpy().transpose(1,2,0)
            image=Image.fromarray(rgb)
            for enhancer,magnitude in ((ImageEnhance.Brightness,.25),(ImageEnhance.Contrast,.25),(ImageEnhance.Color,.2)):
                image=enhancer(image).enhance(float(1+rng.uniform(-magnitude,magnitude)))
            array=np.asarray(image,dtype=np.float32).transpose(2,0,1).copy()/255.
            adjusted=(torch.from_numpy(array)-IMAGENET_MEAN)/IMAGENET_STD
            # Keep padding exactly unchanged. Coordinates/ownership never move.
            item=dict(item,image=torch.where(item['valid_image_mask'][None],adjusted,item['image']))
        return item


def resolution_gain(width,height,context_width,context_height,*,lr_input=1024,hr_input=768):
    """Geometric sampling gain only, not added optical detail or accuracy."""
    if min(width,height,context_width,context_height,lr_input,hr_input)<=0:
        raise ValueError('positive image dimensions required')
    return (hr_input/max(context_width,context_height))/(lr_input/max(width,height))
