"""Combine V39 ultra-local cleanup with scale-adaptive V40 pair evidence."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path
import sys


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

import develop_v36_local_duplicate_merge as v36  # noqa: E402
import develop_v38_point_integrity_component_merge as v38  # noqa: E402
from run_vivid_hr_core_calibration import atomic_json  # noqa: E402


EXP = PROJECT / "experiments" / "cru_detail_v1"
V40 = EXP / "vivid_adaptive_scale_duplicate_pair_oof_v40" / "oof_pair_scores.json"
OUT = EXP / "vivid_adaptive_scale_point_integrity_v41"
V39_POLICY = v38.Policy(
    probability_threshold=0.75,
    maximum_pair_distance_1024=6.0,
    ultra_local_probability_threshold=0.70,
    ultra_local_maximum_pair_distance_1024=2.5,
)
APPLY_ALL = v38.Policy(probability_threshold=0.5, maximum_pair_distance_1024=32.0)


@dataclass(frozen=True)
class AdaptivePolicy:
    probability_threshold: float
    maximum_pair_distance_1024: float
    maximum_midpoint_candidate_distance_1024: float
    minimum_midpoint_candidate_score: float


POLICIES = tuple(
    AdaptivePolicy(probability_threshold=p, maximum_pair_distance_1024=d,
                   maximum_midpoint_candidate_distance_1024=s,
                   minimum_midpoint_candidate_score=c)
    for p in (0.96, 0.97, 0.975, 0.98, 0.985)
    for d in (8.0, 12.0, 16.0)
    for s in (4.0, 6.0, 8.0, 12.0)
    for c in (0.05, 0.075)
)


def v39_accept(row: dict) -> bool:
    return bool(
        (row["score"] >= 0.75 and row["distance"] <= 6.0)
        or (row["score"] >= 0.70 and row["distance"] <= 2.5)
    )


def union_pairs(v39_pairs: list[dict], v40_pairs: list[dict], policy: AdaptivePolicy) -> tuple[list[dict], dict]:
    combined: dict[tuple[int, int], dict] = {}
    v39_count = 0; adaptive_count = 0
    for row in v39_pairs:
        if not v39_accept(row):
            continue
        key = tuple(sorted((int(row["first"]), int(row["second"]))))
        combined[key] = {**row, "score": 1.0, "source": "v39"}
        v39_count += 1
    for row in v40_pairs:
        features = row["features"]
        if (float(row["score"]) < policy.probability_threshold
                or float(row["distance"]) > policy.maximum_pair_distance_1024
                or int(row["target_candidate_index"]) < 0
                or float(features["midpoint_candidate_distance"]) > policy.maximum_midpoint_candidate_distance_1024
                or float(features["midpoint_candidate_score"]) < policy.minimum_midpoint_candidate_score):
            continue
        key = tuple(sorted((int(row["first"]), int(row["second"]))))
        if key in combined:
            continue
        combined[key] = {
            "first": key[0], "second": key[1], "distance": float(row["distance"]),
            "score": 1.0, "candidate_index": int(row["target_candidate_index"]),
            "source": "v40_adaptive",
        }
        adaptive_count += 1
    return list(combined.values()), {
        "v39_edges": v39_count, "adaptive_edges_added": adaptive_count,
        "union_edges": len(combined),
    }


def main() -> None:
    if OUT.exists():
        raise SystemExit(f"refusing to overwrite existing experiment: {OUT}")
    OUT.mkdir(parents=True)
    bases, actions_by_id, scores_by_id = v36.prepare()
    v39_pairs_by_id = {
        base["sample_id"]: v36.unique_pairs(
            base, actions_by_id[base["sample_id"]], scores_by_id[base["sample_id"]]
        )
        for base in bases
    }
    v40_by_id: dict[str, list[dict]] = {}
    for row in json.loads(V40.read_text(encoding="utf-8")):
        v40_by_id.setdefault(row["sample_id"], []).append(row)

    screening = []; eligible = []
    for policy in POLICIES:
        pairs_by_id = {}; source_counts = {"v39_edges": 0, "adaptive_edges_added": 0, "union_edges": 0}
        for base in bases:
            pairs, counts = union_pairs(
                v39_pairs_by_id[base["sample_id"]], v40_by_id.get(base["sample_id"], []), policy
            )
            pairs_by_id[base["sample_id"]] = pairs
            for key in source_counts:
                source_counts[key] += counts[key]
        rows, report = v38.evaluate(bases, pairs_by_id, APPLY_ALL)
        report["adaptive_policy"] = asdict(policy)
        report["source_counts"] = source_counts
        report["eligible"] = bool(
            report["merges"] > 103
            and report["removal_precision_proxy"] >= 0.98
            and report["competition_reduction"] > 82
            and all(value >= 0 for value in report["f1_gain"].values())
            and report["count_mae_after"] - report["count_mae_before"] < 0.50
        )
        screening.append(report)
        if report["eligible"]:
            eligible.append((rows, report))
        print(json.dumps({
            "policy": report["adaptive_policy"], "merges": report["merges"],
            "precision": report["removal_precision_proxy"],
            "competition_reduction": report["competition_reduction"],
            "f1_gain": report["f1_gain"], "mae_change": -report["count_mae_gain"],
            "adaptive_edges": source_counts["adaptive_edges_added"], "eligible": report["eligible"],
        }, ensure_ascii=False), flush=True)

    eligible.sort(key=lambda item: (
        item[1]["competition_reduction"], item[1]["removal_precision_proxy"],
        item[1]["f1_gain"]["4"], item[1]["f1_gain"]["8"], item[1]["f1_gain"]["16"],
    ), reverse=True)
    selected_rows, selected = eligible[0] if eligible else (None, None)
    summary = {
        "status": "ADAPTIVE_SCALE_POLICY_FOUND" if selected else "NO_ACCEPTABLE_ADAPTIVE_POLICY",
        "selected": selected,
        "bootstrap": v36.bootstrap(selected_rows) if selected_rows else None,
        "policies": len(screening), "eligible_policies": len(eligible),
        "development_selected": True, "independent_confirmation": False,
        "sealed_test_used": False,
    }
    atomic_json(OUT / "screening.json", screening)
    atomic_json(OUT / "summary.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
