"""Stabilise the exhaustive-HR global count expert across count regimes.

All model, target, weighting, decoder and ensemble decisions are selected by
grouped Expert-A OOF.  The existing development role is used only once as a
component gate, while Router-B and the sealed test remain unavailable.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import sys

import joblib
import numpy as np
from sklearn.ensemble import ExtraTreesRegressor, GradientBoostingRegressor, RandomForestRegressor

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

from geopriv.data.hash_utils import file_sha256
from geopriv.metrics import maximum_cardinality_point_matches
import run_vivid_hr_global_conservation as base_stage
import run_vivid_hr_residual_fusion as residual_stage


def atomic_json(path: Path, payload: object) -> None:
    base_stage.atomic_json(path, payload)


def prepare(args: argparse.Namespace) -> None:
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"non-empty output exists: {output}")
    output.mkdir(parents=True, exist_ok=True)
    base = args.base_run.resolve()
    base_summary = json.loads((base / "summary.json").read_text(encoding="utf-8"))
    if not base_summary.get("promotion_gate_passed"):
        raise ValueError("base exhaustive-HR teacher did not pass its component gate")
    base_protocol = json.loads((base / "protocol.json").read_text(encoding="utf-8"))
    if base_protocol.get("router_B_used") or base_protocol.get("sealed_test_used"):
        raise ValueError("base teacher crossed a forbidden role boundary")
    configs = [
        {"name": "gbr_huber_sqrt_uniform", "kind": "gbr", "loss": "huber", "target": "sqrt_residual", "weight": "uniform", "depth": 3, "trees": 160, "leaf": 12},
        {"name": "gbr_huber_sqrt_balanced", "kind": "gbr", "loss": "huber", "target": "sqrt_residual", "weight": "count_bin_balanced", "depth": 3, "trees": 200, "leaf": 10},
        {"name": "gbr_squared_sqrt_uniform", "kind": "gbr", "loss": "squared_error", "target": "sqrt_residual", "weight": "uniform", "depth": 2, "trees": 200, "leaf": 12},
        {"name": "gbr_squared_sqrt_balanced", "kind": "gbr", "loss": "squared_error", "target": "sqrt_residual", "weight": "count_bin_balanced", "depth": 2, "trees": 240, "leaf": 10},
        {"name": "gbr_huber_logratio_uniform", "kind": "gbr", "loss": "huber", "target": "log_ratio", "weight": "uniform", "depth": 3, "trees": 200, "leaf": 10},
        {"name": "gbr_squared_logratio_balanced", "kind": "gbr", "loss": "squared_error", "target": "log_ratio", "weight": "count_bin_balanced", "depth": 2, "trees": 240, "leaf": 10},
        {"name": "extra_sqrt_uniform", "kind": "extra", "target": "sqrt_residual", "weight": "uniform", "trees": 400, "leaf": 4, "features": 0.7},
        {"name": "extra_sqrt_balanced", "kind": "extra", "target": "sqrt_residual", "weight": "count_bin_balanced", "trees": 400, "leaf": 4, "features": 0.7},
        {"name": "extra_logratio_uniform", "kind": "extra", "target": "log_ratio", "weight": "uniform", "trees": 400, "leaf": 4, "features": 0.7},
        {"name": "extra_directlog_balanced", "kind": "extra", "target": "direct_log", "weight": "count_bin_balanced", "trees": 400, "leaf": 4, "features": 0.7},
        {"name": "forest_sqrt_balanced", "kind": "forest", "target": "sqrt_residual", "weight": "count_bin_balanced", "trees": 400, "leaf": 4, "features": 0.7},
    ]
    protocol = {
        **base_protocol,
        "version": "vivid-lr-hr-global-count-conservation-v2-stable-ensemble",
        "status": "PREPARED",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "seed": 20261008,
        "base_run": str(base),
        "base_protocol_sha256": file_sha256(base / "protocol.json"),
        "base_model_sha256": file_sha256(base / "global_count_model.joblib"),
        "model_candidates": configs,
        "alpha_candidates": [0.5, 0.75, 1.0, 1.25, 1.5],
        "ensemble_candidates": ["individual", "top3_mean", "top3_median", "top5_mean"],
        "selection": "five-fold grouped Expert-A OOF MAE; no development selection",
        "development_gate": "MAE below v1 exhaustive teacher and F1@8 no worse than v1 - 0.005",
        "source_sha256": {
            "scripts/run_vivid_hr_global_conservation_v2.py": file_sha256(Path(__file__)),
            "scripts/run_vivid_hr_global_conservation.py": file_sha256(PROJECT / "scripts/run_vivid_hr_global_conservation.py"),
            "scripts/run_vivid_hr_residual_fusion.py": file_sha256(PROJECT / "scripts/run_vivid_hr_residual_fusion.py"),
        },
        "development_used_for_fitting": False,
        "router_B_used": False,
        "sealed_test_used": False,
    }
    atomic_json(output / "protocol.json", protocol)
    atomic_json(output / "progress.json", {"status": "PREPARED", "router_B_used": False, "sealed_test_used": False})
    print(json.dumps(protocol, ensure_ascii=False, indent=2))


def verify(output: Path) -> dict[str, object]:
    protocol = json.loads((output / "protocol.json").read_text(encoding="utf-8"))
    for name, expected in protocol["source_sha256"].items():
        if file_sha256(PROJECT / name) != expected:
            raise ValueError(f"source drift: {name}")
    base = Path(protocol["base_run"])
    if file_sha256(base / "protocol.json") != protocol["base_protocol_sha256"]:
        raise ValueError("base protocol drift")
    if file_sha256(base / "global_count_model.joblib") != protocol["base_model_sha256"]:
        raise ValueError("base model drift")
    if protocol["router_B_used"] or protocol["sealed_test_used"]:
        raise ValueError("forbidden role boundary")
    return protocol


def count_bin_index(values: np.ndarray) -> np.ndarray:
    return np.digitize(values, [50, 100, 200], right=True).astype(np.int64)


def sample_weights(table: dict[str, object], scheme: str) -> np.ndarray:
    if scheme == "uniform":
        return np.ones(len(table["target"]), dtype=np.float64)
    bins = count_bin_index(table["target"])
    frequency = np.bincount(bins, minlength=4).astype(np.float64)
    weights = len(bins) / (4.0 * np.maximum(frequency, 1.0))
    return weights[bins]


def regression_target(table: dict[str, object], kind: str) -> np.ndarray:
    truth = table["target"].astype(np.float64)
    lr = table["lr_total"].astype(np.float64)
    if kind == "sqrt_residual":
        return (truth - lr) / np.sqrt(lr + 1.0)
    if kind == "log_ratio":
        return np.log1p(truth) - np.log1p(lr)
    if kind == "direct_log":
        return np.log1p(truth)
    raise ValueError(kind)


def make_model(config: dict[str, object], seed: int):
    if config["kind"] == "gbr":
        options = dict(
            loss=str(config["loss"]), random_state=seed,
            max_depth=int(config["depth"]), n_estimators=int(config["trees"]),
            learning_rate=0.03, min_samples_leaf=int(config["leaf"]),
            subsample=0.85, max_features="sqrt",
        )
        if config["loss"] == "huber":
            options["alpha"] = 0.85
        return GradientBoostingRegressor(**options)
    common = dict(
        n_estimators=int(config["trees"]), random_state=seed,
        min_samples_leaf=int(config["leaf"]), max_features=float(config["features"]),
        n_jobs=-1,
    )
    if config["kind"] == "extra":
        return ExtraTreesRegressor(**common)
    if config["kind"] == "forest":
        return RandomForestRegressor(**common)
    raise ValueError(str(config["kind"]))


def decode(table: dict[str, object], raw: np.ndarray, target_kind: str, alpha: float) -> np.ndarray:
    lr = table["lr_total"].astype(np.float64)
    if target_kind == "sqrt_residual":
        count = lr + np.rint(alpha * raw * np.sqrt(lr + 1.0))
    elif target_kind == "log_ratio":
        count = np.rint(np.expm1(np.log1p(lr) + alpha * raw))
    elif target_kind == "direct_log":
        count = np.rint(np.expm1((1.0 - alpha) * np.log1p(lr) + alpha * raw))
    else:
        raise ValueError(target_kind)
    return np.maximum(count, 0).astype(np.int64)


def count_metrics(table: dict[str, object], prediction: np.ndarray) -> dict[str, object]:
    difference = prediction - table["target"]
    bins = count_bin_index(table["target"])
    return {
        "mae": float(np.abs(difference).mean()),
        "rmse": float(np.sqrt(np.square(difference).mean())),
        "bias": float(difference.mean()),
        "by_count_mae": {
            str(index): float(np.abs(difference[bins == index]).mean())
            for index in range(4) if (bins == index).any()
        },
    }


def select_oof(
    output: Path, protocol: dict[str, object], table: dict[str, object], data: dict[str, object]
) -> dict[str, object]:
    (output / "oof_models").mkdir(parents=True, exist_ok=True)
    folds = base_stage.make_folds(table, data, 5, int(protocol["seed"]))
    raw_by_config: dict[int, np.ndarray] = {}
    individual_rows = []
    best_per_config = {}
    for index, config in enumerate(protocol["model_candidates"]):
        target = regression_target(table, str(config["target"]))
        weights = sample_weights(table, str(config["weight"]))
        raw = np.zeros(len(target), dtype=np.float64)
        for fold in range(5):
            train = folds != fold
            valid = folds == fold
            model = make_model(config, int(protocol["seed"]) + index * 100 + fold)
            model.fit(table["features"][train], target[train], sample_weight=weights[train])
            raw[valid] = model.predict(table["features"][valid])
            joblib.dump(model, output / "oof_models" / f"config_{index}_fold_{fold}.joblib")
            atomic_json(
                output / "progress.json",
                {"status": "EXPERT_A_OOF", "config": index, "fold": fold + 1,
                 "router_B_used": False, "sealed_test_used": False},
            )
        raw_by_config[index] = raw
        rows = []
        for alpha in protocol["alpha_candidates"]:
            prediction = decode(table, raw, str(config["target"]), float(alpha))
            row = {"strategy": "individual", "config_index": index, "config": config,
                   "alpha": float(alpha), **count_metrics(table, prediction)}
            rows.append(row)
            individual_rows.append(row)
        best_per_config[index] = min(rows, key=lambda row: (row["mae"], row["rmse"], abs(row["bias"])))
    ranked = sorted(best_per_config, key=lambda index: (
        best_per_config[index]["mae"], best_per_config[index]["rmse"]
    ))
    decoded = {
        index: decode(
            table, raw_by_config[index],
            str(protocol["model_candidates"][index]["target"]),
            float(best_per_config[index]["alpha"]),
        )
        for index in ranked
    }
    ensemble_rows = []
    for size, method in ((3, "mean"), (3, "median"), (5, "mean")):
        members = ranked[:size]
        stack = np.stack([decoded[index] for index in members]).astype(np.float64)
        value = stack.mean(axis=0) if method == "mean" else np.median(stack, axis=0)
        prediction = np.rint(value).astype(np.int64)
        ensemble_rows.append(
            {"strategy": f"top{size}_{method}", "members": members,
             "member_settings": [best_per_config[index] for index in members],
             **count_metrics(table, prediction)}
        )
    candidates = individual_rows + ensemble_rows
    selected = min(candidates, key=lambda row: (
        row["mae"], row["rmse"], abs(row["bias"]), row["strategy"] != "individual"
    ))
    report = {
        "status": "COMPLETE_EXPERT_A_GROUPED_OOF",
        "selected": selected,
        "best_per_config": best_per_config,
        "ensemble_rows": ensemble_rows,
        "individual_rows": individual_rows,
        "ranked_configs": ranked,
        "development_used": False,
        "router_B_used": False,
        "sealed_test_used": False,
    }
    atomic_json(output / "expert_A_oof.json", report)
    return report


def fit_artifact(
    output: Path, protocol: dict[str, object], table: dict[str, object], report: dict[str, object]
) -> dict[str, object]:
    selected = report["selected"]
    if selected["strategy"] == "individual":
        indices = [int(selected["config_index"])]
        settings = [selected]
    else:
        indices = [int(value) for value in selected["members"]]
        settings = selected["member_settings"]
    models = []
    for position, (index, setting) in enumerate(zip(indices, settings, strict=True)):
        config = protocol["model_candidates"][index]
        target = regression_target(table, str(config["target"]))
        weights = sample_weights(table, str(config["weight"]))
        model = make_model(config, int(protocol["seed"]) + 9000 + position)
        model.fit(table["features"], target, sample_weight=weights)
        models.append({"config_index": index, "config": config, "alpha": setting["alpha"], "model": model})
    artifact = {
        "strategy": selected["strategy"], "models": models,
        "selection": selected, "feature_dim": int(table["features"].shape[1]),
    }
    base_stage.atomic_joblib(output / "global_count_ensemble.joblib", artifact)
    return artifact


def predict_artifact(table: dict[str, object], artifact: dict[str, object]) -> np.ndarray:
    predictions = []
    for item in artifact["models"]:
        raw = item["model"].predict(table["features"])
        predictions.append(decode(table, raw, str(item["config"]["target"]), float(item["alpha"])))
    stack = np.stack(predictions).astype(np.float64)
    if artifact["strategy"].endswith("median"):
        return np.rint(np.median(stack, axis=0)).astype(np.int64)
    return np.rint(stack.mean(axis=0)).astype(np.int64)


def paired_bootstrap(rows: list[dict[str, object]], seed: int) -> dict[str, object]:
    delta = np.asarray([
        abs(int(row["true_count"]) - int(row["lr_count"]))
        - abs(int(row["true_count"]) - int(row["predicted_count"]))
        for row in rows
    ], dtype=np.float64)
    rng = np.random.default_rng(seed)
    means = delta[rng.integers(0, len(delta), size=(20000, len(delta)))].mean(axis=1)
    return {
        "mean_mae_improvement_vs_lr": float(delta.mean()),
        "ci95": [float(value) for value in np.quantile(means, [0.025, 0.975])],
        "improved": int((delta > 0).sum()), "worsened": int((delta < 0).sum()),
        "tied": int((delta == 0).sum()),
    }


def evaluate(
    output: Path, protocol: dict[str, object], table: dict[str, object],
    data: dict[str, object], artifact: dict[str, object],
) -> dict[str, object]:
    requested = predict_artifact(table, artifact)
    index_by_sample = {str(sample_id): index for index, sample_id in enumerate(table["sample_ids"])}
    rows = []
    point_dir = output / "development_points"
    point_dir.mkdir(exist_ok=True)
    residual_protocol = residual_stage.verify(Path(protocol["residual_run"]))
    root = Path(residual_protocol["root"])
    for sample_id in sorted(data["records"]):
        indices = np.flatnonzero(data["sample_ids"] == sample_id)
        image_index = index_by_sample[sample_id]
        points, capacity, saturated = base_stage.conserve_points(
            [data["candidates"][index] for index in indices],
            [data["candidate_scores"][index] for index in indices],
            data["residual_count"][indices], int(requested[image_index]),
        )
        record = data["records"][sample_id]
        truth = np.load(root / record.points_path, allow_pickle=False).astype(np.float32)
        scale = 1024.0 / max(record.width, record.height)
        tp, fp, fn = maximum_cardinality_point_matches(points * scale, truth * scale, 8.0)
        rows.append({
            "sample_id": sample_id, "true_count": len(truth),
            "lr_count": int(table["lr_total"][image_index]),
            "predicted_count": len(points), "absolute_error": abs(len(points) - len(truth)),
            "signed_error": len(points) - len(truth), "tp": tp, "fp": fp, "fn": fn,
            "candidate_capacity": capacity, "candidate_saturated": saturated,
            "count_bin": residual_stage.count_bin(len(truth)),
            "source_family": residual_stage.source_family(sample_id),
        })
        np.savez_compressed(point_dir / (sample_id.replace(":", "_") + ".npz"), truth=truth, global_conserved_hr=points)
    metrics = base_stage.summarize(rows)
    by_count: dict[str, list[dict[str, object]]] = defaultdict(list)
    by_source: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        by_count[str(row["count_bin"])].append(row)
        by_source[str(row["source_family"])].append(row)
    base_summary = json.loads((Path(protocol["base_run"]) / "summary.json").read_text(encoding="utf-8"))
    base_metrics = base_summary["development"]
    gate = metrics["mae"] < base_metrics["mae"] and metrics["f1_at_8"] >= base_metrics["f1_at_8"] - 0.005
    summary = {
        "status": "COMPLETE_DEVELOPMENT_REVIEW_REQUIRED",
        "development": metrics, "base_teacher_development": base_metrics,
        "enhanced_lr": base_summary["enhanced_lr"],
        "selected_expert_A_oof": artifact["selection"],
        "paired_bootstrap_vs_lr": paired_bootstrap(rows, int(protocol["seed"])),
        "promotion_gate_passed": bool(gate),
        "by_count": {key: base_stage.summarize(value) for key, value in sorted(by_count.items())},
        "by_source": {key: base_stage.summarize(value) for key, value in sorted(by_source.items())},
        "development_used_for_fitting": False, "router_B_used": False,
        "sealed_test_used": False,
        "claim_boundary": "bounded Expert-A repair and existing-development component gate",
    }
    atomic_json(output / "development_per_image.json", rows)
    atomic_json(output / "development_summary.json", summary)
    return summary


def run(output: Path, protocol: dict[str, object]) -> None:
    data = base_stage.load_components(protocol, "train")
    table = base_stage.make_image_table(data)
    atomic_json(output / "engineering_smoke.json", {
        "status": "PASS", "train_images": len(table["target"]),
        "feature_dim": int(table["features"].shape[1]),
        "finite": bool(np.isfinite(table["features"]).all()),
        "router_B_used": False, "sealed_test_used": False,
    })
    report = select_oof(output, protocol, table, data)
    artifact = fit_artifact(output, protocol, table, report)
    development_data = base_stage.load_components(protocol, "development")
    development_table = base_stage.make_image_table(development_data)
    summary = evaluate(output, protocol, development_table, development_data, artifact)
    summary["model_sha256"] = file_sha256(output / "global_count_ensemble.joblib")
    atomic_json(output / "summary.json", summary)
    atomic_json(output / "progress.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("prepare", "run"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--base-run", type=Path)
    args = parser.parse_args()
    if args.mode == "prepare":
        if args.base_run is None:
            parser.error("prepare requires --base-run")
        prepare(args)
    else:
        run(args.output.resolve(), verify(args.output.resolve()))


if __name__ == "__main__":
    main()
