"""Development-only cluster-aware repair of frozen CRU berry points.

The whole-image CRU count is conserved exactly.  A small, predeclared grid
tests whether rich-HR candidate evidence can redistribute a few points from an
over-served predicted bunch to an under-served predicted bunch.  This script
does not open Router-B or the sealed test and never uses labels at inference.

Labels are read only for the open-development audit and parameter screening.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import asdict, dataclass
import hashlib
import json
import math
from pathlib import Path
import sys
from typing import Iterable

import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.spatial import cKDTree


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))

from geopriv.counting import ClusterBox, assign_berries_to_cluster_boxes, box_iou
from geopriv.metrics import maximum_cardinality_point_matches
from geopriv.routing import make_core_halo_tiles


EXP = PROJECT / "experiments" / "cru_detail_v1"
MANIFEST = EXP / "vivid_application_lr_repair_inputs_v1" / "development_val_clean.jsonl"
PROPOSALS = EXP / "vivid_stage6_secondary_scale_recovery_development_v1" / "development_proposals.jsonl"
BASE_POINTS = EXP / "vivid_cru_near_count_repair_v2_center_gated" / "oof_development_points"
CANDIDATE_ROOT = EXP / "vivid_application_development_density_core_points_v2"
OUT = EXP / "vivid_cluster_aware_point_reallocation_v1"

CORE_SIZE = 1024
HALO = 128
BOOTSTRAP_REPLICATES = 5000
SEED = 20261003
EXAMPLE_ID = "vivid5k:IMG_20220721_141934"


@dataclass(frozen=True)
class Config:
    score_threshold: float
    blend: float
    movement_l1_gate: int
    max_transfers: int
    nms_radius_1024: float
    removal: str

    @property
    def name(self) -> str:
        return (
            f"s{self.score_threshold:.3f}_a{self.blend:.2f}"
            f"_g{self.movement_l1_gate}_m{self.max_transfers}"
            f"_r{self.nms_radius_1024:.1f}_{self.removal}"
        ).replace(".", "p")


# The grid is intentionally compact.  The conservative caps prevent a single
# image from being extensively rewritten during open-development selection.
CONFIGS = tuple(
    Config(score, blend, gate, transfers, radius, removal)
    for score in (0.075, 0.100, 0.125)
    for blend in (0.35, 0.50, 0.65)
    for gate in (6, 10)
    for transfers in (4,)
    for radius in (4.0, 6.0)
    for removal in ("hybrid_support",)
)


def read_rows(path: Path) -> list[dict]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8-sig").splitlines()
        if line.strip()
    ]


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def atomic_npz(path: Path, **arrays: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp.npz")
    np.savez_compressed(temporary, **arrays)
    temporary.replace(path)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def make_boxes(row: dict, key: str) -> list[ClusterBox]:
    boxes = []
    for index, item in enumerate(row[key]):
        boxes.append(ClusterBox(
            cluster_id=str(item.get("cluster_id", f"truth_{index}")),
            bbox_xyxy=tuple(float(value) for value in item["bbox_xyxy"]),
            confidence=float(item.get("confidence", 1.0)),
            source=str(item.get("source", "truth_box")),
        ))
    return boxes


def ensure_evaluation_box(
    points: np.ndarray,
    boxes: list[ClusterBox],
    image_size: tuple[int, int],
) -> tuple[list[ClusterBox], bool]:
    """Mirror the production point-envelope fallback for a missing detector box."""
    if boxes or not len(points):
        return boxes, False
    width, height = image_size
    minimum = points.min(axis=0)
    maximum = points.max(axis=0)
    margin = max(4.0, 0.015 * math.hypot(width, height))
    x0 = max(0.0, float(minimum[0] - margin))
    y0 = max(0.0, float(minimum[1] - margin))
    x1 = min(float(width - 1), float(maximum[0] + margin))
    y1 = min(float(height - 1), float(maximum[1] + margin))
    if x1 <= x0:
        x1 = min(float(width - 1), x0 + 1.0)
    if y1 <= y0:
        y1 = min(float(height - 1), y0 + 1.0)
    return [ClusterBox("cluster_fallback_001", (x0, y0, x1, y1), 0.0, "point_envelope_fallback")], True


def matched_boxes(predicted: list[ClusterBox], truth: list[ClusterBox], threshold: float = 0.5):
    if not predicted or not truth:
        return [], list(range(len(predicted))), list(range(len(truth)))
    matrix = np.asarray([
        [box_iou(np.asarray(p.bbox_xyxy), np.asarray(t.bbox_xyxy)) for t in truth]
        for p in predicted
    ], dtype=np.float64)
    pi, ti = linear_sum_assignment(-matrix)
    pairs = [(int(i), int(j), float(matrix[i, j])) for i, j in zip(pi, ti) if matrix[i, j] >= threshold]
    used_p = {i for i, _, _ in pairs}
    used_t = {j for _, j, _ in pairs}
    return pairs, [i for i in range(len(predicted)) if i not in used_p], [j for j in range(len(truth)) if j not in used_t]


def owner_indices(points: np.ndarray, boxes: list[ClusterBox], image_size: tuple[int, int]) -> np.ndarray:
    assigned = assign_berries_to_cluster_boxes(points, boxes, image_size=image_size)
    index = {box.cluster_id: i for i, box in enumerate(boxes)}
    result = np.asarray([index[item["cluster_id"]] for item in assigned["assignments"]], dtype=np.int64)
    if len(result) != len(points):
        raise RuntimeError("ownership length mismatch")
    return result


def strict_candidate_owner(points: np.ndarray, boxes: list[ClusterBox]) -> np.ndarray:
    """Containment-only owner; outside-box candidates cannot affect quotas."""
    owner = np.full(len(points), -1, dtype=np.int64)
    for point_index, point in enumerate(points):
        containing = []
        for box_index, box in enumerate(boxes):
            x0, y0, x1, y1 = box.bbox_xyxy
            if x0 <= point[0] <= x1 and y0 <= point[1] <= y1:
                cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
                hx, hy = max((x1 - x0) / 2, 1.0), max((y1 - y0) / 2, 1.0)
                cost = ((point[0] - cx) / hx) ** 2 + ((point[1] - cy) / hy) ** 2
                containing.append((cost, -box.confidence, box_index))
        if containing:
            owner[point_index] = min(containing)[2]
    return owner


def largest_remainder(values: np.ndarray, total: int, eligible: np.ndarray) -> np.ndarray:
    values = np.maximum(np.asarray(values, dtype=np.float64), 0.0)
    eligible = np.asarray(eligible, dtype=bool)
    result = np.zeros(len(values), dtype=np.int64)
    if total <= 0 or not len(values):
        return result
    active = np.flatnonzero(eligible)
    if not len(active):
        active = np.arange(len(values))
    # Give a detected bunch one point when the whole-image count permits it.
    if total >= len(active):
        result[active] = 1
        remaining = total - len(active)
    else:
        order = active[np.argsort(-values[active], kind="stable")]
        result[order[:total]] = 1
        return result
    if remaining == 0:
        return result
    weights = values[active]
    if float(weights.sum()) <= 0:
        weights = np.ones_like(weights)
    scaled = weights / weights.sum() * remaining
    floor = np.floor(scaled).astype(np.int64)
    result[active] += floor
    left = remaining - int(floor.sum())
    if left:
        fraction = scaled - floor
        order = active[np.argsort(-fraction, kind="stable")]
        result[order[:left]] += 1
    if int(result.sum()) != total:
        raise RuntimeError("largest-remainder conservation failed")
    return result


def capped_target(current: np.ndarray, desired: np.ndarray, cap: int) -> np.ndarray:
    target = current.astype(np.int64).copy()
    donors = [[int(i), int(current[i] - desired[i])] for i in np.flatnonzero(current > desired)]
    receivers = [[int(i), int(desired[i] - current[i])] for i in np.flatnonzero(desired > current)]
    donors.sort(key=lambda row: (-row[1], row[0]))
    receivers.sort(key=lambda row: (-row[1], row[0]))
    moved = 0
    di = ri = 0
    while moved < cap and di < len(donors) and ri < len(receivers):
        donor, dleft = donors[di]
        receiver, rleft = receivers[ri]
        amount = min(dleft, rleft, cap - moved)
        target[donor] -= amount
        target[receiver] += amount
        moved += amount
        donors[di][1] -= amount
        receivers[ri][1] -= amount
        if donors[di][1] == 0:
            di += 1
        if receivers[ri][1] == 0:
            ri += 1
    if int(target.sum()) != int(current.sum()):
        raise RuntimeError("capped target changed total")
    return target


def nearest_candidate_support(points: np.ndarray, candidates: np.ndarray, scores: np.ndarray, scale: float) -> np.ndarray:
    if not len(points) or not len(candidates):
        return np.zeros(len(points), dtype=np.float64)
    tree = cKDTree(candidates)
    distance, nearest = tree.query(points)
    support = scores[nearest].astype(np.float64)
    support[distance * scale > 8.0] = 0.0
    return support


def realization(
    points: np.ndarray,
    reliability: np.ndarray,
    boxes: list[ClusterBox],
    candidates: np.ndarray,
    scores: np.ndarray,
    candidate_owner: np.ndarray,
    target: np.ndarray,
    image_size: tuple[int, int],
    config: Config,
) -> tuple[np.ndarray, np.ndarray, dict]:
    width, height = image_size
    scale = 1024.0 / max(width, height)
    owners = owner_indices(points, boxes, image_size)
    current = np.bincount(owners, minlength=len(boxes))
    support = nearest_candidate_support(points, candidates, scores, scale)
    if len(reliability) != len(points):
        reliability = np.full(len(points), 0.5, dtype=np.float64)
    else:
        reliability = np.asarray(reliability, dtype=np.float64)
    if config.removal == "reliability":
        removal_support = reliability
    elif config.removal == "hybrid_support":
        # Rank-normalized evidence avoids mixing incomparable score scales.
        def ranks(values: np.ndarray) -> np.ndarray:
            order = np.argsort(values, kind="stable")
            rank = np.empty(len(values), dtype=np.float64)
            rank[order] = np.linspace(0.0, 1.0, len(values), endpoint=True) if len(values) > 1 else 1.0
            return rank
        removal_support = 0.6 * ranks(reliability) + 0.4 * ranks(support)
    else:
        raise ValueError(config.removal)

    keep = np.ones(len(points), dtype=bool)
    removed_by_box = np.zeros(len(boxes), dtype=np.int64)
    for box_index in range(len(boxes)):
        need = int(current[box_index] - target[box_index])
        if need <= 0:
            continue
        members = np.flatnonzero(owners == box_index)
        order = members[np.argsort(removal_support[members], kind="stable")]
        keep[order[:need]] = False
        removed_by_box[box_index] = need

    kept = points[keep].copy()
    kept_rel = reliability[keep].copy()
    kept_owner = owners[keep].copy()
    additions: list[np.ndarray] = []
    addition_scores: list[float] = []
    addition_owner: list[int] = []
    failed = False
    radius_native = config.nms_radius_1024 / scale
    for box_index in range(len(boxes)):
        have = int(np.count_nonzero(kept_owner == box_index)) + addition_owner.count(box_index)
        need = int(target[box_index] - have)
        if need <= 0:
            continue
        available = np.flatnonzero((candidate_owner == box_index) & (scores >= config.score_threshold))
        available = available[np.argsort(-scores[available], kind="stable")]
        existing = kept[kept_owner == box_index]
        if addition_owner:
            extra = np.asarray([p for p, owner in zip(additions, addition_owner) if owner == box_index], dtype=np.float64).reshape(-1, 2)
            if len(extra):
                existing = np.vstack([existing, extra]) if len(existing) else extra
        accepted = 0
        for candidate_index in available:
            point = candidates[candidate_index]
            if len(existing) and float(np.min(np.linalg.norm(existing - point, axis=1))) < radius_native:
                continue
            additions.append(point.copy())
            addition_scores.append(float(scores[candidate_index]))
            addition_owner.append(box_index)
            existing = np.vstack([existing, point]) if len(existing) else point[None]
            accepted += 1
            if accepted == need:
                break
        if accepted < need:
            failed = True
            break

    if failed or len(additions) != int(np.count_nonzero(~keep)):
        return points.copy(), reliability.copy(), {"applied": False, "reason": "insufficient_nonduplicate_candidates", "transfers": 0}
    result = np.vstack([kept, np.asarray(additions, dtype=np.float64).reshape(-1, 2)]) if additions else kept
    result_reliability = np.concatenate([kept_rel, np.asarray(addition_scores, dtype=np.float64)])
    if len(result) != len(points) or np.any(result < 0) or np.any(result >= [width, height]):
        raise RuntimeError("realized points violate invariants")
    # Verify that realization actually reaches the intended quotas.
    actual_owner = owner_indices(result, boxes, image_size)
    actual = np.bincount(actual_owner, minlength=len(boxes))
    if not np.array_equal(actual, target):
        raise RuntimeError(f"realized quota mismatch: {actual.tolist()} != {target.tolist()}")
    return result, result_reliability, {
        "applied": True,
        "reason": "cluster_aware_count_conserving_transfer",
        "transfers": int(len(additions)),
        "removed_by_box": removed_by_box.tolist(),
        "added_by_box": np.bincount(np.asarray(addition_owner, dtype=np.int64), minlength=len(boxes)).tolist(),
    }


def point_metrics(prediction: np.ndarray, truth: np.ndarray, width: int, height: int) -> dict:
    scale = 1024.0 / max(width, height)
    pred = prediction * scale
    target = truth * scale
    result = {}
    for radius in (4.0, 8.0, 16.0):
        tp, fp, fn = maximum_cardinality_point_matches(pred, target, radius)
        result[str(int(radius))] = {"tp": tp, "fp": fp, "fn": fn}
    if len(pred) and len(target):
        pred_distance = cKDTree(target).query(pred)[0]
        truth_distance = cKDTree(pred).query(target)[0]
    else:
        pred_distance = np.full(len(pred), 32.0)
        truth_distance = np.full(len(target), 32.0)
    result["symmetric_clipped_32"] = 0.5 * (
        float(np.minimum(pred_distance, 32.0).mean()) if len(pred_distance) else 32.0
    ) + 0.5 * (
        float(np.minimum(truth_distance, 32.0).mean()) if len(truth_distance) else 32.0
    )
    return result


def cluster_metrics(
    points: np.ndarray,
    pred_boxes: list[ClusterBox],
    truth_points: np.ndarray,
    truth_boxes: list[ClusterBox],
    truth_meta: list[dict],
    image_size: tuple[int, int],
) -> dict:
    pred_owner = owner_indices(points, pred_boxes, image_size) if pred_boxes else np.empty(0, dtype=np.int64)
    truth_owner = owner_indices(truth_points, truth_boxes, image_size) if truth_boxes else np.empty(0, dtype=np.int64)
    pred_counts = np.bincount(pred_owner, minlength=len(pred_boxes))
    truth_counts = np.bincount(truth_owner, minlength=len(truth_boxes))
    pairs, fp, fn = matched_boxes(pred_boxes, truth_boxes)
    matched_error = int(sum(abs(int(pred_counts[i]) - int(truth_counts[j])) for i, j, _ in pairs))
    full_error = matched_error + int(sum(pred_counts[i] for i in fp)) + int(sum(truth_counts[j] for j in fn))
    undercount = int(sum(max(int(truth_counts[j]) - int(pred_counts[i]), 0) for i, j, _ in pairs))
    overcount = int(sum(max(int(pred_counts[i]) - int(truth_counts[j]), 0) for i, j, _ in pairs))
    small_error = int(sum(abs(int(pred_counts[i]) - int(truth_counts[j])) for i, j, _ in pairs if truth_meta[j].get("small", False)))
    border_error = int(sum(abs(int(pred_counts[i]) - int(truth_counts[j])) for i, j, _ in pairs if truth_meta[j].get("border", False)))
    exact = int(sum(int(pred_counts[i]) == int(truth_counts[j]) for i, j, _ in pairs))
    return {
        "counts": pred_counts.tolist(),
        "truth_counts": truth_counts.tolist(),
        "pairs": [[i, j, iou] for i, j, iou in pairs],
        "matched_error": matched_error,
        "full_error": full_error,
        "undercount": undercount,
        "overcount": overcount,
        "small_error": small_error,
        "border_error": border_error,
        "exact_matched": exact,
        "matched_boxes": len(pairs),
    }


def aggregate(rows: list[dict], key: str) -> dict:
    result: dict[str, object] = {"images": len(rows)}
    for section in ("cluster", "point"):
        baseline = section == "cluster"
        if baseline:
            names = ("matched_error", "full_error", "undercount", "overcount", "small_error", "border_error", "exact_matched", "matched_boxes")
            result[section] = {name: int(sum(row[key][section][name] for row in rows)) for name in names}
        else:
            radii = {}
            for radius in ("4", "8", "16"):
                tp = int(sum(row[key][section][radius]["tp"] for row in rows))
                fp = int(sum(row[key][section][radius]["fp"] for row in rows))
                fn = int(sum(row[key][section][radius]["fn"] for row in rows))
                f1 = 2 * tp / max(2 * tp + fp + fn, 1)
                radii[radius] = {"tp": tp, "fp": fp, "fn": fn, "f1": float(f1)}
            result[section] = {
                "radii": radii,
                "symmetric_clipped_32": float(np.mean([row[key][section]["symmetric_clipped_32"] for row in rows])),
            }
    result["applied_images"] = int(sum(row[key]["repair"]["applied"] for row in rows))
    result["transfers"] = int(sum(row[key]["repair"]["transfers"] for row in rows))
    result["count_conserved"] = all(row[key]["count"] == row["baseline"]["count"] for row in rows)
    return result


def bootstrap(rows: list[dict], candidate_key: str) -> dict:
    grouped: dict[str, list[np.ndarray]] = defaultdict(list)
    for row in rows:
        base = row["baseline"]["cluster"]
        cand = row[candidate_key]["cluster"]
        grouped[row["group"]].append(np.asarray([
            base["full_error"] - cand["full_error"],
            base["matched_error"] - cand["matched_error"],
            base["undercount"] - cand["undercount"],
            cand["exact_matched"] - base["exact_matched"],
        ], dtype=np.float64))
    sums = np.asarray([np.sum(values, axis=0) for values in grouped.values()])
    sizes = np.asarray([len(values) for values in grouped.values()], dtype=np.int64)
    rng = np.random.default_rng(SEED)
    draw = rng.integers(0, len(sizes), (BOOTSTRAP_REPLICATES, len(sizes)))
    distribution = sums[draw].sum(axis=1) / sizes[draw].sum(axis=1)[:, None]
    interval = np.percentile(distribution, [2.5, 97.5], axis=0)
    names = ("full_error_per_image", "matched_error_per_image", "undercount_per_image", "exact_matched_per_image")
    return {
        "capture_groups": len(sizes),
        "replicates": BOOTSTRAP_REPLICATES,
        "seed": SEED,
        "endpoints": {
            name: {
                "mean_improvement": float(sums[:, index].sum() / sizes.sum()),
                "percentile_95_ci": interval[:, index].tolist(),
            }
            for index, name in enumerate(names)
        },
    }


def load_candidates(index: list[dict], manifest: dict[str, dict]) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    grouped: dict[str, list[dict]] = defaultdict(list)
    for item in index:
        grouped[item["sample_id"]].append(item)
    result = {}
    for sample_index, (sample_id, items) in enumerate(grouped.items(), start=1):
        record = manifest[sample_id]
        tiles = {tile.tile_id: tile for tile in make_core_halo_tiles(
            int(record["width"]), int(record["height"]), core_size=CORE_SIZE, halo=HALO
        )}
        point_parts, score_parts = [], []
        for item in sorted(items, key=lambda value: value["tile_id"]):
            with np.load(CANDIDATE_ROOT / item["file"], allow_pickle=False) as payload:
                points = np.asarray(payload["candidate_native_xy"], dtype=np.float64)
                scores = np.asarray(payload["candidate_scores"], dtype=np.float64)
            tile = tiles[int(item["tile_id"])]
            owned = np.asarray([tile.owns(float(x), float(y)) for x, y in points], dtype=bool)
            point_parts.append(points[owned])
            score_parts.append(scores[owned])
        result[sample_id] = (
            np.concatenate(point_parts, axis=0) if point_parts else np.empty((0, 2)),
            np.concatenate(score_parts, axis=0) if score_parts else np.empty(0),
        )
        if sample_index % 30 == 0 or sample_index == len(grouped):
            print(f"loaded candidate pools {sample_index}/{len(grouped)}", flush=True)
    return result


def evaluate_config(base_rows: list[dict], config: Config) -> list[dict]:
    rows = []
    for base in base_rows:
        points = base["points"]
        owners = owner_indices(points, base["pred_boxes"], base["image_size"])
        current = np.bincount(owners, minlength=len(base["pred_boxes"]))
        strong = base["candidate_scores"] >= config.score_threshold
        signal = np.bincount(base["candidate_owner"][strong], minlength=len(base["pred_boxes"])) if np.any(strong) else np.zeros(len(base["pred_boxes"]), dtype=np.int64)
        eligible = signal > 0
        raw = largest_remainder(signal.astype(np.float64), len(points), eligible)
        blended = largest_remainder(
            (1.0 - config.blend) * current + config.blend * raw,
            len(points),
            np.ones(len(current), dtype=bool),
        )
        l1 = int(np.abs(raw - current).sum())
        if not base["repair_allowed"] or len(base["pred_boxes"]) < 2 or l1 < config.movement_l1_gate:
            result_points = points.copy()
            result_rel = base["reliability"].copy()
            repair = {"applied": False, "reason": "gate_closed", "transfers": 0}
        else:
            target = capped_target(current, blended, config.max_transfers)
            if np.array_equal(target, current):
                result_points = points.copy()
                result_rel = base["reliability"].copy()
                repair = {"applied": False, "reason": "zero_capped_transfer", "transfers": 0}
            else:
                result_points, result_rel, repair = realization(
                    points, base["reliability"], base["pred_boxes"],
                    base["candidates"], base["candidate_scores"], base["candidate_owner"],
                    target, base["image_size"], config,
                )
        candidate_cluster = cluster_metrics(
            result_points, base["pred_boxes"], base["truth"], base["truth_boxes"],
            base["truth_meta"], base["image_size"],
        )
        candidate_point = point_metrics(result_points, base["truth"], *base["image_size"])
        rows.append({
            "sample_id": base["sample_id"],
            "group": base["group"],
            "baseline": base["baseline"],
            "candidate": {
                "count": int(len(result_points)),
                "cluster": candidate_cluster,
                "point": candidate_point,
                "repair": {**repair, "raw_l1": l1, "current_counts": current.tolist(), "raw_counts": raw.tolist()},
            },
            "result_points": result_points,
            "result_reliability": result_rel,
            "truth": base["truth"],
        })
    return rows


def gains(baseline: dict, candidate: dict, rows: list[dict]) -> dict:
    cluster_names = ("full_error", "matched_error", "undercount", "overcount", "small_error", "border_error")
    result = {
        name: int(baseline["cluster"][name] - candidate["cluster"][name])
        for name in cluster_names
    }
    result["exact_matched"] = int(candidate["cluster"]["exact_matched"] - baseline["cluster"]["exact_matched"])
    for radius in ("4", "8", "16"):
        result[f"f1_{radius}"] = candidate["point"]["radii"][radius]["f1"] - baseline["point"]["radii"][radius]["f1"]
        result[f"tp_{radius}"] = candidate["point"]["radii"][radius]["tp"] - baseline["point"]["radii"][radius]["tp"]
    result["symmetric_error_reduction"] = baseline["point"]["symmetric_clipped_32"] - candidate["point"]["symmetric_clipped_32"]
    result["improved_images"] = sum(row["baseline"]["cluster"]["full_error"] > row["candidate"]["cluster"]["full_error"] for row in rows)
    result["worsened_images"] = sum(row["baseline"]["cluster"]["full_error"] < row["candidate"]["cluster"]["full_error"] for row in rows)
    result["unchanged_images"] = len(rows) - result["improved_images"] - result["worsened_images"]
    return result


def main() -> None:
    if OUT.exists():
        raise SystemExit(f"refusing to overwrite existing experiment: {OUT}")
    OUT.mkdir(parents=True)
    protocol = {
        "version": "vivid-cluster-aware-point-reallocation-v1",
        "status": "OPEN_DEVELOPMENT_ENGINEERING",
        "purpose": "stably reduce per-bunch starvation while conserving frozen whole-image CRU count",
        "inference_uses_labels": False,
        "configuration_grid": [asdict(config) for config in CONFIGS],
        "selection_gate": {
            "full_cluster_error_reduction_positive": True,
            "paired_group_bootstrap_full_error_lower_bound_positive": True,
            "matched_error_reduction_positive": True,
            "improved_images_at_least_worsened": True,
            "f1_4_8_16_non_decrease": True,
            "symmetric_clipped_error_non_increase": True,
            "whole_image_count_conserved": True,
        },
        "development_images": 153,
        "example_used_only_for_post_selection_reporting": EXAMPLE_ID,
        "router_b_used": False,
        "sealed_test_used": False,
        "input_hashes": {
            str(path): sha256(path)
            for path in (MANIFEST, PROPOSALS, CANDIDATE_ROOT / "protocol.json", CANDIDATE_ROOT / "index.json", Path(__file__))
        },
    }
    atomic_json(OUT / "protocol.json", protocol)

    manifest = {row["sample_id"]: row for row in read_rows(MANIFEST)}
    proposals = {row["sample_id"]: row for row in read_rows(PROPOSALS)}
    if set(manifest) != set(proposals) or len(manifest) != 153:
        raise RuntimeError("development inputs do not describe the same 153 images")
    candidate_index = json.loads((CANDIDATE_ROOT / "index.json").read_text(encoding="utf-8"))
    candidate_pools = load_candidates(candidate_index, manifest)

    base_rows = []
    for image_index, sample_id in enumerate(sorted(manifest), start=1):
        record = manifest[sample_id]
        row = proposals[sample_id]
        with np.load(BASE_POINTS / f"{sample_id.replace(':', '_')}.npz", allow_pickle=False) as payload:
            points = np.asarray(payload["cru"], dtype=np.float64)
            truth = np.asarray(payload["truth"], dtype=np.float64)
            reliability = np.asarray(payload["reliability"], dtype=np.float64)
        pred_boxes = make_boxes(row, "proposals")
        truth_boxes = make_boxes(row, "truth")
        image_size = (int(record["width"]), int(record["height"]))
        pred_boxes, synthetic = ensure_evaluation_box(points, pred_boxes, image_size)
        candidates, candidate_scores = candidate_pools[sample_id]
        candidate_owner = strict_candidate_owner(candidates, pred_boxes)
        inside = candidate_owner >= 0
        candidates = candidates[inside]
        candidate_scores = candidate_scores[inside]
        candidate_owner = candidate_owner[inside]
        base_cluster = cluster_metrics(points, pred_boxes, truth, truth_boxes, row["truth"], image_size)
        base_point = point_metrics(points, truth, *image_size)
        base_rows.append({
            "sample_id": sample_id,
            "group": str(record["capture_group_id"]),
            "image_size": image_size,
            "points": points,
            "truth": truth,
            "reliability": reliability,
            "pred_boxes": pred_boxes,
            "repair_allowed": not synthetic,
            "truth_boxes": truth_boxes,
            "truth_meta": row["truth"],
            "candidates": candidates,
            "candidate_scores": candidate_scores,
            "candidate_owner": candidate_owner,
            "baseline": {"count": int(len(points)), "cluster": base_cluster, "point": base_point, "repair": {"applied": False, "transfers": 0}},
        })
        if image_index % 30 == 0 or image_index == len(manifest):
            print(f"prepared images {image_index}/{len(manifest)}", flush=True)

    baseline = aggregate([{"baseline": row["baseline"]} for row in base_rows], "baseline")
    screening = []
    selected_payload = None
    for config_index, config in enumerate(CONFIGS, start=1):
        rows = evaluate_config(base_rows, config)
        candidate = aggregate(rows, "candidate")
        delta = gains(baseline, candidate, rows)
        interval = bootstrap(rows, "candidate")
        lower = interval["endpoints"]["full_error_per_image"]["percentile_95_ci"][0]
        eligible = (
            delta["full_error"] > 0
            and lower > 0
            and delta["matched_error"] > 0
            and delta["improved_images"] >= delta["worsened_images"]
            and delta["f1_4"] >= 0
            and delta["f1_8"] >= 0
            and delta["f1_16"] >= 0
            and delta["symmetric_error_reduction"] >= 0
            and candidate["count_conserved"]
        )
        item = {
            "config": asdict(config),
            "name": config.name,
            "candidate": candidate,
            "gains": delta,
            "paired_group_bootstrap": interval,
            "eligible": bool(eligible),
        }
        screening.append(item)
        if eligible:
            key = (delta["full_error"], delta["matched_error"], delta["undercount"], delta["f1_4"], delta["f1_8"])
            if selected_payload is None or key > selected_payload[0]:
                selected_payload = (key, config, rows, item)
        if config_index % 24 == 0 or config_index == len(CONFIGS):
            print(f"screened configurations {config_index}/{len(CONFIGS)}", flush=True)

    summary = {
        "status": "COMPLETE_NO_STABLE_CANDIDATE" if selected_payload is None else "COMPLETE_STABLE_CANDIDATE_SELECTED",
        "baseline": baseline,
        "configuration_count": len(CONFIGS),
        "eligible_count": int(sum(item["eligible"] for item in screening)),
        "selection_role": "open development engineering; not independent confirmation",
        "whole_image_count_is_frozen": True,
        "router_b_used": False,
        "sealed_test_used": False,
    }
    if selected_payload is not None:
        _, selected_config, selected_rows, selected = selected_payload
        points_dir = OUT / "selected_points"
        report_rows = []
        for row in selected_rows:
            atomic_npz(
                points_dir / f"{row['sample_id'].replace(':', '_')}.npz",
                cru=np.asarray(row["result_points"], dtype=np.float32),
                truth=np.asarray(row["truth"], dtype=np.float32),
                reliability=np.asarray(row["result_reliability"], dtype=np.float32),
            )
            report_rows.append({key: value for key, value in row.items() if key not in ("result_points", "result_reliability", "truth")})
        example = next(row for row in report_rows if row["sample_id"] == EXAMPLE_ID)
        summary.update({
            "selected": selected,
            "example_after_selection": example,
            "selected_point_cache": str(points_dir.resolve()),
            "selected_point_files": len(list(points_dir.glob("*.npz"))),
        })
        atomic_json(OUT / "selected_per_image.json", report_rows)
    atomic_json(OUT / "screening.json", screening)
    atomic_json(OUT / "summary.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
