"""Development-only geometry/sampling and fixed-checkpoint error diagnosis."""
import argparse
from collections import Counter, defaultdict
import json
import os
from pathlib import Path
import time

import numpy as np
from PIL import Image, ImageDraw, ImageOps
import torch
from torch.utils.data import DataLoader

from audit_cru_detail_readiness import read_json, read_rows, save_json, sha
from train_vivid_detail_trial import verify_protocol, make_model, make_loader
from vivid_detail_runtime import safe_load
from diagnose_vivid_hr_calibration import predictions_at
from geopriv.data import PrivilegedManifestDataset, collate_privileged_samples
from geopriv.models import decode_points
from geopriv.metrics import maximum_cardinality_point_matches, aggregate_count_metrics
from geopriv.routing import make_core_halo_tiles


def source_proxy(sample_id):
    n=sample_id.split(':',1)[-1].lower()
    return ('immature' if n.startswith('immature') else 'phone_timestamp' if n.startswith('img_20')
        else 'img_camera' if n.startswith('img') else 'dsc_camera' if 'dsc' in n
        else 'numeric' if n.isdigit() else 'other')


def inside(points, box):
    p=np.asarray(points).reshape(-1,2)
    x0,y0,x1,y1=box
    return (p[:,0]>=x0)&(p[:,0]<x1)&(p[:,1]>=y0)&(p[:,1]<y1)


def geometry_audit(protocol):
    root=Path(protocol['root']); groups=defaultdict(Counter); summary=Counter()
    for row in read_rows(protocol['manifest']):
        pts=np.load(root/row['points_path'],allow_pickle=False)
        tiles=make_core_halo_tiles(row['width'],row['height'],core_size=1024,halo=128)
        owned=np.zeros(len(pts),int)
        group=groups[row['split']+':'+source_proxy(row['sample_id'])]
        group['images']+=1;group['points']+=len(pts);group['tiles']+=len(tiles)
        for tile in tiles:
            core=inside(pts,(tile.core_x0,tile.core_y0,tile.core_x1,tile.core_y1)); owned+=core
            context=inside(pts,(tile.context_x0,tile.context_y0,tile.context_x1,tile.context_y1))
            group['empty_context_tiles']+=int(not context.any())
            group['empty_core_tiles']+=int(not core.any())
            group['context_point_exposures']+=int(context.sum())
        summary['images']+=1;summary['points']+=len(pts)
        summary['not_exactly_one_core']+=int((owned!=1).sum())
    rows={k:dict(v) for k,v in groups.items()}
    return dict(summary=dict(summary),groups=rows,
        caveat='Filename family is a source proxy, not a cultivar or independent domain. Empty annotations do not certify no visible unlabelled fruit.')


def render(raw, truth, pred, path, title):
    small=ImageOps.contain(raw,(700,650)); scale=np.array([small.width/raw.width,small.height/raw.height])
    canvas=Image.new('RGB',(2160,730),'white'); draw=ImageDraw.Draw(canvas)
    draw.text((10,5),title,fill='black')
    for i,(name,points,color) in enumerate([('RAW',[],None),('ANNOTATED CENTRES',truth,'cyan'),('PREDICTIONS',pred,'red')]):
        panel=small.copy();d=ImageDraw.Draw(panel)
        for x,y in np.asarray(points).reshape(-1,2)*scale:
            d.ellipse((x-2,y-2,x+2,y+2),outline=color,width=2)
        canvas.paste(panel,(i*720+10,55));draw.text((i*720+10,30),name,fill='black')
    path.parent.mkdir(parents=True,exist_ok=True);canvas.save(path)


def summarize(rows):
    metrics=aggregate_count_metrics([r['pred'] for r in rows],[r['truth'] for r in rows])
    totals={k:sum(r[k] for r in rows) for k in ('tp','fp','fn','outside_gt_boxes','points_in_empty_cores')}
    totals.update(precision=totals['tp']/max(1,totals['tp']+totals['fp']),recall=totals['tp']/max(1,totals['tp']+totals['fn']))
    return dict(metrics=metrics,totals=totals,n=len(rows))


@torch.inference_mode()
def diagnose(protocol, source, out, name, checkpoint, old, boxmap):
    targetfile=out/(name+'.json')
    if targetfile.exists(): return read_json(targetfile)
    model=make_model(protocol,'control')
    if name!='lr': model.load_state_dict(safe_load(checkpoint)['model'])
    model.eval(); threshold=old['selected']['threshold']; expected=predictions_at(old,threshold)
    if name=='lr':
        ds=PrivilegedManifestDataset(protocol['manifest'],protocol['root'],split='val',image_size=1024,augmentation=False)
        loader=DataLoader(ds,batch_size=1,collate_fn=collate_privileged_samples)
    else: ds,loader,_=make_loader(protocol,'val')
    records={r.sample_id:r for r in ds.records}; cache=defaultdict(list); empty=Counter()
    for index,batch in enumerate(loader):
        outputs=model(batch['images'].cuda(),batch['valid_image_masks'].cuda())
        preds=decode_points(outputs,score_threshold=threshold,topk=4096,local_max_kernel=3,output_stride=2)
        for pred,target in zip(preds,batch['targets'],strict=True):
            points=pred['points'].cpu().numpy(); ident=target['sample_id']
            if name!='lr':
                points=points[inside(points,target['core_bounds_xyxy'].numpy())]
                if not len(target['core_points_xy']): empty[ident]+=len(points)
            affine=target['inverse_affine'].numpy()
            raw=(np.column_stack([points,np.ones(len(points))])@affine.T)[:,:2]
            if name!='lr':raw+=target['context_origin_xy'].numpy()
            cache[ident].append(raw)
        if index%30==0:save_json(out/'progress.json',dict(status='RUNNING',arm=name,batch=index+1,total=len(loader)))
    rows=[]
    for ident in sorted(cache):
        record=records[ident]; pred=np.concatenate(cache[ident]);truth=np.load(Path(protocol['root'])/record.points_path,allow_pickle=False)
        if (len(truth),len(pred))!=expected[ident]:raise ValueError('count replay mismatch: '+ident)
        scale=1024/max(record.width,record.height)
        tp,fp,fn=maximum_cardinality_point_matches(pred*scale,truth*scale,8.)
        contained=np.zeros(len(pred),bool)
        for b in boxmap[ident]['boxes']:contained|=inside(pred,b['bbox_xyxy'])
        rows.append(dict(sample_id=ident,truth=len(truth),pred=len(pred),error=len(pred)-len(truth),
            tp=tp,fp=fp,fn=fn,outside_gt_boxes=int((~contained).sum()),points_in_empty_cores=empty[ident],
            source_proxy=source_proxy(ident)))
        folder=out/'points'/name;folder.mkdir(parents=True,exist_ok=True)
        np.savez_compressed(folder/(ident.replace(':','_')+'.npz'),pred=pred,truth=truth)
    grouped={g:summarize([r for r in rows if r['source_proxy']==g]) for g in sorted({r['source_proxy'] for r in rows})}
    selected=sorted(rows,key=lambda r:abs(r['error']),reverse=True)[:3]
    for row in selected:
        record=records[row['sample_id']]
        with Image.open(Path(protocol['root'])/record.image_path) as image:raw=ImageOps.exif_transpose(image).convert('RGB')
        points=np.load(out/'points'/name/(row['sample_id'].replace(':','_')+'.npz'))
        render(raw,points['truth'],points['pred'],out/'previews'/name/(row['sample_id'].replace(':','_')+'.png'),
            f"{name}: {row['sample_id']} GT={row['truth']} PRED={row['pred']} error={row['error']}")
    report=dict(**summarize(rows),grouped=grouped,rows=rows,threshold=threshold,count_replay_exact=True,
        scope='development only; 8px at common 1024 scale for all models; outside GT boxes is diagnostic, not proof every such point is non-fruit')
    save_json(targetfile,report);print(json.dumps(dict(arm=name,**summarize(rows))),flush=True)
    del model,loader,ds;torch.cuda.empty_cache()
    return report


def main():
    p=argparse.ArgumentParser();p.add_argument('--trial',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--mode',choices=['cpu','points'],required=True);args=p.parse_args()
    source=args.trial.resolve();out=args.output.resolve();protocol=verify_protocol(source)
    out.mkdir(parents=True,exist_ok=True)
    if args.mode=='cpu':
        report=geometry_audit(protocol);save_json(out/'geometry_sampling.json',report);print(json.dumps(report));return
    # Do not compete with the active training worker. It stops at an epoch boundary.
    if read_json(source/'stage.json')['status'] not in ('PAUSED_AFTER_EPOCH','FULL_ADAPTATION_COMPLETE_REVIEW_REQUIRED'):
        raise ValueError('wait for saved epoch boundary before GPU diagnosis')
    snapshots=dict(lr=source/'lr_initial.pt',hr_best=source/'control/best_val_mae.pt',hr_last=source/'control/last.pt')
    boxpath=source.parent/'vivid_only_v1/cluster_boxes.jsonl'
    contract=dict(source_protocol=sha(source/'protocol.json'),script=sha(Path(__file__)),
        checkpoints={k:sha(v) for k,v in snapshots.items()},boxes=sha(boxpath),test_used=False,
        matching='maximum cardinality,8 pixels at common full-image long edge1024',weight_updates=False)
    if (out/'protocol.json').exists() and read_json(out/'protocol.json')!=contract:raise ValueError('diagnosis drift')
    save_json(out/'protocol.json',contract)
    os.environ['CUBLAS_WORKSPACE_CONFIG']=':4096:8';torch.set_num_threads(4)
    torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True;torch.use_deterministic_algorithms(True)
    boxmap={r['sample_id']:r for r in read_rows(boxpath)};results={}
    for name,checkpoint in snapshots.items():
        if name=='lr':old=read_json(source/'lr_baseline.json')
        else:old=read_json(source/'control'/f"validation_epoch_{safe_load(checkpoint)['epoch']:02d}.json")
        results[name]=diagnose(protocol,source,out,name,checkpoint,old,boxmap)
    save_json(out/'summary.json',dict(status='COMPLETE',results={k:{x:r[x] for x in ('metrics','totals','grouped')} for k,r in results.items()},
        test_used=False,weight_updates=False))
    save_json(out/'progress.json',dict(status='COMPLETE',test_used=False))


if __name__=='__main__':main()
