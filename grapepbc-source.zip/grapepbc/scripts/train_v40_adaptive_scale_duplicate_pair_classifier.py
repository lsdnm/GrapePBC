"""Train a group-OOF scale-adaptive duplicate-pair classifier.

The fixed six-pixel (at a 1024-pixel long side) gate misses visually obvious
duplicates on large near berries.  This experiment considers pairs out to 16
normalized pixels and describes their distance relative to neighbouring point
spacing.  It also requires a local Rich-HR midpoint candidate, so an accepted
pair can be collapsed to a plausible berry centre rather than to an arbitrary
midpoint.
"""
from __future__ import annotations

from collections import defaultdict
import json
from pathlib import Path
import sys

import joblib
import numpy as np
from scipy.spatial import cKDTree
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.model_selection import GroupKFold


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

import develop_v36_local_duplicate_merge as v36  # noqa: E402
from run_vivid_hr_core_calibration import atomic_json  # noqa: E402


OUT = PROJECT / "experiments" / "cru_detail_v1" / "vivid_adaptive_scale_duplicate_pair_oof_v40"
SEED = 20261004
MAX_PAIR_DISTANCE = 16.0
TRUTH_ASSOCIATION_RADIUS = 12.0

FEATURES = (
    "pair_distance", "min_reliability", "max_reliability", "reliability_gap",
    "min_semantic", "max_semantic", "semantic_gap",
    "min_support_distance", "max_support_distance",
    "min_candidate_score", "max_candidate_score", "same_nearest_candidate",
    "midpoint_candidate_distance", "midpoint_candidate_score",
    "min_next_spacing", "max_next_spacing", "distance_over_min_spacing",
    "distance_over_mean_spacing", "min_local8", "max_local8",
    "min_local12", "max_local12", "owner_points_log", "image_points_log",
)


def classifier(seed: int) -> ExtraTreesClassifier:
    return ExtraTreesClassifier(
        n_estimators=600, max_features="sqrt", min_samples_leaf=3,
        class_weight="balanced", random_state=seed, n_jobs=-1,
    )


def nearest_spacing_excluding(points_scaled: np.ndarray, first: int, second: int) -> tuple[float, float]:
    if len(points_scaled) <= 2:
        return 64.0, 64.0
    tree = cKDTree(points_scaled)
    result = []
    for anchor, other in ((first, second), (second, first)):
        _, indices = tree.query(points_scaled[anchor], k=min(8, len(points_scaled)))
        indices = np.atleast_1d(indices)
        value = 64.0
        for index in indices:
            if int(index) not in (anchor, other):
                value = float(np.linalg.norm(points_scaled[anchor] - points_scaled[int(index)]))
                break
        result.append(value)
    return result[0], result[1]


def midpoint_candidate(base: dict, first: int, second: int) -> tuple[int, float, float]:
    owner = int(base["owners"][first])
    indices = np.flatnonzero(base["candidate_owner"] == owner)
    if not len(indices):
        return -1, 64.0, 0.0
    midpoint = (base["points"][first] + base["points"][second]) / 2.0
    distance, local = cKDTree(base["candidates"][indices] * base["scale"]).query(midpoint * base["scale"])
    index = int(indices[int(local)])
    return index, float(distance), float(base["candidate_scores"][index])


def make_pairs(base: dict) -> list[dict]:
    points_scaled = base["points"] * base["scale"]
    truth_scaled = base["truth"] * base["scale"]
    truth_tree = cKDTree(truth_scaled) if len(truth_scaled) else None
    if truth_tree:
        truth_distance, nearest_truth = truth_tree.query(points_scaled)
    else:
        truth_distance = np.full(len(points_scaled), np.inf)
        nearest_truth = np.full(len(points_scaled), -1)
    nearest_candidate, support_distance, candidate_score = base["candidate_evidence"]
    rows = []
    for owner in np.unique(base["owners"]):
        members = np.flatnonzero(base["owners"] == owner)
        if len(members) < 2:
            continue
        for left, right in cKDTree(points_scaled[members]).query_pairs(MAX_PAIR_DISTANCE + 1e-6):
            first, second = int(members[left]), int(members[right])
            distance = float(np.linalg.norm(points_scaled[first] - points_scaled[second]))
            close_to_truth = max(truth_distance[first], truth_distance[second]) <= TRUTH_ASSOCIATION_RADIUS
            if not close_to_truth:
                continue
            label = int(nearest_truth[first] >= 0 and nearest_truth[first] == nearest_truth[second])
            first_spacing, second_spacing = nearest_spacing_excluding(points_scaled, first, second)
            midpoint_index, midpoint_distance, midpoint_score = midpoint_candidate(base, first, second)
            rel = sorted((float(base["reliability"][first]), float(base["reliability"][second])))
            semantic = sorted((float(base["semantic_score"][first]), float(base["semantic_score"][second])))
            support = sorted((float(support_distance[first]), float(support_distance[second])))
            scores = sorted((float(candidate_score[first]), float(candidate_score[second])))
            spacing = sorted((first_spacing, second_spacing))
            owner_count = int(np.count_nonzero(base["owners"] == owner))
            values = np.asarray((
                distance, rel[0], rel[1], rel[1] - rel[0],
                semantic[0], semantic[1], semantic[1] - semantic[0],
                support[0], support[1], scores[0], scores[1],
                float(nearest_candidate[first] >= 0 and nearest_candidate[first] == nearest_candidate[second]),
                midpoint_distance, midpoint_score, spacing[0], spacing[1],
                distance / max(spacing[0], 1e-3), distance / max(np.mean(spacing), 1e-3),
                min(base["local_counts"][8][first], base["local_counts"][8][second]),
                max(base["local_counts"][8][first], base["local_counts"][8][second]),
                min(base["local_counts"][12][first], base["local_counts"][12][second]),
                max(base["local_counts"][12][first], base["local_counts"][12][second]),
                np.log1p(owner_count), np.log1p(len(base["points"])),
            ), np.float32)
            if len(values) != len(FEATURES) or not np.isfinite(values).all():
                raise RuntimeError("invalid V40 pair feature")
            rows.append({
                "sample_id": base["sample_id"], "group": base["group"],
                "first": first, "second": second, "distance": distance,
                "target_candidate_index": midpoint_index,
                "label": label, "features": values,
            })
    return rows


def threshold_report(labels: np.ndarray, scores: np.ndarray) -> list[dict]:
    positives = int(labels.sum())
    reports = []
    for threshold in np.arange(0.50, 0.951, 0.025):
        selected = scores >= threshold
        tp = int(np.count_nonzero(selected & (labels == 1)))
        fp = int(np.count_nonzero(selected & (labels == 0)))
        reports.append({
            "threshold": float(round(threshold, 3)), "selected": int(selected.sum()),
            "true_positive": tp, "false_positive": fp,
            "precision": float(tp / max(tp + fp, 1)),
            "recall": float(tp / max(positives, 1)),
        })
    return reports


def main() -> None:
    if OUT.exists():
        raise SystemExit(f"refusing to overwrite existing experiment: {OUT}")
    OUT.mkdir(parents=True)
    bases, _, _ = v36.prepare()
    flat = []
    for number, base in enumerate(bases, start=1):
        flat.extend(make_pairs(base))
        if number % 30 == 0 or number == len(bases):
            print(f"pairs {number}/{len(bases)} total={len(flat)}", flush=True)
    x = np.stack([row["features"] for row in flat])
    y = np.asarray([row["label"] for row in flat], np.int64)
    groups = np.asarray([row["group"] for row in flat])
    oof = np.zeros(len(flat), np.float64)
    for fold, (train, held) in enumerate(GroupKFold(5).split(x, y, groups)):
        model = classifier(SEED + fold); model.fit(x[train], y[train])
        oof[held] = model.predict_proba(x[held])[:, 1]
        joblib.dump(model, OUT / f"fold_{fold}.joblib")
        print(f"trained fold {fold}: train={len(train)} held={len(held)}", flush=True)
    final = classifier(SEED + 99); final.fit(x, y); joblib.dump(final, OUT / "all_development.joblib")
    stored = [{
        "sample_id": row["sample_id"], "group": row["group"],
        "first": row["first"], "second": row["second"], "distance": row["distance"],
        "target_candidate_index": row["target_candidate_index"],
        "label": row["label"], "score": float(score),
        "features": {name: float(value) for name, value in zip(FEATURES, row["features"])},
    } for row, score in zip(flat, oof)]
    atomic_json(OUT / "oof_pair_scores.json", stored)
    reports = threshold_report(y, oof)
    eligible = [row for row in reports if row["selected"] >= 50 and row["precision"] >= 0.98]
    eligible.sort(key=lambda row: (row["recall"], row["precision"]), reverse=True)
    summary = {
        "status": "OOF_PAIR_MODEL_COMPLETE", "pairs": len(flat), "positives": int(y.sum()),
        "positive_rate": float(y.mean()), "feature_names": list(FEATURES),
        "thresholds": reports, "best_high_precision": eligible[0] if eligible else None,
        "maximum_pair_distance_1024": MAX_PAIR_DISTANCE,
        "truth_association_radius_1024": TRUTH_ASSOCIATION_RADIUS,
        "development_selected": True, "independent_confirmation": False,
        "sealed_test_used": False, "runtime_annotations": False,
    }
    atomic_json(OUT / "summary.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
