"""Repair one-berry/multiple-point conflicts on the frozen V29 development role.

This is an open-development engineering experiment.  The deployable rule is
label-free and conserves whole-image count, point order and final bunch owner.
Annotations are used only to screen a compact, predeclared policy grid and to
quantify whether visually duplicated hypotheses are reduced without degrading
point localization.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from scipy.spatial import cKDTree


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

from audit_vivid_error_taxonomy import match_indices  # noqa: E402
from develop_cluster_aware_point_reallocation import (  # noqa: E402
    ensure_evaluation_box,
    load_candidates,
    make_boxes,
    owner_indices,
    read_rows,
    strict_candidate_owner,
)
from geopriv.counting.one_berry_reconciliation import (  # noqa: E402
    OneBerryReconciliationPolicy,
    reconcile_one_berry_one_point,
)
from geopriv.metrics import maximum_cardinality_point_matches  # noqa: E402
from run_vivid_hr_core_calibration import atomic_json, atomic_npz  # noqa: E402


EXP = PROJECT / "experiments" / "cru_detail_v1"
MANIFEST = EXP / "vivid_application_lr_repair_inputs_v1" / "development_val_clean.jsonl"
PROPOSALS = EXP / "vivid_stage6_border_safe_zero_filter_v28b" / "development_proposals.jsonl"
POINTS = EXP / "vivid_v4_v17_hybrid_center_gate_v18" / "oof_development_points"
CANDIDATE_ROOT = EXP / "vivid_application_development_density_core_points_v2"
OUT = EXP / "vivid_one_berry_one_point_v30"
RADII = (4.0, 8.0, 16.0)
SEED = 20261004


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def configs() -> list[OneBerryReconciliationPolicy]:
    # The first pass is deliberately conservative.  Wider collision radii are
    # considered only when HR candidate ownership also says the two points
    # compete for one centre.
    return [
        OneBerryReconciliationPolicy(
            collision_radius_1024=collision,
            candidate_nms_radius_1024=nms,
            candidate_support_radius_1024=support,
            replacement_spacing_1024=spacing,
            replacement_score_threshold=threshold,
            replacement_margin=margin,
            maximum_moves=maximum,
            conflict_mode=mode,
        )
        for collision in (3.0, 4.0, 5.0, 6.0)
        for nms in (4.0,)
        for support in (6.0,)
        for spacing in (6.0, 8.0)
        for threshold in (0.075, 0.125)
        for margin in (0.0,)
        for maximum in (2,)
        for mode in ("shared_candidate", "shared_or_unsupported")
    ]


def f1(triple: np.ndarray) -> float:
    tp, fp, fn = triple
    return float(2 * tp / max(2 * tp + fp + fn, 1))


def point_stats(points: np.ndarray, truth: np.ndarray, image_size: tuple[int, int]) -> dict:
    scale = 1024.0 / max(image_size)
    pred = points * scale
    target = truth * scale
    triples = {
        str(int(radius)): np.asarray(maximum_cardinality_point_matches(pred, target, radius), dtype=np.int64)
        for radius in RADII
    }
    pred_match, _ = match_indices(pred, target, 8.0)
    if len(pred) and len(target):
        pred_distance = cKDTree(target).query(pred)[0]
        truth_distance = cKDTree(pred).query(target)[0]
        competition = int(np.count_nonzero((pred_match < 0) & (pred_distance <= 8.0)))
        symmetric = 0.5 * float(np.minimum(pred_distance, 32.0).mean()) + 0.5 * float(np.minimum(truth_distance, 32.0).mean())
    else:
        competition = 0
        symmetric = 32.0
    collision_pairs = {
        str(int(radius)): int(len(cKDTree(pred).query_pairs(radius))) if len(pred) > 1 else 0
        for radius in (3.0, 4.0, 6.0)
    }
    return {
        "triples": triples,
        "competition_unmatched_within8": competition,
        "symmetric_clipped32": symmetric,
        "collision_pairs": collision_pairs,
    }


def scale_recall(points: np.ndarray, truth: np.ndarray, image_size: tuple[int, int]) -> dict:
    scale = 1024.0 / max(image_size)
    pred = points * scale
    target = truth * scale
    if len(target) > 1:
        spacing = cKDTree(target).query(target, k=2)[0][:, 1]
    else:
        spacing = np.full(len(target), np.inf)
    labels = np.where(spacing < 12.0, "far", np.where(spacing < 24.0, "medium", "near"))
    result = {}
    for radius in RADII:
        _, truth_match = match_indices(pred, target, radius)
        result[str(int(radius))] = {
            label: [int(np.count_nonzero((truth_match >= 0) & (labels == label))), int(np.count_nonzero(labels == label))]
            for label in ("far", "medium", "near")
        }
    return result


def aggregate(rows: list[dict], key: str) -> dict:
    triples = {
        str(int(radius)): np.sum([row[key]["stats"]["triples"][str(int(radius))] for row in rows], axis=0)
        for radius in RADII
    }
    scale_totals = {str(int(radius)): {label: [0, 0] for label in ("far", "medium", "near")} for radius in RADII}
    for row in rows:
        for radius in scale_totals:
            for label in scale_totals[radius]:
                value = row[key]["scale_recall"][radius][label]
                scale_totals[radius][label][0] += value[0]
                scale_totals[radius][label][1] += value[1]
    return {
        "images": len(rows),
        "f1": {radius: f1(value) for radius, value in triples.items()},
        "triples": {radius: value.tolist() for radius, value in triples.items()},
        "competition_unmatched_within8": int(sum(row[key]["stats"]["competition_unmatched_within8"] for row in rows)),
        "collision_pairs": {
            radius: int(sum(row[key]["stats"]["collision_pairs"][radius] for row in rows))
            for radius in ("3", "4", "6")
        },
        "symmetric_clipped32": float(np.mean([row[key]["stats"]["symmetric_clipped32"] for row in rows])),
        "scale_recall": {
            radius: {label: hits / max(total, 1) for label, (hits, total) in values.items()}
            for radius, values in scale_totals.items()
        },
        "moves": int(sum(row[key].get("diagnostic", {}).get("moves", 0) for row in rows)),
        "applied_images": int(sum(bool(row[key].get("diagnostic", {}).get("applied", False)) for row in rows)),
    }


def bootstrap(rows: list[dict], draws: int, seed: int) -> dict:
    groups: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(rows):
        groups[row["group"]].append(index)
    buckets = [np.asarray(value, dtype=np.int64) for value in groups.values()]
    rng = np.random.default_rng(seed)
    f1_gain = {str(int(radius)): np.empty(draws, dtype=np.float64) for radius in RADII}
    competition_gain = np.empty(draws, dtype=np.float64)
    symmetric_gain = np.empty(draws, dtype=np.float64)
    for draw in range(draws):
        chosen = rng.integers(0, len(buckets), len(buckets))
        indices = np.concatenate([buckets[index] for index in chosen])
        competition_gain[draw] = np.mean([
            rows[index]["baseline"]["stats"]["competition_unmatched_within8"]
            - rows[index]["candidate"]["stats"]["competition_unmatched_within8"]
            for index in indices
        ])
        symmetric_gain[draw] = np.mean([
            rows[index]["baseline"]["stats"]["symmetric_clipped32"]
            - rows[index]["candidate"]["stats"]["symmetric_clipped32"]
            for index in indices
        ])
        for radius in f1_gain:
            base = np.sum([rows[index]["baseline"]["stats"]["triples"][radius] for index in indices], axis=0)
            candidate = np.sum([rows[index]["candidate"]["stats"]["triples"][radius] for index in indices], axis=0)
            f1_gain[radius][draw] = f1(candidate) - f1(base)
    return {
        "groups": len(buckets), "draws": draws, "seed": seed,
        "f1_gain_95_ci": {radius: np.quantile(value, [0.025, 0.975]).tolist() for radius, value in f1_gain.items()},
        "competition_reduction_per_image_95_ci": np.quantile(competition_gain, [0.025, 0.975]).tolist(),
        "symmetric_error_reduction_95_ci": np.quantile(symmetric_gain, [0.025, 0.975]).tolist(),
    }


def evaluate(base_rows: list[dict], policy: OneBerryReconciliationPolicy) -> tuple[list[dict], dict]:
    rows = []
    for base in base_rows:
        resolver = lambda value, b=base: owner_indices(value, b["boxes"], b["image_size"])
        result = reconcile_one_berry_one_point(
            base["points"], base["reliability"], base["candidates"], base["candidate_scores"],
            base["owners"], base["candidate_owner"], image_size=base["image_size"],
            owner_resolver=resolver, policy=policy,
        )
        output = np.asarray(result["points_xy"], dtype=np.float64)
        if len(output) != len(base["points"]):
            raise RuntimeError("count changed")
        candidate = {
            "stats": point_stats(output, base["truth"], base["image_size"]),
            "scale_recall": scale_recall(output, base["truth"], base["image_size"]),
            "diagnostic": {key: value for key, value in result.items() if key not in ("points_xy", "reliability")},
        }
        rows.append({
            "sample_id": base["sample_id"], "group": base["group"],
            "baseline": base["baseline"], "candidate": candidate,
            "result_points": output,
            "result_reliability": np.asarray(result["reliability"], dtype=np.float64),
            "truth": base["truth"],
        })
    baseline = aggregate(rows, "baseline")
    candidate = aggregate(rows, "candidate")
    improved = worsened = 0
    for row in rows:
        base_tp = int(row["baseline"]["stats"]["triples"]["8"][0])
        candidate_tp = int(row["candidate"]["stats"]["triples"]["8"][0])
        improved += candidate_tp > base_tp
        worsened += candidate_tp < base_tp
    gains = {
        "f1": {radius: candidate["f1"][radius] - baseline["f1"][radius] for radius in baseline["f1"]},
        "competition_reduction": baseline["competition_unmatched_within8"] - candidate["competition_unmatched_within8"],
        "collision_pair_reduction": {
            radius: baseline["collision_pairs"][radius] - candidate["collision_pairs"][radius]
            for radius in baseline["collision_pairs"]
        },
        "symmetric_error_reduction": baseline["symmetric_clipped32"] - candidate["symmetric_clipped32"],
        "improved_images_tp8": int(improved), "worsened_images_tp8": int(worsened),
    }
    return rows, {"baseline": baseline, "candidate": candidate, "gains": gains}


def main() -> None:
    if OUT.exists():
        raise SystemExit(f"refusing to overwrite existing experiment: {OUT}")
    OUT.mkdir(parents=True)
    policy_grid = configs()
    protocol = {
        "version": "vivid-one-berry-one-point-v30",
        "status": "OPEN_DEVELOPMENT_ENGINEERING",
        "purpose": "reduce visually duplicated berry hypotheses while conserving whole-image count, point order and predicted bunch ownership",
        "grid_size": len(policy_grid),
        "selection_gate": {
            "competition_reduction_positive": True,
            "competition_group_bootstrap_lower_bound_positive": True,
            "f1_4_8_16_non_decrease": True,
            "symmetric_error_non_increase": True,
            "improved_images_at_least_worsened": True,
            "all_spacing_stratum_recall_non_decrease": True,
            "count_and_bunch_owner_conserved": True,
        },
        "annotations_used_at_runtime": False,
        "development_selected": True,
        "independent_confirmation": False,
        "router_b_used": False, "sealed_test_used": False,
        "input_hashes": {str(path): sha256(path) for path in (
            MANIFEST, PROPOSALS, CANDIDATE_ROOT / "index.json", Path(__file__),
            PROJECT / "src/geopriv/counting/one_berry_reconciliation.py",
        )},
    }
    atomic_json(OUT / "protocol.json", protocol)
    manifest = {row["sample_id"]: row for row in read_rows(MANIFEST)}
    proposals = {row["sample_id"]: row for row in read_rows(PROPOSALS)}
    if set(manifest) != set(proposals) or len(manifest) != 153:
        raise RuntimeError("development input mismatch")
    index = json.loads((CANDIDATE_ROOT / "index.json").read_text(encoding="utf-8"))
    # Rebind the imported helper's candidate root to the same frozen cache.
    import develop_cluster_aware_point_reallocation as helper
    helper.CANDIDATE_ROOT = CANDIDATE_ROOT
    candidate_pools = load_candidates(index, manifest)
    base_rows = []
    for number, sample_id in enumerate(sorted(manifest), start=1):
        record = manifest[sample_id]
        proposal = proposals[sample_id]
        with np.load(POINTS / f"{sample_id.replace(':', '_')}.npz", allow_pickle=False) as payload:
            points = np.asarray(payload["cru"], dtype=np.float64)
            truth = np.asarray(payload["truth"], dtype=np.float64)
            reliability = np.asarray(payload["reliability"], dtype=np.float64)
        image_size = (int(record["width"]), int(record["height"]))
        boxes, _ = ensure_evaluation_box(points, make_boxes(proposal, "proposals"), image_size)
        owners = owner_indices(points, boxes, image_size)
        candidate_xy, candidate_scores = candidate_pools[sample_id]
        candidate_owner = strict_candidate_owner(candidate_xy, boxes)
        inside = candidate_owner >= 0
        candidate_xy = candidate_xy[inside]
        candidate_scores = candidate_scores[inside]
        candidate_owner = candidate_owner[inside]
        baseline = {
            "stats": point_stats(points, truth, image_size),
            "scale_recall": scale_recall(points, truth, image_size),
            "diagnostic": {"applied": False, "moves": 0},
        }
        base_rows.append({
            "sample_id": sample_id,
            "group": str(record.get("capture_group_id") or sample_id),
            "points": points, "truth": truth, "reliability": reliability,
            "image_size": image_size, "boxes": boxes, "owners": owners,
            "candidates": candidate_xy, "candidate_scores": candidate_scores,
            "candidate_owner": candidate_owner, "baseline": baseline,
        })
        if number % 30 == 0 or number == len(manifest):
            print(f"prepared {number}/{len(manifest)} images", flush=True)

    screening = []
    selected = None
    for index, policy in enumerate(policy_grid, start=1):
        rows, report = evaluate(base_rows, policy)
        quick = bootstrap(rows, draws=400, seed=SEED + index)
        gain = report["gains"]
        recall_ok = all(
            report["candidate"]["scale_recall"][radius][label] >= report["baseline"]["scale_recall"][radius][label]
            for radius in report["baseline"]["scale_recall"] for label in ("far", "medium", "near")
        )
        eligible = (
            gain["competition_reduction"] > 0
            and quick["competition_reduction_per_image_95_ci"][0] > 0
            and all(value >= 0 for value in gain["f1"].values())
            and gain["symmetric_error_reduction"] >= 0
            and gain["improved_images_tp8"] >= gain["worsened_images_tp8"]
            and recall_ok
            and report["candidate"]["moves"] > 0
        )
        item = {
            "policy": asdict(policy), "eligible_quick": bool(eligible),
            **report, "quick_bootstrap": quick,
        }
        screening.append(item)
        if eligible:
            key = (
                gain["competition_reduction"], gain["f1"]["8"], gain["f1"]["4"],
                gain["symmetric_error_reduction"], -report["candidate"]["moves"],
            )
            if selected is None or key > selected[0]:
                selected = (key, policy, rows, item)
        if index % 96 == 0 or index == len(policy_grid):
            atomic_json(OUT / "progress.json", {"status": "SCREENING", "completed": index, "total": len(policy_grid)})
            print(f"screened {index}/{len(policy_grid)} policies", flush=True)

    summary = {
        "status": "COMPLETE_NO_STABLE_CANDIDATE" if selected is None else "COMPLETE_STABLE_CANDIDATE_SELECTED",
        "policies": len(policy_grid), "quick_eligible": int(sum(row["eligible_quick"] for row in screening)),
        "development_selected": True, "independent_confirmation": False,
        "whole_image_count_conserved": True, "predicted_bunch_owner_conserved": True,
        "router_b_used": False, "sealed_test_used": False,
    }
    if selected is not None:
        _, policy, rows, item = selected
        final_bootstrap = bootstrap(rows, draws=10000, seed=SEED + 100000)
        strict = (
            final_bootstrap["competition_reduction_per_image_95_ci"][0] > 0
            and all(value[0] >= 0 for value in final_bootstrap["f1_gain_95_ci"].values())
            and final_bootstrap["symmetric_error_reduction_95_ci"][0] >= 0
        )
        # If the stricter uncertainty gate fails, retain the candidate only as
        # an ablation rather than silently promoting it.
        summary["status"] = "COMPLETE_STABLE_CANDIDATE_SELECTED" if strict else "COMPLETE_QUICK_GATE_ONLY_NOT_PROMOTED"
        summary.update({
            "selected_policy": asdict(policy),
            "selected_report": {key: value for key, value in item.items() if key != "quick_bootstrap"},
            "final_bootstrap": final_bootstrap,
            "strict_promoted": bool(strict),
        })
        point_out = OUT / "oof_development_points"
        per_image = []
        for row in rows:
            atomic_npz(
                point_out / f"{row['sample_id'].replace(':', '_')}.npz",
                cru=np.asarray(row["result_points"], dtype=np.float32),
                truth=np.asarray(row["truth"], dtype=np.float32),
                reliability=np.asarray(row["result_reliability"], dtype=np.float32),
            )
            per_image.append({
                "sample_id": row["sample_id"], "group": row["group"],
                "baseline": row["baseline"], "candidate": row["candidate"],
            })
        atomic_json(OUT / "per_image.json", per_image)
        summary["point_cache"] = str(point_out.resolve())
        summary["point_files"] = len(list(point_out.glob("*.npz")))
    atomic_json(OUT / "screening.json", screening)
    atomic_json(OUT / "summary.json", summary)
    atomic_json(OUT / "progress.json", {"status": summary["status"]})
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
