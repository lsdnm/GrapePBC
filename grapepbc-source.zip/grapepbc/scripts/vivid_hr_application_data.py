"""Deterministic crop augmentation for the clean ViViD HR expert."""

from __future__ import annotations

from pathlib import Path
import sys

import numpy as np
from PIL import Image, ImageEnhance
import torch
from torch.utils.data import Dataset

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from geopriv.data import CRUContextCropDataset
from geopriv.data.point_dataset import IMAGENET_MEAN, IMAGENET_STD


class ApplicationHRCropDataset(Dataset):
    """Wrap CRU crops with seeded photometric jitter and horizontal flipping."""

    def __init__(self, protocol: dict[str, object], *, augment: bool) -> None:
        self.protocol = protocol
        self.augment = bool(augment)
        self._base = None

    @property
    def base(self):
        if self._base is None:
            split = "train" if self.augment else "val"
            manifest_key = "train_manifest" if self.augment else "val_manifest"
            self._base = CRUContextCropDataset(
                str(self.protocol[manifest_key]),
                str(self.protocol["root"]),
                split=split,
                image_size=int(self.protocol["input_size"]),
                core_size=int(self.protocol["core_size"]),
                halo=int(self.protocol["halo"]),
                cache_images=8 if self.augment else 2,
            )
        return self._base

    @base.setter
    def base(self, value) -> None:
        self._base = value

    def __getstate__(self):
        state = self.__dict__.copy()
        # CRUContextCropDataset owns an instance LRU wrapper that is not
        # pickleable under the Windows spawn start method.  Reconstructing it
        # in each worker preserves membership and deterministic augmentation.
        state["_base"] = None
        return state

    def __len__(self) -> int:
        return len(self.base)

    @property
    def records(self):
        return self.base.records

    @property
    def items(self):
        return self.base.items

    def __getitem__(self, request):
        index, draw, epoch = request if isinstance(request, tuple) else (request, 0, 0)
        item = self.base[int(index)]
        if not self.augment:
            return item
        rng = np.random.default_rng(
            np.random.SeedSequence(
                [int(self.protocol["seed"]), int(epoch), int(index), int(draw)]
            )
        )
        item = dict(item)
        target = dict(item["target"])
        item["target"] = target

        if rng.random() < float(self.protocol["color_jitter_probability"]):
            rgb = (
                (item["image"] * IMAGENET_STD + IMAGENET_MEAN)
                .clamp(0, 1)
                .mul(255)
                .round()
                .byte()
                .numpy()
                .transpose(1, 2, 0)
            )
            image = Image.fromarray(rgb)
            for enhancer, magnitude in (
                (ImageEnhance.Brightness, float(self.protocol["brightness_jitter"])),
                (ImageEnhance.Contrast, float(self.protocol["contrast_jitter"])),
                (ImageEnhance.Color, float(self.protocol["saturation_jitter"])),
            ):
                image = enhancer(image).enhance(
                    float(1.0 + rng.uniform(-magnitude, magnitude))
                )
            array = np.asarray(image, dtype=np.float32).transpose(2, 0, 1).copy() / 255.0
            adjusted = (torch.from_numpy(array) - IMAGENET_MEAN) / IMAGENET_STD
            item["image"] = torch.where(
                item["valid_image_mask"][None], adjusted, item["image"]
            )

        if rng.random() < float(self.protocol["horizontal_flip_probability"]):
            size = int(self.protocol["input_size"])
            item["image"] = torch.flip(item["image"], dims=(-1,))
            item["valid_image_mask"] = torch.flip(
                item["valid_image_mask"], dims=(-1,)
            )
            for key in ("points_xy", "core_points_xy"):
                points = target[key].clone()
                if len(points):
                    points[:, 0] = size - 1 - points[:, 0]
                target[key] = points
            x0, y0, x1, y1 = target["core_bounds_xyxy"].tolist()
            target["core_bounds_xyxy"] = torch.tensor(
                [size - x1, y0, size - x0, y1], dtype=torch.float32
            )
            flip = torch.tensor(
                [[-1.0, 0.0, size - 1.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]],
                dtype=torch.float32,
            )
            stored_forward = target["forward_affine"]
            if tuple(stored_forward.shape) == (2, 3):
                forward = torch.eye(3, dtype=torch.float32)
                forward[:2] = stored_forward
                keep_homogeneous = False
            elif tuple(stored_forward.shape) == (3, 3):
                forward = stored_forward.clone()
                keep_homogeneous = True
            else:
                raise ValueError(
                    f"unsupported forward affine shape: {tuple(stored_forward.shape)}"
                )
            forward = flip @ forward
            inverse = torch.linalg.inv(forward)
            target["forward_affine"] = forward if keep_homogeneous else forward[:2]
            target["inverse_affine"] = inverse if keep_homogeneous else inverse[:2]
        return item


__all__ = ["ApplicationHRCropDataset"]
