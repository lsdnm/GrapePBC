"""Frozen-weight development diagnosis; never updates the pilot or opens tests."""
import argparse
import gc
import json
import os
from pathlib import Path
import time

import numpy as np
import torch
from torch.utils.data import DataLoader

from audit_cru_detail_readiness import read_json, save_json, sha
from train_vivid_detail_trial import verify_protocol, make_model, make_loader
from vivid_detail_runtime import safe_load, evaluate_counts
from geopriv.data import PrivilegedManifestDataset, collate_privileged_samples


def predictions_at(result, threshold):
    indices = [i for i, t in enumerate(result['thresholds']) if abs(t-threshold) < 1e-8]
    if len(indices) != 1:
        raise ValueError('threshold missing or duplicated')
    i = indices[0]
    rows = result['per_image']
    if len({r['sample_id'] for r in rows}) != len(rows):
        raise ValueError('duplicate sample')
    return {r['sample_id']: (r['truth'], r['predictions'][i]) for r in rows}


def verify_replay(old, new):
    for threshold in old['thresholds']:
        if predictions_at(old, threshold) != predictions_at(new, threshold):
            raise ValueError(f'frozen-count replay failed at {threshold}')
    return True


def compare(reference, candidate):
    a = predictions_at(reference, reference['selected']['threshold'])
    b = predictions_at(candidate, candidate['selected']['threshold'])
    if set(a) != set(b) or any(a[k][0] != b[k][0] for k in a):
        raise ValueError('comparison membership/truth mismatch')
    groups = {}
    rows = []
    for key, (truth, pred) in a.items():
        other = b[key][1]
        gain = abs(pred-truth)-abs(other-truth)
        group = '0-99' if truth < 100 else '100-299' if truth < 300 else '300+'
        groups.setdefault(group, []).append((truth, pred, other, gain))
        rows.append(dict(sample_id=key, truth=truth, reference=pred, candidate=other,
                         mae_improvement=gain))
    strata = {}
    for name, values in groups.items():
        arr = np.asarray(values)
        strata[name] = dict(n=len(values), reference_mae=float(np.abs(arr[:,1]-arr[:,0]).mean()),
            candidate_mae=float(np.abs(arr[:,2]-arr[:,0]).mean()),
            reference_bias=float((arr[:,1]-arr[:,0]).mean()),
            candidate_bias=float((arr[:,2]-arr[:,0]).mean()),
            mae_improvement=float(arr[:,3].mean()))
    gains = [r['mae_improvement'] for r in rows]
    return dict(mean_mae_improvement=float(np.mean(gains)), improved=sum(x>0 for x in gains),
        worsened=sum(x<0 for x in gains), tied=sum(x==0 for x in gains), strata=strata,
        per_image=rows, scope='descriptive development analysis, not independent evidence')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--trial', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    trial, out = args.trial.resolve(), args.output.resolve()
    protocol = verify_protocol(trial)
    if read_json(trial/'stage.json')['status'] != 'PILOT_COMPLETE_REVIEW_REQUIRED':
        raise ValueError('completed frozen pilot required')
    checkpoints = dict(lr=trial/'lr_initial.pt',
        control=trial/'control/best_val_mae.pt', detail=trial/'detail/best_val_mae.pt')
    thresholds = [round(i/100, 2) for i in range(5,96)]
    prerecord = dict(version='frozen-weights-equal-dense-grid-v1',
        source_protocol_sha256=sha(trial/'protocol.json'),
        script_sha256=sha(Path(__file__)), checkpoints={k:dict(path=str(p), sha256=sha(p))
            for k,p in checkpoints.items()}, thresholds=thresholds,
        selection='development MAE then RMSE then lower threshold',
        batch_size=1, fp32=True, deterministic=True, test_used=False, router_B_used=False,
        weight_update=False, role='development decoder diagnosis, NOT confirmatory evaluation')
    out.mkdir(parents=True, exist_ok=True)
    if (out/'protocol.json').exists():
        if read_json(out/'protocol.json') != prerecord:
            raise ValueError('diagnosis protocol changed; use a new output directory')
    else:
        save_json(out/'protocol.json', prerecord)
    import msvcrt
    with (out/'worker.lock').open('a+b') as lock:
        if lock.tell() == 0:
            lock.write(b'0'); lock.flush()
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'
        torch.set_num_threads(4)
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        torch.use_deterministic_algorithms(True)
        results = {}
        started = time.monotonic()
        for name, checkpoint in checkpoints.items():
            save_json(out/'progress.json', dict(status='RUNNING', arm=name, pid=os.getpid(),
                completed=list(results), test_used=False))
            old = read_json(trial/'lr_baseline.json') if name == 'lr' else read_json(
                trial/name/f"validation_epoch_{safe_load(checkpoint)['epoch']:02d}.json")
            destination = out/f'{name}.json'
            if destination.exists():
                result = read_json(destination)
            else:
                model = make_model(protocol, 'control' if name == 'lr' else name)
                if name != 'lr':
                    model.load_state_dict(safe_load(checkpoint)['model'])
                if name == 'lr':
                    dataset = PrivilegedManifestDataset(protocol['manifest'], protocol['root'],
                        split='val', image_size=protocol['lr_input_size'], augmentation=False)
                    loader = DataLoader(dataset, batch_size=1, collate_fn=collate_privileged_samples)
                else:
                    dataset, loader, _ = make_loader(protocol, 'val')
                result = evaluate_counts(model, loader, thresholds, core=name!='lr',
                    heartbeat=out/f'{name}_live.json')
                verify_replay(old, result)
                result['exact_old_threshold_replay'] = True
                save_json(destination, result)
                del model, dataset, loader
                gc.collect(); torch.cuda.empty_cache()
            verify_replay(old, result)
            results[name] = result
            print(json.dumps(dict(arm=name, selected=result['selected'],
                old_selected=old['selected'], elapsed=time.monotonic()-started)), flush=True)
        report = dict(status='COMPLETE', frozen_weight_metrics={k:v['selected'] for k,v in results.items()},
            control_vs_lr=compare(results['lr'],results['control']),
            detail_vs_lr=compare(results['lr'],results['detail']),
            detail_vs_control=compare(results['control'],results['detail']),
            exact_old_threshold_replay=True, test_used=False, weight_update=False,
            scope='development calibration; no claim of architecture benefit from calibration alone')
        save_json(out/'summary.json', report)
        save_json(out/'progress.json',dict(status='COMPLETE',seconds=time.monotonic()-started,
            completed=list(results),test_used=False))
        print(json.dumps(report['frozen_weight_metrics']), flush=True)


if __name__ == '__main__':
    main()
