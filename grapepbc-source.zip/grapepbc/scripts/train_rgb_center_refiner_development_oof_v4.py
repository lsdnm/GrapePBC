"""Five-fold development OOF fine-tuning for count-conserving centre refinement.

Each development image is predicted by a model that did not train on that
image.  The final all-development refit is stored only as a deployable model;
all reported development metrics are computed from the OOF predictions.
"""
from __future__ import annotations

import json
from pathlib import Path
import random
import sys
import time

import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.spatial import distance_matrix
from sklearn.model_selection import GroupKFold
import torch


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

from geopriv.data.hash_utils import file_sha256  # noqa: E402
from run_vivid_hr_core_calibration import atomic_json, atomic_npz  # noqa: E402
import train_rgb_point_center_refiner as base  # noqa: E402
import calibrate_scale_aware_rgb_center_refiner_v3 as gate  # noqa: E402


EXP = PROJECT / "experiments" / "cru_detail_v1"
OUT = EXP / "vivid_rgb_point_center_refiner_development_oof_v4"
INITIAL: Path | None = EXP / "vivid_rgb_point_center_refiner_wide_context_v3" / "best_val_offset.pt"
SEED = 20261022
FOLDS = 5
EPOCHS = 2
VERSION = "vivid-rgb-point-center-refiner-development-oof-v4"
TRAINING_DISTRIBUTION = "current accepted CRU points matched to truths within 24 normalized pixels"


def baseline_payload(record: dict) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    filename = record["sample_id"].replace(":", "_") + ".npz"
    with np.load(base.BASE / filename, allow_pickle=False) as payload:
        return (payload["cru"].astype(np.float32),
                payload["truth"].astype(np.float32),
                payload["reliability"].astype(np.float32))


def current_point_anchors(record: dict, truth: np.ndarray, *, epoch: int,
                          validation: bool):
    points, _, _ = baseline_payload(record)
    width, height = int(record["width"]), int(record["height"])
    scale = 1024.0 / max(width, height)
    point_spacing = base.spacing(points, scale)
    if not len(points) or not len(truth):
        return (np.empty((0, 2), np.float32), np.empty((0, 2), np.float32),
                np.empty(0, np.float32), np.empty(0, np.float32))
    cost = distance_matrix(points * scale, truth * scale)
    point_index, truth_index = linear_sum_assignment(cost)
    accepted = cost[point_index, truth_index] <= base.MAX_SHIFT
    positive_points = point_index[accepted]
    positive_truth = truth_index[accepted]
    mapping = {int(p): int(t) for p, t in zip(positive_points, positive_truth, strict=True)}
    rng = np.random.default_rng(SEED + epoch * 10007 + int(record["sha256"][:8], 16))
    strata = np.where(point_spacing < 12.0, 0, np.where(point_spacing < 24.0, 1, 2))
    selected_positive: list[int] = []
    for stratum in range(3):
        values = np.asarray([p for p in positive_points if strata[int(p)] == stratum], dtype=np.int64)
        if len(values) > 96:
            values = rng.choice(values, 96, replace=False)
        selected_positive.extend(int(value) for value in values)
    selected_positive_array = np.asarray(selected_positive, dtype=np.int64)
    negative = np.setdiff1d(np.arange(len(points)), positive_points, assume_unique=False)
    nearest_truth = cost.min(axis=1)
    negative = negative[np.argsort(nearest_truth[negative], kind="stable")]
    negative = negative[:min(len(negative), max(16, len(selected_positive_array) // 3))]
    selected = np.concatenate((selected_positive_array, negative))
    if not validation:
        rng.shuffle(selected)
    anchors = points[selected]
    offsets = np.zeros((len(selected), 2), dtype=np.float32)
    valid = np.zeros(len(selected), dtype=np.float32)
    for output_index, point_id in enumerate(selected):
        truth_id = mapping.get(int(point_id))
        if truth_id is not None:
            offsets[output_index] = (truth[truth_id] - points[point_id]) * scale
            valid[output_index] = 1.0
    return anchors.astype(np.float32), offsets, point_spacing[selected], valid


def initialise(device: torch.device):
    model = base.RGBPointCenterRefiner().to(device)
    if INITIAL is not None:
        checkpoint = torch.load(INITIAL, map_location=device, weights_only=False)
        model.load_state_dict(checkpoint["model"])
    return model


def save_checkpoint(path: Path, payload: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temporary)
    temporary.replace(path)


def fit_fixed(model, records: list[dict], device: torch.device, folder: Path,
              *, fold: int) -> list[dict]:
    folder.mkdir(parents=True, exist_ok=True)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1.0e-4, weight_decay=1.0e-4)
    history = []
    for epoch in range(1, EPOCHS + 1):
        started = time.monotonic()
        metrics = base.epoch_pass(model, records, optimizer, device,
                                  epoch=fold * 100 + epoch, validation=False)
        row = {"fold": fold, "epoch": epoch, "training": metrics,
               "elapsed_seconds": time.monotonic() - started}
        history.append(row)
        with (folder / "history.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")
        payload = {"fold": fold, "epoch": epoch, "model": model.state_dict(),
                   "optimizer": optimizer.state_dict(), "row": row}
        save_checkpoint(folder / "last.pt", payload)
        atomic_json(folder / "progress.json", {"status": "TRAINING" if epoch < EPOCHS else "COMPLETE",
                                                "fold": fold, "last_epoch": epoch,
                                                "router_b_used": False, "sealed_test_used": False})
        print(json.dumps(row, ensure_ascii=False), flush=True)
    return history


@torch.inference_mode()
def infer_records(model, records: list[dict], device: torch.device,
                  oof_cache: Path) -> list[dict]:
    model.eval()
    output = []
    for record in records:
        points, truth, reliability = baseline_payload(record)
        image_size = (int(record["width"]), int(record["height"]))
        scale = 1024.0 / max(image_size)
        point_spacing = base.spacing(points, scale)
        if len(points):
            image = base.load_rgb(base.ROOT / record["image_path"])
            offset, confidence = base.predict_offsets(model, image, points, point_spacing, scale, device)
        else:
            offset = np.empty((0, 2), np.float32)
            confidence = np.empty(0, np.float32)
        filename = record["sample_id"].replace(":", "_") + ".npz"
        atomic_npz(oof_cache / filename, offset=offset, confidence=confidence)
        output.append({"sample_id": record["sample_id"], "image_size": image_size,
                       "scale": scale, "points": points, "truth": truth,
                       "reliability": reliability, "point_spacing": point_spacing,
                       "offset": offset, "confidence": confidence})
    return output


def select_gate(cached: list[dict]) -> tuple[dict, list[dict]]:
    configs = []
    for alpha in (0.50, 0.75, 1.00):
        for far_threshold in (0.65, 0.80, 0.90, 1.10):
            for medium_threshold in (0.50, 0.65, 0.80):
                for near_threshold in (0.50, 0.65, 0.80):
                    for fraction in (0.25, 0.40):
                        predictions = [gate.apply_scale_gate(
                            item, alpha=alpha, far_threshold=far_threshold,
                            medium_threshold=medium_threshold,
                            near_threshold=near_threshold, fraction=fraction,
                        ) for item in cached]
                        report = base.evaluate(cached, predictions)
                        configs.append({"alpha": alpha, "far_threshold": far_threshold,
                                        "medium_threshold": medium_threshold,
                                        "near_threshold": near_threshold,
                                        "spacing_fraction": fraction,
                                        "eligible": gate.eligible(report), **report})
    eligible = [row for row in configs if row["eligible"]]
    selected = max(eligible or configs, key=lambda row: (
        row["image_gains"]["4"]["net_tp"],
        row["image_gains"]["8"]["net_tp"],
        row["image_gains"]["16"]["net_tp"],
        -row["image_gains"]["4"]["worsened"],
    ))
    return selected, configs


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    base.HALF_NORM = 40.0
    base.MAX_SHIFT = 24.0
    torch.manual_seed(SEED); np.random.seed(SEED); random.seed(SEED)
    records = base.rows(base.DEV_MANIFEST)
    groups = np.asarray([row.get("capture_group_id") or row["sample_id"] for row in records])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    protocol = {"version": VERSION, "seed": SEED, "folds": FOLDS,
                "epochs_per_fold": EPOCHS, "fixed_epoch_count": True,
                "initial_checkpoint": str(INITIAL) if INITIAL is not None else None,
                "initial_sha256": file_sha256(INITIAL) if INITIAL is not None else None,
                "training_distribution": TRAINING_DISTRIBUTION,
                "oof_group": "capture_group_id with sample_id fallback",
                "development_selected": True, "independent_confirmation": False,
                "counts_updated": False, "router_b_used": False,
                "sealed_test_used": False, "source_sha256": file_sha256(Path(__file__))}
    atomic_json(OUT / "protocol.json", protocol)
    oof_cache = OUT / "oof_inference_cache"; oof_cache.mkdir(exist_ok=True)
    old_make = base.make_anchors
    base.make_anchors = current_point_anchors
    cached: list[dict] = []
    fold_rows = []
    try:
        splitter = GroupKFold(FOLDS)
        for fold, (fit_index, held_index) in enumerate(splitter.split(np.arange(len(records)), groups=groups)):
            fit_records = [records[int(index)] for index in fit_index]
            held_records = [records[int(index)] for index in held_index]
            model = initialise(device)
            history = fit_fixed(model, fit_records, device, OUT / f"fold_{fold}", fold=fold)
            cached.extend(infer_records(model, held_records, device, oof_cache))
            fold_rows.append({"fold": fold, "train_images": len(fit_records),
                              "held_images": len(held_records), "history": history})
            print(f"fold {fold} complete: {len(held_records)} held images", flush=True)
        by_id = {item["sample_id"]: item for item in cached}
        cached = [by_id[row["sample_id"]] for row in records]
        if len(cached) != len(records):
            raise RuntimeError("OOF coverage mismatch")
        selected, configs = select_gate(cached)
        point_out = OUT / "oof_development_points"; point_out.mkdir(exist_ok=True)
        predictions = [gate.apply_scale_gate(
            item, alpha=float(selected["alpha"]),
            far_threshold=float(selected["far_threshold"]),
            medium_threshold=float(selected["medium_threshold"]),
            near_threshold=float(selected["near_threshold"]),
            fraction=float(selected["spacing_fraction"]),
        ) for item in cached]
        for item, points in zip(cached, predictions, strict=True):
            atomic_npz(point_out / (item["sample_id"].replace(":", "_") + ".npz"),
                       cru=points, truth=item["truth"], reliability=item["reliability"])
        # Fit one deployable checkpoint after the OOF policy has been fixed.  It
        # is not used to calculate the OOF metrics above.
        deploy_model = initialise(device)
        deploy_history = fit_fixed(deploy_model, records, device, OUT / "deploy_refit", fold=FOLDS)
        deploy_last = torch.load(OUT / "deploy_refit" / "last.pt", map_location="cpu", weights_only=False)
        deploy_last["protocol"] = protocol
        save_checkpoint(OUT / "deploy_model.pt", deploy_last)
    finally:
        base.make_anchors = old_make
    eligible_count = sum(bool(row["eligible"]) for row in configs)
    summary = {"status": "COMPLETE_OPEN_DEVELOPMENT_GROUP_OOF",
               "selected": selected, "eligible_configs": eligible_count,
               "configs_evaluated": len(configs), "folds": fold_rows,
               "deploy_history": deploy_history,
               "model_parameters": sum(parameter.numel() for parameter in deploy_model.parameters()),
               "oof_point_files": len(list((OUT / "oof_development_points").glob("*.npz"))),
               "deploy_model_sha256": file_sha256(OUT / "deploy_model.pt"),
               "independent_confirmation": False, "router_b_used": False,
               "sealed_test_used": False}
    atomic_json(OUT / "summary.json", summary)
    atomic_json(OUT / "progress.json", {"status": "COMPLETE", "selected": selected,
                                         "router_b_used": False, "sealed_test_used": False})
    print(json.dumps({key: summary[key] for key in (
        "status", "selected", "eligible_configs", "configs_evaluated",
        "model_parameters", "oof_point_files", "deploy_model_sha256")},
        ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
