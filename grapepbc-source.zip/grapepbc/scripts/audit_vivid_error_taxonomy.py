"""Point-level error taxonomy from immutable prediction caches; no inference GT gating.

Categories describe geometry relative to annotations, not certified semantic
background/duplicate labels. Diagnostic galleries are not manuscript figures.
"""
import argparse
from collections import Counter, defaultdict
from pathlib import Path
import numpy as np
from PIL import Image,ImageOps,ImageDraw
from scipy.spatial import cKDTree
from audit_cru_detail_readiness import read_json,read_rows,save_json,sha
from hr_repair_data import source_proxy
from diagnose_vivid_hr_failure import inside
from geopriv.metrics import maximum_cardinality_point_matches,aggregate_count_metrics
from geopriv.data.point_dataset import letterbox_image_and_points


def match_indices(pred,truth,radius=8.):
    """Same maximum-cardinality criterion as existing metrics, exposing pairs."""
    pred=np.asarray(pred).reshape(-1,2);truth=np.asarray(truth).reshape(-1,2)
    left=np.full(len(pred),-1,int);right=np.full(len(truth),-1,int)
    if not len(pred) or not len(truth):return left,right
    tree=cKDTree(truth)
    adjacency=[sorted(tree.query_ball_point(p,radius)) for p in pred]
    for start in range(len(pred)):
        parent=np.full(len(truth),-1,int);seen=np.zeros(len(pred),bool);seen[start]=True
        queue=[start];i=0;free=-1
        while i<len(queue) and free<0:
            l=queue[i];i+=1
            for r in adjacency[l]:
                if parent[r]>=0:continue
                parent[r]=l;paired=right[r]
                if paired<0:free=r;break
                if not seen[paired]:seen[paired]=True;queue.append(paired)
        while free>=0:
            l=parent[free];previous=left[l];left[l]=free;right[free]=l;free=previous
    return left,right


def nearest(query,reference):
    return cKDTree(reference).query(query)[0] if len(reference) else np.full(len(query),np.inf)


def classify(pred,truth,width,height,boxes):
    scale=1024/max(width,height);p=pred*scale;t=truth*scale
    pm,tm=match_indices(p,t)
    triple=(int((pm>=0).sum()),int((pm<0).sum()),int((tm<0).sum()))
    if triple!=maximum_cardinality_point_matches(p,t,8.):raise ValueError('matching count drift')
    d=nearest(p,t);e=nearest(t,p);fp=pm<0;fn=tm<0
    boxed=np.zeros(len(pred),bool)
    for box in boxes:boxed|=inside(pred,box['bbox_xyxy'])
    inframe=inside(pred,(0,0,width,height))
    categories=np.full(len(pred),'matched',object)
    categories[fp&(d<=8)]='unmatched_near_gt_competition'
    categories[fp&(d>8)&(d<=16)]='unmatched_8_to_16px'
    categories[fp&(d>16)&boxed]='unmatched_far_inside_boxes'
    categories[fp&(d>16)&~boxed]='unmatched_far_outside_boxes'
    categories[fp&~inframe]='outside_image'
    nn=cKDTree(t).query(t,k=2)[0][:,1] if len(t)>1 else np.full(len(t),np.inf)
    spacing=np.where(nn<=4,'spacing_le4',np.where(nn<=8,'spacing_4_to_8','spacing_gt8'))
    groups={g:dict(gt=int((spacing==g).sum()),matched=int(((spacing==g)&~fn).sum())) for g in sorted(set(spacing))}
    # Raw point duplication and LR stride-2 target collisions are different.
    _,transformed,_,_=letterbox_image_and_points(Image.new('RGB',(width,height)),truth,1024)
    cells=np.floor(transformed/2).astype(int)
    counts=dict(tp=triple[0],fp=triple[1],fn=triple[2],
        missed_no_prediction_within8=int((fn&(e>8)).sum()),
        missed_competition_within8=int((fn&(e<=8)).sum()),
        lr_stride2_gt_collisions=int(len(cells)-len(np.unique(cells,axis=0))),
        duplicate_gt_coordinates=int(len(truth)-len(np.unique(truth,axis=0))),
        **{str(k):int(v) for k,v in Counter(categories[fp]).items()})
    if sum(Counter(categories[fp]).values())!=triple[1]:raise ValueError('FP partition failed')
    return counts,groups,pm,tm,categories,spacing


def gallery(raw,pred,truth,pm,tm,path,title):
    size=(660,580);small=ImageOps.contain(raw,size);scale=np.array(small.size)/np.array(raw.size)
    canvas=Image.new('RGB',(2040,640),'white');draw=ImageDraw.Draw(canvas)
    draw.text((12,5),title,fill='black')
    for index,label in enumerate(('RAW','ANNOTATIONS (missed = magenta)','PREDICTIONS (unmatched = red)')):
        panel=small.copy();d=ImageDraw.Draw(panel)
        points=truth if index==1 else pred
        matches=tm if index==1 else pm
        if index:
            for (x,y),matched in zip(points*scale,matches):
                color=('lime' if matched>=0 else ('magenta' if index==1 else 'red'))
                d.ellipse((x-2,y-2,x+2,y+2),outline=color,width=1)
        canvas.paste(panel,(index*680+10,50));draw.text((index*680+10,28),label,fill='black')
    path.parent.mkdir(parents=True,exist_ok=True);canvas.save(path)


def main():
    p=argparse.ArgumentParser()
    for name in ('manifest','root','boxes','cache','reference','output'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();records=[r for r in read_rows(a.manifest) if r['split']=='val']
    if any(r['external_test'] or r['extra']['data_role']!='development_val' for r in records):raise ValueError('role mismatch')
    boxes={r['sample_id']:r['boxes'] for r in read_rows(a.boxes)}
    reference=read_json(a.reference); expected={r['sample_id']:r for r in reference['rows']}
    rows=[];totals=Counter();spacing=defaultdict(Counter);lighting=defaultdict(Counter);cache={};preview_cache={}
    for n,r in enumerate(records):
        ident=r['sample_id'];path=a.cache/(ident.replace(':','_')+'.npz')
        with np.load(path,allow_pickle=False) as z:pred=z['pred'];gt=z['truth']
        source=np.load(a.root/r['points_path'],allow_pickle=False)
        if not np.array_equal(gt,source):raise ValueError('GT cache differs from source')
        if len(pred)!=expected[ident]['pred']:raise ValueError('prediction count drift')
        stats,groups,pm,tm,cat,sp=classify(pred,gt,r['width'],r['height'],boxes[ident])
        if tuple(stats[k] for k in ('tp','fp','fn'))!=tuple(expected[ident][k] for k in ('tp','fp','fn')):raise ValueError('audit metric drift')
        for group,v in groups.items():spacing[group].update(v)
        with Image.open(a.root/r['image_path']) as im:raw=ImageOps.exif_transpose(im).convert('RGB')
        small=ImageOps.contain(raw,(1024,1024)).convert('L');gray=np.asarray(small)
        xy=np.rint(gt*np.array(small.size)/np.array(raw.size)).astype(int)
        values=np.array([gray[max(0,y-2):min(gray.shape[0],y+3),max(0,x-2):min(gray.shape[1],x+3)].mean() for x,y in xy])
        light=np.where(values<64,'dark_lt64',np.where(values>192,'bright_gt192','mid64_192'))
        for group in sorted(set(light)):
            mask=light==group;lighting[group].update(gt=int(mask.sum()),matched=int(((tm>=0)&mask).sum()))
        row=dict(sample_id=ident,truth=len(gt),pred=len(pred),signed_error=len(pred)-len(gt),
                 source_proxy=source_proxy(ident),width=r['width'],height=r['height'],**stats)
        rows.append(row);totals.update(stats)
        cache[ident]=(pred,gt,pm,tm);preview_cache[ident]=r
        if n%25==0:save_json(a.output/'progress.json',dict(status='RUNNING',images=n+1,total=len(records)))
    selected={r['sample_id'] for r in sorted(rows,key=lambda r:r['signed_error'])[:3]+sorted(rows,key=lambda r:r['signed_error'])[-3:]}
    for ident in sorted(selected):
        r=preview_cache[ident]
        with Image.open(a.root/r['image_path']) as im:raw=ImageOps.exif_transpose(im).convert('RGB')
        pred,gt,pm,tm=cache[ident]
        gallery(raw,pred,gt,pm,tm,a.output/'gallery'/(ident.replace(':','_')+'.png'),f'{ident} GT={len(gt)} PRED={len(pred)}')
    for groups in (spacing,lighting):
        for v in groups.values():v['recall']=v['matched']/max(1,v['gt'])
    report=dict(status='COMPLETE',test_used=False,metrics=aggregate_count_metrics([r['pred'] for r in rows],[r['truth'] for r in rows]),
        totals=dict(totals),spacing={k:dict(v) for k,v in spacing.items()},lighting={k:dict(v) for k,v in lighting.items()},
        rows=rows,reference_sha256=sha(a.reference),manifest_sha256=sha(a.manifest),
        interpretation='FP/FN relative to point labels. Near-GT unmatched is not certified duplicate; far-outside-box is not certified background. Spacing is not berry size or row membership. Lighting associations are not causal. Galleries selected by signed error, no cherry-picking.')
    save_json(a.output/'summary.json',report);save_json(a.output/'progress.json',dict(status='COMPLETE'))
    print({k:v for k,v in report.items() if k not in ('rows',)},flush=True)


if __name__=='__main__':main()
