"""Screen conservative one-berry/one-point deletion rules on open development data.

This experiment starts from the retained V29/V18 point cache.  It only removes
the weaker member of an exceptionally close, same-bunch pair when both points
are supported by the *same* frozen Rich-HR centre candidate.  The goal is to
remove visually obvious duplicate hypotheses without collapsing two adjacent
real berries.  Labels are used only for open-development screening and never by
the runtime rule.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import asdict, dataclass
import json
from pathlib import Path
import sys

import numpy as np
from scipy.spatial import cKDTree


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

import develop_cluster_aware_point_reallocation as helper  # noqa: E402
import develop_one_berry_one_point_v30 as metrics  # noqa: E402
from audit_vivid_error_taxonomy import match_indices  # noqa: E402
from develop_cluster_aware_point_reallocation import (  # noqa: E402
    ensure_evaluation_box,
    load_candidates,
    make_boxes,
    owner_indices,
    read_rows,
    strict_candidate_owner,
)
from geopriv.counting.one_berry_reconciliation import _nms_candidates  # noqa: E402
from run_vivid_hr_core_calibration import atomic_json  # noqa: E402


EXP = PROJECT / "experiments" / "cru_detail_v1"
MANIFEST = EXP / "vivid_application_lr_repair_inputs_v1" / "development_val_clean.jsonl"
PROPOSALS = EXP / "vivid_stage6_border_safe_zero_filter_v28b" / "development_proposals.jsonl"
POINTS = EXP / "vivid_v4_v17_hybrid_center_gate_v18" / "oof_development_points"
CANDIDATE_ROOT = EXP / "vivid_application_development_density_core_points_v2"
OUT = EXP / "vivid_conservative_duplicate_deletion_v33_screen"
SEED = 20261006


@dataclass(frozen=True)
class Policy:
    collision_radius_1024: float
    support_radius_1024: float
    candidate_score_threshold: float
    minimum_reliability_gap: float
    maximum_deletions: int


POLICIES = tuple(
    Policy(radius, support, score, gap, maximum)
    # The first screen is intentionally small and conservative.  Wider radii
    # were already shown to be visually unsafe by the rejected relocation run.
    for radius in (2.0, 2.5, 3.0, 3.5, 4.0)
    for support in (2.5, 3.5)
    for score in (0.10, 0.125)
    for gap in (0.0, 0.025)
    for maximum in (2, 4)
)


def candidate_evidence(base: dict) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return nearest candidate index/distance/score for every V18 point."""
    scale = 1024.0 / max(base["image_size"])
    kept = _nms_candidates(
        base["candidates"], base["candidate_scores"], base["candidate_owner"], 4.0 / scale
    )
    nearest = np.full(len(base["points"]), -1, dtype=np.int64)
    distance = np.full(len(base["points"]), np.inf, dtype=np.float64)
    score = np.zeros(len(base["points"]), dtype=np.float64)
    for owner in np.unique(base["owners"]):
        point_index = np.flatnonzero(base["owners"] == owner)
        candidate_index = kept[base["candidate_owner"][kept] == owner]
        if not len(point_index) or not len(candidate_index):
            continue
        tree = cKDTree(base["candidates"][candidate_index])
        local_distance, local_nearest = tree.query(base["points"][point_index])
        nearest[point_index] = candidate_index[local_nearest]
        distance[point_index] = local_distance * scale
        score[point_index] = base["candidate_scores"][nearest[point_index]]
    return nearest, distance, score


def close_pairs(base: dict) -> list[tuple[float, int, int]]:
    scale = 1024.0 / max(base["image_size"])
    pairs: list[tuple[float, int, int]] = []
    for owner in np.unique(base["owners"]):
        members = np.flatnonzero(base["owners"] == owner)
        if len(members) < 2:
            continue
        for first, second in cKDTree(base["points"][members] * scale).query_pairs(6.000001):
            left, right = int(members[first]), int(members[second])
            distance = float(np.linalg.norm(base["points"][left] - base["points"][right]) * scale)
            pairs.append((distance, left, right))
    return sorted(pairs)


def apply_policy(base: dict, policy: Policy) -> tuple[np.ndarray, dict]:
    nearest, support_distance, candidate_score = base["candidate_evidence"]
    candidates = []
    for distance, first, second in base["close_pairs"]:
        if distance > policy.collision_radius_1024:
            continue
        if nearest[first] < 0 or nearest[first] != nearest[second]:
            continue
        if max(support_distance[first], support_distance[second]) > policy.support_radius_1024:
            continue
        if min(candidate_score[first], candidate_score[second]) < policy.candidate_score_threshold:
            continue
        rel_first = float(base["reliability"][first])
        rel_second = float(base["reliability"][second])
        if abs(rel_first - rel_second) < policy.minimum_reliability_gap:
            continue
        weaker, stronger = (first, second) if rel_first <= rel_second else (second, first)
        candidates.append((distance, -float(candidate_score[weaker]), weaker, stronger))
    deleted: set[int] = set()
    protected: set[int] = set()
    rows = []
    for distance, neg_score, weaker, stronger in sorted(candidates):
        if len(deleted) >= policy.maximum_deletions:
            break
        if weaker in deleted or stronger in deleted or weaker in protected:
            continue
        deleted.add(weaker)
        protected.add(stronger)
        rows.append({
            "deleted_index": int(weaker), "kept_index": int(stronger),
            "pair_distance_1024": float(distance),
            "candidate_score": float(-neg_score),
            "deleted_reliability": float(base["reliability"][weaker]),
            "kept_reliability": float(base["reliability"][stronger]),
        })
    mask = np.ones(len(base["points"]), dtype=bool)
    if deleted:
        mask[np.fromiter(sorted(deleted), dtype=np.int64)] = False
    return base["points"][mask], {"deletions": len(deleted), "rows": rows, "mask": mask}


def evaluate(bases: list[dict], policy: Policy) -> tuple[list[dict], dict]:
    rows = []
    correct_deleted = matched_deleted = 0
    for base in bases:
        output, diagnostic = apply_policy(base, policy)
        base_pred_match = base["base_pred_match"]
        deleted_index = np.flatnonzero(~diagnostic["mask"])
        correct_deleted += int(np.count_nonzero(base_pred_match[deleted_index] < 0))
        matched_deleted += int(np.count_nonzero(base_pred_match[deleted_index] >= 0))
        baseline = base["baseline"]
        signature = tuple(int(value) for value in deleted_index)
        if signature not in base["candidate_cache"]:
            base["candidate_cache"][signature] = {
                "stats": metrics.point_stats(output, base["truth"], base["image_size"]),
                "scale_recall": metrics.scale_recall(output, base["truth"], base["image_size"]),
            }
        cached = base["candidate_cache"][signature]
        candidate = {**cached, "diagnostic": diagnostic}
        rows.append({
            "sample_id": base["sample_id"], "group": base["group"],
            "baseline": baseline, "candidate": candidate,
            "baseline_error": abs(len(base["points"]) - len(base["truth"])),
            "candidate_error": abs(len(output) - len(base["truth"])),
        })
    baseline = metrics.aggregate(rows, "baseline")
    candidate = metrics.aggregate(rows, "candidate")
    baseline_mae = float(np.mean([row["baseline_error"] for row in rows]))
    candidate_mae = float(np.mean([row["candidate_error"] for row in rows]))
    report = {
        "policy": asdict(policy),
        "baseline": baseline, "candidate": candidate,
        "deletions": int(sum(row["candidate"]["diagnostic"]["deletions"] for row in rows)),
        "images_changed": int(sum(row["candidate"]["diagnostic"]["deletions"] > 0 for row in rows)),
        "unmatched_deleted": int(correct_deleted), "matched_deleted": int(matched_deleted),
        "deletion_precision_proxy": float(correct_deleted / max(correct_deleted + matched_deleted, 1)),
        "count_mae_before": baseline_mae, "count_mae_after": candidate_mae,
        "count_mae_gain": baseline_mae - candidate_mae,
        "f1_gain": {key: candidate["f1"][key] - baseline["f1"][key] for key in baseline["f1"]},
        "competition_reduction": baseline["competition_unmatched_within8"] - candidate["competition_unmatched_within8"],
        "collision_reduction": {
            key: baseline["collision_pairs"][key] - candidate["collision_pairs"][key]
            for key in baseline["collision_pairs"]
        },
    }
    return rows, report


def paired_bootstrap(rows: list[dict], draws: int = 10000) -> list[float]:
    groups: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(rows):
        groups[row["group"]].append(index)
    buckets = [np.asarray(value, dtype=np.int64) for value in groups.values()]
    rng = np.random.default_rng(SEED)
    values = np.empty(draws, dtype=np.float64)
    for draw in range(draws):
        chosen = rng.integers(0, len(buckets), len(buckets))
        indices = np.concatenate([buckets[index] for index in chosen])
        values[draw] = np.mean([
            rows[index]["baseline_error"] - rows[index]["candidate_error"] for index in indices
        ])
    return np.quantile(values, [0.025, 0.975]).tolist()


def main() -> None:
    if OUT.exists():
        raise SystemExit(f"refusing to overwrite existing experiment: {OUT}")
    OUT.mkdir(parents=True)
    manifest = {row["sample_id"]: row for row in read_rows(MANIFEST)}
    proposals = {row["sample_id"]: row for row in read_rows(PROPOSALS)}
    index = json.loads((CANDIDATE_ROOT / "index.json").read_text(encoding="utf-8"))
    helper.CANDIDATE_ROOT = CANDIDATE_ROOT
    pools = load_candidates(index, manifest)
    bases = []
    for number, sample_id in enumerate(sorted(manifest), start=1):
        record = manifest[sample_id]
        with np.load(POINTS / f"{sample_id.replace(':', '_')}.npz", allow_pickle=False) as payload:
            points = np.asarray(payload["cru"], dtype=np.float64)
            truth = np.asarray(payload["truth"], dtype=np.float64)
            reliability = np.asarray(payload["reliability"], dtype=np.float64)
        image_size = (int(record["width"]), int(record["height"]))
        boxes, _ = ensure_evaluation_box(points, make_boxes(proposals[sample_id], "proposals"), image_size)
        owners = owner_indices(points, boxes, image_size)
        candidate_xy, candidate_scores = pools[sample_id]
        candidate_owner = strict_candidate_owner(candidate_xy, boxes)
        inside = candidate_owner >= 0
        base = {
            "sample_id": sample_id,
            "group": str(record.get("capture_group_id") or sample_id),
            "points": points, "truth": truth, "reliability": reliability,
            "image_size": image_size, "scale": 1024.0 / max(image_size),
            "boxes": boxes, "owners": owners,
            "candidates": candidate_xy[inside],
            "candidate_scores": candidate_scores[inside],
            "candidate_owner": candidate_owner[inside],
        }
        base["candidate_evidence"] = candidate_evidence(base)
        base["close_pairs"] = close_pairs(base)
        base["base_pred_match"], _ = match_indices(
            points * base["scale"], truth * base["scale"], 8.0
        )
        base["baseline"] = {
            "stats": metrics.point_stats(points, truth, image_size),
            "scale_recall": metrics.scale_recall(points, truth, image_size),
            "diagnostic": {"deletions": 0},
        }
        base["candidate_cache"] = {
            (): {"stats": base["baseline"]["stats"], "scale_recall": base["baseline"]["scale_recall"]}
        }
        bases.append(base)
        if number % 30 == 0 or number == len(manifest):
            print(f"prepared {number}/{len(manifest)}", flush=True)

    screening = []
    selected = None
    for number, policy in enumerate(POLICIES, start=1):
        rows, report = evaluate(bases, policy)
        eligible = (
            report["deletions"] >= 5
            and report["deletion_precision_proxy"] >= 0.90
            and all(value >= 0 for value in report["f1_gain"].values())
            and report["count_mae_gain"] >= 0
        )
        report["eligible"] = bool(eligible)
        screening.append(report)
        if eligible:
            key = (
                report["deletion_precision_proxy"], report["competition_reduction"],
                report["f1_gain"]["8"], report["count_mae_gain"], -report["deletions"],
            )
            if selected is None or key > selected[0]:
                selected = (key, policy, rows, report)
        if number % 100 == 0 or number == len(POLICIES):
            print(f"screened {number}/{len(POLICIES)}", flush=True)

    if selected is None:
        summary = {"status": "NO_CONSERVATIVE_RULE", "policies": len(POLICIES)}
    else:
        _, policy, rows, report = selected
        summary = {
            "status": "CONSERVATIVE_RULE_FOUND",
            "policies": len(POLICIES), "eligible": sum(item["eligible"] for item in screening),
            "selected": report,
            "count_mae_gain_group_bootstrap_95_ci": paired_bootstrap(rows),
            "development_selected": True, "independent_confirmation": False,
            "sealed_test_used": False, "router_b_used": False,
        }
    atomic_json(OUT / "screening.json", screening)
    atomic_json(OUT / "summary.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
