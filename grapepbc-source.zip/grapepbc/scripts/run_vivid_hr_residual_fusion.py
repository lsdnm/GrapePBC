"""Train an LR-conditioned rich-HR residual count head with safe fallback."""

from __future__ import annotations

import argparse
from collections import defaultdict
from datetime import datetime, timezone
import csv
import json
import math
from pathlib import Path
import random
import sys
import time

import numpy as np
import torch
from torch.nn import functional as F

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

from geopriv.data.hash_utils import file_sha256
from geopriv.data.manifest import read_manifest
from geopriv.metrics import aggregate_count_metrics, maximum_cardinality_point_matches
from geopriv.models import ResidualCountHead, decode_residual_counts
from geopriv.routing import assign_points_to_tiles, make_core_halo_tiles


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def atomic_checkpoint(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(value, temporary)
    temporary.replace(path)


def seed_all(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def source_hashes() -> dict[str, str]:
    paths = (
        "scripts/run_vivid_hr_residual_fusion.py",
        "src/geopriv/models/residual_count_head.py",
        "src/geopriv/routing/counterfactual.py",
    )
    return {name: file_sha256(PROJECT / name) for name in paths}


def source_family(sample_id: str) -> str:
    name = sample_id.split(":", 1)[-1].lower()
    if name.startswith("immature"):
        return "immature"
    if name.startswith("img_20"):
        return "phone_timestamp"
    if name.startswith("img"):
        return "img_camera"
    if "dsc" in name:
        return "dsc_camera"
    if name.isdigit() and len(name) >= 12:
        return "numeric_timestamp"
    if name.isdigit():
        return "numeric_short"
    return "other"


def count_bin(count: int) -> str:
    if count <= 50:
        return "01_le50"
    if count <= 100:
        return "02_51to100"
    if count <= 200:
        return "03_101to200"
    return "04_gt200"


def prepare(args: argparse.Namespace) -> None:
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"non-empty output exists: {output}")
    output.mkdir(parents=True, exist_ok=True)
    calibration = args.calibration_run.resolve()
    calibration_protocol = json.loads((calibration / "protocol.json").read_text(encoding="utf-8"))
    calibration_summary = json.loads((calibration / "summary.json").read_text(encoding="utf-8"))
    if calibration_summary.get("status") != "COMPLETE_DEVELOPMENT_REVIEW_REQUIRED":
        raise ValueError("calibration run is incomplete")
    if calibration_summary.get("router_B_used") or calibration_summary.get("sealed_test_used"):
        raise ValueError("calibration run used a sealed role")
    train_lr = args.train_lr.resolve()
    train_lr_summary = json.loads((train_lr / "summary.json").read_text(encoding="utf-8"))
    if train_lr_summary.get("status") != "COMPLETE_EXPERT_A_ONLY":
        raise ValueError("Expert-A LR cache is incomplete")
    development_diagnosis = args.development_diagnosis.resolve()
    development_summary = json.loads((development_diagnosis / "summary.json").read_text(encoding="utf-8"))
    if development_summary.get("boundary") != "development-only diagnosis; no Router-B/test access and no weight update":
        raise ValueError("unexpected development diagnosis boundary")
    base_names = list(calibration_protocol["feature_names"])
    extra_names = (
        "log1p_lr_core_count",
        "log1p_lr_image_count",
        "lr_core_share",
        "log1p_hr_candidate_count",
    )
    protocol = {
        "version": "vivid-rich-hr-lr-conditioned-residual-v1",
        "status": "PREPARED",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "seed": 20261002,
        "calibration_run": str(calibration),
        "calibration_protocol_sha256": file_sha256(calibration / "protocol.json"),
        "calibration_checkpoint": str((calibration / "best_val_mae.pt").resolve()),
        "calibration_checkpoint_sha256": file_sha256(calibration / "best_val_mae.pt"),
        "train_feature_cache": str((calibration / "features" / "train").resolve()),
        "development_feature_cache": str((calibration / "features" / "development").resolve()),
        "train_lr_points": str((train_lr / "points").resolve()),
        "train_lr_summary": str((train_lr / "summary.json").resolve()),
        "train_lr_summary_sha256": file_sha256(train_lr / "summary.json"),
        "development_lr_points": str((development_diagnosis / "points").resolve()),
        "development_diagnosis_summary": str((development_diagnosis / "summary.json").resolve()),
        "development_diagnosis_summary_sha256": file_sha256(development_diagnosis / "summary.json"),
        "train_manifest": calibration_protocol["train_manifest"],
        "development_manifest": calibration_protocol["development_manifest"],
        "train_manifest_sha256": calibration_protocol["train_manifest_sha256"],
        "development_manifest_sha256": calibration_protocol["development_manifest_sha256"],
        "root": calibration_protocol["root"],
        "core_size": calibration_protocol["core_size"],
        "halo": calibration_protocol["halo"],
        "base_feature_dim": calibration_protocol["feature_dim"],
        "feature_names": base_names + list(extra_names),
        "feature_dim": len(base_names) + len(extra_names),
        "head": {
            "hidden_dim": 64,
            "bottleneck_dim": 32,
            "dropout": 0.10,
            "max_epochs": 100,
            "early_stop_patience": 15,
            "batch_size": 256,
            "learning_rate": 0.002,
            "weight_decay": 0.0001,
            "folds": 5,
            "dense_weight": "1 + log1p(core truth)/3, normalized per batch",
            "target": "signed true_core_count - enhanced_LR_core_count",
            "uncertainty": "predicted log1p absolute correction error",
        },
        "selection": {
            "head_epochs": "Expert-A grouped OOF image MAE",
            "fallback_threshold": "Expert-A OOF predicted-error quantiles; ties prefer fewer accepted replacements",
            "development_gate": "MAE < enhanced LR and F1@8 >= enhanced LR - 0.01",
        },
        "development_used_for_fitting": False,
        "router_B_used": False,
        "sealed_test_used": False,
        "source_sha256": source_hashes(),
    }
    atomic_json(output / "protocol.json", protocol)
    atomic_json(output / "stage.json", {"status": "PREPARED", "router_B_used": False, "sealed_test_used": False})
    print(json.dumps(protocol, ensure_ascii=False, indent=2))


def verify(output: Path) -> dict[str, object]:
    protocol = json.loads((output / "protocol.json").read_text(encoding="utf-8"))
    for name, expected in protocol["source_sha256"].items():
        if file_sha256(PROJECT / name) != expected:
            raise ValueError(f"source drift: {name}")
    checks = (
        ("calibration_checkpoint", "calibration_checkpoint_sha256"),
        ("train_lr_summary", "train_lr_summary_sha256"),
        ("development_diagnosis_summary", "development_diagnosis_summary_sha256"),
        ("train_manifest", "train_manifest_sha256"),
        ("development_manifest", "development_manifest_sha256"),
    )
    for path_key, hash_key in checks:
        if file_sha256(Path(protocol[path_key])) != protocol[hash_key]:
            raise ValueError(f"artifact drift: {path_key}")
    if protocol["router_B_used"] or protocol["sealed_test_used"]:
        raise ValueError("sealed roles are forbidden")
    return protocol


def load_lr_points(folder: Path, sample_id: str) -> np.ndarray:
    with np.load(folder / (sample_id.replace(":", "_") + ".npz"), allow_pickle=False) as payload:
        return payload["lr"].astype(np.float32)


def build_data(protocol: dict[str, object], split_name: str) -> dict[str, object]:
    if split_name == "train":
        manifest_path = Path(protocol["train_manifest"])
        cache_folder = Path(protocol["train_feature_cache"])
        lr_folder = Path(protocol["train_lr_points"])
    elif split_name == "development":
        manifest_path = Path(protocol["development_manifest"])
        cache_folder = Path(protocol["development_feature_cache"])
        lr_folder = Path(protocol["development_lr_points"])
    else:
        raise ValueError(split_name)
    records = {record.sample_id: record for record in read_manifest(manifest_path)}
    lr_by_core: dict[tuple[str, int], np.ndarray] = {}
    lr_totals: dict[str, int] = {}
    for sample_id, record in records.items():
        points = load_lr_points(lr_folder, sample_id)
        tiles = make_core_halo_tiles(
            record.width,
            record.height,
            core_size=int(protocol["core_size"]),
            halo=int(protocol["halo"]),
        )
        owners = assign_points_to_tiles(points, tiles, strict=False)
        if np.any(owners < 0):
            raise ValueError(f"LR point outside image partition: {sample_id}")
        lr_totals[sample_id] = len(points)
        for tile in tiles:
            lr_by_core[(sample_id, tile.tile_id)] = points[owners == tile.tile_id]

    features, targets, sample_ids, tile_ids = [], [], [], []
    candidates, lr_core_points = [], []
    for path in sorted(cache_folder.glob("*.npz")):
        with np.load(path, allow_pickle=False) as payload:
            sample_id = str(payload["sample_id"])
            tile_id = int(str(payload["tile_id"]))
            base = payload["feature"].astype(np.float32)
            candidate = payload["candidate_native_xy"].astype(np.float32)
            truth = int(payload["true_count"])
        low_points = lr_by_core[(sample_id, tile_id)]
        low_total = lr_totals[sample_id]
        low_count = len(low_points)
        extra = np.asarray(
            [
                math.log1p(low_count),
                math.log1p(low_total),
                low_count / max(low_total, 1),
                math.log1p(len(candidate)),
            ],
            dtype=np.float32,
        )
        features.append(np.concatenate((base, extra)))
        targets.append(truth)
        sample_ids.append(sample_id)
        tile_ids.append(tile_id)
        candidates.append(candidate)
        lr_core_points.append(low_points)
    if not features or len(set(sample_ids)) != len(records):
        raise ValueError(f"incomplete {split_name} fusion inputs")
    return {
        "features": np.stack(features).astype(np.float32),
        "target": np.asarray(targets, dtype=np.int64),
        "sample_ids": np.asarray(sample_ids),
        "tile_ids": np.asarray(tile_ids, dtype=np.int64),
        "candidates": candidates,
        "candidate_counts": np.asarray([len(value) for value in candidates], dtype=np.int64),
        "lr_core_points": lr_core_points,
        "lr_counts": np.asarray([len(value) for value in lr_core_points], dtype=np.int64),
        "records": records,
    }


def grouped_folds(sample_ids: np.ndarray, target: np.ndarray, folds: int, seed: int) -> np.ndarray:
    groups: dict[str, list[int]] = defaultdict(list)
    for index, sample_id in enumerate(sample_ids):
        groups[str(sample_id)].append(index)
    strata: dict[tuple[str, str], list[str]] = defaultdict(list)
    for sample_id, indices in groups.items():
        strata[(source_family(sample_id), count_bin(int(target[indices].sum())))].append(sample_id)
    rng = np.random.default_rng(seed)
    load = np.zeros(folds, dtype=np.int64)
    assignment = {}
    for key in sorted(strata):
        values = sorted(strata[key])
        rng.shuffle(values)
        for sample_id in values:
            fold = int(np.argmin(load))
            assignment[sample_id] = fold
            load[fold] += 1
    return np.asarray([assignment[str(value)] for value in sample_ids], dtype=np.int64)


def image_mae(prediction: np.ndarray, target: np.ndarray, sample_ids: np.ndarray) -> float:
    errors = []
    for sample_id in np.unique(sample_ids):
        chosen = sample_ids == sample_id
        errors.append(abs(int(prediction[chosen].sum()) - int(target[chosen].sum())))
    return float(np.mean(errors))


def decode_numpy(low: np.ndarray, delta: np.ndarray, candidate: np.ndarray) -> np.ndarray:
    return decode_residual_counts(
        torch.from_numpy(low), torch.from_numpy(delta), torch.from_numpy(candidate)
    ).numpy()


def head_instance(protocol: dict[str, object]) -> ResidualCountHead:
    return ResidualCountHead(
        int(protocol["feature_dim"]),
        int(protocol["head"]["hidden_dim"]),
        int(protocol["head"]["bottleneck_dim"]),
        float(protocol["head"]["dropout"]),
    )


def batch_loss(prediction: dict[str, torch.Tensor], truth: torch.Tensor, low: torch.Tensor) -> torch.Tensor:
    target_delta = truth - low
    dense_weight = 1.0 + torch.log1p(truth.clamp_min(0.0)) / 3.0
    dense_weight = dense_weight / dense_weight.mean().clamp_min(1e-6)
    regression = F.smooth_l1_loss(
        prediction["delta"], target_delta, beta=5.0, reduction="none"
    )
    residual = (prediction["delta"].detach() - target_delta).abs()
    uncertainty_target = torch.log1p(residual)
    uncertainty = F.smooth_l1_loss(
        prediction["log_error"], uncertainty_target, reduction="none"
    )
    return (dense_weight * regression).mean() + 0.20 * uncertainty.mean()


def train_fold(
    data: dict[str, object],
    train_indices: np.ndarray,
    val_indices: np.ndarray,
    protocol: dict[str, object],
    seed: int,
) -> dict[str, object]:
    seed_all(seed)
    features = data["features"]
    mean = features[train_indices].mean(axis=0).astype(np.float32)
    std = features[train_indices].std(axis=0).astype(np.float32)
    std[std < 1e-5] = 1.0
    normalized = ((features - mean) / std).astype(np.float32)
    device = torch.device("cuda")
    model = head_instance(protocol).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(protocol["head"]["learning_rate"]),
        weight_decay=float(protocol["head"]["weight_decay"]),
    )
    rng = np.random.default_rng(seed)
    best_key = (float("inf"), float("inf"))
    best_epoch = 0
    best_state = None
    best_outputs = None
    patience = 0
    history = []
    for epoch in range(1, int(protocol["head"]["max_epochs"]) + 1):
        model.train()
        order = train_indices.copy()
        rng.shuffle(order)
        losses = []
        for start in range(0, len(order), int(protocol["head"]["batch_size"])):
            chosen = order[start : start + int(protocol["head"]["batch_size"])]
            x = torch.from_numpy(normalized[chosen]).to(device)
            truth = torch.from_numpy(data["target"][chosen].astype(np.float32)).to(device)
            low = torch.from_numpy(data["lr_counts"][chosen].astype(np.float32)).to(device)
            prediction = model(x)
            loss = batch_loss(prediction, truth, low)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(float(loss.detach()))
        model.eval()
        with torch.inference_mode():
            prediction = model(torch.from_numpy(normalized[val_indices]).to(device))
        delta = prediction["delta"].cpu().numpy()
        error = np.expm1(np.clip(prediction["log_error"].cpu().numpy(), 0.0, 10.0))
        count = decode_numpy(data["lr_counts"][val_indices], delta, data["candidate_counts"][val_indices])
        key = (
            image_mae(count, data["target"][val_indices], data["sample_ids"][val_indices]),
            float(np.abs(count - data["target"][val_indices]).mean()),
        )
        history.append(
            {
                "epoch": epoch,
                "training_loss": float(np.mean(losses)),
                "validation_image_mae_all_accept": key[0],
                "validation_core_mae_all_accept": key[1],
            }
        )
        if key < best_key:
            best_key = key
            best_epoch = epoch
            best_state = {name: value.detach().cpu().clone() for name, value in model.state_dict().items()}
            best_outputs = (delta.copy(), error.copy())
            patience = 0
        else:
            patience += 1
        if patience >= int(protocol["head"]["early_stop_patience"]):
            break
    assert best_state is not None and best_outputs is not None
    return {
        "best_epoch": best_epoch,
        "best_image_mae": best_key[0],
        "best_core_mae": best_key[1],
        "delta": best_outputs[0],
        "predicted_error": best_outputs[1],
        "history": history,
    }


def fit_final(
    output: Path,
    protocol: dict[str, object],
    data: dict[str, object],
    epochs: int,
    fallback_threshold: float,
) -> dict[str, object]:
    seed_all(int(protocol["seed"]) + 900)
    features = data["features"]
    mean = features.mean(axis=0).astype(np.float32)
    std = features.std(axis=0).astype(np.float32)
    std[std < 1e-5] = 1.0
    normalized = ((features - mean) / std).astype(np.float32)
    model = head_instance(protocol).cuda()
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(protocol["head"]["learning_rate"]),
        weight_decay=float(protocol["head"]["weight_decay"]),
    )
    rng = np.random.default_rng(int(protocol["seed"]) + 900)
    history = []
    history_path = output / "history.jsonl"
    history_path.write_text("", encoding="utf-8")
    for epoch in range(1, epochs + 1):
        model.train()
        order = rng.permutation(len(features))
        losses = []
        for start in range(0, len(order), int(protocol["head"]["batch_size"])):
            chosen = order[start : start + int(protocol["head"]["batch_size"])]
            prediction = model(torch.from_numpy(normalized[chosen]).cuda())
            truth = torch.from_numpy(data["target"][chosen].astype(np.float32)).cuda()
            low = torch.from_numpy(data["lr_counts"][chosen].astype(np.float32)).cuda()
            loss = batch_loss(prediction, truth, low)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(float(loss.detach()))
        row = {"epoch": epoch, "training_loss": float(np.mean(losses))}
        history.append(row)
        checkpoint = {
            "epoch": epoch,
            "target_epochs": epochs,
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "feature_mean": mean,
            "feature_std": std,
            "feature_names": protocol["feature_names"],
            "fallback_error_threshold": fallback_threshold,
            "history": history,
            "protocol": protocol,
            "selection_source": "Expert-A grouped OOF only",
        }
        atomic_checkpoint(output / "last.pt", checkpoint)
        atomic_checkpoint(output / "best_val_mae.pt", checkpoint)
        atomic_json(
            output / "progress.json",
            {
                "status": "TRAINING_FINAL_RESIDUAL_HEAD",
                "last_completed_epoch": epoch,
                "requested_epochs": epochs,
                "router_B_used": False,
                "sealed_test_used": False,
            },
        )
        with history_path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(row) + "\n")
    return checkpoint


def predict(checkpoint: dict[str, object], data: dict[str, object]):
    normalized = ((data["features"] - checkpoint["feature_mean"]) / checkpoint["feature_std"]).astype(np.float32)
    model = head_instance(checkpoint["protocol"]).cuda()
    model.load_state_dict(checkpoint["model"], strict=True)
    model.eval()
    delta, error = [], []
    with torch.inference_mode():
        for start in range(0, len(normalized), 512):
            output = model(torch.from_numpy(normalized[start : start + 512]).cuda())
            delta.append(output["delta"].cpu().numpy())
            error.append(np.expm1(np.clip(output["log_error"].cpu().numpy(), 0.0, 10.0)))
    delta = np.concatenate(delta)
    error = np.concatenate(error)
    fused = decode_numpy(data["lr_counts"], delta, data["candidate_counts"])
    accepted = error <= float(checkpoint["fallback_error_threshold"])
    final = np.where(accepted, fused, data["lr_counts"])
    return final, fused, accepted, delta, error


def summarize(rows: list[dict[str, object]]) -> dict[str, object]:
    tp = sum(int(row["tp"]) for row in rows)
    fp = sum(int(row["fp"]) for row in rows)
    fn = sum(int(row["fn"]) for row in rows)
    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)
    return {
        "images": len(rows),
        **aggregate_count_metrics(
            [int(row["predicted_count"]) for row in rows],
            [int(row["true_count"]) for row in rows],
        ),
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "precision_at_8": precision,
        "recall_at_8": recall,
        "f1_at_8": 2 * precision * recall / max(precision + recall, 1e-12),
    }


def evaluate(output: Path, protocol: dict[str, object], checkpoint: dict[str, object], data: dict[str, object]) -> dict[str, object]:
    final, fused, accepted, delta, error = predict(checkpoint, data)
    pieces: dict[str, list[np.ndarray]] = defaultdict(list)
    core_rows = []
    for index in range(len(final)):
        if accepted[index]:
            points = data["candidates"][index][: int(final[index])]
        else:
            points = data["lr_core_points"][index]
        sample_id = str(data["sample_ids"][index])
        pieces[sample_id].append(points)
        core_rows.append(
            {
                "sample_id": sample_id,
                "tile_id": int(data["tile_ids"][index]),
                "true_count": int(data["target"][index]),
                "lr_count": int(data["lr_counts"][index]),
                "fused_count_before_fallback": int(fused[index]),
                "predicted_count": int(final[index]),
                "accepted": bool(accepted[index]),
                "predicted_delta": float(delta[index]),
                "predicted_absolute_error": float(error[index]),
            }
        )
    rows = []
    point_dir = output / "development_points"
    point_dir.mkdir(exist_ok=True)
    for sample_id in sorted(data["records"]):
        record = data["records"][sample_id]
        prediction = np.concatenate(pieces[sample_id]) if pieces[sample_id] else np.empty((0, 2), np.float32)
        truth = np.load(Path(protocol["root"]) / record.points_path, allow_pickle=False).astype(np.float32)
        scale = 1024.0 / max(record.width, record.height)
        tp, fp, fn = maximum_cardinality_point_matches(prediction * scale, truth * scale, 8.0)
        rows.append(
            {
                "sample_id": sample_id,
                "true_count": len(truth),
                "predicted_count": len(prediction),
                "absolute_error": abs(len(prediction) - len(truth)),
                "signed_error": len(prediction) - len(truth),
                "tp": tp,
                "fp": fp,
                "fn": fn,
                "source_family": source_family(sample_id),
                "count_bin": count_bin(len(truth)),
            }
        )
        np.savez_compressed(point_dir / (sample_id.replace(":", "_") + ".npz"), truth=truth, residual_fusion=prediction)
    metrics = summarize(rows)
    baseline = json.loads(Path(protocol["development_diagnosis_summary"]).read_text(encoding="utf-8"))["lr"]
    baseline_precision = baseline["tp"] / (baseline["tp"] + baseline["fp"])
    baseline_recall = baseline["tp"] / (baseline["tp"] + baseline["fn"])
    baseline_f1 = 2 * baseline_precision * baseline_recall / (baseline_precision + baseline_recall)
    gate = metrics["mae"] < baseline["mae"] and metrics["f1_at_8"] >= baseline_f1 - 0.01
    paired = []
    baseline_rows = {
        row["sample_id"]: row
        for row in json.loads(
            (Path(protocol["development_diagnosis_summary"]).parent / "per_image.json").read_text(encoding="utf-8")
        )
    }
    for row in rows:
        paired.append(row["absolute_error"] - baseline_rows[row["sample_id"]]["lr_absolute_error"])
    by_count: dict[str, list[dict[str, object]]] = defaultdict(list)
    by_source: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        by_count[row["count_bin"]].append(row)
        by_source[row["source_family"]].append(row)
    summary = {
        "status": "COMPLETE_DEVELOPMENT_REVIEW_REQUIRED",
        "development": metrics,
        "enhanced_lr": {**baseline, "f1_at_8": baseline_f1},
        "paired": {
            "mean_mae_difference_vs_lr": float(np.mean(paired)),
            "improved_images": int(sum(value < 0 for value in paired)),
            "worsened_images": int(sum(value > 0 for value in paired)),
            "ties": int(sum(value == 0 for value in paired)),
        },
        "by_count": {key: summarize(value) for key, value in sorted(by_count.items())},
        "by_source": {key: summarize(value) for key, value in sorted(by_source.items())},
        "accepted_core_replacements": int(accepted.sum()),
        "fallback_core_replacements": int((~accepted).sum()),
        "accepted_fraction": float(accepted.mean()),
        "promotion_gate_passed": bool(gate),
        "head_parameters": sum(value.numel() for value in checkpoint["model"].values()),
        "development_used_for_fitting": False,
        "router_B_used": False,
        "sealed_test_used": False,
        "claim_boundary": "post-development bounded repair; not independent evidence",
    }
    atomic_json(output / "development_summary.json", summary)
    atomic_json(output / "development_per_image.json", rows)
    with (output / "development_core_rows.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(core_rows[0]))
        writer.writeheader()
        writer.writerows(core_rows)
    return summary


def run(output: Path, protocol: dict[str, object]) -> None:
    smoke = json.loads((output / "engineering_smoke.json").read_text(encoding="utf-8"))
    if smoke.get("status") != "PASS":
        raise ValueError("passing smoke is required")
    train = build_data(protocol, "train")
    development = build_data(protocol, "development")
    if train["features"].shape[1] != int(protocol["feature_dim"]):
        raise ValueError("training feature dimension drift")
    folds = grouped_folds(train["sample_ids"], train["target"], int(protocol["head"]["folds"]), int(protocol["seed"]))
    oof_delta = np.zeros(len(train["target"]), dtype=np.float32)
    oof_error = np.zeros(len(train["target"]), dtype=np.float32)
    reports, best_epochs = [], []
    for fold in range(int(protocol["head"]["folds"])):
        train_indices = np.flatnonzero(folds != fold)
        val_indices = np.flatnonzero(folds == fold)
        result = train_fold(train, train_indices, val_indices, protocol, int(protocol["seed"]) + fold)
        oof_delta[val_indices] = result["delta"]
        oof_error[val_indices] = result["predicted_error"]
        best_epochs.append(int(result["best_epoch"]))
        reports.append(
            {
                "fold": fold,
                "best_epoch": result["best_epoch"],
                "best_image_mae_all_accept": result["best_image_mae"],
                "best_core_mae_all_accept": result["best_core_mae"],
                "history": result["history"],
            }
        )
        atomic_json(output / "oof_progress.json", {"status": "OOF_TRAINING", "completed_folds": fold + 1, "folds": 5})
    fused = decode_numpy(train["lr_counts"], oof_delta, train["candidate_counts"])
    finite = np.unique(np.quantile(oof_error, np.linspace(0.10, 1.00, 19)))
    # The maximum OOF-predicted error already represents accepting every
    # replacement, so no non-standard JSON Infinity sentinel is needed.
    thresholds = [float(value) for value in finite]
    threshold_rows = []
    for threshold in thresholds:
        accepted = oof_error <= threshold
        prediction = np.where(accepted, fused, train["lr_counts"])
        threshold_rows.append(
            {
                "threshold": threshold,
                "image_mae": image_mae(prediction, train["target"], train["sample_ids"]),
                "core_mae": float(np.abs(prediction - train["target"]).mean()),
                "accepted_fraction": float(accepted.mean()),
                "bias": float((prediction - train["target"]).mean()),
            }
        )
    selected = min(
        threshold_rows,
        key=lambda row: (row["image_mae"], row["core_mae"], row["accepted_fraction"], abs(row["bias"])),
    )
    final_epochs = max(1, int(round(float(np.median(best_epochs)))))
    oof_report = {
        "status": "COMPLETE_EXPERT_A_GROUPED_OOF",
        "folds": reports,
        "fallback_threshold_search": threshold_rows,
        "selected": selected,
        "best_epochs": best_epochs,
        "final_training_epochs": final_epochs,
        "development_used": False,
        "router_B_used": False,
        "sealed_test_used": False,
    }
    atomic_json(output / "expert_A_oof.json", oof_report)
    checkpoint = fit_final(output, protocol, train, final_epochs, float(selected["threshold"]))
    summary = evaluate(output, protocol, checkpoint, development)
    atomic_json(output / "summary.json", summary)
    atomic_json(output / "stage.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def smoke(output: Path, protocol: dict[str, object]) -> None:
    train = build_data(protocol, "train")
    development = build_data(protocol, "development")
    model = head_instance(protocol).cuda()
    with torch.inference_mode():
        prediction = model(torch.from_numpy(train["features"][:2]).cuda())
    decoded = decode_residual_counts(
        torch.from_numpy(train["lr_counts"][:2]),
        prediction["delta"].cpu(),
        torch.from_numpy(train["candidate_counts"][:2]),
    )
    report = {
        "status": "PASS",
        "train_images": len(np.unique(train["sample_ids"])),
        "train_cores": len(train["target"]),
        "development_images": len(np.unique(development["sample_ids"])),
        "development_cores": len(development["target"]),
        "feature_dim": train["features"].shape[1],
        "head_parameters": sum(parameter.numel() for parameter in model.parameters()),
        "decode_shape": list(decoded.shape),
        "train_truth_ownership_matches": bool(
            all(
                int(train["target"][train["sample_ids"] == sample_id].sum())
                == int(train["records"][sample_id].point_count)
                for sample_id in train["records"]
            )
        ),
        "development_truth_ownership_matches": bool(
            all(
                int(development["target"][development["sample_ids"] == sample_id].sum())
                == int(development["records"][sample_id].point_count)
                for sample_id in development["records"]
            )
        ),
        "router_B_used": False,
        "sealed_test_used": False,
    }
    if report["feature_dim"] != int(protocol["feature_dim"]):
        raise ValueError("feature dimension mismatch")
    if not report["train_truth_ownership_matches"] or not report["development_truth_ownership_matches"]:
        raise ValueError("truth ownership mismatch")
    atomic_json(output / "engineering_smoke.json", report)
    print(json.dumps(report, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("prepare", "smoke", "run"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--calibration-run", type=Path)
    parser.add_argument("--train-lr", type=Path)
    parser.add_argument("--development-diagnosis", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    if args.mode == "prepare":
        if args.calibration_run is None or args.train_lr is None or args.development_diagnosis is None:
            parser.error("prepare requires calibration and LR sources")
        prepare(args)
        return
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    torch.set_num_threads(4)
    protocol = verify(output)
    if args.mode == "smoke":
        smoke(output, protocol)
    else:
        run(output, protocol)


if __name__ == "__main__":
    main()
