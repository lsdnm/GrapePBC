"""Train a group-OOF high-precision duplicate-point action classifier.

Each example asks whether deleting one member of a close pair is safe.  A
positive label requires that the proposed deletion is the unmatched hypothesis
while the retained point is matched to the same nearby annotated berry.  The
runtime features contain only frozen point reliability, Rich-HR candidate
evidence, held-fold RGB semantic scores, and local geometry; labels are never
runtime inputs.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import asdict, dataclass
import json
from pathlib import Path
import sys

import joblib
import numpy as np
from scipy.spatial import cKDTree
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.model_selection import GroupKFold


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

import develop_cluster_aware_point_reallocation as helper  # noqa: E402
import develop_one_berry_one_point_v30 as metrics  # noqa: E402
import develop_v33_conservative_duplicate_deletion as geometry  # noqa: E402
from audit_vivid_error_taxonomy import match_indices  # noqa: E402
from develop_cluster_aware_point_reallocation import (  # noqa: E402
    ensure_evaluation_box, load_candidates, make_boxes, owner_indices,
    read_rows, strict_candidate_owner,
)
from run_vivid_hr_core_calibration import atomic_json, atomic_npz  # noqa: E402


EXP = PROJECT / "experiments" / "cru_detail_v1"
MANIFEST = EXP / "vivid_application_lr_repair_inputs_v1" / "development_val_clean.jsonl"
PROPOSALS = EXP / "vivid_stage6_border_safe_zero_filter_v28b" / "development_proposals.jsonl"
POINTS = EXP / "vivid_v4_v17_hybrid_center_gate_v18" / "oof_development_points"
CANDIDATE_ROOT = EXP / "vivid_application_development_density_core_points_v2"
SEMANTIC_ROOT = EXP / "vivid_semantic_duplicate_deletion_v34" / "oof_semantic_scores"
OUT = EXP / "vivid_oof_duplicate_action_classifier_v35"
SEED = 20261008


FEATURES = (
    "pair_distance_1024",
    "delete_reliability", "keep_reliability", "reliability_advantage",
    "delete_semantic", "keep_semantic", "semantic_advantage",
    "delete_support_distance", "keep_support_distance",
    "delete_candidate_score", "keep_candidate_score",
    "delete_nn2", "keep_nn2", "delete_nn3", "keep_nn3",
    "delete_local4", "keep_local4", "delete_local8", "keep_local8",
    "delete_local12", "keep_local12", "owner_points_log", "image_points_log",
)


@dataclass(frozen=True)
class RuntimePolicy:
    probability_threshold: float
    maximum_deletions: int
    maximum_pair_distance_1024: float = 6.0
    maximum_support_distance_1024: float = 5.0
    minimum_candidate_score: float = 0.075


POLICIES = tuple(
    RuntimePolicy(threshold, maximum)
    for threshold in (0.50, 0.60, 0.70, 0.80, 0.85, 0.90, 0.925, 0.95, 0.975, 0.99)
    for maximum in (1, 2, 3)
)


def local_geometry(points: np.ndarray, scale: float) -> tuple[np.ndarray, dict[int, np.ndarray]]:
    if len(points) < 2:
        nearest = np.full((len(points), 3), 64.0, np.float64)
    else:
        k = min(4, len(points))
        nearest = cKDTree(points * scale).query(points * scale, k=k)[0]
        if nearest.ndim == 1:
            nearest = nearest[:, None]
        padding = np.full((len(points), 4 - nearest.shape[1]), 64.0)
        nearest = np.concatenate((nearest, padding), axis=1)
    counts = {}
    tree = cKDTree(points * scale) if len(points) else None
    for radius in (4, 8, 12):
        counts[radius] = np.asarray(
            [len(value) - 1 for value in tree.query_ball_point(points * scale, radius)] if tree else [],
            dtype=np.float64,
        )
    return nearest, counts


def action_features(base: dict, delete: int, keep: int, distance: float) -> np.ndarray:
    nearest_candidate, support_distance, candidate_score = base["candidate_evidence"]
    nearest = base["point_nearest"]
    counts = base["local_counts"]
    owner_count = int(np.count_nonzero(base["owners"] == base["owners"][delete]))
    values = (
        distance,
        base["reliability"][delete], base["reliability"][keep],
        base["reliability"][keep] - base["reliability"][delete],
        base["semantic_score"][delete], base["semantic_score"][keep],
        base["semantic_score"][keep] - base["semantic_score"][delete],
        support_distance[delete], support_distance[keep],
        candidate_score[delete], candidate_score[keep],
        nearest[delete, 2], nearest[keep, 2], nearest[delete, 3], nearest[keep, 3],
        counts[4][delete], counts[4][keep], counts[8][delete], counts[8][keep],
        counts[12][delete], counts[12][keep], np.log1p(owner_count), np.log1p(len(base["points"])),
    )
    result = np.asarray(values, np.float32)
    if len(result) != len(FEATURES) or not np.isfinite(result).all():
        raise RuntimeError("invalid action feature")
    return result


def make_actions(base: dict) -> list[dict]:
    truth = base["truth"] * base["scale"]
    points = base["points"] * base["scale"]
    pred_match, _ = match_indices(points, truth, 8.0)
    truth_tree = cKDTree(truth) if len(truth) else None
    nearest_truth = truth_tree.query(points)[1] if truth_tree else np.full(len(points), -1)
    candidate_index, support_distance, candidate_score = base["candidate_evidence"]
    actions = []
    for distance, first, second in base["close_pairs"]:
        if distance > 6.0:
            continue
        if candidate_index[first] < 0 or candidate_index[first] != candidate_index[second]:
            continue
        if max(support_distance[first], support_distance[second]) > 5.0:
            continue
        if min(candidate_score[first], candidate_score[second]) < 0.075:
            continue
        same_truth = nearest_truth[first] >= 0 and nearest_truth[first] == nearest_truth[second]
        for delete, keep in ((first, second), (second, first)):
            label = bool(same_truth and pred_match[delete] < 0 and pred_match[keep] >= 0)
            actions.append({
                "sample_id": base["sample_id"], "group": base["group"],
                "delete": int(delete), "keep": int(keep), "distance": float(distance),
                "features": action_features(base, delete, keep, distance), "label": int(label),
            })
    return actions


def classifier(seed: int) -> ExtraTreesClassifier:
    return ExtraTreesClassifier(
        n_estimators=400, max_depth=10, min_samples_leaf=2,
        max_features=0.8, class_weight="balanced", n_jobs=-1,
        random_state=seed,
    )


def apply_policy(base: dict, actions: list[dict], scores: np.ndarray,
                 policy: RuntimePolicy) -> tuple[np.ndarray, dict]:
    ranked = sorted(
        ((float(score), action) for score, action in zip(scores, actions)
         if float(score) >= policy.probability_threshold),
        key=lambda value: (-value[0], value[1]["distance"], value[1]["delete"]),
    )
    deleted: set[int] = set(); protected: set[int] = set(); rows = []
    for score, action in ranked:
        if len(deleted) >= policy.maximum_deletions:
            break
        delete, keep = action["delete"], action["keep"]
        if delete in deleted or keep in deleted or delete in protected:
            continue
        deleted.add(delete); protected.add(keep)
        rows.append({
            "deleted_index": delete, "kept_index": keep,
            "probability": score, "pair_distance_1024": action["distance"],
        })
    mask = np.ones(len(base["points"]), bool)
    if deleted:
        mask[np.fromiter(sorted(deleted), dtype=np.int64)] = False
    return base["points"][mask], {"deletions": len(deleted), "rows": rows, "mask": mask}


def evaluate(bases: list[dict], actions_by_id: dict[str, list[dict]],
             scores_by_id: dict[str, np.ndarray], policy: RuntimePolicy) -> tuple[list[dict], dict]:
    rows = []; correct = wrong = 0
    for base in bases:
        actions = actions_by_id[base["sample_id"]]
        scores = scores_by_id.get(base["sample_id"], np.empty(0, np.float64))
        output, diagnostic = apply_policy(base, actions, scores, policy)
        deleted = np.flatnonzero(~diagnostic["mask"])
        correct += int(np.count_nonzero(base["base_pred_match"][deleted] < 0))
        wrong += int(np.count_nonzero(base["base_pred_match"][deleted] >= 0))
        signature = tuple(int(value) for value in deleted)
        if signature not in base["candidate_cache"]:
            base["candidate_cache"][signature] = {
                "stats": metrics.point_stats(output, base["truth"], base["image_size"]),
                "scale_recall": metrics.scale_recall(output, base["truth"], base["image_size"]),
            }
        candidate = {**base["candidate_cache"][signature], "diagnostic": diagnostic}
        rows.append({
            "sample_id": base["sample_id"], "group": base["group"],
            "baseline": base["baseline"], "candidate": candidate,
            "baseline_error": abs(len(base["points"]) - len(base["truth"])),
            "candidate_error": abs(len(output) - len(base["truth"])),
        })
    baseline = metrics.aggregate(rows, "baseline"); candidate = metrics.aggregate(rows, "candidate")
    before = float(np.mean([row["baseline_error"] for row in rows])); after = float(np.mean([row["candidate_error"] for row in rows]))
    return rows, {
        "policy": asdict(policy), "baseline": baseline, "candidate": candidate,
        "deletions": int(sum(row["candidate"]["diagnostic"]["deletions"] for row in rows)),
        "images_changed": int(sum(row["candidate"]["diagnostic"]["deletions"] > 0 for row in rows)),
        "unmatched_deleted": correct, "matched_deleted": wrong,
        "deletion_precision_proxy": float(correct / max(correct + wrong, 1)),
        "count_mae_before": before, "count_mae_after": after, "count_mae_gain": before - after,
        "f1_gain": {key: candidate["f1"][key] - baseline["f1"][key] for key in baseline["f1"]},
        "competition_reduction": baseline["competition_unmatched_within8"] - candidate["competition_unmatched_within8"],
        "collision_reduction": {key: baseline["collision_pairs"][key] - candidate["collision_pairs"][key] for key in baseline["collision_pairs"]},
    }


def paired_bootstrap(rows: list[dict], draws: int = 10000) -> dict:
    groups: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(rows): groups[row["group"]].append(index)
    buckets = [np.asarray(value, np.int64) for value in groups.values()]
    rng = np.random.default_rng(SEED); count = np.empty(draws); f1 = {key: np.empty(draws) for key in ("4", "8", "16")}
    for draw in range(draws):
        selected = rng.integers(0, len(buckets), len(buckets)); indices = np.concatenate([buckets[i] for i in selected])
        count[draw] = np.mean([rows[i]["baseline_error"] - rows[i]["candidate_error"] for i in indices])
        for radius in f1:
            before = np.sum([rows[i]["baseline"]["stats"]["triples"][radius] for i in indices], axis=0)
            after = np.sum([rows[i]["candidate"]["stats"]["triples"][radius] for i in indices], axis=0)
            f1[radius][draw] = metrics.f1(after) - metrics.f1(before)
    return {
        "count_mae_gain_95_ci": np.quantile(count, (0.025, 0.975)).tolist(),
        "f1_gain_95_ci": {key: np.quantile(value, (0.025, 0.975)).tolist() for key, value in f1.items()},
    }


def main() -> None:
    if OUT.exists(): raise SystemExit(f"refusing to overwrite existing experiment: {OUT}")
    OUT.mkdir(parents=True)
    records = read_rows(MANIFEST); manifest = {row["sample_id"]: row for row in records}
    proposals = {row["sample_id"]: row for row in read_rows(PROPOSALS)}
    index = json.loads((CANDIDATE_ROOT / "index.json").read_text(encoding="utf-8"))
    helper.CANDIDATE_ROOT = CANDIDATE_ROOT; pools = load_candidates(index, manifest)
    bases = []
    for number, sample_id in enumerate(sorted(manifest), start=1):
        record = manifest[sample_id]
        with np.load(POINTS / f"{sample_id.replace(':', '_')}.npz", allow_pickle=False) as payload:
            points = np.asarray(payload["cru"], np.float64); truth = np.asarray(payload["truth"], np.float64); reliability = np.asarray(payload["reliability"], np.float64)
        semantic = np.load(SEMANTIC_ROOT / f"{sample_id.replace(':', '_')}.npz", allow_pickle=False)["score"].astype(np.float64)
        image_size = (int(record["width"]), int(record["height"])); scale = 1024.0 / max(image_size)
        boxes, _ = ensure_evaluation_box(points, make_boxes(proposals[sample_id], "proposals"), image_size)
        owners = owner_indices(points, boxes, image_size); candidate_xy, candidate_scores = pools[sample_id]
        candidate_owner = strict_candidate_owner(candidate_xy, boxes); inside = candidate_owner >= 0
        point_nearest, local_counts = local_geometry(points, scale)
        base = {
            "sample_id": sample_id, "group": str(record.get("capture_group_id") or sample_id),
            "points": points, "truth": truth, "reliability": reliability, "semantic_score": semantic,
            "image_size": image_size, "scale": scale, "boxes": boxes, "owners": owners,
            "candidates": candidate_xy[inside], "candidate_scores": candidate_scores[inside], "candidate_owner": candidate_owner[inside],
            "point_nearest": point_nearest, "local_counts": local_counts,
        }
        base["candidate_evidence"] = geometry.candidate_evidence(base); base["close_pairs"] = geometry.close_pairs(base)
        base["base_pred_match"], _ = match_indices(points * scale, truth * scale, 8.0)
        base["baseline"] = {"stats": metrics.point_stats(points, truth, image_size), "scale_recall": metrics.scale_recall(points, truth, image_size), "diagnostic": {"deletions": 0}}
        base["candidate_cache"] = {(): {"stats": base["baseline"]["stats"], "scale_recall": base["baseline"]["scale_recall"]}}
        bases.append(base)
        if number % 30 == 0 or number == len(manifest): print(f"prepared {number}/{len(manifest)}", flush=True)

    actions_by_id = {base["sample_id"]: make_actions(base) for base in bases}
    flat = [action for base in bases for action in actions_by_id[base["sample_id"]]]
    x = np.stack([action["features"] for action in flat]); y = np.asarray([action["label"] for action in flat], np.int64)
    groups = np.asarray([action["group"] for action in flat]); oof = np.zeros(len(flat), np.float64)
    for fold, (train, held) in enumerate(GroupKFold(5).split(x, y, groups)):
        model = classifier(SEED + fold); model.fit(x[train], y[train]); oof[held] = model.predict_proba(x[held])[:, 1]
        joblib.dump(model, OUT / f"fold_{fold}.joblib"); print(f"trained fold {fold}", flush=True)
    final_model = classifier(SEED + 100); final_model.fit(x, y); joblib.dump(final_model, OUT / "full_refit.joblib")
    score_by_id: dict[str, list[float]] = defaultdict(list)
    for action, score in zip(flat, oof): score_by_id[action["sample_id"]].append(float(score))
    score_by_id_np = {key: np.asarray(value, np.float64) for key, value in score_by_id.items()}
    atomic_json(OUT / "oof_action_scores.json", [
        {
            "sample_id": action["sample_id"], "group": action["group"],
            "delete": action["delete"], "keep": action["keep"],
            "distance": action["distance"], "label": action["label"],
            "score": float(score),
            "features": {name: float(value) for name, value in zip(FEATURES, action["features"])},
        }
        for action, score in zip(flat, oof)
    ])

    screening = []; selected = None
    for policy in POLICIES:
        rows, report = evaluate(bases, actions_by_id, score_by_id_np, policy)
        eligible = (report["deletions"] >= 5 and report["deletion_precision_proxy"] >= 0.90
                    and all(value >= 0 for value in report["f1_gain"].values()) and report["count_mae_gain"] >= 0)
        report["eligible"] = bool(eligible); screening.append(report)
        if eligible:
            key = (report["deletion_precision_proxy"], report["competition_reduction"], report["f1_gain"]["8"], report["count_mae_gain"], -report["deletions"])
            if selected is None or key > selected[0]: selected = (key, policy, rows, report)
    if selected is None:
        summary = {"status": "NO_HIGH_PRECISION_OOF_RULE", "actions": len(flat), "positives": int(y.sum()), "policies": len(POLICIES)}
    else:
        _, policy, rows, report = selected; point_root = OUT / "oof_development_points"; per_image = []
        for base in bases:
            output, diagnostic = apply_policy(
                base,
                actions_by_id[base["sample_id"]],
                score_by_id_np.get(base["sample_id"], np.empty(0, np.float64)),
                policy,
            )
            mask = diagnostic["mask"]
            atomic_npz(point_root / f"{base['sample_id'].replace(':', '_')}.npz", cru=output.astype(np.float32), truth=base["truth"].astype(np.float32), reliability=base["reliability"][mask].astype(np.float32))
            per_image.append({"sample_id": base["sample_id"], "diagnostic": {k: v for k, v in diagnostic.items() if k != "mask"}})
        atomic_json(OUT / "per_image.json", per_image)
        summary = {
            "status": "HIGH_PRECISION_OOF_RULE_FOUND", "actions": len(flat), "positives": int(y.sum()), "policies": len(POLICIES),
            "selected": report, "bootstrap": paired_bootstrap(rows), "feature_names": list(FEATURES),
            "point_cache": str(point_root.resolve()), "development_selected": True,
            "independent_confirmation": False, "sealed_test_used": False, "router_b_used": False,
        }
    atomic_json(OUT / "screening.json", screening); atomic_json(OUT / "summary.json", summary)
    atomic_json(OUT / "protocol.json", {
        "version": "vivid-oof-duplicate-action-classifier-v35", "features": list(FEATURES),
        "classifier": "ExtraTrees; group-OOF development evaluation; full-data refit retained for future unseen inference",
        "source": "frozen V29/V18 points", "action": "delete only; never relocate",
        "development_selected": True, "independent_confirmation": False,
        "annotations_used_at_runtime": False, "sealed_test_used": False,
    })
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__": main()
