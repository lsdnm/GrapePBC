"""Fine-tune a crop-scale local expert for CRU core/halo inference."""

from __future__ import annotations

import argparse
from contextlib import nullcontext
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import random
import sys
import time
from typing import Iterator, Sequence

import numpy as np
import torch
from torch.utils.data import DataLoader, Sampler


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from evaluate_geopriv import _load_checkpoint, restore_model
from train_geopriv import incremental_match_table, select_validation_metrics, threshold_grid
from geopriv.data import CRUContextCropDataset, collate_cru_crops
from geopriv.metrics import aggregate_count_metrics
from geopriv.models import decode_points
from geopriv.training import GeoPrivLossWeights, build_geopriv_targets, geopriv_loss


class ImageGroupedSampler(Sampler[int]):
    """Shuffle source images while keeping their tiles adjacent for I/O reuse."""

    def __init__(self, dataset: CRUContextCropDataset, seed: int) -> None:
        self.dataset = dataset
        self.seed = int(seed)
        self.epoch = 0
        groups: dict[int, list[int]] = {}
        for item_index, (record_index, _tile) in enumerate(dataset.items):
            groups.setdefault(record_index, []).append(item_index)
        self.groups = tuple(tuple(groups[key]) for key in sorted(groups))

    def set_epoch(self, epoch: int) -> None:
        self.epoch = int(epoch)

    def __iter__(self) -> Iterator[int]:
        generator = np.random.default_rng(
            np.random.SeedSequence([self.seed & 0xFFFFFFFF, self.epoch])
        )
        for group_index in generator.permutation(len(self.groups)):
            yield from self.groups[int(group_index)]

    def __len__(self) -> int:
        return len(self.dataset)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Train an A0-initialized local expert on virtual CRU crops."
    )
    parser.add_argument("--initial-checkpoint", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--resume",
        type=Path,
        help="Resume model/optimizer/scaler and best validation state from a local-expert checkpoint.",
    )
    parser.add_argument("--train-split", default="train")
    parser.add_argument("--val-split", default="val")
    parser.add_argument(
        "--diagnostic-train-reuse",
        action="store_true",
        help="Required when train and validation splits are identical.",
    )
    parser.add_argument("--max-train-images", type=int)
    parser.add_argument("--max-val-images", type=int)
    parser.add_argument("--image-size", type=int, default=768)
    parser.add_argument("--core-size", type=int, default=1024)
    parser.add_argument("--halo", type=int, default=128)
    parser.add_argument("--epochs", type=int, default=40)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--gradient-clip", type=float, default=5.0)
    parser.add_argument("--eval-every", type=int, default=5)
    parser.add_argument("--seed", type=int, default=20260918)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--no-amp", action="store_true")
    parser.add_argument("--gaussian-radius", type=int, default=1)
    parser.add_argument("--threshold-start", type=float, default=0.05)
    parser.add_argument("--threshold-stop", type=float, default=0.95)
    parser.add_argument("--threshold-step", type=float, default=0.02)
    parser.add_argument("--match-radius", type=float, default=8.0)
    parser.add_argument("--local-max-kernel", type=int, default=3)
    parser.add_argument("--topk", type=int, default=4096)
    return parser


def _validate_args(parser: argparse.ArgumentParser, args: argparse.Namespace) -> None:
    for name in (
        "image_size",
        "core_size",
        "epochs",
        "batch_size",
        "eval_every",
        "local_max_kernel",
        "topk",
    ):
        if getattr(args, name) <= 0:
            parser.error(f"--{name.replace('_', '-')} must be positive")
    if args.halo < 0 or args.num_workers < 0 or args.gaussian_radius < 0:
        parser.error("halo, num-workers and gaussian-radius must be non-negative")
    if args.learning_rate <= 0 or args.weight_decay < 0 or args.gradient_clip < 0:
        parser.error("invalid optimizer settings")
    if args.local_max_kernel % 2 == 0:
        parser.error("--local-max-kernel must be odd")
    if args.train_split == args.val_split and not args.diagnostic_train_reuse:
        parser.error(
            "identical train/val splits require --diagnostic-train-reuse; "
            "such a run cannot become a formal checkpoint"
        )
    for name in ("max_train_images", "max_val_images"):
        value = getattr(args, name)
        if value is not None and value <= 0:
            parser.error(f"--{name.replace('_', '-')} must be positive")
    threshold_grid(args.threshold_start, args.threshold_stop, args.threshold_step)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _atomic_torch_save(payload: dict[str, object], path: Path) -> None:
    """Write a checkpoint atomically so interruption cannot corrupt the last good file."""

    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temporary)
    temporary.replace(path)


def _atomic_json_write(payload: dict[str, object], path: Path) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, default=str) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def _seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


@torch.inference_mode()
def evaluate_local_expert(
    model: torch.nn.Module,
    loader: DataLoader,
    device: torch.device,
    thresholds: Sequence[float],
    *,
    matching_radius: float,
    local_max_kernel: int,
    topk: int,
) -> dict[str, dict[str, object]]:
    """Select a decoder using whole-source-image count metrics."""

    if not thresholds:
        raise ValueError("threshold grid cannot be empty")
    was_training = model.training
    model.eval()
    minimum_threshold = min(thresholds)
    tile_tables: list[tuple[str, dict[float, tuple[int, int]], int]] = []
    for batch in loader:
        images = batch["images"].to(device, non_blocking=True)
        masks = batch["valid_image_masks"].to(device, non_blocking=True)
        outputs = model(images, masks)  # type: ignore[call-arg]
        predictions = decode_points(
            outputs,
            score_threshold=minimum_threshold,
            topk=topk,
            local_max_kernel=local_max_kernel,
            output_stride=model.output_stride,
        )
        for prediction, target in zip(predictions, batch["targets"], strict=True):
            points = prediction["points"].detach().cpu().numpy()
            scores = prediction["scores"].detach().cpu().numpy()
            x0, y0, x1, y1 = target["core_bounds_xyxy"].numpy().tolist()
            owned = (
                (points[:, 0] >= x0)
                & (points[:, 0] < x1)
                & (points[:, 1] >= y0)
                & (points[:, 1] < y1)
            )
            core_points = points[owned]
            core_scores = scores[owned]
            truth = target["core_points_xy"].numpy()
            table = incremental_match_table(
                core_points,
                core_scores,
                truth,
                thresholds,
                matching_radius,
            )
            tile_tables.append((str(target["sample_id"]), table, len(truth)))

    candidates: list[dict[str, object]] = []
    for threshold in thresholds:
        per_image_prediction: dict[str, int] = {}
        per_image_truth: dict[str, int] = {}
        true_positive = false_positive = false_negative = 0
        for sample_id, table, target_count in tile_tables:
            tp, prediction_count = table[float(threshold)]
            per_image_prediction[sample_id] = (
                per_image_prediction.get(sample_id, 0) + prediction_count
            )
            per_image_truth[sample_id] = per_image_truth.get(sample_id, 0) + target_count
            true_positive += tp
            false_positive += prediction_count - tp
            false_negative += target_count - tp
        sample_ids = sorted(per_image_truth)
        count_metrics = aggregate_count_metrics(
            [per_image_prediction.get(sample_id, 0) for sample_id in sample_ids],
            [per_image_truth[sample_id] for sample_id in sample_ids],
        )
        precision = true_positive / max(true_positive + false_positive, 1)
        recall = true_positive / max(true_positive + false_negative, 1)
        f1 = 2 * precision * recall / max(precision + recall, 1e-12)
        candidates.append(
            {
                "threshold": float(threshold),
                **count_metrics,
                "precision_at_8": precision,
                "recall_at_8": recall,
                "f1_at_8": f1,
                "true_positive": true_positive,
                "false_positive": false_positive,
                "false_negative": false_negative,
                "samples": len(sample_ids),
                "tiles": len(tile_tables),
                "threshold_source": "validation_only",
                "count_aggregation": "sum_non_overlapping_core_owned_predictions",
            }
        )
    if was_training:
        model.train()
    return select_validation_metrics(candidates)


def _checkpoint_payload(
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    scaler: torch.amp.GradScaler,
    *,
    args: argparse.Namespace,
    epoch: int,
    validation: dict[str, object],
    initial_checkpoint: Path,
    manifest: Path,
) -> dict[str, object]:
    formal = not args.diagnostic_train_reuse
    threshold = float(validation["threshold"])
    return {
        "schema_version": 3,
        "model": model.state_dict(),
        "optimizer": optimizer.state_dict(),
        "scaler": scaler.state_dict(),
        "epoch": epoch,
        "config": {
            **vars(args),
            "image_size": args.image_size,
            "match_radius": args.match_radius,
            "local_max_kernel": args.local_max_kernel,
            "topk": args.topk,
        },
        "model_config": {
            "fpn_channels": model.encoder.lateral2.out_channels,  # type: ignore[attr-defined]
            "decoder_norm": model.encoder.decoder_norm,  # type: ignore[attr-defined]
            "freeze_backbone_bn": model.encoder.freeze_backbone_bn,  # type: ignore[attr-defined]
        },
        "output_stride": model.output_stride,
        "selected_threshold": threshold,
        "threshold_selection": {
            "source": "validation_only" if formal else "diagnostic_train_reuse",
            "validation_epoch": epoch,
            "frozen_for_checkpoint": formal,
            "objective": "mae",
        },
        "decoder_config": {
            "count_mode": "peak_threshold",
            "score_threshold": threshold,
            "local_max_kernel": args.local_max_kernel,
            "topk": args.topk,
            "candidate_score_floor": 1e-6,
            "density_rounding": "half_up_nonnegative",
            "valid_region": "valid_image_mask_projected_with_adaptive_max_pool",
            "output_stride": model.output_stride,
            "frozen_for_checkpoint": formal,
            "validation_epoch": epoch,
            "selection_objective": "mae",
            "threshold_source": (
                "validation_only" if formal else "diagnostic_train_reuse"
            ),
        },
        "validation_metrics": dict(validation),
        "selection": "minimum_source_image_validation_mae",
        "training_role": "CRU_crop_scale_local_expert",
        "crop_protocol": {
            "core_size": args.core_size,
            "halo": args.halo,
            "all_context_points_supervised": True,
            "only_core_predictions_owned": True,
        },
        "provenance": {
            "initial_checkpoint": str(initial_checkpoint),
            "initial_checkpoint_sha256": _sha256(initial_checkpoint),
            "manifest": str(manifest),
            "manifest_sha256": _sha256(manifest),
            "test_split_opened": False,
            "formal": formal,
        },
    }


def main(argv: Sequence[str] | None = None) -> dict[str, object]:
    parser = build_parser()
    args = parser.parse_args(argv)
    _validate_args(parser, args)
    _seed_everything(args.seed)
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise SystemExit("CUDA is unavailable")
    initial_path = args.initial_checkpoint.resolve()
    manifest_path = args.manifest.resolve()
    root = args.root.resolve()
    args.output = args.output.resolve()
    args.output.mkdir(parents=True, exist_ok=True)

    train_dataset = CRUContextCropDataset(
        manifest_path,
        root,
        split=args.train_split,
        image_size=args.image_size,
        core_size=args.core_size,
        halo=args.halo,
        max_images=args.max_train_images,
        cache_images=2,
    )
    val_dataset = CRUContextCropDataset(
        manifest_path,
        root,
        split=args.val_split,
        image_size=args.image_size,
        core_size=args.core_size,
        halo=args.halo,
        max_images=args.max_val_images,
        cache_images=2,
    )
    sampler = ImageGroupedSampler(train_dataset, args.seed)
    loader_options = {
        "num_workers": args.num_workers,
        "collate_fn": collate_cru_crops,
        "pin_memory": device.type == "cuda",
        "persistent_workers": False,
    }
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        sampler=sampler,
        **loader_options,
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        **loader_options,
    )

    initial_checkpoint = _load_checkpoint(initial_path)
    resume_checkpoint: dict[str, object] | None = None
    start_epoch = 1
    if args.resume is not None:
        resume_path = args.resume.resolve()
        loaded_resume = _load_checkpoint(resume_path)
        resume_checkpoint = dict(loaded_resume)
        stored_config = loaded_resume.get("config")
        if isinstance(stored_config, dict):
            for name in ("image_size", "core_size", "halo", "train_split", "val_split"):
                if name in stored_config and stored_config[name] != getattr(args, name):
                    raise ValueError(
                        f"resume configuration mismatch for {name}: "
                        f"checkpoint={stored_config[name]!r}, current={getattr(args, name)!r}"
                    )
        start_epoch = int(loaded_resume.get("epoch", 0)) + 1
        if start_epoch > args.epochs:
            raise SystemExit(
                f"resume checkpoint is already at epoch {start_epoch - 1}, "
                f"but --epochs={args.epochs}"
            )
        model, model_kind, model_config = restore_model(loaded_resume, "auto")
    else:
        model, model_kind, model_config = restore_model(initial_checkpoint, "auto")
    if model_kind not in {"litepoint", "geopriv"}:
        raise ValueError(f"unsupported initial model kind: {model_kind}")
    model = model.to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay
    )
    amp_enabled = device.type == "cuda" and not args.no_amp
    scaler = torch.amp.GradScaler(device.type, enabled=amp_enabled)
    weights = GeoPrivLossWeights(
        center=1.0,
        offset=1.0,
        radius=0.0,
        density=0.0,
        count_conservation=0.0,
    )
    thresholds = threshold_grid(
        args.threshold_start, args.threshold_stop, args.threshold_step
    )
    if resume_checkpoint is not None:
        if "optimizer" in resume_checkpoint:
            optimizer.load_state_dict(resume_checkpoint["optimizer"])
        if "scaler" in resume_checkpoint:
            scaler.load_state_dict(resume_checkpoint["scaler"])
        stored_validation = resume_checkpoint.get("validation_metrics")
        if not isinstance(stored_validation, dict):
            raise ValueError("resume checkpoint has no validation_metrics")
        best_metrics = dict(stored_validation)
        best_epoch = int(
            resume_checkpoint.get("best_epoch", resume_checkpoint.get("epoch", 0))
        )
        initial_validation = {
            "f1": dict(best_metrics),
            "mae": dict(best_metrics),
        }
        print(
            f"resuming local expert from {args.resume.resolve()} at epoch {start_epoch}",
            flush=True,
        )
    else:
        initial_validation = evaluate_local_expert(
            model,
            val_loader,
            device,
            thresholds,
            matching_radius=args.match_radius,
            local_max_kernel=args.local_max_kernel,
            topk=args.topk,
        )
        best_metrics = dict(initial_validation["mae"])
        best_epoch = 0
        _atomic_torch_save(
            _checkpoint_payload(
                model,
                optimizer,
                scaler,
                args=args,
                epoch=0,
                validation=best_metrics,
                initial_checkpoint=initial_path,
                manifest=manifest_path,
            ),
            args.output / "best_val_mae.pt",
        )

    history_rows: list[dict[str, object]] = []
    started = time.monotonic()
    history_path = args.output / "history.jsonl"
    history_mode = "a" if resume_checkpoint is not None and history_path.exists() else "w"
    with history_path.open(history_mode, encoding="utf-8") as history:
        for epoch in range(start_epoch, args.epochs + 1):
            sampler.set_epoch(epoch)
            model.train()
            totals = {"loss": 0.0, "center_loss": 0.0, "offset_loss": 0.0}
            collisions = valid_points = 0
            for batch in train_loader:
                images = batch["images"].to(device, non_blocking=True)
                masks = batch["valid_image_masks"].to(device, non_blocking=True)
                optimizer.zero_grad(set_to_none=True)
                context = (
                    torch.amp.autocast(device_type=device.type, dtype=torch.float16)
                    if amp_enabled
                    else nullcontext()
                )
                with context:
                    outputs = model(images, masks)  # type: ignore[call-arg]
                    cpu_targets = build_geopriv_targets(
                        [target["points_xy"] for target in batch["targets"]],
                        output_height=outputs["center_logits"].shape[-2],
                        output_width=outputs["center_logits"].shape[-1],
                        stride=model.output_stride,
                        gaussian_radius=args.gaussian_radius,
                        density_sigma=1.0,
                        equivalent_radius=[None] * len(batch["targets"]),
                        frame_boundary_completeness=[None] * len(batch["targets"]),
                        geometry_available=[False] * len(batch["targets"]),
                        valid_image_mask=batch["valid_image_masks"],
                        device="cpu",
                    )
                    targets = {
                        name: value.to(device, non_blocking=True)
                        for name, value in cpu_targets.items()
                    }
                    losses = geopriv_loss(outputs, targets, weights=weights)
                if not torch.isfinite(losses["loss"]):
                    raise FloatingPointError(f"non-finite loss at epoch {epoch}")
                scaler.scale(losses["loss"]).backward()
                scaler.unscale_(optimizer)
                if args.gradient_clip > 0:
                    torch.nn.utils.clip_grad_norm_(model.parameters(), args.gradient_clip)
                scaler.step(optimizer)
                scaler.update()
                for name in totals:
                    totals[name] += float(losses[name].detach())
                collisions += int(cpu_targets["collision_count"])
                valid_points += int(cpu_targets["valid_point_count"])

            row: dict[str, object] = {
                "epoch": epoch,
                **{name: value / len(train_loader) for name, value in totals.items()},
                "collision_rate": collisions / max(valid_points, 1),
                "elapsed_seconds": time.monotonic() - started,
            }
            if epoch == 1 or epoch % args.eval_every == 0 or epoch == args.epochs:
                validation = evaluate_local_expert(
                    model,
                    val_loader,
                    device,
                    thresholds,
                    matching_radius=args.match_radius,
                    local_max_kernel=args.local_max_kernel,
                    topk=args.topk,
                )
                row["validation"] = validation
                current = validation["mae"]
                current_key = (float(current["mae"]), -float(current["f1_at_8"]))
                best_key = (
                    float(best_metrics["mae"]),
                    -float(best_metrics["f1_at_8"]),
                )
                if current_key < best_key:
                    best_metrics = dict(current)
                    best_epoch = epoch
                    best_payload = _checkpoint_payload(
                            model,
                            optimizer,
                            scaler,
                            args=args,
                            epoch=epoch,
                            validation=best_metrics,
                            initial_checkpoint=initial_path,
                            manifest=manifest_path,
                        )
                    best_payload["best_epoch"] = best_epoch
                    _atomic_torch_save(
                        best_payload,
                        args.output / "best_val_mae.pt",
                    )
            history_rows.append(row)
            history.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
            history.flush()
            last_payload = _checkpoint_payload(
                model,
                optimizer,
                scaler,
                args=args,
                epoch=epoch,
                validation=best_metrics,
                initial_checkpoint=initial_path,
                manifest=manifest_path,
            )
            last_payload["selection"] = "latest_completed_epoch_with_best_frozen_decoder"
            last_payload["best_epoch"] = best_epoch
            _atomic_torch_save(last_payload, args.output / "last.pt")
            _atomic_json_write(
                {
                    "schema_version": 1,
                    "updated_at_utc": datetime.now(timezone.utc).isoformat(),
                    "status": "training",
                    "last_completed_epoch": epoch,
                    "requested_epochs": args.epochs,
                    "best_epoch": best_epoch,
                    "best_validation": best_metrics,
                    "last_epoch_metrics": row,
                    "resume_checkpoint": str(args.output / "last.pt"),
                    "best_checkpoint": str(args.output / "best_val_mae.pt"),
                    "history": str(history_path),
                    "test_split_opened": False,
                },
                args.output / "progress.json",
            )
            if "validation" in row:
                current_mae = row["validation"]["mae"]["mae"]  # type: ignore[index]
                print(
                    f"epoch={epoch} loss={row['loss']:.5f} "
                    f"val_mae={current_mae:.3f} best={best_metrics['mae']:.3f}",
                    flush=True,
                )

    initial_mae = float(initial_validation["mae"]["mae"])
    best_mae = float(best_metrics["mae"])
    summary: dict[str, object] = {
        "schema_version": 1,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "role": "CRU crop-scale local expert",
        "formal": not args.diagnostic_train_reuse,
        "test_split_opened": False,
        "model_kind": model_kind,
        "model_config": model_config,
        "parameters": sum(parameter.numel() for parameter in model.parameters()),
        "train_images": len(train_dataset.records),
        "train_tiles": len(train_dataset),
        "validation_images": len(val_dataset.records),
        "validation_tiles": len(val_dataset),
        "initial_validation": initial_validation,
        "best_epoch": best_epoch,
        "best_validation": best_metrics,
        "relative_mae_reduction_from_initial": (
            (initial_mae - best_mae) / initial_mae if initial_mae > 0 else None
        ),
        "diagnostic_gate_passed": best_mae < initial_mae,
        "loss_weights": asdict(weights),
        "crop_protocol": {
            "image_size": args.image_size,
            "core_size": args.core_size,
            "halo": args.halo,
            "all_context_points_supervised": True,
            "only_core_predictions_owned": True,
        },
        "files": {
            "best_checkpoint": str(args.output / "best_val_mae.pt"),
            "history": str(history_path),
        },
    }
    _atomic_json_write(
        summary,
        args.output / "summary.json",
    )
    _atomic_json_write(
        {
            "schema_version": 1,
            "updated_at_utc": datetime.now(timezone.utc).isoformat(),
            "status": "complete",
            "last_completed_epoch": args.epochs,
            "requested_epochs": args.epochs,
            "best_epoch": best_epoch,
            "best_validation": best_metrics,
            "resume_checkpoint": str(args.output / "last.pt"),
            "best_checkpoint": str(args.output / "best_val_mae.pt"),
            "history": str(history_path),
            "summary": str(args.output / "summary.json"),
            "test_split_opened": False,
        },
        args.output / "progress.json",
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
    return summary


if __name__ == "__main__":
    main()
