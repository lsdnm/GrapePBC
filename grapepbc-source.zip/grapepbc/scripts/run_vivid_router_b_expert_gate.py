"""Learn a conservative Router-B gate between stable HR and density HR.

Model family and hyperparameters are selected inside each outer Router-B fold.
The full Router-B fit is then applied once to the existing development set.
Neither expert is updated and the sealed test remains unopened.
"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

import joblib
import numpy as np
from sklearn.base import clone
from sklearn.ensemble import (
    GradientBoostingClassifier,
    GradientBoostingRegressor,
    RandomForestClassifier,
    RandomForestRegressor,
)
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, str(PROJECT / "scripts"))

from geopriv.data.hash_utils import file_sha256
from geopriv.data.manifest import read_manifest
import run_vivid_hr_global_conservation as global_stage
import run_vivid_hr_global_conservation_v2 as stable_stage


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    temporary.replace(path)


def metric(prediction: np.ndarray, truth: np.ndarray) -> dict[str, float]:
    difference = prediction.astype(np.float64) - truth.astype(np.float64)
    high = truth > 200
    return {
        "mae": float(np.abs(difference).mean()),
        "rmse": float(np.sqrt(np.square(difference).mean())),
        "bias": float(difference.mean()),
        "high_gt200_mae": float(np.abs(difference[high]).mean()) if high.any() else float("nan"),
        "high_gt200_images": int(high.sum()),
    }


def feature_indices(name: str) -> np.ndarray:
    if name == "minimal":
        return np.asarray(list(range(0, 9)) + list(range(51, 65)) + list(range(170, 180)))
    if name == "count":
        return np.asarray(list(range(0, 65)) + list(range(170, 180)))
    if name == "all":
        return np.arange(180)
    raise ValueError(name)


def configurations() -> list[dict[str, object]]:
    configs: list[dict[str, object]] = []
    # Density is a specialist, not a replacement.  Restrict the search to a
    # conservative, direction-aware half correction on high-count scenes.
    for subset in ("count",):
        for c in (0.1, 0.3):
            for eligibility in (150, 180, 200):
                for threshold_down in (0.40, 0.50, 0.60):
                    for threshold_up in (0.55, 0.65, 0.75):
                        configs.append({
                            "family": "logistic_hard", "subset": subset, "c": c,
                            "balanced": True, "gain": 0.5, "eligibility": eligibility,
                            "threshold_down": threshold_down, "threshold_up": threshold_up,
                        })
    return configs


def make_estimator(config: dict[str, object], seed: int):
    family = str(config["family"])
    if family in {"logistic_soft", "logistic_hard"}:
        return make_pipeline(
            StandardScaler(),
            LogisticRegression(
                C=float(config["c"]),
                class_weight="balanced" if config["balanced"] else None,
                max_iter=3000,
                random_state=seed,
            ),
        )
    if family == "gbc_soft":
        return GradientBoostingClassifier(
            n_estimators=120, learning_rate=0.03, max_depth=int(config["depth"]),
            min_samples_leaf=int(config["leaf"]), subsample=0.85, max_features="sqrt", random_state=seed,
        )
    if family == "forest_soft":
        return RandomForestClassifier(
            n_estimators=400, max_depth=int(config["depth"]), min_samples_leaf=int(config["leaf"]),
            max_features="sqrt", class_weight="balanced", random_state=seed, n_jobs=-1,
        )
    if family == "ridge_alpha":
        return make_pipeline(StandardScaler(), Ridge(alpha=float(config["alpha"])))
    if family == "gbr_alpha":
        return GradientBoostingRegressor(
            loss="huber", alpha=0.85, n_estimators=120, learning_rate=0.03,
            max_depth=int(config["depth"]), min_samples_leaf=int(config["leaf"]),
            subsample=0.85, max_features="sqrt", random_state=seed,
        )
    if family == "forest_alpha":
        return RandomForestRegressor(
            n_estimators=400, max_depth=int(config["depth"]), min_samples_leaf=int(config["leaf"]),
            max_features="sqrt", random_state=seed, n_jobs=-1,
        )
    raise ValueError(family)


def alpha_target(truth: np.ndarray, stable: np.ndarray, density: np.ndarray) -> np.ndarray:
    denominator = density.astype(np.float64) - stable.astype(np.float64)
    target = np.zeros(len(truth), dtype=np.float64)
    valid = np.abs(denominator) >= 1.0
    target[valid] = (truth[valid] - stable[valid]) / denominator[valid]
    return np.clip(target, 0.0, 1.0)


def fit_estimator(
    config: dict[str, object], features: np.ndarray, truth: np.ndarray,
    stable: np.ndarray, density: np.ndarray, indices: np.ndarray, seed: int,
):
    columns = feature_indices(str(config["subset"]))
    estimator = make_estimator(config, seed)
    if str(config["family"]).endswith(("soft", "hard")):
        target = (np.abs(density - truth) < np.abs(stable - truth)).astype(np.int64)
    else:
        target = alpha_target(truth, stable, density)
    estimator.fit(features[indices][:, columns], target[indices])
    return estimator


def predict_estimator(
    config: dict[str, object], estimator, features: np.ndarray,
    stable: np.ndarray, density: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    columns = feature_indices(str(config["subset"]))
    if str(config["family"]).endswith("soft"):
        alpha = estimator.predict_proba(features[:, columns])[:, 1] * float(config["gain"])
    elif str(config["family"]).endswith("hard"):
        probability = estimator.predict_proba(features[:, columns])[:, 1]
        if "threshold_down" in config:
            threshold = np.where(
                density < stable, float(config["threshold_down"]), float(config["threshold_up"])
            )
            eligible = np.maximum(stable, density) >= int(config["eligibility"])
            alpha = (eligible & (probability >= threshold)).astype(np.float64) * float(config["gain"])
        else:
            alpha = (probability >= float(config["threshold"])).astype(np.float64) * float(config["gain"])
    else:
        alpha = estimator.predict(features[:, columns])
    alpha = np.clip(alpha, 0.0, 1.0)
    prediction = np.rint(stable + alpha * (density - stable)).astype(np.int64)
    return prediction, alpha


def strata(truth: np.ndarray) -> np.ndarray:
    return np.digitize(truth, [50, 100, 200], right=True)


def candidate_oof(
    config: dict[str, object], features: np.ndarray, truth: np.ndarray,
    stable: np.ndarray, density: np.ndarray, groups: np.ndarray,
    folds: int, seed: int,
) -> tuple[np.ndarray, np.ndarray]:
    prediction = np.zeros(len(truth), dtype=np.int64)
    alpha = np.zeros(len(truth), dtype=np.float64)
    splitter = StratifiedGroupKFold(n_splits=folds, shuffle=True, random_state=seed)
    for fold, (train, valid) in enumerate(splitter.split(features, strata(truth), groups)):
        estimator = fit_estimator(config, features, truth, stable, density, train, seed + fold)
        fold_prediction, fold_alpha = predict_estimator(config, estimator, features[valid], stable[valid], density[valid])
        prediction[valid] = fold_prediction
        alpha[valid] = fold_alpha
    return prediction, alpha


def select_config(
    configs: list[dict[str, object]], features: np.ndarray, truth: np.ndarray,
    stable: np.ndarray, density: np.ndarray, groups: np.ndarray,
    folds: int, seed: int,
) -> tuple[int, list[dict[str, object]]]:
    stable_metrics = metric(stable, truth)
    rows = []
    for index, config in enumerate(configs):
        # Every candidate must be compared on exactly the same grouped folds.
        prediction, alpha = candidate_oof(config, features, truth, stable, density, groups, folds, seed)
        values = metric(prediction, truth)
        rows.append({
            "config_index": index, "config": config, **values,
            "mean_alpha": float(alpha.mean()), "max_alpha": float(alpha.max()),
            "dense_gate_passed": bool(values["high_gt200_mae"] < stable_metrics["high_gt200_mae"]),
        })
    eligible = [row for row in rows if row["dense_gate_passed"]]
    pool = eligible if eligible else rows
    selected = min(pool, key=lambda row: (row["mae"], row["high_gt200_mae"], row["rmse"], row["config_index"]))
    return int(selected["config_index"]), rows


def nested_oof(
    configs: list[dict[str, object]], features: np.ndarray, truth: np.ndarray,
    stable: np.ndarray, density: np.ndarray, groups: np.ndarray, seed: int,
) -> tuple[np.ndarray, np.ndarray, list[dict[str, object]]]:
    prediction = np.zeros(len(truth), dtype=np.int64)
    alpha = np.zeros(len(truth), dtype=np.float64)
    decisions = []
    outer = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=seed)
    for fold, (train, valid) in enumerate(outer.split(features, strata(truth), groups)):
        chosen, rows = select_config(
            configs, features[train], truth[train], stable[train], density[train], groups[train],
            4, seed + 1000 + fold * 100,
        )
        estimator = fit_estimator(configs[chosen], features, truth, stable, density, train, seed + 5000 + fold)
        fold_prediction, fold_alpha = predict_estimator(configs[chosen], estimator, features[valid], stable[valid], density[valid])
        prediction[valid] = fold_prediction
        alpha[valid] = fold_alpha
        decisions.append({
            "fold": fold, "selected_config_index": chosen, "selected_config": configs[chosen],
            "inner_selected": rows[chosen], "outer_images": len(valid),
        })
        print(json.dumps({"outer_fold_complete": fold + 1, "selected": configs[chosen]}), flush=True)
    return prediction, alpha, decisions


def load_development(stable_run: Path, density_run: Path) -> dict[str, object]:
    protocol = json.loads((stable_run / "protocol.json").read_text(encoding="utf-8"))
    data = global_stage.load_components(protocol, "development")
    table = global_stage.make_image_table(data)
    artifact = joblib.load(stable_run / "global_count_ensemble.joblib")
    stable = stable_stage.predict_artifact(table, artifact)
    rows = json.loads((density_run / "density_rows_epoch_04.json").read_text(encoding="utf-8"))
    masses: dict[str, list[float]] = {}
    density: dict[str, int] = {}
    for row in rows:
        sample_id = str(row["sample_id"])
        masses.setdefault(sample_id, []).append(float(row["mass"]))
        density[sample_id] = density.get(sample_id, 0) + int(row["requested"])
    density_total = np.asarray([density[str(value)] for value in table["sample_ids"]], dtype=np.int64)
    density_stats = np.asarray(
        [global_stage.distribution_stats(np.asarray(masses[str(value)])) for value in table["sample_ids"]],
        dtype=np.float32,
    )
    features = np.column_stack(
        (
            table["features"], density_stats, np.log1p(density_total),
            (density_total - stable) / np.sqrt(stable + 1.0),
            np.abs(density_total - stable) / np.sqrt(stable + 1.0),
        )
    ).astype(np.float32)
    return {
        "sample_ids": table["sample_ids"], "truth": table["target"],
        "stable": stable, "density": density_total, "features": features,
    }


def bootstrap_improvement(baseline: np.ndarray, prediction: np.ndarray, truth: np.ndarray, seed: int) -> dict[str, object]:
    delta = np.abs(baseline - truth) - np.abs(prediction - truth)
    rng = np.random.default_rng(seed)
    means = delta[rng.integers(0, len(delta), size=(20000, len(delta)))].mean(axis=1)
    return {
        "mean_mae_improvement": float(delta.mean()),
        "ci95": [float(value) for value in np.quantile(means, [0.025, 0.975])],
        "improved": int((delta > 0).sum()), "worsened": int((delta < 0).sum()), "tied": int((delta == 0).sum()),
    }


def run(args: argparse.Namespace) -> None:
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"non-empty output exists: {output}")
    output.mkdir(parents=True, exist_ok=True)
    inputs = args.router_inputs.resolve()
    stable_run = args.stable_run.resolve()
    density_run = args.density_run.resolve()
    with np.load(inputs / "router_b_predictions.npz", allow_pickle=False) as payload:
        ids = payload["sample_ids"]
        truth = payload["truth"].astype(np.int64)
        stable = payload["stable"].astype(np.int64)
        density = payload["density"].astype(np.int64)
        features = payload["observable_features"].astype(np.float32)
    manifest_path = Path(json.loads((inputs / "protocol.json").read_text(encoding="utf-8"))["manifest"])
    records = {record.sample_id: record for record in read_manifest(manifest_path)}
    groups = np.asarray([records[str(value)].capture_group_id or str(value) for value in ids])
    configs = configurations()
    protocol = {
        "version": "vivid-router-b-expert-gate-v1", "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "seed": 20261021, "router_inputs": str(inputs),
        "router_inputs_sha256": file_sha256(inputs / "router_b_predictions.npz"),
        "stable_run": str(stable_run), "stable_model_sha256": file_sha256(stable_run / "global_count_ensemble.joblib"),
        "density_run": str(density_run), "density_checkpoint_sha256": file_sha256(density_run / "best_val_mae.pt"),
        "candidate_count": len(configs),
        "selection": "fully nested group-safe Router-B OOF; modal exact outer-fold configuration; overall MAE with high-density non-degradation gate",
        "development_used_for_fitting": False, "expert_weights_updated": False,
        "router_B_used": True, "sealed_test_used": False,
        "source_sha256": file_sha256(Path(__file__)),
    }
    atomic_json(output / "protocol.json", protocol)
    nested_prediction, nested_alpha, decisions = nested_oof(configs, features, truth, stable, density, groups, int(protocol["seed"]))
    screen_chosen, screen = select_config(configs, features, truth, stable, density, groups, 5, int(protocol["seed"]) + 9000)
    # Prefer the exact configuration most repeatedly selected by independent
    # outer folds.  This stability-selection rule is less sensitive to one
    # unusually favourable full-data OOF realization than the raw minimum.
    signatures = [json.dumps(item["selected_config"], sort_keys=True) for item in decisions]
    frequency = Counter(signatures)
    modal_signature, modal_frequency = min(
        frequency.items(), key=lambda item: (-item[1], signatures.index(item[0]))
    )
    modal_config = json.loads(modal_signature)
    chosen = next(index for index, config in enumerate(configs) if config == modal_config)
    final_estimator = fit_estimator(configs[chosen], features, truth, stable, density, np.arange(len(truth)), int(protocol["seed"]) + 19000)
    joblib.dump({"config": configs[chosen], "estimator": final_estimator, "feature_dim": features.shape[1]}, output / "router_gate.joblib")
    development = load_development(stable_run, density_run)
    development_prediction, development_alpha = predict_estimator(
        configs[chosen], final_estimator, development["features"], development["stable"], development["density"]
    )
    rows = []
    for index, sample_id in enumerate(development["sample_ids"]):
        rows.append({
            "sample_id": str(sample_id), "truth": int(development["truth"][index]),
            "stable": int(development["stable"][index]), "density": int(development["density"][index]),
            "alpha": float(development_alpha[index]), "prediction": int(development_prediction[index]),
            "stable_absolute_error": int(abs(development["stable"][index] - development["truth"][index])),
            "absolute_error": int(abs(development_prediction[index] - development["truth"][index])),
        })
    atomic_json(output / "screen.json", {
        "raw_full_oof_selected_config_index": screen_chosen,
        "raw_full_oof_selected_config": configs[screen_chosen],
        "stability_selected_config_index": chosen,
        "stability_selected_config": configs[chosen],
        "outer_selection_frequency": modal_frequency,
        "rows": screen,
    })
    atomic_json(output / "nested_oof_decisions.json", decisions)
    atomic_json(output / "development_per_image.json", rows)
    summary = {
        "status": "COMPLETE_ROUTER_B_NESTED_GATE_AND_DEVELOPMENT_REVIEW",
        "selected_config_index": chosen, "selected_config": configs[chosen],
        "selection_rule": "modal exact configuration across five outer Router-B folds",
        "outer_selection_frequency": modal_frequency,
        "router_b_nested_oof": {
            "stable": metric(stable, truth), "density": metric(density, truth),
            "gate": metric(nested_prediction, truth),
            "paired_vs_stable": bootstrap_improvement(stable, nested_prediction, truth, int(protocol["seed"])),
            "mean_alpha": float(nested_alpha.mean()),
        },
        "development": {
            "stable": metric(development["stable"], development["truth"]),
            "density": metric(development["density"], development["truth"]),
            "gate": metric(development_prediction, development["truth"]),
            "paired_vs_stable": bootstrap_improvement(
                development["stable"], development_prediction, development["truth"], int(protocol["seed"]) + 1
            ),
            "mean_alpha": float(development_alpha.mean()),
        },
        "promotion_gate_passed": bool(
            metric(development_prediction, development["truth"])["mae"] < metric(development["stable"], development["truth"])["mae"]
            and metric(development_prediction, development["truth"])["high_gt200_mae"] < metric(development["stable"], development["truth"])["high_gt200_mae"]
        ),
        "development_used_for_fitting": False, "expert_weights_updated": False,
        "router_B_used": True, "sealed_test_used": False,
    }
    atomic_json(output / "summary.json", summary)
    atomic_json(output / "progress.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--router-inputs", type=Path, required=True)
    parser.add_argument("--stable-run", type=Path, required=True)
    parser.add_argument("--density-run", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    run(parser.parse_args())


if __name__ == "__main__":
    main()
