"""Common validation and interruption-safe checkpoint utilities for this trial."""
from pathlib import Path, WindowsPath
import json
import random
import sys

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from geopriv.models import decode_points
from geopriv.metrics import aggregate_count_metrics
from audit_cru_detail_readiness import save_json


def safe_load(path):
    with torch.serialization.safe_globals([
        WindowsPath, np.ndarray, np.dtype, np._core.multiarray._reconstruct,
        type(np.dtype("uint32")),
    ]):
        return torch.load(path, map_location="cpu", weights_only=True)


def atomic_checkpoint(path, payload):
    path = Path(path)
    temporary = path.with_suffix(".pt.tmp")
    torch.save(payload, temporary)
    temporary.replace(path)


def rng_state():
    return dict(python=random.getstate(), numpy=np.random.get_state(),
                torch=torch.get_rng_state(), cuda=torch.cuda.get_rng_state_all())


def restore_rng(state):
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"])
    torch.cuda.set_rng_state_all(state["cuda"])


def publish_epoch(folder, checkpoint):
    """last.pt is authoritative; regenerate derived history/progress on resume.

    Embed best weights in last as well, so a crash between best/last publication
    cannot permanently lose the best model or leave a mismatched best pointer.
    """
    folder = Path(folder)
    atomic_checkpoint(folder / "last.pt", checkpoint)
    repair_epoch(folder, checkpoint)


def repair_epoch(folder, checkpoint):
    folder = Path(folder)
    atomic_checkpoint(folder / "best_val_mae.pt", {
        "model": checkpoint["best_model"], "epoch": checkpoint["best_epoch"],
        "metrics": checkpoint["best_metrics"], "protocol": checkpoint["protocol"],
        "variant": checkpoint["variant"],
    })
    history = folder / "history.jsonl"
    temp = history.with_suffix(".jsonl.tmp")
    temp.write_text("".join(json.dumps(row) + "\n" for row in checkpoint["history"]), encoding="utf-8")
    temp.replace(history)
    save_json(folder / "progress.json", {
        "status": "complete" if checkpoint["epoch"] == checkpoint["protocol"]["epochs"] else "training",
        "last_completed_epoch": checkpoint["epoch"],
        "requested_epochs": checkpoint["protocol"]["epochs"],
        "best_epoch": checkpoint["best_epoch"], "best_metrics": checkpoint["best_metrics"],
        "variant": checkpoint["variant"], "test_used": False,
    })


@torch.inference_mode()
def evaluate_counts(model, loader, thresholds, *, core, heartbeat=None):
    """Float32 batch-one deployment evaluation; retain every image and threshold."""
    model.eval()
    records = {}
    for index, batch in enumerate(loader):
        outputs = model(batch["images"].cuda(), batch["valid_image_masks"].cuda())
        decoded = decode_points(outputs, score_threshold=min(thresholds),
                                topk=4096, local_max_kernel=3, output_stride=2)
        for prediction, target in zip(decoded, batch["targets"], strict=True):
            points = prediction["points"].cpu().numpy()
            scores = prediction["scores"].cpu().numpy()
            if core:
                x0, y0, x1, y1 = target["core_bounds_xyxy"].numpy()
                owned = ((points[:, 0] >= x0) & (points[:, 0] < x1) &
                         (points[:, 1] >= y0) & (points[:, 1] < y1))
                scores = scores[owned]
                count = len(target["core_points_xy"])
            else:
                count = len(target["points_xy"])
            row = records.setdefault(target["sample_id"], {
                "sample_id": target["sample_id"], "truth": 0,
                "predictions": [0 for _ in thresholds]})
            row["truth"] += count
            row["predictions"] = [old + int(np.count_nonzero(scores >= threshold))
                                  for old, threshold in zip(row["predictions"], thresholds)]
        if heartbeat and (index % 25 == 0 or index + 1 == len(loader)):
            save_json(heartbeat, {"status": "validating", "batches": index + 1,
                                 "total_batches": len(loader)})
    rows = [records[k] for k in sorted(records)]
    metrics = [{"threshold": t, **aggregate_count_metrics(
        [r["predictions"][i] for r in rows], [r["truth"] for r in rows])}
        for i, t in enumerate(thresholds)]
    best = min(metrics, key=lambda m: (m["mae"], m["rmse"], m["threshold"]))
    return {"selected": best, "threshold_metrics": metrics, "per_image": rows,
            "samples": len(rows), "thresholds": thresholds, "batch_size": 1,
            "selection": "development MAE then RMSE then threshold; not final test"}
