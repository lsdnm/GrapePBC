package com.geopriv.grapecounter

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ApiClientTest {
    @Test
    fun normalizeBaseAddress_addsSchemeAndRemovesTrailingSlash() {
        assertEquals(
            "http://192.168.1.20:8000",
            ApiClient.normalizeBaseAddress(" 192.168.1.20:8000/ ")
        )
    }

    @Test
    fun endpoint_joinsPathExactlyOnce() {
        assertEquals(
            "http://192.168.1.20:8000/api/v1/health",
            ApiClient.endpoint("http://192.168.1.20:8000/", "/api/v1/health")
        )
    }

    @Test
    fun parseHealth_readsUnifiedContract() {
        val parsed = ApiClient.parseHealth(
            """{"status":"ok","model_loaded":true,"device":"cuda","model_profile":"cru","routing_mode":"forced_topk","model_selection_status":"posthoc_test_selected_demo"}"""
        )
        assertEquals("ok", parsed.status)
        assertTrue(parsed.modelLoaded)
        assertEquals("cuda", parsed.device)
        assertEquals("cru", parsed.modelProfile)
        assertEquals("forced_topk", parsed.routingMode)
        assertEquals("posthoc_test_selected_demo", parsed.modelSelectionStatus)
    }

    @Test
    fun parseCount_readsUnifiedTopLevelContract() {
        val parsed = ApiClient.parseCount(
            """
            {
              "request_id":"req-1",
              "count":321,
              "low_resolution_count":300,
              "selected_tile_ids":[7],
              "budget_fraction":0.0833333333,
              "selected_core_fraction":0.0833333333,
              "context_processing_load":0.1209,
              "processing_time_ms":456.7,
              "device":"cuda",
              "model_profile":"cru",
              "routing_mode":"forced_topk",
              "model_selection_status":"posthoc_test_selected_demo",
              "image_width":4032,
              "image_height":3024,
              "annotated_image_base64":"YWJj"
            }
            """.trimIndent()
        )
        assertEquals(321, parsed.count)
        assertEquals(300, parsed.lowResolutionCount)
        assertEquals(listOf("7"), parsed.selectedTileIds)
        assertEquals(456.7, parsed.processingTimeMs!!, 0.001)
        assertEquals("YWJj", parsed.annotatedImageBase64)
        assertEquals("forced_topk", parsed.routingMode)
        assertEquals("posthoc_test_selected_demo", parsed.modelSelectionStatus)
    }

    @Test
    fun parseCount_alsoAcceptsDetailedNestedContract() {
        val parsed = ApiClient.parseCount(
            """
            {
              "count":99,
              "selected_regions":[{"tile_id":"r2c1"}],
              "budget":{"requested_fraction":0.25,"actual_core_fraction":0.24,"context_processing_load":0.31},
              "timing_ms":{"total":123.4},
              "model":{"method":"CRU","device":"cpu"},
              "annotated_image":{"mime_type":"image/jpeg","base64":"eHl6"}
            }
            """.trimIndent()
        )
        assertEquals(listOf("r2c1"), parsed.selectedTileIds)
        assertEquals(0.25, parsed.budgetFraction!!, 0.0001)
        assertEquals(123.4, parsed.processingTimeMs!!, 0.001)
        assertEquals("eHl6", parsed.annotatedImageBase64)
        assertFalse(parsed.selectedTileIds.isEmpty())
    }
}
