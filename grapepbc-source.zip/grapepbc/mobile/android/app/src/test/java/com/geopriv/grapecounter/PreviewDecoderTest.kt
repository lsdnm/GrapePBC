package com.geopriv.grapecounter

import androidx.exifinterface.media.ExifInterface
import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.IOException

class PreviewDecoderTest {
    @Test
    fun exifFailureFallsBackToNormalOrientation() {
        val orientation = PreviewDecoder.exifOrientationOrNormal {
            throw IOException("broken metadata")
        }

        assertEquals(ExifInterface.ORIENTATION_NORMAL, orientation)
    }

    @Test
    fun largeCameraImageUsesSampledPreview() {
        assertEquals(4, PreviewDecoder.sampleSize(4032, 3024))
        assertEquals(1, PreviewDecoder.sampleSize(1600, 1200))
    }
}
