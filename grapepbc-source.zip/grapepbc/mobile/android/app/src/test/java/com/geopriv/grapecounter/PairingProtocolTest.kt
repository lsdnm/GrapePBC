package com.geopriv.grapecounter

import org.junit.Assert.*
import org.junit.Test
import org.json.JSONObject
import java.security.KeyPairGenerator
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.util.Base64

class PairingProtocolTest {
    @Test fun addressValidation() {
        assertEquals("http://192.168.1.2:7860", PairingProtocol.address("192.168.1.2"))
        assertEquals("http://10.66.165.114:7860", PairingProtocol.address("http://10.66.165.114:7860/"))
        listOf("http://evil.test", "file:///x", "http://8.8.8.8", "http://192.168.1.2/evil",
            "http://user@192.168.1.2", "http://127.0.0.1", "http://192.168.1.2?q=x").forEach {
            assertNull(it, PairingProtocol.address(it))
        }
    }
    @Test fun signatureAndFreshNonce() {
        val keyPair = KeyPairGenerator.getInstance("EC").apply { initialize(ECGenParameterSpec("secp256r1")) }.generateKeyPair()
        val pair = PairingProtocol.Pairing("d1ac28b7-e24b-4ee6-a0da-18f86b08d399", "Test PC",
            Base64.getEncoder().encodeToString(keyPair.public.encoded), listOf("http://192.168.1.2:7860"))
        assertEquals(pair, PairingProtocol.parse(pair.json()))
        val nonce = PairingProtocol.nonce()
        assertEquals(64, nonce.length)
        val signature = Signature.getInstance("SHA256withECDSA").run {
            initSign(keyPair.private)
            update("ABBC/1|${pair.id}|$nonce".toByteArray())
            Base64.getEncoder().encodeToString(sign())
        }
        val response = JSONObject().put("id", pair.id).put("signature", signature).toString()
        assertTrue(PairingProtocol.verify(pair, nonce, response))
        assertFalse(PairingProtocol.verify(pair, PairingProtocol.nonce(), response))
        assertFalse(PairingProtocol.verify(pair.copy(id = "other"), nonce, response))
        assertFalse(PairingProtocol.verify(pair, nonce, "{}"))
    }
    @Test(expected = IllegalArgumentException::class)
    fun rejectsOtherQR() { PairingProtocol.parse("{\"type\":\"OTHER\"}") }
}
