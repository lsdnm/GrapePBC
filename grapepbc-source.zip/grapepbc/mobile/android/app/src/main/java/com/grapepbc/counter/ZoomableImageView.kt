package com.grapepbc.counter

import android.content.Context
import android.graphics.Matrix
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.appcompat.widget.AppCompatImageView
import kotlin.math.min

class ZoomableImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : AppCompatImageView(context, attrs, defStyleAttr) {
    private val displayMatrix = Matrix()
    private var relativeScale = MIN_SCALE
    private var lastX = 0f
    private var lastY = 0f

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val target = (relativeScale * detector.scaleFactor).coerceIn(MIN_SCALE, MAX_SCALE)
                val applied = target / relativeScale
                relativeScale = target
                displayMatrix.postScale(applied, applied, detector.focusX, detector.focusY)
                constrainTranslation()
                imageMatrix = displayMatrix
                return true
            }
        }
    )

    private val gestureDetector = GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(event: MotionEvent): Boolean = true

            override fun onDoubleTap(event: MotionEvent): Boolean {
                resetZoom()
                return true
            }
        }
    )

    init {
        scaleDetector.isQuickScaleEnabled = false
        super.setScaleType(ScaleType.MATRIX)
    }

    override fun setScaleType(scaleType: ScaleType?) {
        super.setScaleType(ScaleType.MATRIX)
    }

    override fun setImageDrawable(drawable: Drawable?) {
        super.setImageDrawable(drawable)
        post { resetZoom() }
    }

    override fun onSizeChanged(width: Int, height: Int, oldWidth: Int, oldHeight: Int) {
        super.onSizeChanged(width, height, oldWidth, oldHeight)
        resetZoom()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                parent?.requestDisallowInterceptTouchEvent(true)
            }

            MotionEvent.ACTION_MOVE -> {
                if (!scaleDetector.isInProgress && relativeScale > MIN_SCALE) {
                    displayMatrix.postTranslate(event.x - lastX, event.y - lastY)
                    constrainTranslation()
                    imageMatrix = displayMatrix
                }
                lastX = event.x
                lastY = event.y
            }

            MotionEvent.ACTION_POINTER_UP -> {
                val remainingIndex = if (event.actionIndex == 0) 1 else 0
                if (remainingIndex < event.pointerCount) {
                    lastX = event.getX(remainingIndex)
                    lastY = event.getY(remainingIndex)
                }
            }

            MotionEvent.ACTION_UP -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick()
            }

            MotionEvent.ACTION_CANCEL -> parent?.requestDisallowInterceptTouchEvent(false)
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun resetZoom() {
        val image = drawable ?: return
        val availableWidth = width - paddingLeft - paddingRight
        val availableHeight = height - paddingTop - paddingBottom
        if (availableWidth <= 0 || availableHeight <= 0 ||
            image.intrinsicWidth <= 0 || image.intrinsicHeight <= 0
        ) return

        val scale = min(
            availableWidth.toFloat() / image.intrinsicWidth,
            availableHeight.toFloat() / image.intrinsicHeight
        )
        val imageWidth = image.intrinsicWidth * scale
        val imageHeight = image.intrinsicHeight * scale
        val left = paddingLeft + (availableWidth - imageWidth) / 2f
        val top = paddingTop + (availableHeight - imageHeight) / 2f

        displayMatrix.reset()
        displayMatrix.postScale(scale, scale)
        displayMatrix.postTranslate(left, top)
        relativeScale = MIN_SCALE
        imageMatrix = displayMatrix
    }

    private fun constrainTranslation() {
        val image = drawable ?: return
        val bounds = RectF(0f, 0f, image.intrinsicWidth.toFloat(), image.intrinsicHeight.toFloat())
        displayMatrix.mapRect(bounds)

        val leftBound = paddingLeft.toFloat()
        val topBound = paddingTop.toFloat()
        val rightBound = (width - paddingRight).toFloat()
        val bottomBound = (height - paddingBottom).toFloat()
        val availableWidth = rightBound - leftBound
        val availableHeight = bottomBound - topBound

        val dx = when {
            bounds.width() <= availableWidth -> leftBound + (availableWidth - bounds.width()) / 2f - bounds.left
            bounds.left > leftBound -> leftBound - bounds.left
            bounds.right < rightBound -> rightBound - bounds.right
            else -> 0f
        }
        val dy = when {
            bounds.height() <= availableHeight -> topBound + (availableHeight - bounds.height()) / 2f - bounds.top
            bounds.top > topBound -> topBound - bounds.top
            bounds.bottom < bottomBound -> bottomBound - bounds.bottom
            else -> 0f
        }
        displayMatrix.postTranslate(dx, dy)
    }

    private companion object {
        const val MIN_SCALE = 1f
        const val MAX_SCALE = 5f
    }
}
