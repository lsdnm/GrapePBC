package com.geopriv.grapecounter

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import androidx.appcompat.app.AlertDialog
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

/** Native Android shell for the same-LAN CRU mobile interface. */
class MainActivity : AppCompatActivity() {
    private lateinit var addressEdit: EditText
    private lateinit var connectButton: Button
    private lateinit var statusText: TextView
    private lateinit var webView: WebView
    private val preferences by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }

    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null
    private var cameraFile: File? = null
    private var mainFrameFailed = false
    private var navigationId = 0
    private lateinit var pcConnection: PcConnection
    private val qrScanner = registerForActivityResult(ScanContract()) { result ->
        result.contents?.let { text ->
            runCatching { PairingProtocol.parse(text) }.onSuccess { pair ->
                AlertDialog.Builder(this).setTitle("Pair with ${pair.name}?")
                    .setMessage("Scan only the QR shown by your own PC. After pairing, this app will find this PC even when its IP changes. Use a trusted local Wi-Fi network.")
                    .setPositiveButton("Pair") { _, _ -> pcConnection.save(pair) }
                    .setNegativeButton("Cancel", null).show()
            }.onFailure { status("Not a valid ABGC-mobile pairing QR. Open /pair on your PC.", false) }
        }
    }

    private val fileChooser = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val callback = fileCallback ?: return@registerForActivityResult
        val selected = if (result.resultCode == Activity.RESULT_OK) {
            WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
                ?: cameraUri?.let { uri ->
                    if (cameraFile?.let { it.exists() && it.length() > 0L } == true) arrayOf(uri) else null
                }
        } else {
            null
        }
        callback.onReceiveValue(selected)
        fileCallback = null
        cameraUri = null
        cameraFile = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(4, 16, 14)
        window.navigationBarColor = Color.rgb(4, 16, 14)
        buildLayout()
        configureWebView()
        pcConnection = PcConnection(this, { status(it, false) }, { address ->
            addressEdit.setText(address)
            preferences.edit().putString(KEY_SERVER, address).apply()
            webView.stopLoading()
            webView.clearCache(true)
            webView.loadUrl(address)
        })

        val savedAddress = preferences.getString(KEY_SERVER, DEFAULT_SERVER) ?: DEFAULT_SERVER
        addressEdit.setText(savedAddress)
        connectButton.setOnClickListener { connect() }
        addressEdit.setOnEditorActionListener { _, _, _ ->
            connect()
            true
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    private fun buildLayout() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(6, 16, 14))
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(7))
            setBackgroundColor(Color.rgb(8, 29, 24))
        }
        addressEdit = EditText(this).apply {
            setSingleLine(true)
            hint = "PC address, e.g. 192.168.1.90:7860"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(134, 164, 151))
            setBackgroundColor(Color.rgb(14, 48, 40))
            setPadding(dp(12), 0, dp(12), 0)
            textSize = 13f
        }
        connectButton = Button(this).apply {
            text = "Connect"
            isAllCaps = false
            setTextColor(Color.rgb(3, 27, 20))
            setBackgroundColor(Color.rgb(101, 240, 189))
            textSize = 13f
        }
        toolbar.addView(
            addressEdit,
            LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(8) }
        )
        toolbar.addView(connectButton, LinearLayout.LayoutParams(dp(78), dp(46)))

        statusText = TextView(this).apply {
            text = "Connecting to PC…"
            setTextColor(Color.rgb(158, 185, 174))
            setBackgroundColor(Color.rgb(7, 24, 20))
            setPadding(dp(12), dp(5), dp(12), dp(5))
            textSize = 11f
            gravity = Gravity.CENTER_VERTICAL
        }
        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(6, 16, 14))
        }
        root.addView(toolbar, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        root.addView(statusText, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        val pairButton = Button(this).apply {
            text = "Pair PC · Scan QR"
            isAllCaps = false
            textSize = 12f
            setOnClickListener {
                qrScanner.launch(ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                    .setPrompt("On your PC, open http://127.0.0.1:7860/pair")
                    .setBeepEnabled(false).setOrientationLocked(false))
            }
        }
        root.addView(pairButton, LinearLayout.LayoutParams.MATCH_PARENT, dp(44))
        val browserButton = Button(this).apply {
            text = "Blank page? Open in browser"
            textSize = 12f
            setOnClickListener {
                normalizeAddress(addressEdit.text.toString())?.let { address ->
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(address))) }
                        .onFailure { status("Cannot open browser. Copy the address above.", false) }
                }
            }
        }
        root.addView(browserButton, LinearLayout.LayoutParams.MATCH_PARENT, dp(44))
        root.addView(webView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        ViewCompat.requestApplyInsets(root)
    }

    @Suppress("SetJavaScriptEnabled")
    private fun configureWebView() {
        WebView.setWebContentsDebuggingEnabled(false)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            loadsImagesAutomatically = true
            mediaPlaybackRequiresUserGesture = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = false
            cacheMode = WebSettings.LOAD_NO_CACHE
        }
        CookieManager.getInstance().setAcceptCookie(true)
        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                navigationId++
                mainFrameFailed = false
                status("Connecting to PC…", false)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (!mainFrameFailed && url?.startsWith("http") == true) verifyLoadedPage(url)
            }

            override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?) {
                if (request?.isForMainFrame == true) {
                    mainFrameFailed = true
                    status("HTTP ${errorResponse?.statusCode}. Check the PC service.", false)
                    pcConnection.pageFailed()
                }
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) {
                    mainFrameFailed = true
                    status("Connection failed. Start ABGC-mobile on the PC and use the same Wi-Fi.", false)
                    pcConnection.pageFailed()
                }
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                newCallback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = newCallback ?: return false
                return runCatching { launchFileChooser(params) }
                    .onFailure {
                        fileCallback?.onReceiveValue(null)
                        fileCallback = null
                        status("Cannot open camera or gallery: ${it.message ?: "Unknown error"}", false)
                    }
                    .isSuccess
            }
        }
    }

    private fun launchFileChooser(params: WebChromeClient.FileChooserParams?) {
        val contentIntent = (params?.createIntent() ?: Intent(Intent.ACTION_OPEN_DOCUMENT)).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        val captureIntent = createCameraIntent()
        if (params?.isCaptureEnabled == true && captureIntent != null) {
            fileChooser.launch(captureIntent)
            return
        }
        val chooser = Intent.createChooser(contentIntent, "Choose a grape photo")
        if (captureIntent != null) {
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(captureIntent))
        }
        fileChooser.launch(chooser)
    }

    private fun createCameraIntent(): Intent? = runCatching {
        val cameraDir = File(cacheDir, "camera").apply { mkdirs() }
        val output = File.createTempFile("cru_photo_", ".jpg", cameraDir)
        val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", output)
        cameraFile = output
        cameraUri = uri
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(MediaStore.EXTRA_OUTPUT, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }.takeIf { it.resolveActivity(packageManager) != null }
    }.getOrNull()

    private fun connect() {
        pcConnection.manual(addressEdit.text?.toString().orEmpty())
    }

    private fun verifyLoadedPage(address: String) {
        val generation = navigationId
        webView.evaluateJavascript("Boolean(document.querySelector('#analyzeButton') && document.querySelector('#albumInput') && document.body && document.body.getBoundingClientRect().height > 50)") { valid ->
            if (generation != navigationId || mainFrameFailed) return@evaluateJavascript
            if (valid != "true" || webView.height <= 0) {
                status("Page not loaded. Reconnect or open in browser.", false)
                return@evaluateJavascript
            }
            status("Page loaded. Checking PC model service…", false)
            Thread {
                var connection: HttpURLConnection? = null
                val ready = runCatching {
                    val uri = Uri.parse(address)
                    val health = uri.buildUpon().path("/api/health").clearQuery().fragment(null).build().toString()
                    connection = URL(health).openConnection() as HttpURLConnection
                    connection!!.connectTimeout = 5000
                    connection!!.readTimeout = 5000
                    connection!!.useCaches = false
                    connection!!.responseCode == 200 && JSONObject(connection!!.inputStream.bufferedReader().use { it.readText() }).optBoolean("ready", false)
                }.getOrDefault(false)
                connection?.disconnect()
                runOnUiThread {
                    if (!isDestroyed && generation == navigationId && !mainFrameFailed) {
                        status(if (ready) "Connected and verified · Choose a photo" else "Page loaded, but model not ready. Check the PC.", ready)
                    }
                }
            }.start()
        }
    }

    private fun normalizeAddress(raw: String): String? {
        return PairingProtocol.address(raw)
    }

    private fun status(message: String, connected: Boolean) {
        statusText.text = message
        statusText.setTextColor(
            if (connected) Color.rgb(101, 240, 189) else Color.rgb(255, 191, 85)
        )
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    override fun onDestroy() {
        pcConnection.destroy()
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        webView.stopLoading()
        webView.loadUrl("about:blank")
        webView.removeAllViews()
        webView.destroy()
        super.onDestroy()
    }

    override fun onStart() {
        super.onStart()
        pcConnection.start()
    }

    override fun onStop() {
        pcConnection.stop()
        super.onStop()
    }

    companion object {
        private const val PREFS = "cru_grape_counter_mobile"
        private const val KEY_SERVER = "server_address"
        private const val DEFAULT_SERVER = "http://192.168.1.90:7860"
    }
}
