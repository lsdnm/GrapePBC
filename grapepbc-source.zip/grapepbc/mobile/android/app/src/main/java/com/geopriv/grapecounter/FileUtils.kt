package com.geopriv.grapecounter

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

data class PreparedUpload(
    val file: File,
    val displayName: String,
    val mimeType: String
)

object FileUtils {
    private const val MAX_UPLOAD_BYTES = 30L * 1024L * 1024L

    fun copyUriToUploadCache(context: Context, uri: Uri): PreparedUpload {
        val resolver = context.contentResolver
        val rawMime = resolver.getType(uri)?.lowercase() ?: guessMime(uri)
        require(rawMime !in setOf("image/heic", "image/heif", "image/heic-sequence", "image/heif-sequence")) {
            "HEIC/HEIF is not supported. Use JPEG or export as JPEG first."
        }
        val mime = when (rawMime) {
            "image/jpg", "image/pjpeg" -> "image/jpeg"
            else -> rawMime
        }
        require(mime in setOf("image/jpeg", "image/png", "image/webp")) {
            "Only JPEG, PNG or WebP images are supported"
        }

        val originalName = queryDisplayName(context, uri)
            ?: "grape_${System.currentTimeMillis()}.${extensionFor(mime)}"
        val safeName = originalName.replace(Regex("[^A-Za-z0-9._-]"), "_")
            .takeLast(100)
            .ifBlank { "grape.${extensionFor(mime)}" }
        val uploadDir = File(context.cacheDir, "uploads").apply { mkdirs() }
        val output = File.createTempFile("upload_", ".${extensionFor(mime)}", uploadDir)

        try {
            resolver.openInputStream(uri)?.use { input ->
                FileOutputStream(output).use { stream ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    var total = 0L
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        total += read
                        if (total > MAX_UPLOAD_BYTES) {
                            throw IOException("Image exceeds the default 30 MB limit. Choose a smaller image.")
                        }
                        stream.write(buffer, 0, read)
                    }
                }
            } ?: throw IOException("Cannot read the selected image")
        } catch (error: Exception) {
            output.delete()
            throw error
        }

        if (output.length() == 0L) {
            output.delete()
            throw IOException("The selected image is empty")
        }
        return PreparedUpload(output, safeName, mime)
    }

    fun queryDisplayName(context: Context, uri: Uri): String? {
        return runCatching {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        }.getOrNull()
    }

    private fun guessMime(uri: Uri): String = when (uri.toString().substringAfterLast('.', "").lowercase()) {
        "png" -> "image/png"
        "webp" -> "image/webp"
        else -> "image/jpeg"
    }

    private fun extensionFor(mime: String): String = when (mime) {
        "image/png" -> "png"
        "image/webp" -> "webp"
        else -> "jpg"
    }
}
