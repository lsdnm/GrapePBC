package com.geopriv.grapecounter

import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class HealthResponse(
    val status: String,
    val modelLoaded: Boolean,
    val device: String?,
    val modelProfile: String?,
    val routingMode: String?,
    val modelSelectionStatus: String?
)

data class CountResponse(
    val requestId: String?,
    val count: Int,
    val lowResolutionCount: Int?,
    val selectedTileIds: List<String>,
    val budgetFraction: Double?,
    val selectedCoreFraction: Double?,
    val contextProcessingLoad: Double?,
    val processingTimeMs: Double?,
    val device: String?,
    val modelProfile: String?,
    val routingMode: String?,
    val modelSelectionStatus: String?,
    val imageWidth: Int?,
    val imageHeight: Int?,
    val annotatedImageBase64: String?
)

class ApiException(val statusCode: Int, message: String) : IOException(message)

class ApiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .writeTimeout(5, TimeUnit.MINUTES)
        .readTimeout(15, TimeUnit.MINUTES)
        .callTimeout(16, TimeUnit.MINUTES)
        .build()

    fun checkHealth(
        baseAddress: String,
        callback: (Result<HealthResponse>) -> Unit
    ): Call {
        val request = Request.Builder()
            .url(endpoint(baseAddress, "/api/v1/health"))
            .get()
            .build()
        return client.newCall(request).also { call ->
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    callback(Result.failure(e))
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        val body = it.body?.string().orEmpty()
                        if (!it.isSuccessful) {
                            callback(Result.failure(ApiException(it.code, parseError(body))))
                            return
                        }
                        callback(runCatching { parseHealth(body) })
                    }
                }
            })
        }
    }

    fun countImage(
        baseAddress: String,
        upload: PreparedUpload,
        budget: String,
        callback: (Result<CountResponse>) -> Unit
    ): Call {
        val imageBody = upload.file.asRequestBody(upload.mimeType.toMediaTypeOrNull())
        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("image", upload.displayName, imageBody)
            .addFormDataPart("budget", budget)
            .build()
        val request = Request.Builder()
            .url(endpoint(baseAddress, "/api/v1/count"))
            .post(multipart)
            .build()
        return client.newCall(request).also { call ->
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    callback(Result.failure(e))
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        val body = it.body?.string().orEmpty()
                        if (!it.isSuccessful) {
                            callback(Result.failure(ApiException(it.code, parseError(body))))
                            return
                        }
                        callback(runCatching { parseCount(body) })
                    }
                }
            })
        }
    }

    companion object {
        internal fun normalizeBaseAddress(raw: String): String {
            var value = raw.trim()
            require(value.isNotBlank()) { "Enter the PC server address" }
            if (!value.startsWith("http://", true) && !value.startsWith("https://", true)) {
                value = "http://$value"
            }
            return value.trimEnd('/')
        }

        internal fun endpoint(rawBaseAddress: String, path: String): String =
            normalizeBaseAddress(rawBaseAddress) + "/" + path.trimStart('/')

        internal fun parseHealth(body: String): HealthResponse {
            val json = JSONObject(body)
            return HealthResponse(
                status = json.optString("status", "unknown"),
                modelLoaded = json.optBoolean("model_loaded", false),
                device = json.stringOrNull("device"),
                modelProfile = json.stringOrNull("model_profile"),
                routingMode = json.stringOrNull("routing_mode"),
                modelSelectionStatus = json.stringOrNull("model_selection_status")
            )
        }

        internal fun parseCount(body: String): CountResponse {
            val json = JSONObject(body)
            require(json.has("count") && !json.isNull("count")) {
                "Server response is missing the count field"
            }

            val budgetObject = json.objectOrNull("budget")
            val timingObject = json.objectOrNull("timing_ms")
            val modelObject = json.objectOrNull("model")
            val annotatedObject = json.objectOrNull("annotated_image")

            return CountResponse(
                requestId = json.stringOrNull("request_id"),
                count = json.getInt("count"),
                lowResolutionCount = json.intOrNull("low_resolution_count"),
                selectedTileIds = parseTileIds(json),
                budgetFraction = json.doubleOrNull("budget_fraction")
                    ?: budgetObject?.doubleOrNull("requested_fraction"),
                selectedCoreFraction = json.doubleOrNull("selected_core_fraction")
                    ?: budgetObject?.doubleOrNull("actual_core_fraction"),
                contextProcessingLoad = json.doubleOrNull("context_processing_load")
                    ?: budgetObject?.doubleOrNull("context_processing_load"),
                processingTimeMs = json.doubleOrNull("processing_time_ms")
                    ?: timingObject?.doubleOrNull("total"),
                device = json.stringOrNull("device") ?: modelObject?.stringOrNull("device"),
                modelProfile = json.stringOrNull("model_profile")
                    ?: modelObject?.stringOrNull("method"),
                routingMode = json.stringOrNull("routing_mode")
                    ?: modelObject?.stringOrNull("routing_mode"),
                modelSelectionStatus = json.stringOrNull("model_selection_status")
                    ?: modelObject?.stringOrNull("selection_status"),
                imageWidth = json.intOrNull("image_width"),
                imageHeight = json.intOrNull("image_height"),
                annotatedImageBase64 = json.stringOrNull("annotated_image_base64")
                    ?: annotatedObject?.stringOrNull("base64")
            )
        }

        private fun parseTileIds(json: JSONObject): List<String> {
            val direct = json.arrayOrNull("selected_tile_ids")
            if (direct != null) {
                return (0 until direct.length()).map { direct.opt(it).toString() }
            }
            val regions = json.arrayOrNull("selected_regions") ?: return emptyList()
            return (0 until regions.length()).mapNotNull { index ->
                regions.optJSONObject(index)?.stringOrNull("tile_id")
            }
        }

        private fun parseError(body: String): String {
            if (body.isBlank()) return "Server returned no error details"
            return runCatching {
                val root = JSONObject(body)
                when (val detail = root.opt("detail")) {
                    is String -> detail
                    is JSONObject -> detail.stringOrNull("message") ?: detail.toString()
                    is JSONArray -> (0 until detail.length()).joinToString("；") { index ->
                        val item = detail.optJSONObject(index)
                        item?.stringOrNull("msg") ?: detail.opt(index).toString()
                    }
                    else -> root.stringOrNull("message") ?: body
                }
            }.getOrDefault(body.take(300))
        }

        private fun JSONObject.stringOrNull(key: String): String? =
            if (!has(key) || isNull(key)) null else optString(key).takeIf { it.isNotBlank() }

        private fun JSONObject.intOrNull(key: String): Int? =
            if (!has(key) || isNull(key)) null else runCatching { getInt(key) }.getOrNull()

        private fun JSONObject.doubleOrNull(key: String): Double? =
            if (!has(key) || isNull(key)) null else runCatching { getDouble(key) }.getOrNull()

        private fun JSONObject.objectOrNull(key: String): JSONObject? =
            if (!has(key) || isNull(key)) null else optJSONObject(key)

        private fun JSONObject.arrayOrNull(key: String): JSONArray? =
            if (!has(key) || isNull(key)) null else optJSONArray(key)
    }
}
