package com.grapepbc.counter

import org.json.JSONObject
import java.net.URI
import java.security.KeyFactory
import java.security.SecureRandom
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.util.Base64
import java.util.UUID

/** Public-key pinning identifies the paired PC; HTTP photos are not encrypted. */
object PairingProtocol {
    data class Pairing(val id: String, val name: String, val key: String, val urls: List<String>) {
        fun json(): String = JSONObject().put("type", "ABBC_PAIR_V1").put("id", id)
            .put("name", name).put("key", key).put("urls", org.json.JSONArray(urls)).toString()
    }

    fun address(raw: String): String? = runCatching {
        val value = raw.trim().let { if (it.contains("://")) it else "http://$it" }
        val uri = URI(value)
        require(uri.scheme == "http" && uri.userInfo == null && uri.query == null && uri.fragment == null)
        require(uri.path.isNullOrEmpty() || uri.path == "/")
        val host = uri.host ?: error("Missing host")
        val parts = host.split('.').map { it.toInt() }
        require(parts.size == 4 && parts.all { it in 0..255 })
        require(parts[0] == 10 || (parts[0] == 192 && parts[1] == 168) ||
            (parts[0] == 172 && parts[1] in 16..31))
        val port = if (uri.port == -1) 7860 else uri.port
        require(port in 1..65535)
        "http://$host:$port"
    }.getOrNull()

    fun parse(raw: String): Pairing {
        require(raw.length <= 8192) { "Invalid pairing QR" }
        val obj = JSONObject(raw)
        require(obj.getString("type") == "ABBC_PAIR_V1") { "Not an GrapePBC pairing QR" }
        val id = obj.getString("id")
        UUID.fromString(id)
        val key = obj.getString("key")
        require(key.length <= 256)
        val decoded = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Base64.getDecoder().decode(key)))
        require((decoded as java.security.interfaces.ECPublicKey).params.curve.field.fieldSize == 256)
        val urls = obj.getJSONArray("urls")
        require(urls.length() <= 32)
        return Pairing(id, obj.optString("name", "GrapePBC PC").take(64), key,
            (0 until urls.length()).mapNotNull { address(urls.getString(it)) }.distinct())
    }

    fun nonce(): String = ByteArray(32).also { SecureRandom().nextBytes(it) }
        .joinToString("") { "%02x".format(it.toInt() and 255) }

    fun verify(pair: Pairing, nonce: String, response: String): Boolean = runCatching {
        val obj = JSONObject(response)
        require(obj.getString("id") == pair.id)
        val key = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Base64.getDecoder().decode(pair.key)))
        Signature.getInstance("SHA256withECDSA").run {
            initVerify(key)
            update("ABBC/1|${pair.id}|$nonce".toByteArray(Charsets.UTF_8))
            verify(Base64.getDecoder().decode(obj.getString("signature")))
        }
    }.getOrDefault(false)
}
