package com.grapepbc.counter

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.ArrayDeque
import java.util.concurrent.Executors

/** Foreground-only reconnect; never changes the model or reloads a healthy page. */
class PcConnection(context: Context, private val message: (String) -> Unit,
                   private val connected: (String) -> Unit) {
    private val preferences = context.getSharedPreferences("abbc_pc_pairing", Context.MODE_PRIVATE)
    private val nsd = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val connectivity = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var active = false
    private var generation = 0
    private var checking = false
    private var discovery: NsdManager.DiscoveryListener? = null
    private val pending = ArrayDeque<NsdServiceInfo>()
    private var resolving = false
    private var loadedAddress: String? = null
    private var candidates = ArrayDeque<String>()
    private val attempted = mutableSetOf<String>()
    private var pair = preferences.getString("pair", null)?.let { runCatching { PairingProtocol.parse(it) }.getOrNull() }
    private val retry = Runnable { if (active && !checking) begin(null) }
    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { main.post { if (active) begin(null) } }
        override fun onLost(network: Network) { main.post { if (active) schedule(3000) } }
    }

    fun pairedName(): String? = pair?.name
    fun save(value: PairingProtocol.Pairing) {
        pair = value
        preferences.edit().putString("pair", value.json()).remove("address").apply()
        loadedAddress = null
        begin(null)
    }
    fun start() {
        if (active) return
        active = true
        runCatching { connectivity.registerDefaultNetworkCallback(callback) }
        begin(null)
    }
    fun stop() {
        active = false
        generation++
        main.removeCallbacks(retry)
        stopDiscovery()
        runCatching { connectivity.unregisterNetworkCallback(callback) }
        checking = false
    }
    fun destroy() { stop(); worker.shutdownNow() }
    fun manual(raw: String) {
        val address = PairingProtocol.address(raw)
        if (address == null) message("Enter a local IPv4 address, e.g. 192.168.1.90:7860")
        else { loadedAddress = null; begin(address) }
    }
    fun pageFailed() { loadedAddress = null; schedule(3000) }

    private fun schedule(delay: Long = 30000) {
        main.removeCallbacks(retry)
        if (active) main.postDelayed(retry, delay)
    }

    private fun begin(manual: String?) {
        if (!active) return
        val current = pair ?: run { message("First use: tap Pair PC and scan the QR on your PC."); return }
        generation++
        checking = false
        stopDiscovery()
        main.removeCallbacks(retry)
        candidates.clear()
        attempted.clear()
        (listOfNotNull(manual, preferences.getString("address", null)) + current.urls).distinct().forEach { candidates.add(it) }
        tryNext()
    }

    private fun tryNext() {
        if (!active || checking) return
        while (candidates.isNotEmpty()) {
            val address = candidates.removeFirst()
            if (attempted.add(address)) { check(address); return }
        }
        discover()
    }

    private fun check(address: String) {
        val current = pair ?: return
        val ticket = generation
        checking = true
        if (loadedAddress == null) message("Finding and verifying ${current.name}…")
        worker.execute {
            val success = runCatching {
                val nonce = PairingProtocol.nonce()
                val conn = URL("$address/api/pairing/verify").openConnection() as HttpURLConnection
                try {
                    conn.connectTimeout = 2500
                    conn.readTimeout = 3500
                    conn.instanceFollowRedirects = false
                    conn.requestMethod = "POST"
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json")
                    conn.outputStream.use { it.write(JSONObject().put("nonce", nonce).toString().toByteArray()) }
                    conn.responseCode == 200 && PairingProtocol.verify(current, nonce,
                        conn.inputStream.bufferedReader().use { it.readText().take(4096) })
                } finally { conn.disconnect() }
            }.getOrDefault(false)
            main.post {
                if (!active || ticket != generation) return@post
                checking = false
                if (success) {
                    stopDiscovery()
                    preferences.edit().putString("address", address).apply()
                    if (loadedAddress != address) {
                        loadedAddress = address
                        connected(address)
                    }
                    schedule()
                } else {
                    if (loadedAddress == address) loadedAddress = null
                    tryNext()
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun discover() {
        if (discovery != null || !active) return
        val ticket = generation
        message("Searching for paired PC · Keep both devices on the same Wi-Fi")
        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(type: String) {}
            override fun onDiscoveryStopped(type: String) {}
            override fun onServiceLost(info: NsdServiceInfo) {}
            override fun onStopDiscoveryFailed(type: String, code: Int) {}
            override fun onStartDiscoveryFailed(type: String, code: Int) {
                main.post { if (ticket == generation) { stopDiscovery(); schedule() } }
            }
            override fun onServiceFound(info: NsdServiceInfo) {
                main.post {
                    if (active && ticket == generation && info.serviceName.startsWith("ABBC-")) {
                        pending.add(info)
                        resolveNext(ticket)
                    }
                }
            }
        }
        discovery = listener
        runCatching { nsd.discoverServices("_http._tcp.", NsdManager.PROTOCOL_DNS_SD, listener) }
            .onFailure { stopDiscovery(); schedule() }
        main.postDelayed({
            if (active && ticket == generation && discovery != null) {
                stopDiscovery()
                message("PC not found. Check its service and Wi-Fi, or enter its new IP. Retrying automatically…")
                schedule()
            }
        }, 12000)
    }

    @Suppress("DEPRECATION")
    private fun resolveNext(ticket: Int) {
        if (resolving || pending.isEmpty() || !active) return
        resolving = true
        val info = pending.removeFirst()
        runCatching {
            nsd.resolveService(info, object : NsdManager.ResolveListener {
                override fun onResolveFailed(info: NsdServiceInfo, code: Int) {
                    main.post {
                        resolving = false
                        if (active) resolveNext(generation)
                    }
                }
                override fun onServiceResolved(info: NsdServiceInfo) {
                    main.post {
                        resolving = false
                        if (!active) return@post
                        if (ticket != generation) { resolveNext(generation); return@post }
                        val id = info.attributes["id"]?.toString(Charsets.UTF_8)
                        if (id == pair?.id) {
                            PairingProtocol.address("http://${info.host.hostAddress}:${info.port}")?.let {
                                if (it !in attempted) candidates.add(it)
                            }
                            if (!checking && candidates.isNotEmpty()) tryNext()
                        }
                        resolveNext(ticket)
                    }
                }
            })
        }.onFailure { resolving = false; resolveNext(ticket) }
    }

    private fun stopDiscovery() {
        discovery?.let { runCatching { nsd.stopServiceDiscovery(it) } }
        discovery = null
        pending.clear()
        // An old resolve operation finishes asynchronously; it must not overlap a new one.
    }
}
