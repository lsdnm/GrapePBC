"""LAN discovery and QR-pinned PC identity. This is not upload access control.

Only a public key is put in the QR. The PC signs a fresh phone challenge,
so another HTTP server cannot pass verification merely by copying its name.
Photo transport remains HTTP and must be used on a trusted local network.
"""

from __future__ import annotations

import base64
import io
import json
import logging
import os
from pathlib import Path
import re
import socket
import sys
import threading
import time
import uuid

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from flask import jsonify, request, Response

ROOT = Path(__file__).resolve().parents[1]
LOG = logging.getLogger(__name__)


class Identity:
    def __init__(self, directory: Path):
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / "pc_identity.json"
        if not path.exists():
            key = ec.generate_private_key(ec.SECP256R1())
            data = {
                "id": str(uuid.uuid4()),
                "key": key.private_bytes(
                    serialization.Encoding.PEM,
                    serialization.PrivateFormat.PKCS8,
                    serialization.NoEncryption(),
                ).decode(),
            }
            # Exclusive creation: never silently rotate a previously paired identity.
            with path.open("x", encoding="utf-8") as out:
                json.dump(data, out)
                out.flush()
                os.fsync(out.fileno())
        data = json.loads(path.read_text(encoding="utf-8"))
        self.id = data["id"]
        self.key = serialization.load_pem_private_key(data["key"].encode(), None)
        self.public_key = base64.b64encode(
            self.key.public_key().public_bytes(
                serialization.Encoding.DER,
                serialization.PublicFormat.SubjectPublicKeyInfo,
            )
        ).decode()

    def sign(self, nonce: str) -> str:
        if not re.fullmatch(r"[0-9a-f]{64}", nonce):
            raise ValueError("Invalid challenge")
        value = f"ABBC/1|{self.id}|{nonce}".encode()
        return base64.b64encode(
            self.key.sign(value, ec.ECDSA(hashes.SHA256()))
        ).decode()


def addresses():
    import ipaddress
    import psutil

    found = []
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        found.append(sock.getsockname()[0])
    except OSError:
        pass
    finally:
        sock.close()
    stats = psutil.net_if_stats()
    for name, entries in psutil.net_if_addrs().items():
        if name not in stats or not stats[name].isup:
            continue
        for entry in entries:
            if entry.family == socket.AF_INET:
                found.append(entry.address)
    return list(
        dict.fromkeys(
            ip
            for ip in found
            if not ipaddress.ip_address(ip).is_loopback
            and not ipaddress.ip_address(ip).is_link_local
            and not ipaddress.ip_address(ip).is_unspecified
        )
    )


PAGE = """<!doctype html><html lang="en"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ABGC-mobile - Pair your phone</title><style>
body{font:17px system-ui;background:#081d18;color:#edfff5;margin:0}
main{max-width:720px;margin:35px auto;padding:28px;text-align:center}
img{width:min(430px,90%);height:auto;background:white;border:12px solid white;border-radius:12px}
h1{color:#65f0bd}p{line-height:1.6}.small{font-size:13px;color:#aac5b8}
button{padding:12px 24px;background:#65f0bd;border:0;border-radius:9px;font-size:17px}
</style><main><h1>Pair once. Reconnect automatically.</h1>
<p>On your phone, open <b>ABGC-mobile</b> and tap <b>Pair PC</b>.<br>
Scan this QR code. Keep the phone and PC on the same local network.</p>
<img id="qr" src="/pair/qr.svg" alt="PC pairing QR code">
<p id="details"></p><button onclick="location.reload()">Refresh addresses</button>
<p class="small">This QR identifies this PC; it is not a login or encryption feature.
Use a trusted Wi-Fi network. If your network blocks discovery, enter the PC address manually.
The PC service must stay running. Internet-wide remote access is not included.</p>
<script>fetch('/pair/info').then(r=>r.json()).then(x=>{
document.getElementById('details').textContent=x.name+' · '+x.urls.join(' / ');
});</script></main></html>"""


def install_pairing(app, directory=None):
    identity = Identity(Path(directory) if directory else ROOT / "runtime" / "pairing")

    def payload():
        return {
            "type": "ABBC_PAIR_V1",
            "id": identity.id,
            "name": socket.gethostname(),
            "key": identity.public_key,
            "urls": [f"http://{ip}:7860" for ip in addresses()],
        }

    @app.before_request
    def local_pairing_page_only():
        if request.path == "/pair" or request.path.startswith("/pair/"):
            if request.remote_addr not in ("127.0.0.1", "::1") or request.host.split(
                ":"
            )[0] not in ("127.0.0.1", "localhost", "["):
                return (
                    jsonify(
                        error="Open the pairing page on the PC at http://127.0.0.1:7860/pair"
                    ),
                    403,
                )

    @app.get("/pair")
    def pair_page():
        return Response(
            PAGE, content_type="text/html", headers={"Cache-Control": "no-store"}
        )

    @app.get("/pair/info")
    def pair_info():
        return jsonify(payload())

    @app.get("/pair/qr.svg")
    def pair_qr():
        import qrcode
        from qrcode.image.svg import SvgPathImage

        output = io.BytesIO()
        qrcode.make(
            json.dumps(payload(), separators=(",", ":")),
            image_factory=SvgPathImage,
            box_size=8,
            border=4,
        ).save(output)
        return Response(
            output.getvalue(),
            content_type="image/svg+xml",
            headers={"Cache-Control": "no-store"},
        )

    @app.post("/api/pairing/verify")
    def verify():
        data = request.get_json(silent=True) or {}
        if not isinstance(data, dict):
            return jsonify(error="Invalid challenge"), 400
        nonce = data.get("nonce", "")
        if not isinstance(nonce, str):
            return jsonify(error="Invalid challenge"), 400
        try:
            signature = identity.sign(nonce)
        except ValueError:
            return jsonify(error="Invalid challenge"), 400
        return jsonify(id=identity.id, signature=signature)

    return identity


def advertise(identity, stop_event=None):
    """Refresh DNS-SD when adapters change; failure never stops inference."""
    stop_event = stop_event or threading.Event()

    def worker():
        from zeroconf import Zeroconf, ServiceInfo, IPVersion

        registrations = []
        last = None
        try:
            while not stop_event.is_set():
                try:
                    ips = addresses()
                    current = tuple(ips)
                    if current != last:
                        for existing in registrations:
                            existing.close()
                        registrations.clear()
                        for ip in ips:
                            # Publish only the address reachable on this interface.
                            # Otherwise older Android versions can resolve an unrelated
                            # Ethernet/VPN address while connected over Wi-Fi.
                            zc = Zeroconf(interfaces=[ip], ip_version=IPVersion.V4Only)
                            registrations.append(zc)
                            suffix = ip.replace(".", "-")
                            info = ServiceInfo(
                                "_http._tcp.local.",
                                f"ABBC-{identity.id[:8]}-{suffix}._http._tcp.local.",
                                addresses=[socket.inet_aton(ip)],
                                port=7860,
                                properties={"app": "abbc", "id": identity.id, "v": "1"},
                                server=f"abbc-{identity.id[:8]}-{suffix}.local.",
                            )
                            zc.register_service(info)
                        last = current
                        LOG.info("ABBC discovery advertised on %s", ", ".join(ips))
                except Exception:
                    LOG.exception(
                        "LAN discovery unavailable; manual address remains available"
                    )
                    for existing in registrations:
                        existing.close()
                    registrations.clear()
                    last = None
                stop_event.wait(20)
        finally:
            for existing in registrations:
                existing.close()

    thread = threading.Thread(target=worker, name="abbc-discovery", daemon=True)
    thread.start()
    return stop_event
