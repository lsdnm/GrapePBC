"""Mobile pairing support."""
