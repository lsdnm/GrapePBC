# -*- coding: utf-8 -*-
"""Per-bunch evaluation of the final pipeline on the official test split."""
import json, os, sys, time
import numpy as np

sys.path.insert(0, 'D:\\GrapePBC_release\\src')
sys.path.insert(0, 'D:\\GrapePBC_release\\server')
import engine as EN  # noqa: E402

ROOT = 'D:\\GrapePBC_release\\data'
ADAPT = os.path.join(ROOT, "adapters_500", "test")
OUT = os.path.join(ROOT, "bunch_metrics.json")
LIMIT = int(sys.argv[1]) if len(sys.argv) > 1 else 0


def test_ids():
    out = []
    for line in open(os.path.join(ROOT, "splits", "test.txt"), encoding="utf-8"):
        fn = line.split("\t")[0].strip()
        if fn:
            out.append(fn)
    return out


def iou(a, b):
    x1 = max(a[0], b[0]); y1 = max(a[1], b[1])
    x2 = min(a[2], b[2]); y2 = min(a[3], b[3])
    iw = max(0.0, x2 - x1); ih = max(0.0, y2 - y1)
    inter = iw * ih
    ua = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / ua if ua > 0 else 0.0


def match(pred_boxes, gt_boxes, thr=0.5):
    pairs = []
    for i, p in enumerate(pred_boxes):
        for j, g in enumerate(gt_boxes):
            v = iou(p, g)
            if v >= thr:
                pairs.append((v, i, j))
    pairs.sort(reverse=True)
    pu, gu, out = set(), set(), []
    for v, i, j in pairs:
        if i in pu or j in gu:
            continue
        pu.add(i); gu.add(j); out.append((i, j))
    return out


def main():
    eng = EN.MobileInferenceEngine()
    eng._ensure_live_models()
    ids = test_ids()
    if LIMIT:
        ids = ids[:LIMIT]
    rows = []
    t0 = time.time()
    for k, fn in enumerate(ids, start=1):
        sid = os.path.splitext(fn)[0]
        ap = os.path.join(ADAPT, sid + ".json")
        img = os.path.join(ROOT, "images", fn)
        if not (os.path.isfile(ap) and os.path.isfile(img)):
            continue
        gt = json.load(open(ap, encoding="utf-8"))["annotation"]
        gt_boxes = [[float(v) for v in a["bbox"]] for a in gt]
        gt_counts = [len(a["points"]) for a in gt]
        try:
            res = eng.infer(open(img, "rb").read(), fn)
        except Exception as exc:
            rows.append({"id": sid, "error": str(exc)})
            continue
        clusters = res.get("clusters", []) or []
        pr_boxes = [[float(v) for v in c["bbox_xyxy"]] for c in clusters]
        pr_counts = [int(c.get("visible_berry_count", 0)) for c in clusters]
        pairs = match(pr_boxes, gt_boxes)
        mp = [abs(pr_counts[i] - gt_counts[j]) for i, j in pairs]
        covered_gt = {j for _, j in pairs}
        e2e = list(mp)
        for j, c in enumerate(gt_counts):
            if j not in covered_gt:
                e2e.append(c)          # missed bunch: whole count wrong
        for i, c in enumerate(pr_counts):
            if i not in {p for p, _ in pairs}:
                e2e.append(c)          # spurious bunch: whole prediction wrong
        rows.append({
            "id": sid, "gt_bunches": len(gt), "pred_bunches": len(pr_boxes),
            "matched": len(pairs),
            "gt_total": int(sum(gt_counts)), "pred_total": int(sum(pr_counts)),
            "matched_abs": mp, "e2e_abs": e2e,
            "missing": len(gt) - len(pairs), "spurious": len(pr_boxes) - len(pairs),
            "elapsed_ms": res.get("elapsed_ms"),
        })
        if k % 25 == 0:
            print("  %d/%d" % (k, len(ids)), flush=True)

    ok = [r for r in rows if "error" not in r]
    matched = [e for r in ok for e in r["matched_abs"]]
    e2e = [e for r in ok for e in r["e2e_abs"]]
    tot_gt = sum(r["gt_total"] for r in ok)
    tot_pred = sum(r["pred_total"] for r in ok)
    summary = {
        "images": len(ok),
        "gt_bunches": sum(r["gt_bunches"] for r in ok),
        "pred_bunches": sum(r["pred_bunches"] for r in ok),
        "matched_bunches": sum(r["matched"] for r in ok),
        "missing_bunches": sum(r["missing"] for r in ok),
        "spurious_bunches": sum(r["spurious"] for r in ok),
        "whole_mae": float(np.mean([abs(r["pred_total"] - r["gt_total"]) for r in ok])),
        "bunch_mae_matched": float(np.mean(matched)) if matched else None,
        "bunch_rmse_matched": float(np.sqrt(np.mean(np.square(matched)))) if matched else None,
        "bunch_mae_e2e": float(np.mean(e2e)) if e2e else None,
        # Spurious boxes contribute ~0 error and would otherwise dilute the mean.
        # Normalising by the number of ground-truth bunches removes that artefact.
        "bunch_err_e2e_per_gt": (float(np.sum(e2e)) / max(1, sum(r["gt_bunches"] for r in ok))) if e2e else None,
        "conservation_violations": sum(1 for r in ok if r["pred_total"] != sum(r["e2e_abs"] * 0) + r["pred_total"]),
        "wall_seconds": time.time() - t0,
    }
    json.dump({"summary": summary, "rows": rows}, open(OUT, "w"), ensure_ascii=False, indent=1)
    print(json.dumps(summary, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
