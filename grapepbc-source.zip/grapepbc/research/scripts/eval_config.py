# -*- coding: utf-8 -*-
"""Evaluate one ablation configuration with LIVE inference (no artifact replay).

Usage: python eval_config.py <config>
configs: no_hr | fixed1 | fixed4 | fixed8 | fixed12 | adaptive | no_merge
"""
import json
import os
import sys
import time

import numpy as np
from PIL import Image
from PIL import ImageFile

ImageFile.LOAD_TRUNCATED_IMAGES = True

CFG = sys.argv[1]
LIMIT = int(sys.argv[2]) if len(sys.argv) > 2 else 0

ENV = {
    "no_hr":    {"FORCE_CALLS": "0"},
    "fixed1":   {"FORCE_CALLS": "1", "FORCE_NO_STOP": "1"},
    "fixed4":   {"FORCE_CALLS": "4", "FORCE_NO_STOP": "1"},
    "fixed8":   {"FORCE_CALLS": "8", "FORCE_NO_STOP": "1"},
    "fixed12":  {"FORCE_CALLS": "12", "FORCE_NO_STOP": "1"},
    "adaptive": {},
    "no_merge": {"MERGE_THR": "2.0"},
}[CFG]

os.environ.pop("MERGE_THR", None)
os.environ.pop("FORCE_CALLS", None)
os.environ.pop("FORCE_NO_STOP", None)
os.environ.update(ENV)
os.environ.setdefault("BBA_CONF", "0.35")

sys.path.insert(0, 'D:\\GrapePBC_release\\src')
sys.path.insert(0, 'D:\\GrapePBC_release\\server')
import engine as EN  # noqa: E402

ROOT = 'D:\\GrapePBC_release\\data'
ADAPT = os.path.join(ROOT, "adapters_500", "test")
OUT = os.path.join('D:\\GrapePBC_release\\research\\results', "ablation_%s.json" % CFG)


def iou(a, b):
    x1, y1 = max(a[0], b[0]), max(a[1], b[1])
    x2, y2 = min(a[2], b[2]), min(a[3], b[3])
    inter = max(0.0, x2 - x1) * max(0.0, y2 - y1)
    ua = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / ua if ua > 0 else 0.0


def match(pred, gt, thr=0.5):
    pairs = []
    for i, p in enumerate(pred):
        for j, g in enumerate(gt):
            v = iou(p, g)
            if v >= thr:
                pairs.append((v, i, j))
    pairs.sort(reverse=True)
    pu, gu, out = set(), set(), []
    for v, i, j in pairs:
        if i in pu or j in gu:
            continue
        pu.add(i); gu.add(j); out.append((i, j))
    return out


def main():
    eng = EN.MobileInferenceEngine()
    eng._ensure_live_models()
    ids = [l.split("\t")[0].strip() for l in
           open(os.path.join(ROOT, "splits", "test.txt"), encoding="utf-8") if l.strip()]
    if LIMIT:
        ids = ids[:LIMIT]

    rows = []
    t0 = time.time()
    for k, fn in enumerate(ids, start=1):
        img_path = os.path.join(ROOT, "images", fn)
        sid = os.path.splitext(fn)[0]
        ap = os.path.join(ADAPT, sid + ".json")
        if not os.path.isfile(img_path) or not os.path.isfile(ap):
            continue
        try:
            with Image.open(img_path) as src:
                im = src.convert("RGB")
        except Exception:
            continue
        res = eng._live_preview(im)          # live inference, no replay
        clusters = res.get("clusters") or []
        pr_boxes = [[float(v) for v in c["bbox_xyxy"]] for c in clusters]
        pr_counts = [int(c.get("visible_berry_count", 0)) for c in clusters]

        gt = json.load(open(ap, encoding="utf-8"))["annotation"]
        gt_boxes = [[float(v) for v in a["bbox"]] for a in gt]
        gt_counts = [len(a["points"]) for a in gt]

        pairs = match(pr_boxes, gt_boxes)
        mp = [abs(pr_counts[i] - gt_counts[j]) for i, j in pairs]
        covered = {j for _, j in pairs}
        e2e = list(mp) + [gt_counts[j] for j in range(len(gt_counts)) if j not in covered] \
            + [pr_counts[i] for i in range(len(pr_counts)) if i not in {p for p, _ in pairs}]

        rows.append({
            "id": sid, "gt_bunches": len(gt), "pred_bunches": len(pr_boxes),
            "matched": len(pairs), "missing": len(gt) - len(pairs),
            "spurious": len(pr_boxes) - len(pairs),
            "gt_total": int(sum(gt_counts)), "pred_total": int(sum(pr_counts)),
            "matched_abs": mp, "e2e_abs": e2e,
            "calls": res.get("hr_calls") if res.get("hr_calls") is not None else None,
        })
        if k % 50 == 0:
            print("  %d/%d" % (k, len(ids)), flush=True)

    ok = rows
    matched = [e for r in ok for e in r["matched_abs"]]
    e2e = [e for r in ok for e in r["e2e_abs"]]
    calls = [r["calls"] for r in ok if r["calls"] is not None]
    summary = {
        "config": CFG, "env": ENV,
        "images": len(ok),
        "bunch_images": sum(1 for r in ok if r["gt_bunches"] > 0),
        "gt_bunches": sum(r["gt_bunches"] for r in ok),
        "pred_bunches": sum(r["pred_bunches"] for r in ok),
        "matched": sum(r["matched"] for r in ok),
        "missing": sum(r["missing"] for r in ok),
        "spurious": sum(r["spurious"] for r in ok),
        "whole_mae": float(np.mean([abs(r["pred_total"] - r["gt_total"]) for r in ok])),
        "bunch_mae_matched": float(np.mean(matched)) if matched else None,
        "bunch_rmse_matched": float(np.sqrt(np.mean(np.square(matched)))) if matched else None,
        "per_gt_error": float(np.sum(e2e) / max(1, sum(r["gt_bunches"] for r in ok))),
        "mean_calls": float(np.mean(calls)) if calls else None,
        "wall_seconds": time.time() - t0,
    }
    json.dump({"summary": summary, "rows": rows}, open(OUT, "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print(json.dumps(summary, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
