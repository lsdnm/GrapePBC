# -*- coding: utf-8 -*-
"""Apply the trained merge model to a set of predicted bunch boxes."""
import json
import os
import numpy as np
import cv2

MODEL = json.load(open('D:\\GrapePBC_release\\configs\\merge_model_cv.json', encoding="utf-8"))
_F = MODEL["features"]
_MU = np.asarray(MODEL["mean"], np.float64)
_SD = np.asarray(MODEL["std"], np.float64)
_W = np.asarray(MODEL["coef"], np.float64)
_B = float(MODEL["intercept"])
THRESHOLD = float(os.environ.get("MERGE_THR", MODEL.get("threshold", 0.90)))


def _iou(a, b):
    x1 = max(a[0], b[0]); y1 = max(a[1], b[1]); x2 = min(a[2], b[2]); y2 = min(a[3], b[3])
    iw = max(0.0, x2 - x1); ih = max(0.0, y2 - y1)
    inter = iw * ih
    ua = (a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - inter
    return inter / ua if ua > 0 else 0.0


def _pair_features(mi, mj, ai, aj, ci, cj):
    k1 = np.ones((3, 3), np.uint8)
    contact = int((cv2.dilate(mi.astype(np.uint8), k1) & mj.astype(np.uint8)).sum())
    cnt_i = max(cv2.findContours(mi.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[0],
                key=cv2.contourArea)
    cnt_j = max(cv2.findContours(mj.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)[0],
                key=cv2.contourArea)
    per = min(max(1.0, cv2.arcLength(cnt_i, True)), max(1.0, cv2.arcLength(cnt_j, True)))
    contact_rel = contact / per
    ys, xs = np.where(mi > 0); gi = (xs.mean(), ys.mean())
    ys, xs = np.where(mj > 0); gj = (xs.mean(), ys.mean())
    centroid_rel = float(np.hypot(gi[0] - gj[0], gi[1] - gj[1])) / max(np.sqrt(min(ai, aj)), 1.0)
    small, big = sorted((ai, aj))
    balance = small / max(big, 1.0)
    u = ((mi > 0) | (mj > 0))
    rel_area = float(u.sum()) / max(np.median([ai, aj]), 1.0)
    return [contact_rel, centroid_rel, balance, rel_area, abs(ci - cj)]


def merge(boxes, confs, masks, counts):
    """Return (boxes, counts, merged_groups) after probabilistic merging."""
    n = len(boxes)
    if n < 2 or masks is None:
        return boxes, counts, 0
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    merged = 0
    for i in range(n):
        for j in range(i + 1, n):
            mi = masks[i].astype(np.uint8); mj = masks[j].astype(np.uint8)
            ai = float(mi.sum()); aj = float(mj.sum())
            if ai <= 0 or aj <= 0:
                continue
            feats = _pair_features(mi, mj, ai, aj, confs[i], confs[j])
            z = (np.asarray(feats, np.float64) - _MU) / _SD
            p = 1.0 / (1.0 + np.exp(-(z @ _W + _B)))
            if p >= THRESHOLD and find(i) != find(j):
                parent[find(j)] = find(i)
                merged += 1

    groups = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(i)
    out_boxes, out_counts = [], []
    for idx in groups.values():
        bs = [boxes[i] for i in idx]
        out_boxes.append([min(b[0] for b in bs), min(b[1] for b in bs),
                          max(b[2] for b in bs), max(b[3] for b in bs)])
        out_counts.append(int(sum(counts[i] for i in idx)))
    return out_boxes, out_counts, merged
