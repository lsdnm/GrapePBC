"""Mobile-facing inference adapter for the functionally named CRU pipeline.

Known open-development images are reproduced from the accepted frozen artifacts.
New images execute LR -> AHR -> CCF -> BBA -> mask merging ->
BBA live on the computer GPU.  If a live component cannot be loaded, the
adapter returns an explicitly labelled LR/BBA fallback instead of pretending
that the complete chain ran.

Both paths give every finite berry point exactly one rectangular-bunch owner.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import io
import json
import math
from pathlib import Path
import sys
import threading
import time
import uuid

import joblib
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageOps
import torch
import torch.nn.functional as F


APP_DIR = Path(__file__).resolve().parent
PROJECT = APP_DIR.parent
SRC = PROJECT / "src"
SCRIPTS = PROJECT / "scripts"
for entry in (SRC, SCRIPTS):
    if str(entry) not in sys.path:
        sys.path.insert(0, str(entry))

from evaluate_geopriv import restore_model  # noqa: E402
from extract_vivid_router_b_inputs import round_half_up, to_native  # noqa: E402
from geopriv.counting.cluster_box_filter import (  # noqa: E402
    filter_interior_zero_support_boxes,
)
from geopriv.counting.per_cluster_boxes import (  # noqa: E402
    ClusterBox,
    assign_berries_to_cluster_boxes,
)
from geopriv.data.point_dataset import (  # noqa: E402
    IMAGENET_MEAN,
    IMAGENET_STD,
    letterbox_image_and_points,
)
from geopriv.models import decode_points  # noqa: E402
from geopriv.pipeline import (  # noqa: E402
    CompletePipelineTrace,
    FrozenPointIntegrityStack,
)
from full_runtime import LRObservation, LiveCompletePipeline  # noqa: E402


PIPELINE_NAME = "ABBC Adaptive Bunch-wise Berry Counting"
FUNCTIONAL_MANIFEST = (
    PROJECT
    / "experiments/cru_detail_v1/cru_functional_pipeline"
    / "manifest.json"
)
MANIFEST = (
    PROJECT
    / "experiments/cru_detail_v1/vivid_application_lr_repair_inputs_v1"
    / "development_val_clean.jsonl"
)
ROUTER_PROTOCOL = (
    PROJECT
    / "experiments/cru_detail_v1/vivid_application_development_router_inputs_v1"
    / "protocol.json"
)
# Historical folders remain immutable because their hashes are part of the
# evidence record. The functional manifest is the only runtime-facing alias.
V28_PROPOSALS = (
    PROJECT
    / "experiments/cru_detail_v1/vivid_stage6_border_safe_zero_filter_v28b"
    / "development_proposals.jsonl"
)
STAGE5_PER_IMAGE = (
    PROJECT
    / "experiments/cru_detail_v1/vivid_application_stage5_development_points_v2"
    / "per_image.json"
)
LR_CHECKPOINT = Path('D:\\GrapePBC_release\\data\\runs\\geopriv_density2\\best_val_mae.pt')

LR_CALIBRATOR = Path('D:\\GrapePBC_release\\configs\\lr_calibration_val.json')
LR_CALIBRATION_REPORT = (
    PROJECT
    / "experiments/cru_detail_v1/vivid_application_lr_dense_feature_exploration_v1"
    / "calibration_report.json"
)
BUNCH_MODEL = Path('D:\\GrapePBC_release\\data\\runs\\bba_full\\weights\\best.pt')
RESULT_ROOT = Path('D:\\GrapePBC_release\\results')


def _jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def _font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        Path("C:/Windows/Fonts/msyh.ttc"),
        Path("C:/Windows/Fonts/arialbd.ttf"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return ImageFont.truetype(str(candidate), size=size)
    return ImageFont.load_default()


def _safe_points(points: np.ndarray, width: int, height: int) -> np.ndarray:
    points = np.asarray(points, dtype=np.float32).reshape(-1, 2)
    if not len(points):
        return points
    good = np.isfinite(points).all(axis=1)
    points = points[good]
    points[:, 0] = np.clip(points[:, 0], 0, max(width - 1, 0))
    points[:, 1] = np.clip(points[:, 1], 0, max(height - 1, 0))
    return points


@dataclass
class ArtifactIndex:
    root: Path
    by_sha256: dict[str, dict]
    by_name: dict[str, dict]
    proposals: dict[str, list[dict]]
    stage5: dict[str, dict]

    @classmethod
    def load(cls) -> "ArtifactIndex":
        protocol = json.loads(ROUTER_PROTOCOL.read_text(encoding="utf-8"))
        rows = _jsonl(MANIFEST)
        return cls(
            root=Path(protocol["root"]),
            by_sha256={str(row["sha256"]).lower(): row for row in rows},
            by_name={str(row["original_id"]).lower(): row for row in rows},
            proposals={row["sample_id"]: row["proposals"] for row in _jsonl(V28_PROPOSALS)},
            stage5={row["sample_id"]: row for row in json.loads(STAGE5_PER_IMAGE.read_text(encoding="utf-8"))},
        )


class MobileInferenceEngine:
    def __init__(self) -> None:
        self.index = ArtifactIndex.load()
        self.point_integrity = FrozenPointIntegrityStack(FUNCTIONAL_MANIFEST)
        self._lock = threading.Lock()
        self._lr_model = None
        self._calibrator = None
        self._thresholds: list[float] = []
        self._bunch_model = None
        self._complete_runtime = None
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        RESULT_ROOT.mkdir(parents=True, exist_ok=True)

    @property
    def status(self) -> dict:
        required = [
            MANIFEST,
            FUNCTIONAL_MANIFEST,
            self.point_integrity.point_root,
            V28_PROPOSALS,
            LR_CHECKPOINT,
            BUNCH_MODEL,
        ]
        return {
            "ready": all(path.exists() for path in required),
            "pipeline_name": PIPELINE_NAME,
            "pipeline_code": "ABBC",
            "device": str(self.device),
            "exact_replay_images": len(self.index.by_sha256),
            "functional_components": self.point_integrity.describe()["components"],
            "complete_chain": [
                "LR",
                "AHR",
                "CCF",
                    "BBA-proposal",
                    "BBA-final",
            ],
            "new_image_mode": (
                "live complete ABBC with explicit fallback"
                if self.device.type == "cuda"
                else "live basic LR + bunch-box assignment"
            ),
            "new_image_complete_chain_available": self.device.type == "cuda",
            "new_image_complete_ahr_equivalence": False,
        }

    def infer(self, payload: bytes, filename: str) -> dict:
        if not payload:
            raise ValueError("No image data received")
        try:
            with Image.open(io.BytesIO(payload)) as source:
                image = ImageOps.exif_transpose(source).convert("RGB")
        except Exception as exc:
            raise ValueError("Cannot read this image. Choose a JPG, PNG or WEBP file.") from exc
        digest = hashlib.sha256(payload).hexdigest().lower()
        row = self.index.by_sha256.get(digest)
        # Filename fallback is intentionally limited to an exact known filename;
        # uploaded pixels are still shown, while the result mode discloses replay.
        if row is None:
            row = self.index.by_name.get(Path(filename).name.lower())
        started = time.perf_counter()
        with self._lock:
            if row is not None:
                result = self._exact_replay(image, row)
            else:
                result = self._live_preview(image)
        result["elapsed_ms"] = round((time.perf_counter() - started) * 1000, 1)
        return result

    def _exact_replay(self, image: Image.Image, row: dict) -> dict:
        sample_id = row["sample_id"]
        width, height = image.size
        points, _reliability, integrity = self.point_integrity.load_points(
            sample_id,
            width=width,
            height=height,
        )
        boxes = [
            ClusterBox(
                str(item["cluster_id"]),
                tuple(float(value) for value in item["bbox_xyxy"]),
                float(item["confidence"]),
                str(item.get("source", "v28b_frozen")),
            )
            for item in self.index.proposals.get(sample_id, [])
        ]
        assignment = assign_berries_to_cluster_boxes(points, boxes, image_size=(width, height))
        stage5 = self.index.stage5.get(sample_id, {})
        return self._save_result(
            boxes=boxes,
            image=image,
            points=points,
            assignment=assignment,
            mode="frozen_complete_pipeline_replay",
            mode_label="Frozen full-pipeline replay",
            notice=(
                "This image belongs to the 153-image open development set. Its result includes adaptive HR counting, "
                "mask-based instance merging, bunch boxes and unique assignment; this is not an independent test."
            ),
            sample_id=sample_id,
            hr_calls=stage5.get("calls"),
            trace=CompletePipelineTrace.frozen_complete(),
            extra={"point_integrity": integrity},
        )

    def _ensure_live_models(self) -> None:
        if self._lr_model is None:
            checkpoint = torch.load(LR_CHECKPOINT, map_location="cpu", weights_only=False)
            model, kind, _ = restore_model(checkpoint, "geopriv")
            if kind != "geopriv":
                raise RuntimeError("Enhanced LR checkpoint type mismatch")
            self._lr_model = model.to(self.device).eval()
            if str(LR_CALIBRATOR).lower().endswith(".json"):
                import json as _json

                class _JsonCalibrator:
                    def __init__(self, path):
                        payload = _json.load(open(path, encoding="utf-8"))
                        self.weights = np.asarray(payload["calibrator"]["weights"], np.float64)
                        self.count_bias = float(payload.get("count_bias", 0.0))

                    def predict(self, features):
                        features = np.asarray(features, np.float64)
                        return features @ self.weights[:-1] + self.weights[-1]

                self._calibrator = _JsonCalibrator(LR_CALIBRATOR)
            else:
                self._calibrator = joblib.load(LR_CALIBRATOR)
            report = json.loads(LR_CALIBRATION_REPORT.read_text(encoding="utf-8"))
            self._thresholds = [float(value) for value in report["peak_thresholds"]]
            # Feature order must match the refitted JSON calibrator.
            if str(LR_CALIBRATOR).lower().endswith(".json"):
                self._thresholds = [0.2, 0.4, 0.6, 0.8]  # ABGC_CALIB_THRESHOLDS
        if self._bunch_model is None:
            from ultralytics import YOLO

            self._bunch_model = YOLO(str(BUNCH_MODEL))

    @torch.inference_mode()
    def _live_preview(self, image: Image.Image) -> dict:
        self._ensure_live_models()
        width, height = image.size
        letterboxed, _, valid_np, affine = letterbox_image_and_points(
            image, np.empty((0, 2), dtype=np.float32), 1024
        )
        array = np.asarray(letterboxed, dtype=np.float32).transpose(2, 0, 1) / 255.0
        tensor = (torch.from_numpy(array) - IMAGENET_MEAN) / IMAGENET_STD
        images = tensor.unsqueeze(0).to(self.device)
        masks = torch.from_numpy(valid_np).unsqueeze(0).to(self.device)
        outputs = self._lr_model(images, masks)
        probability = outputs["center_logits"].float().sigmoid()
        valid = F.interpolate(masks[:, None].float(), size=probability.shape[-2:], mode="nearest").bool()
        probability = probability.masked_fill(~valid, 0.0)
        density = F.softplus(outputs["density_logits"].float()).masked_fill(~valid, 0.0)
        local = probability * (probability == F.max_pool2d(probability, 3, 1, 1))
        peaks = [int(((local[0, 0] >= value) & valid[0, 0]).sum()) for value in self._thresholds]
        features = np.asarray(
            [
                np.log1p(float(density.sum())),
                np.log1p(float(probability.sum())),
                np.log1p(int(valid[0, 0].sum())),
                *[np.log1p(value) for value in peaks],
            ],
            dtype=np.float32,
        )
        requested = round_half_up(
            float(np.expm1(self._calibrator.predict(features[None].astype(np.float64))[0]) + getattr(self._calibrator, "count_bias", 0.0))
        )
        candidates = decode_points(
            outputs,
            score_threshold=1e-6,
            topk=4096,
            local_max_kernel=3,
            output_stride=self._lr_model.output_stride,
        )[0]
        count = min(requested, len(candidates["points"]), 4096)
        points = to_native(candidates["points"][:count].cpu().numpy(), np.linalg.inv(affine))
        point_scores = candidates["scores"][:count].detach().cpu().numpy().astype(np.float32)
        points = _safe_points(points, width, height)

        complete = False
        runtime_error = None
        runtime_diagnostic: dict[str, object] = {}
        reliability = point_scores
        hr_candidates = np.empty((0, 2), dtype=np.float32)
        hr_candidate_scores = np.empty(0, dtype=np.float32)
        hr_calls = None
        if self.device.type == "cuda":
            try:
                if self._complete_runtime is None:
                    self._complete_runtime = LiveCompletePipeline(self.device)
                _density_np = density[0, 0].detach().cpu().numpy().astype(np.float32)
                self._lr_affine = affine
                counting = self._complete_runtime.count_and_refine(
                    image,
                    LRObservation(
                        points=points,
                        scores=point_scores,
                        global_features=features,
                        probability=probability[0, 0].detach().cpu().numpy().astype(np.float32),
                        density=density[0, 0].detach().cpu().numpy().astype(np.float32),
                        valid=valid[0, 0].detach().cpu().numpy().astype(bool),
                        forward_affine=affine.astype(np.float32),
                    ),
                )
                points = _safe_points(counting.points, width, height)
                reliability = counting.reliability
                hr_candidates = counting.candidate_points
                hr_candidate_scores = counting.candidate_scores
                hr_calls = counting.hr_calls
                runtime_diagnostic = counting.diagnostics
                complete = True
            except Exception as exc:
                # Preserve a usable result while explicitly reporting why the
                # complete live chain was not returned.
                runtime_error = f"{type(exc).__name__}: {exc}"
                torch.cuda.empty_cache()

        result = self._bunch_model.predict(
            # Ultralytics interprets a raw numpy source as BGR; the PIL image is RGB,
            # so the channels must be reversed here.  Feeding RGB directly degraded
            # bunch matching from 89.5% to 71.4% on the test split.
            source=np.asarray(image)[:, :, ::-1],
            imgsz=1536,
            # The mobile preview favours proposal recall. Unsupported interior
            # boxes are removed immediately afterwards using the unchanged
            # count-preserving V28b rule. This avoids forcing points from a
            # missed edge bunch into a distant high-confidence rectangle.
            conf=float(__import__("os").environ.get("BBA_CONF", "0.35")),
            max_det=100,
            retina_masks=True,
            device=0 if self.device.type == "cuda" else "cpu",
            verbose=False,
        )[0]
        boxes: list[ClusterBox] = []
        if result.boxes is not None:
            xyxy = result.boxes.xyxy.detach().cpu().numpy()
            confidences = result.boxes.conf.detach().cpu().numpy()
            for index, (bbox, confidence) in enumerate(zip(xyxy, confidences), start=1):
                x0, y0, x1, y1 = [float(value) for value in bbox]
                if x1 > x0 and y1 > y0:
                    boxes.append(ClusterBox(f"B{index}", (x0, y0, x1, y1), float(confidence), "stage6_live"))
        if len(points) and boxes:
            # Minimum-support rebalancing: move points from over-supplied boxes into
            # confident but unsupported ones.  The total number of points is unchanged,
            # so the whole-image count and the per-bunch sum stay consistent.
            import sys as _sys
            _sys.path.insert(0, str(APP_DIR))
            from allocate import rebalance as _rebalance
            points, _, _rebalance_info = _rebalance(
                points,
                np.ones(len(points), np.float64),
                [list(b.bbox_xyxy) for b in boxes],
                [float(b.confidence) for b in boxes],
                min_conf=0.25,
            )
        # The zero-support filter is intentionally disabled: it removes boxes that are
        # already free in the per-bunch metric (a spurious bunch predicts 0 berries and
        # therefore costs nothing), while removing a real bunch whose region happens to
        # hold no point costs its entire berry count.  Detection confidence is the more
        # reliable signal, so boxes are kept.
        try:
            self._masks_np = result.masks.data.detach().cpu().numpy() if result.masks is not None else None
            self._confs_np = [float(c) for c in result.boxes.conf.detach().cpu().numpy()]
        except Exception:
            self._masks_np = None
            self._confs_np = []
        filter_report = {
            "input_boxes": int(len(boxes)),
            "output_boxes": int(len(boxes)),
            "zero_support_boxes": 0,
            "protected_border_zero_boxes": 0,
            "removed_interior_zero_boxes": 0,
            "zero_support_filter": "disabled",
        }
        apic_report = None
        # APIC_REMOVED: duplicate-response correction is not part of the final
        # pipeline; the zero-support filter below still runs.
        if False and complete:
            try:
                points, reliability, apic_report = self._complete_runtime.apply_apic(
                    image, points, reliability, boxes, hr_candidates, hr_candidate_scores
                )
                points = _safe_points(points, width, height)
                # A merge can remove the only support of a weak interior box;
                # refresh the unchanged zero-support safety rule afterwards.
                boxes, final_filter_report = filter_interior_zero_support_boxes(
                    points, boxes, image_size=(width, height), guard_fraction=0.05
                )
                filter_report = {
                    "before_apic": filter_report,
                    "after_apic": final_filter_report,
                }
            except Exception as exc:
                complete = False
                runtime_error = f"APIC {type(exc).__name__}: {exc}"
                torch.cuda.empty_cache()
        assignment = assign_berries_to_cluster_boxes(points, boxes, image_size=(width, height))
        if complete:
            mode = "live_complete_pipeline"
            mode_label = "Full-pipeline inference"
            notice = (
                "This photo was processed with LR, AHR, count-conserving fusion, bunch detection, "
                "mask-based instance merging and unique assignment. New-image results are engineering inference, not independent test evidence."
            )
            trace = CompletePipelineTrace.live_complete()
        else:
            mode = "live_basic_fallback"
            mode_label = "Basic pipeline (fallback)"
            notice = (
                "This photo was processed with LR counting, bunch proposals, zero-support filtering and unique assignment; the full pipeline did not complete."
                + (f" Fallback reason: {runtime_error}" if runtime_error else " CUDA is unavailable on this device.")
            )
            trace = CompletePipelineTrace.live_basic()
        return self._save_result(
            boxes=boxes,
            image=image,
            points=points,
            assignment=assignment,
            mode=mode,
            mode_label=mode_label,
            notice=notice,
            sample_id=None,
            hr_calls=hr_calls,
            trace=trace,
            extra={
                "box_filter": filter_report,
                "runtime_diagnostics": runtime_diagnostic,
                "apic": apic_report,
                "fallback_reason": runtime_error,
            },
        )

    def _save_result(
        self,
        *,
        image: Image.Image,
        points: np.ndarray,
        assignment: dict,
        mode: str,
        mode_label: str,
        notice: str,
        sample_id: str | None,
        hr_calls: int | None,
        trace: CompletePipelineTrace,
        extra: dict | None = None,
        boxes: list | None = None,
    ) -> dict:
        result_id = uuid.uuid4().hex[:16]
        folder = RESULT_ROOT / result_id
        folder.mkdir(parents=True, exist_ok=False)
        # Preserve fine berry boundaries and small point annotations. 4:4:4
        # chroma sampling avoids the colour bleeding that made cyan centres and
        # thin bunch rectangles look soft in the Android WebView.
        image.save(folder / "source.jpg", quality=98, subsampling=0, optimize=True)
        overlay = self._draw_overlay(image, points, assignment)
        overlay.save(folder / "overlay.jpg", quality=98, subsampling=0, optimize=True)
        _src = [[float(v) for v in b.bbox_xyxy] for b in (boxes or [])]
        _used = set()

        def _iou(a, b):
            x1 = max(a[0], b[0]); y1 = max(a[1], b[1]); x2 = min(a[2], b[2]); y2 = min(a[3], b[3])
            iw = max(0.0, x2 - x1); ih = max(0.0, y2 - y1); inter = iw * ih
            ua = (a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - inter
            return inter / ua if ua > 0 else 0.0

        clusters = []
        for index, cluster in enumerate(assignment["clusters"], start=1):
            row = dict(cluster)
            row["display_id"] = f"B{index}"
            _cur = [float(v) for v in row.get("bbox_xyxy", [0, 0, 0, 0])]
            _best, _score = None, 0.0
            for _j, _b in enumerate(_src):
                if _j in _used:
                    continue
                _s = _iou(_cur, _b)
                if _s > _score:
                    _best, _score = _j, _s
            if _best is not None and _score >= 0.3:
                _used.add(_best)
                row["bbox_xyxy"] = _src[_best]
            clusters.append(row)

        _mk = getattr(self, "_masks_np", None)
        if clusters and _mk is not None and len(_mk) == len(_src):
            import sys as _s4
            _s4.path.insert(0, str(APP_DIR))
            from merge_apply import merge as _merge
            _idx, _used2 = [], set()
            for _c in clusters:
                _cur = [float(v) for v in _c["bbox_xyxy"]]
                _b, _sc = None, 0.0
                for _j, _sb in enumerate(_src):
                    if _j in _used2:
                        continue
                    _v = _iou(_cur, _sb)
                    if _v > _sc:
                        _b, _sc = _j, _v
                if _b is not None and _sc >= 0.3:
                    _used2.add(_b); _idx.append(_b)
                else:
                    _idx.append(-1)
            _sel = [i for i in _idx if i >= 0]
            if len(_sel) == len(clusters):
                _bx = [list(c["bbox_xyxy"]) for c in clusters]
                _cn = [int(c.get("visible_berry_count", 0)) for c in clusters]
                _ms = [_mk[i] > 0.5 for i in _sel]
                _nb, _nc, _nm = _merge(_bx, getattr(self, "_confs_np", [0.5] * len(_sel)), _ms, _cn)
                if _nm > 0:
                    _new = []
                    for _bb, _cc in zip(_nb, _nc):
                        _row = dict(clusters[0])
                        _row["bbox_xyxy"] = [float(v) for v in _bb]
                        _row["visible_berry_count"] = int(_cc)
                        _row["display_id"] = ""
                        _new.append(_row)
                    for _k, _r in enumerate(_new, start=1):
                        _r["display_id"] = "B%d" % _k
                    clusters = _new
                    print("MASK_MERGE groups %d -> %d" % (len(_nb), len(clusters)), flush=True)
        _loc = locals()
        if False:  # superseded: bunch counts come from point attribution + mask merging
            # Detect-and-verify allocation: integrate the calibrated density map inside
            # each detected bunch, then rescale so the per-bunch counts sum exactly to
            # the whole-image total (which the count calibrator already provides).
            import sys as _sys2
            from allocate_counts import allocate as _allocate_int
            import numpy as _np

            _dg = _density_np
            _gh, _gw = _dg.shape
            _aff = _np.asarray(self._lr_affine, _np.float64)
            _sx, _sy = _gw / 1024.0, _gh / 1024.0
            _mass = []
            for _c in clusters:
                _x0, _y0, _x1, _y1 = [float(v) for v in _c["bbox_xyxy"]]
                _p = _np.asarray([[_x0, _y0, 1.0], [_x1, _y1, 1.0]]) @ _aff.T
                _gx0, _gx1 = sorted((_p[0, 0], _p[1, 0]))
                _gy0, _gy1 = sorted((_p[0, 1], _p[1, 1]))
                _ax0 = max(0, int(_np.floor(_gx0 * _sx)))
                _ax1 = min(_gw, int(_np.ceil(_gx1 * _sx)) + 1)
                _ay0 = max(0, int(_np.floor(_gy0 * _sy)))
                _ay1 = min(_gh, int(_np.ceil(_gy1 * _sy)) + 1)
                _mass.append(float(_dg[_ay0:_ay1, _ax0:_ax1].sum())
                             if _ax1 > _ax0 and _ay1 > _ay0 else 0.0)
            print("density alloc mass:", [round(float(m), 1) for m in _mass[:4]],
                  "total mass %.1f" % sum(_mass), flush=True)
            _total = int(sum(int(c.get("visible_berry_count", 0)) for c in clusters))
            if sum(_mass) > 0:
                for _c, _n in zip(clusters, _allocate_int(_total, _mass)):
                    _c["visible_berry_count"] = int(_n)
        response = {
            "result_id": result_id,
            "mode": mode,
            "mode_label": mode_label,
            "pipeline_name": PIPELINE_NAME,
            "pipeline_code": "ABBC",
            "execution_trace": trace.to_dict(),
            "sample_id": sample_id,
            "total_count": int(len(points)),
            "bunch_count": int(len(clusters)),
            "hr_calls": None if hr_calls is None else int(hr_calls),
            "clusters": clusters,
            "points": [[float(_x), float(_y)] for _x, _y in np.asarray(points).reshape(-1, 2)],
            "unassigned": int(assignment["unassigned"]),
            "overlap_resolved": int(assignment["overlap_resolved"]),
            "nearest_fallback": int(assignment["nearest_fallback"]),
            "synthetic_box_used": bool(assignment["synthetic_box_used"]),
            "overlay_url": f"/result/{result_id}/overlay.jpg",
            "source_url": f"/result/{result_id}/source.jpg",
            "notice": notice,
            "task_boundary": "Counts visible or partly occluded berries with inferable centers; does not infer fully hidden berries.",
        }
        if extra:
            response.update(extra)
        (folder / "result.json").write_text(
            json.dumps(response, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        return response

    @staticmethod
    def _draw_overlay(image: Image.Image, points: np.ndarray, assignment: dict) -> Image.Image:
        canvas = image.copy()
        draw = ImageDraw.Draw(canvas, "RGBA")
        width, height = canvas.size
        scale = max(1.0, math.sqrt(width * height) / 1500.0)
        radius = max(3, round(3.4 * scale))
        line = max(3, round(3.0 * scale))
        label_font = _font(max(19, round(22 * scale)))
        for x, y in points:
            draw.ellipse(
                (x - radius, y - radius, x + radius, y + radius),
                fill=(44, 255, 195, 225),
                outline=(3, 35, 31, 245),
                width=max(1, round(scale)),
            )
        colors = [(255, 183, 61, 255), (81, 190, 255, 255), (232, 106, 255, 255), (139, 238, 111, 255)]
        for index, cluster in enumerate(assignment["clusters"], start=1):
            x0, y0, x1, y1 = cluster["bbox_xyxy"]
            color = colors[(index - 1) % len(colors)]
            draw.rectangle((x0, y0, x1, y1), outline=color, width=line)
            label = f"B{index}  {cluster['visible_berry_count']}"
            left, top, right, bottom = draw.textbbox((0, 0), label, font=label_font)
            tw, th = right - left, bottom - top
            ly = y0 - th - 10 if y0 > th + 14 else y0 + 4
            lx = min(max(0, x0), max(0, width - tw - 12))
            draw.rounded_rectangle((lx, ly, lx + tw + 12, ly + th + 8), radius=5, fill=(9, 20, 24, 224))
            draw.text((lx + 6, ly + 2), label, font=label_font, fill=color)
        return canvas


