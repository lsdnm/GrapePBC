"""Same-LAN mobile web application for the CRU-AHPI counting pipeline."""

from __future__ import annotations

import json
from pathlib import Path
import socket
import sys

from flask import Flask, jsonify, render_template, request, send_file, send_from_directory
from werkzeug.exceptions import RequestEntityTooLarge

from engine import MobileInferenceEngine, RESULT_ROOT


APP_DIR = Path(__file__).resolve().parent
app = Flask(__name__, template_folder=str(APP_DIR / "templates"), static_folder=str(APP_DIR / "static"))
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024
engine = MobileInferenceEngine()
sys.path.insert(0, 'D:\\GrapePBC_release\\mobile\\connection')
from abbc_pairing import install_pairing, advertise
pc_identity = install_pairing(app)
APK_PATH = Path('D:\\GrapePBC_release\\mobile\\dist\\GrapePBC-mobile.apk')


def lan_ip() -> str:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        return str(sock.getsockname()[0])
    except OSError:
        return "127.0.0.1"
    finally:
        sock.close()


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/health")
def health():
    return jsonify({**engine.status, "lan_url": f"http://{lan_ip()}:7860",
                    "server_id": pc_identity.id, "pairing_version": 1})


@app.get("/download/apk")
def download_apk():
    if not APK_PATH.exists():
        return jsonify({"error": "APK is not available yet"}), 404
    return send_file(
        APK_PATH,
        mimetype="application/vnd.android.package-archive",
        as_attachment=True,
        download_name="GrapePBC-mobile.apk",
    )


@app.post("/api/infer")
def infer():
    upload = request.files.get("image")
    if upload is None or not upload.filename:
        return jsonify({"error": "Please select a grape photo"}), 400
    try:
        result = engine.infer(upload.read(), upload.filename)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    except Exception as exc:
        app.logger.exception("inference failed")
        return jsonify({"error": f"Inference failed: {exc}"}), 500
    return jsonify(result)


@app.get("/result/<result_id>/<filename>")
def result_file(result_id: str, filename: str):
    if not result_id.isalnum() or filename not in {"source.jpg", "overlay.jpg", "result.json"}:
        return jsonify({"error": "Invalid result path"}), 404
    return send_from_directory(RESULT_ROOT / result_id, filename)


@app.errorhandler(RequestEntityTooLarge)
def too_large(_error):
    return jsonify({"error": "Image exceeds 25 MB. Compress it and try again."}), 413


if __name__ == "__main__":
    advertise(pc_identity)
    status = engine.status
    print(json.dumps(status, ensure_ascii=False, indent=2), flush=True)
    print(f"Phone access URL: http://{lan_ip()}:7860", flush=True)
    app.run(host="0.0.0.0", port=7860, threaded=True, use_reloader=False)
