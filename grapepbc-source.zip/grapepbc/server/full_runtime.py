"""Live functionally named CRU counting, centre refinement and point integrity.

This module packages the previously separate research stages without changing
their frozen weights or thresholds.  It never loads annotation files.  The
large-image branch executes every core; the sparse branch calls Rich-HR only
for cores selected sequentially by the frozen router.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import os
import math

from pathlib import Path
from types import SimpleNamespace
from typing import Sequence

import joblib
import numpy as np
from PIL import Image
from scipy.spatial import cKDTree
import torch
import torch.nn.functional as F


APP_DIR = Path(__file__).resolve().parent
PROJECT = APP_DIR.parent
EXP = PROJECT / "experiments" / "cru_detail_v1"

from geopriv.counting import (  # noqa: E402
    PrimaryCenterGatePolicy,
    SupplementalCenterGatePolicy,
    apply_primary_center_gate,
    apply_supplemental_candidate_gate,
)
from geopriv.counting.per_cluster_boxes import ClusterBox  # noqa: E402
from geopriv.data.point_dataset import (  # noqa: E402
    IMAGENET_MEAN,
    IMAGENET_STD,
    letterbox_image_and_points,
)
from geopriv.models import decode_points  # noqa: E402
from geopriv.routing import (  # noqa: E402
    assign_points_to_tiles,
    fuse_sparse_core_points,
    interpolate_full_hr_points,
    make_core_halo_tiles,
)

import analyze_vivid_density_core_replacement as count_stage  # noqa: E402
import develop_cluster_aware_point_reallocation as cluster_helper  # noqa: E402
import develop_v33_conservative_duplicate_deletion as candidate_geometry  # noqa: E402
import develop_v36_local_duplicate_merge as local_merge  # noqa: E402
import develop_v38_point_integrity_component_merge as component_merge  # noqa: E402
import develop_v41_adaptive_scale_point_integrity as adaptive_merge  # noqa: E402
import run_vivid_hr_core_calibration as rich_stage  # noqa: E402
import run_vivid_hr_global_conservation as global_stage  # noqa: E402
import run_vivid_hr_global_conservation_v2 as stable_stage  # noqa: E402
import run_vivid_hr_residual_fusion as residual_stage  # noqa: E402
import run_vivid_router_b_expert_gate as full_gate_stage  # noqa: E402
import select_vivid_router_density_fusion as router_fusion  # noqa: E402
import train_anchor_heatmap_center_refiner_oof_v5 as heatmap_refiner  # noqa: E402
import train_rgb_point_center_refiner as rgb_refiner  # noqa: E402
import train_synthetic_center_quality_selector_oof_v17 as quality_stage  # noqa: E402
import train_v35_oof_duplicate_action_classifier as local_pair_stage  # noqa: E402
import train_v40_adaptive_scale_duplicate_pair_classifier as adaptive_pair_stage  # noqa: E402
import train_vivid_hr_density_conservation as density_stage  # noqa: E402
import train_vivid_sequential_router as router_stage  # noqa: E402


RICH_PROTOCOL = EXP / "vivid_application_rich_hr_core_calibration_v1/protocol.json"
DENSITY_RUN = EXP / "vivid_application_rich_hr_density_v2"

# Feature expert is skipped by default: it does not affect counting or placement
# (verified on the development split) but accounts for ~62% of one HR call.
SKIP_RICH_EXPERT = os.environ.get("SKIP_RICH", "1") == "1"
RICH_FEATURE_DIM = 349
RESIDUAL_CHECKPOINT = EXP / "vivid_application_rich_hr_residual_fusion_v1/best_val_mae.pt"
ROUTER_PACKAGE = EXP / "vivid_application_stage4_refined_fusion_v2/router_package.pt"
STABLE_RUN = EXP / "vivid_application_hr_global_conservation_v2"
FULL_GATE_RUN = EXP / "vivid_application_hr_conservative_gate_frozen_v1"
CPCR_MANIFEST = EXP / "vivid_center_refinement_v18_frozen/manifest.json"
LOCAL_PAIR_MODEL = EXP / "vivid_oof_duplicate_action_classifier_v35/full_refit.joblib"
ADAPTIVE_PAIR_MODEL = EXP / "vivid_adaptive_scale_duplicate_pair_oof_v40/all_development.joblib"


@dataclass(slots=True)
class LRObservation:
    points: np.ndarray
    scores: np.ndarray
    global_features: np.ndarray
    probability: np.ndarray
    density: np.ndarray
    valid: np.ndarray
    forward_affine: np.ndarray


@dataclass(slots=True)
class CountingResult:
    points: np.ndarray
    reliability: np.ndarray
    candidate_points: np.ndarray
    candidate_scores: np.ndarray
    hr_calls: int
    heatmap: np.ndarray
    diagnostics: dict[str, object]


def _json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _safe_points(value: np.ndarray) -> np.ndarray:
    points = np.asarray(value, dtype=np.float32).reshape(-1, 2)
    if not np.isfinite(points).all():
        raise ValueError("non-finite point coordinates")
    return points


def _make_tile_item(image: Image.Image, tile, input_size: int) -> dict[str, object]:
    context = image.crop((tile.context_x0, tile.context_y0, tile.context_x1, tile.context_y1))
    transformed, _, valid, affine = letterbox_image_and_points(
        context, np.empty((0, 2), dtype=np.float32), input_size
    )
    corners = np.asarray(
        [
            [tile.core_x0 - tile.context_x0, tile.core_y0 - tile.context_y0, 1.0],
            [tile.core_x1 - tile.context_x0, tile.core_y1 - tile.context_y0, 1.0],
        ],
        dtype=np.float32,
    )
    mapped = (affine @ corners.T).T[:, :2]
    bounds = np.asarray([mapped[0, 0], mapped[0, 1], mapped[1, 0], mapped[1, 1]], np.float32)
    array = np.asarray(transformed, dtype=np.float32).transpose(2, 0, 1).copy() / 255.0
    tensor = (torch.from_numpy(array) - IMAGENET_MEAN) / IMAGENET_STD
    return {
        "image": tensor,
        "valid_image_mask": torch.from_numpy(valid),
        "target": {
            "sample_id": "runtime:phone",
            "tile_id": str(tile.tile_id),
            "core_bounds_xyxy": torch.from_numpy(bounds),
            "inverse_affine": torch.from_numpy(np.linalg.inv(affine).astype(np.float32)),
            "context_origin_xy": torch.tensor(
                [tile.context_x0, tile.context_y0], dtype=torch.float32
            ),
            "core_count": torch.tensor(0, dtype=torch.int64),
        },
    }


def _score_points_from_candidates(
    points: np.ndarray,
    candidates: np.ndarray,
    scores: np.ndarray,
    *,
    default: float = 0.5,
) -> np.ndarray:
    if not len(points):
        return np.empty(0, np.float32)
    if not len(candidates):
        return np.full(len(points), default, np.float32)
    tree = cKDTree(np.asarray(candidates, np.float64))
    _distance, nearest = tree.query(np.asarray(points, np.float64))
    return np.asarray(scores, np.float32)[np.asarray(nearest, np.int64)]


def _realize_candidate_total(
    candidates: Sequence[np.ndarray],
    scores: Sequence[np.ndarray],
    local_counts: Sequence[int],
    requested_total: int,
) -> tuple[np.ndarray, np.ndarray]:
    selected_p, selected_s, spare_p, spare_s = [], [], [], []
    for points, confidence, count in zip(candidates, scores, local_counts, strict=True):
        count = max(0, min(int(count), len(points)))
        order = np.argsort(-confidence, kind="stable")
        points, confidence = points[order], confidence[order]
        if count:
            selected_p.append(points[:count]); selected_s.append(confidence[:count])
        if count < len(points):
            spare_p.append(points[count:]); spare_s.append(confidence[count:])
    chosen_p = np.concatenate(selected_p) if selected_p else np.empty((0, 2), np.float32)
    chosen_s = np.concatenate(selected_s) if selected_s else np.empty(0, np.float32)
    spare_points = np.concatenate(spare_p) if spare_p else np.empty((0, 2), np.float32)
    spare_scores = np.concatenate(spare_s) if spare_s else np.empty(0, np.float32)
    requested = min(max(int(requested_total), 0), len(chosen_p) + len(spare_points))
    if requested <= len(chosen_p):
        order = np.argsort(-chosen_s, kind="stable")[:requested]
        return chosen_p[order].astype(np.float32), chosen_s[order].astype(np.float32)
    need = requested - len(chosen_p)
    order = np.argsort(-spare_scores, kind="stable")[:need]
    return (
        np.concatenate((chosen_p, spare_points[order])).astype(np.float32),
        np.concatenate((chosen_s, spare_scores[order])).astype(np.float32),
    )


class LiveCompletePipeline:
    """Lazy-loaded live AHR -> CCF -> CPCR -> APIC implementation."""

    def __init__(self, device: torch.device) -> None:
        if device.type != "cuda":
            raise RuntimeError("完整AHR运行链需要CUDA；CPU路径保留基础LR回退")
        self.device = device
        self.rich_protocol = _json(RICH_PROTOCOL)
        self.density_protocol = _json(DENSITY_RUN / "protocol.json")
        self.cpcr_manifest = _json(CPCR_MANIFEST)
        self.core_size = int(self.rich_protocol["core_size"])
        self.halo = int(self.rich_protocol["halo"])
        self.input_size = int(self.rich_protocol["input_size"])
        self._rich = None
        self._density = None
        self._residual = None
        self._residual_checkpoint = None
        self._router = None
        self._router_payload = None
        self._primary = None
        self._secondary = None
        self._heatmap_refiner = None
        self._quality = None
        self._local_pair_model = None
        self._adaptive_pair_model = None

    def _ensure_counting_models(self) -> None:
        if self._rich is None:
            self._rich = rich_stage.make_expert(self.rich_protocol)
        if self._density is None:
            self._density = density_stage.make_model(self.density_protocol)
            checkpoint = torch.load(
                DENSITY_RUN / "best_val_mae.pt", map_location="cpu", weights_only=False
            )
            self._density.load_state_dict(checkpoint["model"], strict=True)
            self._density.eval()
        if self._residual is None:
            checkpoint = torch.load(RESIDUAL_CHECKPOINT, map_location="cpu", weights_only=False)
            self._residual_checkpoint = checkpoint
            self._residual = residual_stage.head_instance(checkpoint["protocol"]).to(self.device)
            self._residual.load_state_dict(checkpoint["model"], strict=True)
            self._residual.eval()
        if self._router is None:
            payload = torch.load(ROUTER_PACKAGE, map_location="cpu", weights_only=False)
            self._router_payload = payload
            self._router = router_stage.model_instance(payload["protocol"]).to(self.device)
            self._router.load_state_dict(payload["model"], strict=True)
            self._router.eval()

    def _ensure_cpcr_models(self) -> None:
        if self._primary is not None:
            return
        components = self.cpcr_manifest["components"]
        primary = torch.load(components["primary_rgb_offset"]["path"], map_location="cpu", weights_only=False)
        secondary = torch.load(components["candidate_v6"]["path"], map_location="cpu", weights_only=False)
        heatmap = torch.load(components["candidate_heatmap_v5"]["path"], map_location="cpu", weights_only=False)
        quality = torch.load(components["candidate_quality_v17"]["path"], map_location="cpu", weights_only=False)
        self._primary = rgb_refiner.RGBPointCenterRefiner().to(self.device)
        self._primary.load_state_dict(primary["model"], strict=True); self._primary.eval()
        self._secondary = rgb_refiner.RGBPointCenterRefiner().to(self.device)
        self._secondary.load_state_dict(secondary["model"], strict=True); self._secondary.eval()
        self._heatmap_refiner = heatmap_refiner.AnchorHeatmapRefiner().to(self.device)
        self._heatmap_refiner.load_state_dict(heatmap["model"], strict=True); self._heatmap_refiner.eval()
        self._quality = quality_stage.CenterQualityNet().to(self.device)
        self._quality.load_state_dict(quality["model"], strict=True); self._quality.eval()

    def _ensure_apic_models(self) -> None:
        self._ensure_cpcr_models()
        if self._local_pair_model is None:
            self._local_pair_model = joblib.load(LOCAL_PAIR_MODEL)
        if self._adaptive_pair_model is None:
            self._adaptive_pair_model = joblib.load(ADAPTIVE_PAIR_MODEL)

    def _base_cores(self, observation: LRObservation, tiles, width: int, height: int) -> list[dict]:
        owners = assign_points_to_tiles(observation.points, tiles, strict=True)
        probability_total = float(observation.probability[observation.valid].sum())
        density_total = float(observation.density[observation.valid].sum())
        max_row = max(tile.row for tile in tiles)
        max_column = max(tile.column for tile in tiles)
        rows = []
        for tile in tiles:
            chosen = owners == tile.tile_id
            core_points = observation.points[chosen]
            core_scores = observation.scores[chosen]
            probability_values = router_stage.map_region(
                observation.probability, observation.valid, observation.forward_affine, tile
            )
            density_values = router_stage.map_region(
                observation.density, observation.valid, observation.forward_affine, tile
            )
            width_fraction = (tile.core_x1 - tile.core_x0) / width
            height_fraction = (tile.core_y1 - tile.core_y0) / height
            base = [
                *observation.global_features.tolist(),
                math.log1p(len(observation.points)), math.log1p(len(core_points)),
                len(core_points) / max(len(observation.points), 1),
                (tile.core_x0 + tile.core_x1) / (2.0 * width),
                (tile.core_y0 + tile.core_y1) / (2.0 * height),
                width_fraction, height_fraction, width_fraction * height_fraction,
                tile.row / max(max_row, 1), tile.column / max(max_column, 1),
                float(tile.core_x0 == 0 or tile.core_y0 == 0 or tile.core_x1 == width or tile.core_y1 == height),
                *router_stage.distribution_features(core_points, core_scores, tile),
                *router_stage.map_features(probability_values, probability_total),
                *router_stage.map_features(density_values, density_total),
                float(len(probability_values) / max(
                    (tile.core_x1 - tile.core_x0) * (tile.core_y1 - tile.core_y0) / 4.0, 1.0
                )),
            ]
            rows.append({
                "tile_id": tile.tile_id,
                "row": tile.row,
                "column": tile.column,
                "center": np.asarray(base[15:17], np.float32),
                "lr_count": int(len(core_points)),
                "base": np.asarray(base, np.float32),
                "lr_points": core_points,
                "lr_scores": core_scores,
            })
        return rows

    @torch.inference_mode()
    def _predict_residual(self, feature: np.ndarray, lr_count: int, candidate_count: int) -> dict[str, object]:
        checkpoint = self._residual_checkpoint
        normalized = ((feature - checkpoint["feature_mean"]) / checkpoint["feature_std"]).astype(np.float32)
        output = self._residual(torch.from_numpy(normalized[None]).to(self.device))
        delta = output["delta"].detach().cpu().numpy()
        error = float(np.expm1(np.clip(output["log_error"].item(), 0.0, 10.0)))
        fused = int(residual_stage.decode_numpy(
            np.asarray([lr_count]), delta, np.asarray([candidate_count])
        )[0])
        accepted = error <= float(checkpoint["fallback_error_threshold"])
        return {"count": fused if accepted else lr_count, "raw_count": fused, "error": error, "accepted": accepted}

    @torch.inference_mode()
    def _run_tile(self, image: Image.Image, tile) -> dict[str, object]:
        item = _make_tile_item(image, tile, self.input_size)
        if SKIP_RICH_EXPERT:
            # The feature expert no longer feeds counting or placement after the
            # removal of APIC and the dense calibration path; it only costs time.
            rich = {
                "feature": np.zeros(RICH_FEATURE_DIM, np.float32),
                "candidate_native_xy": np.empty((0, 2), np.float32),
                "candidate_scores": np.empty(0, np.float32),
                "candidates": np.empty((0, 2), np.float32),
                "scores": np.empty(0, np.float32),
            }
        else:
            rich = rich_stage.extract_item(self._rich, item, self.rich_protocol)
        tensor = item["image"].to(self.device)
        valid = item["valid_image_mask"].to(self.device)
        outputs = self._density(tensor[None], valid[None])
        decoded = decode_points(
            outputs, score_threshold=1e-6, topk=4096, local_max_kernel=3,
            output_stride=self._density.output_stride,
        )[0]
        density_map = F.softplus(outputs["density_logits"].float())
        bounds = item["target"]["core_bounds_xyxy"].to(self.device)
        owned_density = rich_stage.rect_mask(
            valid, bounds, density_map.shape[-2], density_map.shape[-1], self.input_size
        )
        mass = float(density_map[0, 0][owned_density].sum())
        density_count = max(0, int(math.floor(mass + 0.5)))
        points = decoded["points"].detach().cpu().numpy().astype(np.float32)
        scores = decoded["scores"].detach().cpu().numpy().astype(np.float32)
        x0, y0, x1, y1 = item["target"]["core_bounds_xyxy"].numpy().tolist()
        owned = (points[:, 0] >= x0) & (points[:, 0] < x1) & (points[:, 1] >= y0) & (points[:, 1] < y1)
        points, scores = points[owned], scores[owned]
        order = np.argsort(-scores, kind="stable")
        points, scores = points[order], scores[order]
        native = rich_stage.to_native(
            points,
            item["target"]["inverse_affine"].numpy(),
            item["target"]["context_origin_xy"].numpy(),
        )
        return {
            "rich_feature": rich["feature"],
            "rich_candidates": rich["candidate_native_xy"],
            "rich_scores": rich["candidate_scores"],
            "density_candidates": native,
            "density_scores": scores,
            "density_mass": mass,
            "density_count": min(density_count, len(native)),
        }

    def _attach_tile_prediction(self, core: dict, tile_output: dict, lr_total: int) -> None:
        feature = np.concatenate((
            tile_output["rich_feature"],
            np.asarray([
                math.log1p(core["lr_count"]), math.log1p(lr_total),
                core["lr_count"] / max(lr_total, 1),
                math.log1p(len(tile_output["rich_candidates"])),
            ], np.float32),
        ))
        residual = self._predict_residual(feature, core["lr_count"], len(tile_output["rich_candidates"]))
        core.update(tile_output)
        core["fusion_feature"] = feature
        core["hr_count"] = int(residual["count"])
        core["hr_delta"] = int(residual["count"]) - int(core["lr_count"])
        core["hr_predicted_error"] = float(residual["error"])

    def _router_utility(self, features: np.ndarray) -> np.ndarray:
        payload = self._router_payload
        target_dim = int(payload["feature_mean"].shape[0])
        if features.shape[1] < target_dim:
            _pad = np.zeros((features.shape[0], target_dim - features.shape[1]), np.float32)
            features = np.concatenate([features, _pad], axis=1)
        elif features.shape[1] > target_dim:
            features = features[:, :target_dim]
        normalized = ((features - payload["feature_mean"]) / payload["feature_std"]).astype(np.float32)
        with torch.inference_mode():
            encoded = self._router(torch.from_numpy(normalized).to(self.device))
        from geopriv.models.sequential_utility_router import decode_utility
        return decode_utility(encoded).cpu().numpy()

    def _sparse_counting(
        self, image: Image.Image, observation: LRObservation, tiles, cores
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, int, dict[str, object]]:
        policy = self._router_payload["refined_stage4_policy"]
        selected: list[int] = []
        utilities: list[float] = []
        _budget = int(__import__("os").environ.get("FORCE_CALLS", "0") or 0)
        _cap = _budget if _budget >= 0 and "FORCE_CALLS" in __import__("os").environ else int(policy["maximum_calls"])
        force_no_stop = os.environ.get("FORCE_NO_STOP", "0") == "1"
        while len(selected) < min(_cap, len(cores)):
            remaining = [index for index in range(len(cores)) if index not in selected]
            features = np.stack([
                router_stage.state_features(
                    {"lr_total": len(observation.points), "cores": cores},
                    tuple(selected), index, int(policy["maximum_calls"]),
                )
                for index in remaining
            ])
            utility = self._router_utility(features)
            density_prior = np.log1p(np.asarray([cores[index]["lr_count"] for index in remaining], np.float32))
            utility_z = (utility - utility.mean()) / (utility.std() + 1e-6)
            density_z = (density_prior - density_prior.mean()) / (density_prior.std() + 1e-6)
            score = ((1.0 - float(policy["density_weight"])) * utility_z
                     + float(policy["density_weight"]) * density_z)
            position = int(np.argmax(score))
            chosen = remaining[position]
            if not force_no_stop and float(utility[position]) <= float(policy["minimum_predicted_utility"]):
                break
            output = self._run_tile(image, tiles[chosen])
            self._attach_tile_prediction(cores[chosen], output, len(observation.points))
            selected.append(chosen); utilities.append(float(utility[position]))

        if not selected:
            return (
                observation.points.copy(), observation.scores.copy(),
                np.empty((0, 2), np.float32), np.empty(0, np.float32), 0,
                {"branch": "sparse_ahr", "selected_tile_ids": [], "utilities": []},
            )
        lr_total = len(observation.points)
        if lr_total <= 50:
            gain, floor = 0.5, 5
        elif lr_total <= 100:
            gain, floor = 0.5, 5
        elif lr_total <= 200:
            gain, floor = 0.625, 15
        else:
            gain, floor = 0.375, 0
        _g_ov = __import__("os").environ.get("CCF_GAIN")
        _f_ov = __import__("os").environ.get("CCF_FLOOR")
        if _g_ov is not None:
            gain = float(_g_ov)
        if _f_ov is not None:
            floor = int(_f_ov)
        if _g_ov is not None or _f_ov is not None:
            print("CCF OVERRIDE ACTIVE gain=%s floor=%s" % (gain, floor), flush=True)
        owners = assign_points_to_tiles(observation.points, tiles, strict=True)
        requested, candidates, scores = {}, {}, {}
        reliability_parts = [observation.scores[~np.isin(owners, np.asarray(selected, np.int64))]]
        saturated = 0
        for index in selected:
            core = cores[index]
            target = (
                count_stage.gain_count(core["lr_count"], core["density_count"], gain)
                if core["density_count"] >= floor else core["lr_count"]
            )
            target = min(int(target), len(core["density_candidates"]))
            saturated += int(target < (
                count_stage.gain_count(core["lr_count"], core["density_count"], gain)
                if core["density_count"] >= floor else core["lr_count"]
            ))
            requested[index] = target
            candidates[index] = core["density_candidates"]
            scores[index] = core["density_scores"]
            tile = tiles[index]
            owned = (
                (core["density_candidates"][:, 0] >= tile.core_x0)
                & (core["density_candidates"][:, 0] < tile.core_x1)
                & (core["density_candidates"][:, 1] >= tile.core_y0)
                & (core["density_candidates"][:, 1] < tile.core_y1)
            )
            local_scores = core["density_scores"][owned]
            reliability_parts.append(np.sort(local_scores)[::-1][:target])
        fused = fuse_sparse_core_points(
            observation.points, tiles, selected, requested, candidates, scores
        )
        reliability = np.concatenate(reliability_parts).astype(np.float32)
        pool_points = np.concatenate([cores[index]["density_candidates"] for index in selected])
        pool_scores = np.concatenate([cores[index]["density_scores"] for index in selected])
        return fused.points, reliability, pool_points, pool_scores, len(selected), {
            "branch": "sparse_ahr",
            "selected_tile_ids": selected,
            "utilities": utilities,
            "requested_counts_by_tile": {str(key): int(value) for key, value in requested.items()},
            "candidate_saturation_events": saturated,
        }

    def _full_counting(
        self, image: Image.Image, observation: LRObservation, tiles, cores, width: int, height: int
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, int, dict[str, object]]:
        for index, tile in enumerate(tiles):
            output = self._run_tile(image, tile)
            self._attach_tile_prediction(cores[index], output, len(observation.points))
        residual_checkpoint = self._residual_checkpoint
        features = np.stack([core["fusion_feature"] for core in cores]).astype(np.float32)
        candidates = [core["rich_candidates"] for core in cores]
        rich_scores = [core["rich_scores"] for core in cores]
        lr_counts = np.asarray([core["lr_count"] for core in cores], np.int64)
        candidate_counts = np.asarray([len(value) for value in candidates], np.int64)
        residual_count = np.asarray([core["hr_count"] for core in cores], np.int64)
        residual_error = np.asarray([core["hr_predicted_error"] for core in cores], np.float32)
        stable_protocol = _json(STABLE_RUN / "protocol.json")
        absolute_checkpoint = torch.load(
            stable_protocol["absolute_checkpoint"], map_location="cpu", weights_only=False
        )
        absolute_count, occupancy, log_count = rich_stage.predict_head(
            absolute_checkpoint,
            features[:, : len(absolute_checkpoint["feature_names"])],
            candidate_counts,
        )
        sample_ids = np.asarray(["runtime:phone"] * len(cores))
        data = {
            "features": features,
            "target": np.zeros(len(cores), np.int64),
            "sample_ids": sample_ids,
            "tile_ids": np.asarray([tile.tile_id for tile in tiles], np.int64),
            "candidates": candidates,
            "candidate_scores": rich_scores,
            "candidate_counts": candidate_counts,
            "lr_counts": lr_counts,
            "residual_count": residual_count,
            "residual_error": residual_error,
            "absolute_count": absolute_count,
            "absolute_occupancy": occupancy,
            "absolute_log_count": log_count,
            "records": {"runtime:phone": SimpleNamespace(width=width, height=height)},
        }
        table = global_stage.make_image_table(data)
        stable_artifact = joblib.load(STABLE_RUN / "global_count_ensemble.joblib")
        stable_total = int(stable_stage.predict_artifact(table, stable_artifact)[0])
        stable_points, _capacity, _saturated = global_stage.conserve_points(
            candidates, rich_scores, residual_count, stable_total
        )
        density_candidates = [core["density_candidates"] for core in cores]
        density_scores = [core["density_scores"] for core in cores]
        density_counts = [core["density_count"] for core in cores]
        density_total = int(sum(density_counts))
        density_points, density_point_scores = _realize_candidate_total(
            density_candidates, density_scores, density_counts, density_total
        )
        density_stats = np.asarray(
            [global_stage.distribution_stats(np.asarray([core["density_mass"] for core in cores]))],
            np.float32,
        )
        observable = np.column_stack((
            table["features"], density_stats, np.log1p([density_total]),
            (np.asarray([density_total]) - stable_total) / math.sqrt(stable_total + 1.0),
            np.abs(np.asarray([density_total]) - stable_total) / math.sqrt(stable_total + 1.0),
        )).astype(np.float32)
        gate = joblib.load(FULL_GATE_RUN / "router_gate_frozen.joblib")
        requested, alpha = full_gate_stage.predict_estimator(
            gate["config"], gate["estimator"], observable,
            np.asarray([stable_total]), np.asarray([density_total]),
        )
        expected = int(requested[0])
        match_radius = 8.0 * max(width, height) / 1024.0
        points, _sources = interpolate_full_hr_points(
            stable_points, density_points, density_point_scores, expected,
            match_radius=match_radius,
        )
        pool_points = np.concatenate(density_candidates) if density_candidates else np.empty((0, 2), np.float32)
        pool_scores = np.concatenate(density_scores) if density_scores else np.empty(0, np.float32)
        rich_pool = np.concatenate(candidates) if candidates else np.empty((0, 2), np.float32)
        rich_pool_scores = np.concatenate(rich_scores) if rich_scores else np.empty(0, np.float32)
        all_candidates = np.concatenate((pool_points, rich_pool))
        all_scores = np.concatenate((pool_scores, rich_pool_scores))
        reliability = _score_points_from_candidates(points, all_candidates, all_scores)
        return points, reliability, pool_points, pool_scores, len(tiles), {
            "branch": "exhaustive_ahr_gate",
            "selected_tile_ids": [tile.tile_id for tile in tiles],
            "stable_count": stable_total,
            "density_count": density_total,
            "fused_count": len(points),
            "gate_alpha": float(alpha[0]),
            "candidate_saturated": bool(_saturated),
        }

    @torch.inference_mode()
    def _cpcr(self, image: Image.Image, points: np.ndarray) -> tuple[np.ndarray, dict[str, object]]:
        self._ensure_cpcr_models()
        points = _safe_points(points)
        if not len(points):
            return points, {"primary_moved": 0, "supplemental_moved": 0}
        rgb = np.asarray(image.convert("RGB"), dtype=np.uint8)
        width, height = image.size
        scale = 1024.0 / max(width, height)
        spacing = rgb_refiner.spacing(points, scale)
        primary_offset, primary_confidence = rgb_refiner.predict_offsets(
            self._primary, rgb, points, spacing, scale, self.device
        )
        primary, primary_moved = apply_primary_center_gate(
            points, primary_offset, primary_confidence,
            coordinate_scale=scale, image_size=(width, height),
            policy=PrimaryCenterGatePolicy(),
        )
        secondary_offset, secondary_confidence = rgb_refiner.predict_offsets(
            self._secondary, rgb, points, spacing, scale, self.device
        )
        heat_offsets, heat_confidences = [], []
        for start in range(0, len(points), 128):
            patch = rgb_refiner.sample_patches(rgb, points[start:start + 128], scale, self.device)
            logits, confidence = self._heatmap_refiner(patch)
            heat_offsets.append(heatmap_refiner.heatmap_offset(logits).cpu().numpy())
            heat_confidences.append(torch.sigmoid(confidence).cpu().numpy())
        heat_offset = np.concatenate(heat_offsets).astype(np.float32)
        heat_confidence = np.concatenate(heat_confidences).astype(np.float32)
        offsets = np.stack((np.zeros_like(points), primary_offset, secondary_offset, heat_offset), axis=1)
        proposed = points[:, None, :] + offsets / scale
        proposed[:, :, 0] = np.clip(proposed[:, :, 0], 0, width - 1e-3)
        proposed[:, :, 1] = np.clip(proposed[:, :, 1], 0, height - 1e-3)
        scores = []
        for start in range(0, len(proposed), 48):
            patch = quality_stage.sample_patches(rgb, proposed[start:start + 48], scale, self.device)
            scores.append(self._quality(patch).reshape(-1, 4).cpu().numpy())
        quality_scores = np.concatenate(scores).astype(np.float32)
        refined, supplemental_moved, _choice = apply_supplemental_candidate_gate(
            points, primary, offsets, quality_scores,
            coordinate_scale=scale, image_size=(width, height),
            policy=SupplementalCenterGatePolicy(),
        )
        if len(refined) != len(points):
            raise RuntimeError("CPCR changed the point count")
        return refined, {
            "primary_moved": int(primary_moved.sum()),
            "supplemental_moved": int(supplemental_moved.sum()),
            "count_preserved": True,
            "secondary_confidence_mean": float(secondary_confidence.mean()),
            "heatmap_confidence_mean": float(heat_confidence.mean()),
        }

    def count_and_refine(self, image: Image.Image, observation: LRObservation) -> CountingResult:
        self._ensure_counting_models()
        width, height = image.size
        tiles = make_core_halo_tiles(
            width, height, core_size=self.core_size, halo=self.halo
        )
        cores = self._base_cores(observation, tiles, width, height)
        image_row = {"lr_total": len(observation.points), "cores": cores}
        # The 75-count split is removed: every image now goes through the same
        # sequential 1-12 adaptive routing, so the number of HR calls is decided by
        # the utility threshold alone rather than by a count bin.
        try:
            # Every image takes the sequential 1-12 adaptive route; the legacy
            # exhaustive path is only a safety net if the sparse route fails.
            raw = self._sparse_counting(image, observation, tiles, cores)
        except Exception:
            raw = self._full_counting(image, observation, tiles, cores, width, height)
        points, reliability, candidates, candidate_scores, calls, diagnostic = raw
        # CPCR removed: center refinement is not part of the final pipeline.
        refined, cpcr = points, {"disabled": True}
        diagnostic["cpcr"] = cpcr
        diagnostic["tile_count"] = len(tiles)
        diagnostic["lr_count"] = len(observation.points)
        diagnostic["count_after_ccf"] = len(points)
        return CountingResult(
            refined.astype(np.float32), reliability.astype(np.float32),
            candidates.astype(np.float32), candidate_scores.astype(np.float32),
            int(calls), observation.density.astype(np.float32), diagnostic,
        )

    def _semantic_scores(self, image: Image.Image, points: np.ndarray) -> np.ndarray:
        rgb = np.asarray(image.convert("RGB"), dtype=np.uint8)
        scale = 1024.0 / max(image.size)
        values = []
        with torch.inference_mode():
            for start in range(0, len(points), 256):
                patch = quality_stage.sample_patches(
                    rgb, points[start:start + 256].astype(np.float32), scale, self.device
                )
                values.append(self._quality(patch).cpu().numpy())
        return np.concatenate(values).astype(np.float64) if values else np.empty(0, np.float64)

    @staticmethod
    def _runtime_local_actions(base: dict) -> list[dict]:
        nearest, support_distance, candidate_score = base["candidate_evidence"]
        actions = []
        for distance, first, second in base["close_pairs"]:
            if distance > 6.0:
                continue
            if nearest[first] < 0 or nearest[first] != nearest[second]:
                continue
            if max(support_distance[first], support_distance[second]) > 5.0:
                continue
            if min(candidate_score[first], candidate_score[second]) < 0.075:
                continue
            for delete, keep in ((first, second), (second, first)):
                actions.append({
                    "delete": int(delete), "keep": int(keep), "distance": float(distance),
                    "features": local_pair_stage.action_features(base, delete, keep, distance),
                })
        return actions

    @staticmethod
    def _runtime_adaptive_pairs(base: dict) -> list[dict]:
        points_scaled = base["points"] * base["scale"]
        nearest_candidate, support_distance, candidate_score = base["candidate_evidence"]
        rows = []
        for owner in np.unique(base["owners"]):
            members = np.flatnonzero(base["owners"] == owner)
            if len(members) < 2:
                continue
            for left, right in cKDTree(points_scaled[members]).query_pairs(16.000001):
                first, second = int(members[left]), int(members[right])
                distance = float(np.linalg.norm(points_scaled[first] - points_scaled[second]))
                first_spacing, second_spacing = adaptive_pair_stage.nearest_spacing_excluding(
                    points_scaled, first, second
                )
                midpoint_index, midpoint_distance, midpoint_score = adaptive_pair_stage.midpoint_candidate(
                    base, first, second
                )
                rel = sorted((float(base["reliability"][first]), float(base["reliability"][second])))
                semantic = sorted((float(base["semantic_score"][first]), float(base["semantic_score"][second])))
                support = sorted((float(support_distance[first]), float(support_distance[second])))
                scores = sorted((float(candidate_score[first]), float(candidate_score[second])))
                spacing = sorted((first_spacing, second_spacing))
                owner_count = int(np.count_nonzero(base["owners"] == owner))
                values = np.asarray((
                    distance, rel[0], rel[1], rel[1] - rel[0],
                    semantic[0], semantic[1], semantic[1] - semantic[0],
                    support[0], support[1], scores[0], scores[1],
                    float(nearest_candidate[first] >= 0 and nearest_candidate[first] == nearest_candidate[second]),
                    midpoint_distance, midpoint_score, spacing[0], spacing[1],
                    distance / max(spacing[0], 1e-3), distance / max(np.mean(spacing), 1e-3),
                    min(base["local_counts"][8][first], base["local_counts"][8][second]),
                    max(base["local_counts"][8][first], base["local_counts"][8][second]),
                    min(base["local_counts"][12][first], base["local_counts"][12][second]),
                    max(base["local_counts"][12][first], base["local_counts"][12][second]),
                    np.log1p(owner_count), np.log1p(len(base["points"])),
                ), np.float32)
                # Match the frozen V40 training protocol: training excluded
                # candidate pairs whose feature vector contained a non-finite
                # value (normally an infinite support distance when neither
                # point has an eligible HR candidate).  Such a pair has no
                # calibrated input for the classifier and must not be scored.
                if len(values) != len(adaptive_pair_stage.FEATURES) or not np.isfinite(values).all():
                    continue
                rows.append({
                    "first": first, "second": second, "distance": distance,
                    "target_candidate_index": midpoint_index, "features_array": values,
                    "features": {
                        name: float(value)
                        for name, value in zip(adaptive_pair_stage.FEATURES, values, strict=True)
                    },
                })
        return rows

    def apply_apic(
        self,
        image: Image.Image,
        points: np.ndarray,
        reliability: np.ndarray,
        boxes: Sequence[ClusterBox],
        candidates: np.ndarray,
        candidate_scores: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray, dict[str, object]]:
        self._ensure_apic_models()
        points = _safe_points(points).astype(np.float64)
        reliability = np.asarray(reliability, np.float64).reshape(-1)
        if len(points) < 2 or not len(candidates):
            return points.astype(np.float32), reliability.astype(np.float32), {
                "components": 0, "merges": 0, "reason": "insufficient_points_or_hr_candidates"
            }
        active_boxes, synthetic = cluster_helper.ensure_evaluation_box(
            points, list(boxes), image.size
        )
        owners = cluster_helper.owner_indices(points, active_boxes, image.size)
        candidate_owner = cluster_helper.strict_candidate_owner(candidates, active_boxes)
        inside = candidate_owner >= 0
        base = {
            "points": points,
            "reliability": reliability,
            "semantic_score": self._semantic_scores(image, points),
            "image_size": image.size,
            "scale": 1024.0 / max(image.size),
            "boxes": active_boxes,
            "owners": owners,
            "candidates": np.asarray(candidates, np.float64)[inside],
            "candidate_scores": np.asarray(candidate_scores, np.float64)[inside],
            "candidate_owner": candidate_owner[inside],
        }
        base["point_nearest"], base["local_counts"] = local_pair_stage.local_geometry(
            points, base["scale"]
        )
        base["candidate_evidence"] = candidate_geometry.candidate_evidence(base)
        base["close_pairs"] = candidate_geometry.close_pairs(base)

        local_actions = self._runtime_local_actions(base)
        if local_actions:
            matrix = np.stack([row["features"] for row in local_actions])
            scores = self._local_pair_model.predict_proba(matrix)[:, 1]
            local_pairs = local_merge.unique_pairs(base, local_actions, scores)
        else:
            local_pairs = []
        adaptive_rows = self._runtime_adaptive_pairs(base)
        if adaptive_rows:
            matrix = np.stack([row["features_array"] for row in adaptive_rows])
            probabilities = self._adaptive_pair_model.predict_proba(matrix)[:, 1]
            for row, probability in zip(adaptive_rows, probabilities, strict=True):
                row["score"] = float(probability)
        policy = adaptive_merge.AdaptivePolicy(
            probability_threshold=0.97,
            maximum_pair_distance_1024=12.0,
            maximum_midpoint_candidate_distance_1024=4.0,
            minimum_midpoint_candidate_score=0.075,
        )
        pairs, source_counts = adaptive_merge.union_pairs(local_pairs, adaptive_rows, policy)
        output, output_reliability, diagnostic = component_merge.apply_policy(
            base, pairs, adaptive_merge.APPLY_ALL
        )
        diagnostic = {key: value for key, value in diagnostic.items() if key != "mask"}
        diagnostic.update(source_counts)
        diagnostic["synthetic_box_used"] = bool(synthetic)
        diagnostic["runtime_annotations"] = False
        return output.astype(np.float32), output_reliability.astype(np.float32), diagnostic


__all__ = ["LRObservation", "CountingResult", "LiveCompletePipeline"]
