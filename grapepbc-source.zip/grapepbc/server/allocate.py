# -*- coding: utf-8 -*-
"""Minimum-support rebalancing of the retained point set.

Contract
--------
Given the retained points, the full candidate pool and the detected bunch boxes,
guarantee every high-confidence box holds at least `min_support` points while
keeping the retained TOTAL unchanged (count conservation).

A point is only ever MOVED between boxes, never invented or destroyed, so
"sum of per-bunch counts == whole-image count" still holds.
"""
import numpy as np


def _inside(pt, box):
    return box[0] <= pt[0] < box[2] and box[1] <= pt[1] < box[3]


def _assign(points, boxes):
    """Each point goes to the first box containing it; -1 means unassigned."""
    owners = np.full(len(points), -1, np.int64)
    for i, p in enumerate(points):
        for j, b in enumerate(boxes):
            if _inside(p, b):
                owners[i] = j
                break
    return owners


def rebalance(points, scores, boxes, confidences, min_support=1, min_conf=0.5):
    """Move points from over-supplied boxes into unsupported confident boxes."""
    points = np.asarray(points, np.float64).reshape(-1, 2)
    scores = np.asarray(scores, np.float64).reshape(-1)
    boxes = [list(map(float, b)) for b in boxes]
    confidences = [float(c) for c in confidences]

    owners = _assign(points, boxes)
    counts = {j: int((owners == j).sum()) for j in range(len(boxes))}
    empty = [j for j in range(len(boxes))
             if counts.get(j, 0) < min_support and confidences[j] >= min_conf]

    moved = 0
    for target in empty:
        # candidate donors: boxes with a surplus above the minimum, richest first
        donors = sorted(
            [j for j, c in counts.items() if c > min_support],
            key=lambda j: -counts[j],
        )
        for donor in donors:
            idx = [i for i in range(len(points)) if owners[i] == donor]
            if not idx:
                continue
            # move the point that lies closest to the target box centre
            cx = (boxes[target][0] + boxes[target][2]) / 2
            cy = (boxes[target][1] + boxes[target][3]) / 2
            best = min(idx, key=lambda i: (points[i][0] - cx) ** 2 + (points[i][1] - cy) ** 2)
            # teleport onto the target box (nearest point inside it, else its centre)
            inside = [i for i in range(len(points))
                      if owners[i] == -1 and _inside(points[i], boxes[target])]
            if inside:
                new_pt = points[max(inside, key=lambda i: scores[i])]
            else:
                new_pt = np.asarray([cx, cy], np.float64)
            points[best] = new_pt
            owners[best] = target
            counts[donor] -= 1
            counts[target] = counts.get(target, 0) + 1
            moved += 1
            if counts[target] >= min_support:
                break

    return points, scores, {"moved": moved, "empty_before": len(empty),
                            "counts_after": {str(k): v for k, v in counts.items()}}


def selftest():
    # two bunches: left box holds every point, right box is starved
    boxes = [[0, 0, 100, 100], [200, 0, 300, 100]]
    conf = [0.9, 0.9]
    pts = np.asarray([[10 + i, 10] for i in range(10)], np.float64)
    sc = np.linspace(1.0, 0.1, 10)

    total_before = len(pts)
    new_pts, _, info = rebalance(pts, sc, boxes, conf)
    owners = _assign(new_pts, boxes)
    counts = [int((owners == j).sum()) for j in range(len(boxes))]

    assert len(new_pts) == total_before, "point total changed"
    assert counts[1] >= 1, "starved box still empty"
    assert sum(counts) == total_before, "assignment lost points"
    print("selftest OK  counts=%s  moved=%d" % (counts, info["moved"]))


if __name__ == "__main__":
    selftest()
