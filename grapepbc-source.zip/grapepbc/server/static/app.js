const state = { file: null, result: null, view: "overlay", previewUrl: null };
const $ = (id) => document.getElementById(id);
const statusEl = $("status");
const inputs = [$("cameraInput"), $("albumInput")];
// Also remove the retired notice area from an already cached HTML template.
document.querySelector(".notice-card")?.remove();

async function checkHealth() {
  try {
    const response = await fetch("/api/health", { cache: "no-store" });
    const data = await response.json();
    if (!response.ok || !data.ready) throw new Error("not ready");
    statusEl.className = "status online";
    statusEl.querySelector("span").textContent = data.device.startsWith("cuda") ? "PC online · GPU" : "PC online";
    $("pipelineVersion").textContent = "GrapePBC-mobile";
  } catch (_error) {
    statusEl.className = "status offline";
    statusEl.querySelector("span").textContent = "PC offline";
  }
}

function selectFile(file) {
  if (!file) return;
  state.file = file;
  if (state.previewUrl) URL.revokeObjectURL(state.previewUrl);
  state.previewUrl = URL.createObjectURL(file);
  $("preview").src = state.previewUrl;
  $("previewWrap").classList.add("has-image");
  $("analyzeButton").disabled = false;
  $("errorCard").classList.remove("show");
  $("results").classList.remove("show");
}

function resetCapture(scroll = true) {
  state.file = null;
  state.result = null;
  if (state.previewUrl) URL.revokeObjectURL(state.previewUrl);
  state.previewUrl = null;
  inputs.forEach((input) => { input.value = ""; });
  $("preview").removeAttribute("src");
  $("previewWrap").classList.remove("has-image");
  $("analyzeButton").disabled = true;
  $("results").classList.remove("show");
  $("errorCard").classList.remove("show");
  if (scroll) window.scrollTo({ top: 0, behavior: "smooth" });
}

function resultUrl(view) {
  if (!state.result) return "";
  if (view === "source") return state.result.source_url;
  return state.result.overlay_url;
}

function setView(view) {
  state.view = view;
  document.querySelectorAll(".segmented button").forEach((button) => {
    button.classList.toggle("active", button.dataset.view === view);
  });
  const url = resultUrl(view);
  $("resultImage").src = url;
  $("downloadLink").href = url;
  $("dialogImage").src = url;
}

function renderClusters(clusters) {
  const list = $("clusterList");
  list.replaceChildren();
  if (!clusters.length) {
    const p = document.createElement("p");
    p.className = "empty-clusters";
    p.textContent = "No reliable bunch boxes found. If berries are detected, fallback point-envelope boxes retain their counts.";
    list.appendChild(p);
    return;
  }
  clusters.forEach((cluster) => {
    const row = document.createElement("div");
    row.className = "cluster-row";
    const confidence = Math.round((cluster.confidence || 0) * 100);
    row.innerHTML = `<span class="cluster-id"></span><div><b>Visible berries</b><small></small></div><span class="cluster-count"></span>`;
    row.querySelector(".cluster-id").textContent = cluster.display_id;
    row.querySelector("small").textContent = cluster.source.includes("fallback") ? "Fallback box" : `Box confidence ${confidence}%`;
    row.querySelector(".cluster-count").textContent = `${cluster.visible_berry_count} berries`;
    list.appendChild(row);
  });
}

function renderResult(data) {
  state.result = data;
  $("totalCount").textContent = data.total_count;
  $("bunchCount").textContent = data.bunch_count;
  $("hrCalls").textContent = data.hr_calls ?? "—";
  $("modeBadge").textContent = data.mode_label;
  $("conservationBadge").textContent = data.unassigned === 0 ? "All uniquely assigned" : `${data.unassigned} unassigned`;
  renderClusters(data.clusters);
  setView("overlay");
  $("results").classList.add("show");
  requestAnimationFrame(() => $("results").scrollIntoView({ behavior: "smooth", block: "start" }));
}

async function analyze() {
  if (!state.file) return;
  $("analyzeButton").disabled = true;
  $("processing").classList.add("show");
  $("errorCard").classList.remove("show");
  $("results").classList.remove("show");
  const form = new FormData();
  form.append("image", state.file, state.file.name || "phone_photo.jpg");
  const timer = setTimeout(() => {
    $("processingTitle").textContent = "Running the PC model";
    $("processingHint").textContent = "First load takes longer. Keep this page open.";
  }, 1400);
  try {
    const response = await fetch("/api/infer", { method: "POST", body: form });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Server returned no valid result");
    renderResult(data);
  } catch (error) {
    $("errorText").textContent = error.message || "Check the PC service and local network connection";
    $("errorCard").classList.add("show");
  } finally {
    clearTimeout(timer);
    $("processingTitle").textContent = "Uploading photo";
    $("processingHint").textContent = "The PC will count berries and locate bunches";
    $("processing").classList.remove("show");
    $("analyzeButton").disabled = !state.file;
  }
}

inputs.forEach((input) => input.addEventListener("change", (event) => selectFile(event.target.files?.[0])));
$("preview").addEventListener("click", () => {
  if (!state.previewUrl) return;
  $("dialogImage").src = state.previewUrl;
  $("imageDialog").classList.remove("native-size");
  $("imageDialog").showModal();
});
$("clearButton").addEventListener("click", () => resetCapture(false));
$("analyzeButton").addEventListener("click", analyze);
$("newAnalysis").addEventListener("click", () => resetCapture(true));
document.querySelectorAll(".segmented button").forEach((button) => button.addEventListener("click", () => setView(button.dataset.view)));
$("zoomButton").addEventListener("click", () => {
  $("imageDialog").classList.remove("native-size");
  $("imageDialog").showModal();
});
$("dialogImage").addEventListener("dblclick", () => $("imageDialog").classList.toggle("native-size"));
$("closeDialog").addEventListener("click", () => $("imageDialog").close());
$("imageDialog").addEventListener("click", (event) => { if (event.target === $("imageDialog")) $("imageDialog").close(); });

checkHealth();
setInterval(checkHealth, 30000);
if ("serviceWorker" in navigator) navigator.serviceWorker.register("/static/service-worker.js", { updateViaCache: "none" }).catch(() => {});
