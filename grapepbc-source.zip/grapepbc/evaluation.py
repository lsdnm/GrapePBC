"""Evaluate predicted bunch counts against per-image reference annotations."""

import argparse
import json
from pathlib import Path
import numpy as np


def iou(a, b):
    x1 = max(a[0], b[0])
    y1 = max(a[1], b[1])
    x2 = min(a[2], b[2])
    y2 = min(a[3], b[3])
    iw = max(0.0, x2 - x1)
    ih = max(0.0, y2 - y1)
    inter = iw * ih
    ua = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / ua if ua > 0 else 0.0


def match(pred_boxes, gt_boxes, thr=0.5):
    pairs = []
    for i, p in enumerate(pred_boxes):
        for j, g in enumerate(gt_boxes):
            v = iou(p, g)
            if v >= thr:
                pairs.append((v, i, j))
    pairs.sort(reverse=True)
    pu, gu, out = (set(), set(), [])
    for v, i, j in pairs:
        if i in pu or j in gu:
            continue
        pu.add(i)
        gu.add(j)
        out.append((i, j))
    return out


def main():
    parser = argparse.ArgumentParser(description="Evaluate saved GrapePBC results")
    parser.add_argument(
        "predictions", type=Path, help="JSON mapping image IDs to result objects"
    )
    parser.add_argument(
        "annotations", type=Path, help="JSON mapping image IDs to bunch annotations"
    )
    args = parser.parse_args()
    predictions = json.loads(args.predictions.read_text())
    annotations = json.loads(args.annotations.read_text())
    errors = []
    total_error = 0
    total_bunches = 0
    for image_id, bunches in annotations.items():
        clusters = predictions[image_id]["clusters"]
        predicted_boxes = [row["bbox_xyxy"] for row in clusters]
        predicted_counts = [int(row["visible_berry_count"]) for row in clusters]
        reference_boxes = [row["bbox"] for row in bunches]
        reference_counts = [len(row["points"]) for row in bunches]
        pairs = match(predicted_boxes, reference_boxes)
        matched_predictions = {i for i, j in pairs}
        matched_references = {j for i, j in pairs}
        matched_errors = [
            abs(predicted_counts[i] - reference_counts[j]) for i, j in pairs
        ]
        errors.extend(matched_errors)
        total_error += sum(matched_errors)
        total_error += sum(
            n for j, n in enumerate(reference_counts) if j not in matched_references
        )
        total_error += sum(
            n for i, n in enumerate(predicted_counts) if i not in matched_predictions
        )
        total_bunches += len(bunches)
    print(
        json.dumps(
            {
                "matched_bunches": len(errors),
                "reference_bunches": total_bunches,
                "matched_bunch_mae": float(np.mean(errors)) if errors else None,
                "total_error_per_reference_bunch": (
                    total_error / total_bunches if total_bunches else None
                ),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
