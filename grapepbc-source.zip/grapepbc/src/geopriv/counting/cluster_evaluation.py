"""GT-instance matching with explicit misses, spurious masks and count ambiguity."""
import numpy as np


def mask_iou_matrix(predicted, truth):
    result = np.zeros((len(predicted), len(truth)), float)
    def geometry(cluster):
        y, x = np.nonzero(cluster.mask)
        return len(x), (x.min(), y.min(), x.max() + 1, y.max() + 1)
    pgeom, tgeom = [geometry(c) for c in predicted], [geometry(c) for c in truth]
    for i, p in enumerate(predicted):
        for j, t in enumerate(truth):
            pa, (px0, py0, px1, py1) = pgeom[i]
            ta, (tx0, ty0, tx1, ty1) = tgeom[j]
            x0, y0, x1, y1 = max(px0, tx0), max(py0, ty0), min(px1, tx1), min(py1, ty1)
            if x0 >= x1 or y0 >= y1:
                continue
            intersection = int(np.count_nonzero(p.mask[y0:y1, x0:x1] & t.mask[y0:y1, x0:x1]))
            result[i, j] = intersection / (pa + ta - intersection)
    return result


def match_clusters(predicted, truth, iou_threshold=.5):
    matrix = mask_iou_matrix(predicted, truth)
    if not matrix.size:
        return [], list(range(len(predicted))), list(range(len(truth)))
    # Maximum-cardinality bipartite matching with deterministic, IoU-ordered
    # edge exploration. This is not a maximum-total-IoU matching claim.
    neighbors = [sorted(np.flatnonzero(row >= iou_threshold), key=lambda j: (-row[j], j)) for row in matrix]
    assigned = {}
    def augment(i, visited):
        for j in neighbors[i]:
            if j in visited:
                continue
            visited.add(j)
            if j not in assigned or augment(assigned[j], visited):
                assigned[j] = i
                return True
        return False
    for i in sorted(range(len(predicted)), key=lambda k: (-float(matrix[k].max()), k)):
        augment(i, set())
    pairs = sorted((int(i), int(j), float(matrix[i, j])) for j, i in assigned.items())
    return pairs, [i for i in range(len(predicted)) if i not in {r[0] for r in pairs}], [j for j in range(len(truth)) if j not in {r[1] for r in pairs}]


def truth_count_intervals(points, clusters):
    """Ambiguous GT-mask overlaps do not fabricate berry-to-bunch identities."""
    certain, possible = np.zeros(len(clusters), int), np.zeros(len(clusters), int)
    ambiguous = unassigned = 0
    for x, y in np.asarray(points):
        i, j = int(np.floor(y)), int(np.floor(x))
        candidates = [k for k, c in enumerate(clusters) if 0 <= i < c.mask.shape[0] and 0 <= j < c.mask.shape[1] and c.mask[i, j]]
        if len(candidates) == 1:
            certain[candidates[0]] += 1
        if len(candidates) > 1:
            ambiguous += 1
        if not candidates:
            unassigned += 1
        for k in candidates:
            possible[k] += 1
    return certain, possible, ambiguous, unassigned
