"""Opt-in Q1 selection among fixed C1 anchors and C5-permitted native masks."""
from .identity_conflict_guard import select_conflict_guarded_contours
from .contour_quality import pair_features, replacement_probability


def select_quality_contours(candidates, association, image_size, artifact):
    if artifact.get('enabled_for_development_evaluation') is not True:
        raise ValueError('Quality head has not passed its internal engineering gate')
    if artifact.get('threshold') != .8:
        raise ValueError('Q1 frozen score threshold drift')
    proposed, guarded = select_conflict_guarded_contours(candidates, association)
    selected=[];output=[];decisions=[]
    for i,(root,native) in enumerate(zip(guarded['roots'],guarded['selected'])):
        score=None;choose=root
        if native != root:
            feature=pair_features(candidates,association,root,native,image_size)
            score=replacement_probability(feature,artifact)
            if score>=artifact['threshold']:choose=native
        selected.append(choose)
        output.append(proposed[i] if choose!=root else candidates[root])
        decisions.append(dict(root=root,native=native,selected=choose,score=score,
            reason='quality_native' if choose!=root else 'quality_abstain' if native!=root else 'C5_or_C1_anchor',
            completeness_verified=False))
    return output,dict(policy='Q1_learned_quality_C1_C5_pair_selection_v1',roots=guarded['roots'],
        selected=selected,groups=guarded['groups'],guarded_proposal=guarded,
        decisions=decisions,changed=sum(a!=b for a,b in zip(guarded['roots'],selected)),
        quality_rejected=sum(d['reason']=='quality_abstain' for d in decisions),
        deployed_or_finally_accepted=False)
