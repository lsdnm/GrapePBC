"""Tiled lightweight grape-cluster instance segmentation.

Tiling at source resolution allows small, distant bunches to be proposed even
when they would be tiny after resizing an entire multi-megapixel photograph.
Detection quality still requires validation with complete train/val labels.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import cv2
import numpy as np
from PIL import Image

from .per_cluster import ClusterRegion


def tile_origins(length: int, size: int, stride: int) -> tuple[int, ...]:
    if length < 1 or size < 1 or stride < 1 or stride > size:
        raise ValueError("invalid image length, tile size or stride")
    if length <= size:
        return (0,)
    positions = list(range(0, length - size + 1, stride))
    if positions[-1] != length - size:
        positions.append(length - size)
    return tuple(positions)


def _box_iou(a: np.ndarray, b: np.ndarray) -> float:
    left, top = np.maximum(a[:2], b[:2])
    right, bottom = np.minimum(a[2:], b[2:])
    intersection = max(0.0, right - left) * max(0.0, bottom - top)
    area_a = max(0.0, a[2] - a[0]) * max(0.0, a[3] - a[1])
    area_b = max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])
    union = area_a + area_b - intersection
    return intersection / union if union > 0 else 0.0


@dataclass(frozen=True)
class _Candidate:
    polygon: np.ndarray
    bbox: np.ndarray
    confidence: float
    tile_id: int = -1


def _deduplicate(candidates: list[_Candidate], overlap_threshold: float) -> list[_Candidate]:
    ordered = sorted(candidates, key=lambda row: -row.confidence)
    kept: list[_Candidate] = []
    for candidate in ordered:
        # Box overlap alone is not evidence of a duplicated grape bunch.
        # In particular, two distinct slender bunches can share almost the
        # entire bounding box but have largely disjoint instance masks.
        if all(candidate.tile_id == prior.tile_id or
               _mask_iou(candidate, prior) < overlap_threshold for prior in kept):
            kept.append(candidate)
    return kept


def _mask_iou(a: _Candidate, b: _Candidate) -> float:
    if _box_iou(a.bbox, b.bbox) <= 0:
        return 0.0
    left, top = np.floor(np.minimum(a.bbox[:2], b.bbox[:2])).astype(int)
    right, bottom = np.ceil(np.maximum(a.bbox[2:], b.bbox[2:])).astype(int)
    shape = (max(1, bottom - top + 1), max(1, right - left + 1))
    first = np.zeros(shape, dtype=np.uint8)
    second = np.zeros(shape, dtype=np.uint8)
    offset = np.asarray([left, top])
    cv2.fillPoly(first, [np.rint(a.polygon - offset).astype(np.int32)], 1)
    cv2.fillPoly(second, [np.rint(b.polygon - offset).astype(np.int32)], 1)
    union = int(np.count_nonzero(first | second))
    return float(np.count_nonzero(first & second) / union) if union else 0.0


def detect_clusters_tiled(
    image: Image.Image,
    detector: Any,
    *,
    tile_size: int = 1024,
    stride: int = 768,
    confidence: float = 0.15,
    overlap_threshold: float = 0.45,
    device: str | int = 0,
) -> list[ClusterRegion]:
    """Run a YOLO segmentation model on overlapping native-resolution tiles."""

    if not 0 <= confidence <= 1 or not 0 < overlap_threshold <= 1:
        raise ValueError("invalid confidence or overlap threshold")
    width, height = image.size
    candidates: list[_Candidate] = []
    # One global view supplies large-bunch context. Native-resolution tiles
    # still provide small/distant proposals; neither view is GT-conditioned.
    views = [(0, 0, width, height)]
    views.extend((x, y, min(x + tile_size, width), min(y + tile_size, height))
                 for y in tile_origins(height, tile_size, stride)
                 for x in tile_origins(width, tile_size, stride)
                 if (x, y, min(x + tile_size, width), min(y + tile_size, height)) != views[0])
    for tile_id, (x0, y0, x1, y1) in enumerate(views):
            crop = image.crop((x0, y0, x1, y1))
            rgb = np.asarray(crop.convert("RGB"))
            bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
            result = detector.predict(
                source=bgr,
                imgsz=tile_size,
                conf=confidence,
                iou=0.6,
                device=device,
                retina_masks=True,
                verbose=False,
            )[0]
            if result.boxes is None or result.masks is None:
                continue
            boxes = result.boxes.xyxy.detach().cpu().numpy()
            scores = result.boxes.conf.detach().cpu().numpy()
            polygons = result.masks.xy
            for box, score, polygon in zip(boxes, scores, polygons):
                xy = np.asarray(polygon, dtype=np.float64).reshape(-1, 2)
                if len(xy) < 3:
                    continue
                xy[:, 0] += x0
                xy[:, 1] += y0
                xy[:, 0] = np.clip(xy[:, 0], 0, width - 1)
                xy[:, 1] = np.clip(xy[:, 1], 0, height - 1)
                global_box = np.asarray(box, dtype=np.float64) + np.asarray([x0, y0, x0, y0])
                candidates.append(_Candidate(xy, global_box, float(score), tile_id))
    kept = _deduplicate(candidates, overlap_threshold)
    clusters = []
    for index, candidate in enumerate(kept, start=1):
        mask = np.zeros((height, width), dtype=np.uint8)
        cv2.fillPoly(mask, [np.rint(candidate.polygon).astype(np.int32)], 1)
        if not np.any(mask):
            continue
        clusters.append(ClusterRegion(f"cluster_{index:03d}", mask.astype(bool), candidate.confidence))
    return clusters
