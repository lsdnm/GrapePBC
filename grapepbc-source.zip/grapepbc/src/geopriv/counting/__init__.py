"""Prediction-level counting and cluster attribution helpers."""

from .per_cluster import ClusterRegion, assign_berries_to_clusters
from .per_cluster_boxes import ClusterBox, assign_berries_to_cluster_boxes
from .cluster_detector import detect_clusters_tiled, tile_origins
from .cluster_box_detector import box_iou, deduplicate_boxes, detect_cluster_boxes
from .center_gate import (
    PrimaryCenterGatePolicy,
    SupplementalCenterGatePolicy,
    apply_conservative_center_gate,
    apply_primary_center_gate,
    apply_supplemental_candidate_gate,
    normalized_nearest_spacing,
)
from .cluster_aware_reallocation import (
    ClusterAwareReallocationPolicy,
    reallocate_points_by_cluster_evidence,
)
from .far_dense_repair import FarDenseRepairPolicy, apply_far_dense_repair
from .count_reconciliation import CountReconciliationPolicy, reconcile_point_count
from .one_berry_reconciliation import (
    OneBerryReconciliationPolicy,
    SemanticReconciliationPolicy,
    filter_reconciliation_by_semantic_scores,
    reconcile_one_berry_one_point,
    reconcile_one_berry_one_point_semantic,
)
from .cluster_box_filter import (
    filter_interior_zero_support_boxes,
    touches_image_guard_band,
)

__all__ = [
    "ClusterRegion", "assign_berries_to_clusters",
    "ClusterBox", "assign_berries_to_cluster_boxes",
    "detect_clusters_tiled", "tile_origins",
    "box_iou", "deduplicate_boxes", "detect_cluster_boxes",
    "apply_conservative_center_gate",
    "PrimaryCenterGatePolicy", "SupplementalCenterGatePolicy",
    "apply_primary_center_gate", "apply_supplemental_candidate_gate",
    "normalized_nearest_spacing",
    "ClusterAwareReallocationPolicy", "reallocate_points_by_cluster_evidence",
    "FarDenseRepairPolicy", "apply_far_dense_repair",
    "CountReconciliationPolicy", "reconcile_point_count",
    "OneBerryReconciliationPolicy", "reconcile_one_berry_one_point",
    "reconcile_one_berry_one_point_semantic",
    "SemanticReconciliationPolicy", "filter_reconciliation_by_semantic_scores",
    "filter_interior_zero_support_boxes", "touches_image_guard_band",
]
