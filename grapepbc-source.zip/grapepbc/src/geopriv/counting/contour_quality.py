"""Prediction-only contour-pair features and a small, opt-in logistic gate.

This module does not train a model, read labels, change identities, or bypass
C4 eligibility / C5 conflict protection. ``image_size`` is (width, height).
Artifact schema v1 uses the exact FEATURE_NAMES order and contains finite
``means``, strictly positive ``scales``, ``coefficients``, scalar ``intercept``
and a fixed ``threshold`` in [0, 1]. No sklearn runtime is required.
"""
from __future__ import annotations

from collections.abc import Mapping
from numbers import Integral

import cv2
import numpy as np


FEATURE_NAMES = (
    'root_area_fraction', 'native_area_fraction', 'log_native_root_area_ratio',
    'added_over_root_area', 'removed_over_root_area', 'pair_mask_iou',
    'root_bbox_fill', 'native_bbox_fill', 'log_bbox_width_ratio',
    'log_bbox_height_ratio', 'center_dx_image', 'center_dy_image',
    'root_confidence', 'native_confidence', 'confidence_delta',
    'log_other_view_count', 'root_other_iou_mean', 'root_other_iou_min',
    'root_other_iou_max', 'native_other_iou_mean', 'native_other_iou_min',
    'native_other_iou_max', 'root_compactness', 'native_compactness',
    'log_root_components', 'log_native_components', 'root_view_margin',
    'native_view_margin', 'root_truncated_fraction', 'native_truncated_fraction',
    'root_global_view', 'native_global_view',
)


def _size(image_size):
    if len(image_size) != 2 or any(isinstance(x, bool) or not isinstance(x, Integral)
                                  or x <= 0 for x in image_size):
        raise ValueError('image_size must be positive integer (width, height)')
    return tuple(int(x) for x in image_size)


def _candidate(candidate):
    polygon = np.asarray(candidate.polygon, dtype=np.float64)
    if polygon.size == 0:
        polygon = np.empty((0, 2), dtype=np.float64)
    if polygon.ndim != 2 or polygon.shape[1] != 2 or not np.isfinite(polygon).all():
        raise ValueError('Invalid finite polygon')
    # OpenCV coordinates are int32. Refuse values that could overflow on cast.
    if polygon.size and np.abs(polygon).max() > np.iinfo(np.int32).max // 4:
        raise ValueError('Polygon coordinates outside safe raster range')
    bbox = np.asarray(candidate.bbox, dtype=np.float64)
    bounds = np.asarray(candidate.view_bounds, dtype=np.float64)
    if (bbox.shape != (4,) or bounds.shape != (4,)
            or not np.isfinite(bbox).all() or not np.isfinite(bounds).all()
            or np.any(bbox[2:] < bbox[:2]) or np.any(bounds[2:] <= bounds[:2])):
        raise ValueError('Invalid bbox/view bounds')
    confidence = float(candidate.confidence)
    if not np.isfinite(confidence) or not 0 <= confidence <= 1:
        raise ValueError('Invalid confidence')
    edges = tuple(candidate.truncated_edges)
    if len(set(edges)) != len(edges) or not set(edges) <= {'left', 'right', 'top', 'bottom'}:
        raise ValueError('Invalid truncated edges')
    return polygon, bbox, bounds, confidence, len(edges) / 4.


def _raster(polygon, size):
    """Tight, image-clipped raster; round globally before integer translation."""
    if not len(polygon):
        return np.zeros((0, 0), np.uint8), np.zeros(2, dtype=np.int64)
    rounded = np.rint(polygon).astype(np.int64)
    lo = np.maximum(rounded.min(axis=0), 0)
    hi = np.minimum(rounded.max(axis=0), np.asarray(size) - 1)
    if np.any(hi < lo):
        return np.zeros((0, 0), np.uint8), lo
    mask = np.zeros((int(hi[1]-lo[1]+1), int(hi[0]-lo[0]+1)), np.uint8)
    cv2.fillPoly(mask, [(rounded-lo).astype(np.int32)], 1)
    return mask, lo


def _intersection(a, b):
    ma, la = a
    mb, lb = b
    if not ma.size or not mb.size:
        return 0
    lo = np.maximum(la, lb)
    hi = np.minimum(la + ma.shape[::-1], lb + mb.shape[::-1])
    if np.any(hi <= lo):
        return 0
    aa, bb, span = lo-la, lo-lb, hi-lo
    return int(np.count_nonzero(
        ma[aa[1]:aa[1]+span[1], aa[0]:aa[0]+span[0]]
        & mb[bb[1]:bb[1]+span[1], bb[0]:bb[0]+span[0]]))


def _iou(a, b):
    intersection = _intersection(a, b)
    union = int(a[0].sum()) + int(b[0].sum()) - intersection
    return intersection / union if union else 0.


def _shape(mask):
    if not mask.size or not mask.any():
        return 0., 0
    # Pixel-edge perimeter remains defined for one-pixel / line-like masks.
    padded = np.pad(mask.astype(np.int16), 1)
    perimeter = float(np.abs(np.diff(padded, axis=0)).sum()
                      + np.abs(np.diff(padded, axis=1)).sum())
    area = float(mask.sum())
    compactness = float(4. * np.pi * area / perimeter ** 2)
    components = int(cv2.connectedComponents(mask, connectivity=8)[0] - 1)
    return compactness, components


def _margin(polygon, bounds):
    if not len(polygon):
        return 0.
    extent = np.maximum(bounds[2:] - bounds[:2], 1.)
    distances = np.r_[(polygon.min(0)-bounds[:2])/extent,
                      (bounds[2:]-polygon.max(0))/extent]
    return float(np.clip(distances.min(), -1., 1.))


def pair_features(candidates, association, root, native, image_size):
    """Return a deterministic float32 vector for one existing identity pair.

    Agreement excludes BOTH pair members, so the pair IoU is not double-counted.
    No other supporting views gives zero summary values and zero support count.
    Confidence values are the original proposal confidences, before inheritance.
    """
    size = _size(image_size)
    if (isinstance(root, bool) or isinstance(native, bool)
            or not isinstance(root, Integral) or not isinstance(native, Integral)
            or root == native or min(root, native) < 0 or max(root, native) >= len(candidates)):
        raise ValueError('Pair indices must be distinct valid integers')
    if root not in association.get('representatives', []):
        raise ValueError('Root must be an existing representative')
    members_map = association.get('members', {})
    members = list(members_map.get(root, members_map.get(str(root), [])))
    if (root not in members or native not in members or len(set(members)) != len(members)
            or any(isinstance(i, bool) or not isinstance(i, Integral)
                   or i < 0 or i >= len(candidates) for i in members)):
        raise ValueError('Pair must belong to a valid shared group')
    if len({candidates[i].view_id for i in members}) != len(members):
        raise ValueError('Same-view conflict inside group')
    checked = {i: _candidate(candidates[i]) for i in members}
    rasters = {i: _raster(checked[i][0], size) for i in members}
    rp, rb, rv, rc, rt = checked[root]
    npoly, nb, nv, nc, nt = checked[native]
    rm, nm = rasters[root], rasters[native]
    ra, na = float(rm[0].sum()), float(nm[0].sum())
    intersection = _intersection(rm, nm)
    image_area = float(size[0]) * size[1]
    rw, nw = np.maximum(rb[2:]-rb[:2], 1.), np.maximum(nb[2:]-nb[:2], 1.)
    shift = ((nb[:2]+nb[2:])-(rb[:2]+rb[2:])) / (2.*np.asarray(size))
    other = sorted(i for i in members if i not in (root, native))
    agreements = []
    for index in (root, native):
        vals = [_iou(rasters[index], rasters[i]) for i in other]
        agreements.extend([float(np.mean(vals)), min(vals), max(vals)] if vals else [0., 0., 0.])
    rcompact, rcomponents = _shape(rm[0])
    ncompact, ncomponents = _shape(nm[0])
    # Raster extents include both endpoints; bbox-fill uses +1 consistently.
    rbox_area = float(np.prod(np.maximum(rb[2:]-rb[:2]+1., 1.)))
    nbox_area = float(np.prod(np.maximum(nb[2:]-nb[:2]+1., 1.)))
    vector = np.asarray([
        ra/image_area, na/image_area, np.log((na+1.)/(ra+1.)),
        (na-intersection)/max(ra, 1.), (ra-intersection)/max(ra, 1.), _iou(rm, nm),
        ra/rbox_area, na/nbox_area, *np.log(nw/rw), *shift, rc, nc, nc-rc,
        np.log1p(len(other)), *agreements, rcompact, ncompact,
        np.log1p(rcomponents), np.log1p(ncomponents), _margin(rp, rv),
        _margin(npoly, nv), rt, nt, float(candidates[root].global_view),
        float(candidates[native].global_view),
    ], dtype=np.float32)
    if vector.shape != (len(FEATURE_NAMES),) or not np.isfinite(vector).all():
        raise ValueError('Non-finite or inconsistent feature vector')
    return vector


def _validated_artifact(artifact):
    if not isinstance(artifact, Mapping):
        raise ValueError('Artifact must be a mapping')
    if (type(artifact.get('schema_version')) is not int or artifact['schema_version'] != 1
            or artifact.get('model_type') != 'standardized_logistic'
            or artifact.get('feature_names') != list(FEATURE_NAMES)):
        raise ValueError('Unsupported artifact schema or feature order')
    values = []
    for name in ('means', 'scales', 'coefficients'):
        try:
            array = np.asarray(artifact[name], dtype=np.float64)
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f'Invalid artifact {name}') from exc
        if array.shape != (len(FEATURE_NAMES),) or not np.isfinite(array).all():
            raise ValueError(f'Invalid artifact {name}')
        values.append(array)
    if np.any(values[1] <= 0):
        raise ValueError('Artifact scales must be strictly positive')
    scalars = []
    for name in ('intercept', 'threshold'):
        value = artifact.get(name)
        if isinstance(value, bool) or not np.isscalar(value):
            raise ValueError(f'Invalid artifact {name}')
        try:
            value = float(value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f'Invalid artifact {name}') from exc
        if not np.isfinite(value):
            raise ValueError(f'Invalid artifact {name}')
        scalars.append(value)
    if not 0 <= scalars[1] <= 1:
        raise ValueError('Artifact threshold must be in [0, 1]')
    return *values, *scalars


def replacement_probability(feature, artifact):
    """Validate schema and evaluate a numerically stable logistic probability."""
    means, scales, coefficients, intercept, _ = _validated_artifact(artifact)
    vector = np.asarray(feature, dtype=np.float64)
    if vector.shape != means.shape or not np.isfinite(vector).all():
        raise ValueError('Invalid inference feature vector')
    with np.errstate(over='ignore', invalid='ignore', divide='ignore'):
        logit = float(np.dot((vector-means)/scales, coefficients) + intercept)
    if not np.isfinite(logit):
        raise ValueError('Non-finite standardized model logit')
    if logit >= 0:
        return float(1. / (1. + np.exp(-logit)))
    exp_logit = np.exp(logit)
    return float(exp_logit / (1. + exp_logit))


def decide_replacement(feature, artifact):
    """Return bool at the artifact's frozen threshold; equality selects native."""
    probability = replacement_probability(feature, artifact)
    return bool(probability >= float(artifact['threshold']))
