"""Opt-in lossless raster instances; never changes legacy polygon experiments.

A disconnected visible instance stays ONE identity. Holes and single pixels
are preserved; no morphological filtering, joining or threshold calibration.
"""
from dataclasses import dataclass
import base64
import hashlib
import numpy as np


@dataclass(frozen=True)
class NativeMask:
    x: int
    y: int
    pixels: np.ndarray

    def __post_init__(self):
        if type(self.x) is not int or type(self.y) is not int or min(self.x,self.y)<0:
            raise ValueError('Invalid origin')
        a=np.asarray(self.pixels)
        if a.ndim!=2 or a.dtype!=bool or min(a.shape)<1 or not a.any():
            raise ValueError('Expected nonempty boolean foreground raster')
        a=a.copy();a.flags.writeable=False;object.__setattr__(self,'pixels',a)

    @classmethod
    def from_canvas(cls, pixels, origin=(0,0)):
        a=np.asarray(pixels)
        if a.ndim!=2 or a.dtype!=bool:raise ValueError('Binary boolean canvas required')
        ys,xs=np.nonzero(a)
        if not len(xs):raise ValueError('Empty foreground')
        x,y=int(xs.min()),int(ys.min())
        return cls(int(origin[0])+x,int(origin[1])+y,a[y:int(ys.max())+1,x:int(xs.max())+1])

    @property
    def area(self):return int(self.pixels.sum())

    @property
    def bounds(self):return self.x,self.y,self.x+self.pixels.shape[1],self.y+self.pixels.shape[0]

    def crop(self, bounds):
        x0,y0,x1,y1=map(int,bounds)
        if min(x0,y0)<0 or x1<=x0 or y1<=y0:raise ValueError('Invalid crop bounds')
        out=np.zeros((y1-y0,x1-x0),bool)
        l,t=max(x0,self.x),max(y0,self.y);r,b=min(x1,self.bounds[2]),min(y1,self.bounds[3])
        if l<r and t<b:out[t-y0:b-y0,l-x0:r-x0]=self.pixels[t-self.y:b-self.y,l-self.x:r-self.x]
        return out

    def contains(self, points):
        points=np.asarray(points,dtype=float)
        if points.ndim!=2 or points.shape[1]!=2 or not np.isfinite(points).all():raise ValueError('Invalid points')
        q=np.floor(points).astype(np.int64)-[self.x,self.y]
        ok=(q[:,0]>=0)&(q[:,0]<self.pixels.shape[1])&(q[:,1]>=0)&(q[:,1]<self.pixels.shape[0])
        result=np.zeros(len(q),bool);result[ok]=self.pixels[q[ok,1],q[ok,0]];return result

    def encode(self):
        packed=np.packbits(self.pixels.reshape(-1),bitorder='little').tobytes()
        return dict(encoding='roi_packbits_little_v1',origin=[self.x,self.y],shape=list(self.pixels.shape),area=self.area,
                    payload=base64.b64encode(packed).decode('ascii'),sha256=hashlib.sha256(packed).hexdigest())

    @classmethod
    def decode(cls,value):
        if value.get('encoding')!='roi_packbits_little_v1':raise ValueError('Unknown encoding')
        shape=value['shape'];origin=value['origin']
        if len(shape)!=2 or any(type(v)is not int or v<=0 for v in shape) or np.prod(shape)>100_000_000:
            raise ValueError('Invalid shape')
        if len(origin)!=2 or any(type(v)is not int or v<0 for v in origin):raise ValueError('Invalid origin')
        data=base64.b64decode(value['payload'],validate=True);n=shape[0]*shape[1]
        if len(data)!=(n+7)//8 or hashlib.sha256(data).hexdigest()!=value['sha256']:raise ValueError('Corrupt raster')
        bits=np.unpackbits(np.frombuffer(data,dtype=np.uint8),bitorder='little')
        if bits[n:].any():raise ValueError('Nonzero padding')
        m=cls(*origin,bits[:n].reshape(shape).astype(bool))
        if m.area!=value['area']:raise ValueError('Wrong foreground area')
        return m


def intersection(a,b):
    l,t=max(a.x,b.x),max(a.y,b.y);r,bottom=min(a.bounds[2],b.bounds[2]),min(a.bounds[3],b.bounds[3])
    if r<=l or bottom<=t:return 0
    return int(np.count_nonzero(a.pixels[t-a.y:bottom-a.y,l-a.x:r-a.x]&b.pixels[t-b.y:bottom-b.y,l-b.x:r-b.x]))


def iou(a,b):
    inter=intersection(a,b);return inter/(a.area+b.area-inter)


def point_owners(points,masks,scores):
    if len(masks)!=len(scores) or any(not np.isfinite(s) or not 0<=s<=1 for s in scores):raise ValueError('Invalid scores')
    owners=np.full(len(points),-1,int);degree=np.zeros(len(points),int)
    order=sorted(range(len(masks)),key=lambda j:(-scores[j],masks[j].area,j))
    for j in reversed(order):
        membership=masks[j].contains(points);owners[membership]=j;degree+=membership
    return owners,degree


def associate_native_c1(candidates,containment=.9,match_iou=.45):
    """Same conservative C1 ordering/logic, exact native pixel intersections.

    Candidate dict: mask NativeMask, confidence, view_id, bbox, global_view,
    truncated_edges. Caller keeps .4 gate fixed. No GT participates.
    """
    if not 0<containment<=1 or not 0<match_iou<=1:raise ValueError('Invalid thresholds')
    order=sorted(range(len(candidates)),key=lambda j:(not candidates[j]['global_view'],-candidates[j]['confidence'],
        candidates[j]['view_id'],*candidates[j]['bbox'],j))
    reps=[];members={};decisions=[]
    for idx in order:
        c=candidates[idx];matches=[]
        for keeper in reps:
            a=candidates[keeper]
            if c['view_id']==a['view_id']:continue
            inter=intersection(c['mask'],a['mask']);reason=None
            if inter/(c['mask'].area+a['mask'].area-inter)>=match_iou:reason='cross_view_mask_iou'
            elif a['global_view'] and not c['global_view'] and c['truncated_edges'] and c['mask'].area<a['mask'].area and inter/c['mask'].area>=containment:
                reason='truncated_fragment_of_global_anchor'
            if reason:matches.append((keeper,reason,any(candidates[m]['view_id']==c['view_id'] for m in members[keeper])))
        if len(matches)==1 and not matches[0][2]:
            keeper,reason,_=matches[0];members[keeper].append(idx)
        else:
            keeper=idx;reps.append(idx);members[idx]=[idx]
            reason='ambiguous_keep' if len(matches)>1 else 'same_view_conflict_keep' if matches else 'independent_keep'
        decisions.append(dict(candidate=idx,representative=keeper,reason=reason))
    return dict(representatives=reps,members=members,decisions=decisions,policy='C1_native_raster_opt_in_v1')
