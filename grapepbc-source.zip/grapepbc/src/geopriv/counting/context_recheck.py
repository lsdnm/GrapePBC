"""Opt-in same-nano full-context re-observation; no GT or learned parameters.

Plans are made from frozen C1 outputs, not labels. A fresh view can replace a
group only if it supplies complete masks and preserves the old spatial support.
This is a development hypothesis, not a guarantee of biological identity.
"""
import math
import numpy as np
from .candidate_ceiling import raster_roi, raster_intersection


def expanded_bounds(box, image_size):
    w,h=image_size
    if min(w,h)<=0 or len(box)!=4 or not np.isfinite(box).all():raise ValueError('Invalid geometry')
    x0,y0,x1,y1=map(float,box)
    if x1<=x0 or y1<=y0:raise ValueError('Empty box')
    # A minimum 1024-source-pixel context; otherwise 50% additional extent.
    cw=min(w,max(1024,math.ceil((x1-x0)*1.5)))
    ch=min(h,max(1024,math.ceil((y1-y0)*1.5)))
    left=max(0,min(w-cw,math.floor((x0+x1-cw)/2)))
    top=max(0,min(h-ch,math.floor((y0+y1-ch)/2)))
    return int(left),int(top),int(left+cw),int(top+ch)


def plan_rechecks(candidates, roots, image_size, max_calls=8):
    if isinstance(max_calls,bool) or not isinstance(max_calls,int) or max_calls<1:raise ValueError('Invalid call cap')
    if len(set(roots))!=len(roots) or any(i<0 or i>=len(candidates) for i in roots):raise ValueError('Invalid roots')
    rasters={i:raster_roi([candidates[i].polygon],image_size) for i in roots}
    if any(r.area==0 for r in rasters.values()):raise ValueError('Empty mask')
    anchors=[i for i in roots if candidates[i].global_view]
    groups={a:[a] for a in anchors};orphans=[];ambiguous=[]
    for i in roots:
        if candidates[i].global_view or not candidates[i].truncated_edges:continue
        matches=[a for a in anchors if rasters[i].area<rasters[a].area and
                 raster_intersection(rasters[i],rasters[a])/rasters[i].area>=.9]
        if len(matches)==1:groups[matches[0]].append(i)
        elif not matches:orphans.append([i])
        else:ambiguous.append(i)
    proposals=[g for g in groups.values() if len(g)>1]+orphans
    proposals.sort(key=lambda g:(-len(g),-candidates[g[0]].confidence,g[0]))
    plans=[];seen=set();skipped=[]
    for group in proposals:
        box=np.array([candidates[i].bbox for i in group])
        bounds=expanded_bounds([box[:,0].min(),box[:,1].min(),box[:,2].max(),box[:,3].max()],image_size)
        if bounds in seen or bounds==(0,0,*image_size):
            skipped.append(dict(roots=group,reason='duplicate_or_existing_full_view'));continue
        seen.add(bounds)
        if len(plans)>=max_calls:
            skipped.append(dict(roots=group,reason='safety_call_cap'));continue
        plans.append(dict(roots=group,bounds=list(bounds)))
    return dict(plans=plans,skipped=skipped,ambiguous_roots=ambiguous,max_calls=max_calls)


def verify_replacement(originals, roots, plan, fresh, image_size):
    group=plan['roots']
    if not set(group)<=set(roots):raise ValueError('Plan no longer applies')
    old_union=raster_roi([originals[i].polygon for i in group],image_size)
    usable=[]
    for i,c in enumerate(fresh):
        if c.confidence<.4 or c.truncated_edges:continue
        r=raster_roi([c.polygon],image_size)
        if r.area and raster_intersection(r,old_union)/r.area>=.5:usable.append(i)
    if not usable:return dict(accepted=False,reason='no_complete_supported_prediction',selected=[])
    new_union=raster_roi([fresh[i].polygon for i in usable],image_size)
    coverage=raster_intersection(old_union,new_union)/old_union.area
    if coverage<.9:return dict(accepted=False,reason='old_spatial_support_not_preserved',selected=[],coverage=coverage)
    # Reject a newly observed mask that duplicates an identity outside this
    # replacement group. Never resolve conflicts by deleting a neighbouring ID.
    for i in usable:
        r=raster_roi([fresh[i].polygon],image_size)
        for j in roots:
            if j in group:continue
            other=raster_roi([originals[j].polygon],image_size);v=raster_intersection(r,other)
            if v/(r.area+other.area-v)>=.45 or v/min(r.area,other.area)>=.9:
                return dict(accepted=False,reason='conflict_with_preserved_identity',selected=[],conflict_root=j)
    return dict(accepted=True,reason='complete_reobservation_preserves_support',selected=usable,coverage=coverage)


def apply_rechecks(originals, roots, observations, image_size):
    active=list(roots);added=[];decisions=[]
    for observation in observations:
        plan=observation['plan'];fresh=observation['candidates']
        decision=verify_replacement(originals,active,plan,fresh,image_size)
        if decision['accepted']:
            # Cross-window duplicate protection includes prior fresh outputs.
            for i in decision['selected']:
                r=raster_roi([fresh[i].polygon],image_size)
                for other in added:
                    q=raster_roi([other.polygon],image_size);v=raster_intersection(r,q)
                    if v/min(r.area,q.area)>=.9 or v/(r.area+q.area-v)>=.45:
                        decision=dict(accepted=False,reason='conflict_with_prior_recheck',selected=[]);break
                if not decision['accepted']:break
        if decision['accepted']:
            active=[i for i in active if i not in plan['roots']]
            added.extend(fresh[i] for i in decision['selected'])
        decisions.append(dict(plan=plan,**decision))
    return [originals[i] for i in active]+added, decisions
