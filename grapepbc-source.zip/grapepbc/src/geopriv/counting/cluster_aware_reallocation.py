"""Count-conserving CRU point redistribution between detected bunches.

The whole-image count is immutable.  Rich-HR peaks only provide evidence for
where a small number of already budgeted points should belong.  The policy has
a conservative default and a stronger generic severe-starvation override.
Neither path uses labels, sample identifiers, or image-specific constants.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np

from .per_cluster_boxes import ClusterBox, assign_berries_to_cluster_boxes


@dataclass(frozen=True)
class ClusterAwareReallocationPolicy:
    default_score_threshold: float = 0.125
    default_blend: float = 0.35
    movement_l1_gate: int = 6
    maximum_transfers: int = 4
    minimum_spacing_1024: float = 4.0
    support_radius_1024: float = 8.0
    starvation_score_threshold: float = 0.075
    starvation_blend: float = 0.85
    starvation_current_maximum: int = 2
    starvation_raw_gain_minimum: int = 2

    def __post_init__(self) -> None:
        probabilities = (
            self.default_score_threshold,
            self.default_blend,
            self.starvation_score_threshold,
            self.starvation_blend,
        )
        if any(not 0 <= value <= 1 for value in probabilities):
            raise ValueError("score thresholds and blend weights must lie in [0, 1]")
        if self.movement_l1_gate < 0 or self.maximum_transfers < 0:
            raise ValueError("movement limits must be non-negative")
        if self.minimum_spacing_1024 < 0 or self.support_radius_1024 < 0:
            raise ValueError("distance limits must be non-negative")
        if self.starvation_current_maximum < 0 or self.starvation_raw_gain_minimum < 1:
            raise ValueError("starvation limits are invalid")


def _owner_indices(points: np.ndarray, boxes: Sequence[ClusterBox], image_size: tuple[int, int]) -> np.ndarray:
    assigned = assign_berries_to_cluster_boxes(points, boxes, image_size=image_size)
    lookup = {box.cluster_id: index for index, box in enumerate(boxes)}
    return np.asarray([lookup[item["cluster_id"]] for item in assigned["assignments"]], dtype=np.int64)


def _strict_candidate_owner(points: np.ndarray, boxes: Sequence[ClusterBox]) -> np.ndarray:
    owner = np.full(len(points), -1, dtype=np.int64)
    for point_index, point in enumerate(points):
        containing: list[tuple[float, float, int]] = []
        for box_index, box in enumerate(boxes):
            x0, y0, x1, y1 = box.bbox_xyxy
            if not (x0 <= point[0] <= x1 and y0 <= point[1] <= y1):
                continue
            center = np.asarray([(x0 + x1) / 2, (y0 + y1) / 2])
            half = np.maximum(np.asarray([(x1 - x0) / 2, (y1 - y0) / 2]), 1.0)
            cost = float(np.sum(((point - center) / half) ** 2))
            containing.append((cost, -box.confidence, box_index))
        if containing:
            owner[point_index] = min(containing)[2]
    return owner


def _largest_remainder(values: np.ndarray, total: int, eligible: np.ndarray) -> np.ndarray:
    values = np.maximum(np.asarray(values, dtype=np.float64), 0.0)
    eligible = np.asarray(eligible, dtype=bool)
    result = np.zeros(len(values), dtype=np.int64)
    if total <= 0 or not len(values):
        return result
    active = np.flatnonzero(eligible)
    if not len(active):
        active = np.arange(len(values))
    if total < len(active):
        order = active[np.argsort(-values[active], kind="stable")]
        result[order[:total]] = 1
        return result
    result[active] = 1
    remaining = total - len(active)
    if remaining == 0:
        return result
    weights = values[active]
    if float(weights.sum()) <= 0:
        weights = np.ones_like(weights)
    scaled = weights / weights.sum() * remaining
    floor = np.floor(scaled).astype(np.int64)
    result[active] += floor
    left = remaining - int(floor.sum())
    if left:
        fractions = scaled - floor
        order = active[np.argsort(-fractions, kind="stable")]
        result[order[:left]] += 1
    if int(result.sum()) != total:
        raise RuntimeError("largest-remainder count conservation failed")
    return result


def _raw_quota(
    scores: np.ndarray,
    candidate_owner: np.ndarray,
    threshold: float,
    box_count: int,
    total: int,
) -> np.ndarray:
    strong = scores >= threshold
    signal = (
        np.bincount(candidate_owner[strong], minlength=box_count)
        if np.any(strong) else np.zeros(box_count, dtype=np.int64)
    )
    return _largest_remainder(signal.astype(np.float64), total, signal > 0)


def _capped_target(current: np.ndarray, desired: np.ndarray, cap: int) -> np.ndarray:
    target = current.astype(np.int64).copy()
    donors = [[int(i), int(current[i] - desired[i])] for i in np.flatnonzero(current > desired)]
    receivers = [[int(i), int(desired[i] - current[i])] for i in np.flatnonzero(desired > current)]
    donors.sort(key=lambda row: (-row[1], row[0]))
    receivers.sort(key=lambda row: (-row[1], row[0]))
    moved = donor_index = receiver_index = 0
    while moved < cap and donor_index < len(donors) and receiver_index < len(receivers):
        donor, donor_left = donors[donor_index]
        receiver, receiver_left = receivers[receiver_index]
        amount = min(donor_left, receiver_left, cap - moved)
        target[donor] -= amount
        target[receiver] += amount
        moved += amount
        donors[donor_index][1] -= amount
        receivers[receiver_index][1] -= amount
        donor_index += int(donors[donor_index][1] == 0)
        receiver_index += int(receivers[receiver_index][1] == 0)
    return target


def _rank(values: np.ndarray) -> np.ndarray:
    if not len(values):
        return np.empty(0, dtype=np.float64)
    order = np.argsort(values, kind="stable")
    ranks = np.empty(len(values), dtype=np.float64)
    ranks[order] = np.linspace(0.0, 1.0, len(values), endpoint=True) if len(values) > 1 else 1.0
    return ranks


def _candidate_support(
    points: np.ndarray,
    candidates: np.ndarray,
    scores: np.ndarray,
    scale: float,
    radius_1024: float,
) -> np.ndarray:
    if not len(points) or not len(candidates):
        return np.zeros(len(points), dtype=np.float64)
    support = np.zeros(len(points), dtype=np.float64)
    radius_squared = (radius_1024 / scale) ** 2
    # Point counts are modest and this NumPy-only loop avoids imposing SciPy
    # on the deployable post-processing path. Candidate arrays stay contiguous.
    for index, point in enumerate(points):
        distance_squared = np.sum((candidates - point) ** 2, axis=1)
        nearest = int(np.argmin(distance_squared))
        if float(distance_squared[nearest]) <= radius_squared:
            support[index] = float(scores[nearest])
    return support


def reallocate_points_by_cluster_evidence(
    points_xy: np.ndarray,
    reliability: np.ndarray,
    clusters: Sequence[ClusterBox],
    candidate_xy: np.ndarray,
    candidate_scores: np.ndarray,
    *,
    image_size: tuple[int, int],
    policy: ClusterAwareReallocationPolicy = ClusterAwareReallocationPolicy(),
) -> dict[str, object]:
    """Redistribute up to ``maximum_transfers`` while preserving total count."""

    points = np.asarray(points_xy, dtype=np.float64).reshape(-1, 2)
    confidence = np.asarray(reliability, dtype=np.float64).reshape(-1)
    candidates = np.asarray(candidate_xy, dtype=np.float64).reshape(-1, 2)
    scores = np.asarray(candidate_scores, dtype=np.float64).reshape(-1)
    width, height = image_size
    if len(confidence) != len(points):
        raise ValueError("one reliability value is required for every CRU point")
    if len(scores) != len(candidates):
        raise ValueError("one score is required for every HR candidate")
    if not np.isfinite(points).all() or not np.isfinite(confidence).all():
        raise ValueError("points and reliability must be finite")
    if not np.isfinite(candidates).all() or not np.isfinite(scores).all():
        raise ValueError("candidates and scores must be finite")
    if np.any(points < 0) or np.any(points >= [width, height]):
        raise ValueError("CRU points must lie inside the image")
    if np.any(candidates < 0) or np.any(candidates >= [width, height]):
        raise ValueError("HR candidates must lie inside the image")
    if len(clusters) < 2 or not len(points) or not len(candidates):
        return {
            "points_xy": points.copy(), "reliability": confidence.copy(),
            "applied": False, "reason": "insufficient_clusters_or_points",
            "transfers": 0, "starvation_override": False,
        }

    candidate_owner = _strict_candidate_owner(candidates, clusters)
    inside = candidate_owner >= 0
    candidates, scores, candidate_owner = candidates[inside], scores[inside], candidate_owner[inside]
    if not len(candidates):
        return {
            "points_xy": points.copy(), "reliability": confidence.copy(),
            "applied": False, "reason": "no_candidates_inside_boxes",
            "transfers": 0, "starvation_override": False,
        }

    owners = _owner_indices(points, clusters, image_size)
    current = np.bincount(owners, minlength=len(clusters))
    starvation_raw = _raw_quota(
        scores, candidate_owner, policy.starvation_score_threshold,
        len(clusters), len(points),
    )
    starvation_boxes = np.flatnonzero(
        (current <= policy.starvation_current_maximum)
        & ((starvation_raw - current) >= policy.starvation_raw_gain_minimum)
    )
    starvation = bool(len(starvation_boxes))
    threshold = policy.starvation_score_threshold if starvation else policy.default_score_threshold
    blend = policy.starvation_blend if starvation else policy.default_blend
    raw = starvation_raw if starvation else _raw_quota(
        scores, candidate_owner, threshold, len(clusters), len(points),
    )
    l1 = int(np.abs(raw - current).sum())
    if l1 < policy.movement_l1_gate:
        return {
            "points_xy": points.copy(), "reliability": confidence.copy(),
            "applied": False, "reason": "movement_gate_closed", "transfers": 0,
            "starvation_override": starvation, "starvation_boxes": starvation_boxes.tolist(),
            "current_counts": current.tolist(), "raw_counts": raw.tolist(),
        }
    desired = _largest_remainder(
        (1.0 - blend) * current + blend * raw,
        len(points), np.ones(len(clusters), dtype=bool),
    )
    target = _capped_target(current, desired, policy.maximum_transfers)
    if np.array_equal(target, current):
        return {
            "points_xy": points.copy(), "reliability": confidence.copy(),
            "applied": False, "reason": "zero_capped_transfer", "transfers": 0,
            "starvation_override": starvation, "starvation_boxes": starvation_boxes.tolist(),
            "current_counts": current.tolist(), "raw_counts": raw.tolist(),
        }

    scale = 1024.0 / max(width, height)
    support = _candidate_support(points, candidates, scores, scale, policy.support_radius_1024)
    removal_support = 0.6 * _rank(confidence) + 0.4 * _rank(support)
    keep = np.ones(len(points), dtype=bool)
    for box_index in range(len(clusters)):
        remove = int(current[box_index] - target[box_index])
        if remove <= 0:
            continue
        members = np.flatnonzero(owners == box_index)
        order = members[np.argsort(removal_support[members], kind="stable")]
        keep[order[:remove]] = False
    kept = points[keep]
    kept_confidence = confidence[keep]
    kept_owner = owners[keep]

    additions: list[np.ndarray] = []
    addition_scores: list[float] = []
    addition_owner: list[int] = []
    minimum_distance = policy.minimum_spacing_1024 / scale
    for box_index in range(len(clusters)):
        have = int(np.count_nonzero(kept_owner == box_index)) + addition_owner.count(box_index)
        need = int(target[box_index] - have)
        if need <= 0:
            continue
        available = np.flatnonzero((candidate_owner == box_index) & (scores >= threshold))
        available = available[np.argsort(-scores[available], kind="stable")]
        existing = kept[kept_owner == box_index]
        accepted = 0
        for candidate_index in available:
            point = candidates[candidate_index]
            if len(existing) and float(np.min(np.linalg.norm(existing - point, axis=1))) < minimum_distance:
                continue
            additions.append(point.copy())
            addition_scores.append(float(scores[candidate_index]))
            addition_owner.append(box_index)
            existing = np.vstack([existing, point]) if len(existing) else point[None]
            accepted += 1
            if accepted == need:
                break
        if accepted < need:
            return {
                "points_xy": points.copy(), "reliability": confidence.copy(),
                "applied": False, "reason": "insufficient_nonduplicate_candidates",
                "transfers": 0, "starvation_override": starvation,
                "starvation_boxes": starvation_boxes.tolist(),
                "current_counts": current.tolist(), "raw_counts": raw.tolist(),
            }

    result = np.vstack([kept, np.asarray(additions).reshape(-1, 2)]) if additions else kept.copy()
    result_confidence = np.concatenate([kept_confidence, np.asarray(addition_scores, dtype=np.float64)])
    if len(result) != len(points):
        raise RuntimeError("whole-image count conservation failed")
    actual_owner = _owner_indices(result, clusters, image_size)
    actual = np.bincount(actual_owner, minlength=len(clusters))
    if not np.array_equal(actual, target):
        raise RuntimeError("realized per-bunch quotas do not match target")
    return {
        "points_xy": result,
        "reliability": result_confidence,
        "applied": True,
        "reason": "cluster_aware_count_conserving_transfer",
        "transfers": len(additions),
        "starvation_override": starvation,
        "starvation_boxes": starvation_boxes.tolist(),
        "current_counts": current.tolist(),
        "raw_counts": raw.tolist(),
        "output_counts": actual.tolist(),
    }


__all__ = ["ClusterAwareReallocationPolicy", "reallocate_points_by_cluster_evidence"]
