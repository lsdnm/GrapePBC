"""Bounded cached-proposal capacity audit; no model fitting or policy selection.

All ceilings concern source-mask IoU, not biological identity or count accuracy.
The cached pool is already censored by detector confidence, resolution and NMS.
"""
from __future__ import annotations

from dataclasses import dataclass
import cv2
import numpy as np

from .cluster_identity import associate_c1

CACHE_CONFIDENCE = .25
OPERATIVE_CONFIDENCE = .4
MATCH_IOU = .5
SMALL_AREA_FRACTION = .001


@dataclass(frozen=True)
class RasterROI:
    x: int
    y: int
    mask: np.ndarray
    area: int


def _image_size(image_size):
    if len(image_size) != 2 or any(type(v) not in (int, np.int32, np.int64) or v <= 0 for v in image_size):
        raise ValueError('image_size must contain positive integer width and height')
    return tuple(map(int, image_size))


def raster_roi(polygons, image_size):
    """Rasterize with global np.rint BEFORE integer ROI translation, clipped to canvas."""
    width, height = _image_size(image_size)
    vertices = []
    for polygon in polygons:
        xy = np.asarray(polygon, dtype=float)
        if xy.ndim == 1 and xy.size >= 6 and xy.size % 2 == 0:
            xy = xy.reshape(-1, 2)
        if xy.ndim != 2 or xy.shape[1] != 2 or len(xy) < 3 or not np.isfinite(xy).all():
            raise ValueError('Invalid polygon')
        rounded = np.rint(xy)
        if np.abs(rounded).max() > np.iinfo(np.int32).max // 2:
            raise ValueError('Polygon coordinates exceed raster range')
        vertices.append(rounded.astype(np.int32))
    if not vertices:
        return RasterROI(0, 0, np.zeros((0, 0), bool), 0)
    joined = np.concatenate(vertices)
    x0, y0 = np.maximum(joined.min(axis=0), [0, 0])
    x1, y1 = np.minimum(joined.max(axis=0) + 1, [width, height])
    if x1 <= x0 or y1 <= y0:
        return RasterROI(0, 0, np.zeros((0, 0), bool), 0)
    mask = np.zeros((int(y1-y0), int(x1-x0)), np.uint8)
    offset = np.array([x0, y0], dtype=np.int32)
    # Separate calls preserve union semantics for overlapping source polygons.
    for poly in vertices:
        cv2.fillPoly(mask, [poly-offset], 1)
    return RasterROI(int(x0), int(y0), mask.astype(bool), int(mask.sum()))


def raster_intersection(a, b):
    x0, y0 = max(a.x, b.x), max(a.y, b.y)
    x1 = min(a.x+a.mask.shape[1], b.x+b.mask.shape[1])
    y1 = min(a.y+a.mask.shape[0], b.y+b.mask.shape[0])
    if x1 <= x0 or y1 <= y0:
        return 0
    return int(np.count_nonzero(a.mask[y0-a.y:y1-a.y, x0-a.x:x1-a.x] &
                                b.mask[y0-b.y:y1-b.y, x0-b.x:x1-b.x]))


def raster_iou(a, b):
    intersection = raster_intersection(a, b)
    union = a.area+b.area-intersection
    return float(intersection / union) if union else 0.


def point_membership(points, raster):
    points = np.asarray(points, dtype=float).reshape(-1, 2)
    if not np.isfinite(points).all():
        raise ValueError('Nonfinite source point')
    xy = np.floor(points)
    local = xy - [raster.x, raster.y]
    valid = ((local[:, 0] >= 0) & (local[:, 1] >= 0) &
             (local[:, 0] < raster.mask.shape[1]) & (local[:, 1] < raster.mask.shape[0]))
    result = np.zeros(len(points), bool)
    indices = local[valid].astype(np.int64)
    result[valid] = raster.mask[indices[:, 1], indices[:, 0]]
    return result


def maximum_matching(matrix):
    """Fixed-IoU deterministic maximum cardinality; NOT maximum summed IoU."""
    matrix = np.asarray(matrix, dtype=float)
    if matrix.ndim != 2 or not np.isfinite(matrix).all() or np.any((matrix < 0) | (matrix > 1)):
        raise ValueError('Invalid IoU matrix')
    if not matrix.size:
        return []
    neighbors = [sorted(np.flatnonzero(row >= MATCH_IOU), key=lambda j: (-row[j], j)) for row in matrix]
    assigned = {}

    def augment(i, visited):
        for j in neighbors[i]:
            if j in visited:
                continue
            visited.add(j)
            if j not in assigned or augment(assigned[j], visited):
                assigned[j] = i
                return True
        return False

    for i in sorted(range(len(matrix)), key=lambda k: (-float(matrix[k].max()), k)):
        augment(i, set())
    return sorted((int(i), int(j), float(matrix[i, j])) for j, i in assigned.items())


def _graph(matrix, witnesses, left_ids, kind):
    matches = [dict(left=i, gt=j, iou=value, candidate=int(witnesses[i, j]))
               for i, j, value in maximum_matching(matrix)]
    matched_gt = {m['gt'] for m in matches}
    edges = [dict(left=int(i), gt=int(j), iou=float(matrix[i, j]), candidate=int(witnesses[i, j]))
             for i, j in zip(*np.nonzero(matrix >= MATCH_IOU))]
    result = dict(left_ids=list(map(int, left_ids)), left_kind=kind, edges=edges, matches=matches,
                  matched_count=len(matches), unmatched_gt=[j for j in range(matrix.shape[1]) if j not in matched_gt],
                  zero_edge_gt_ids=[j for j in range(matrix.shape[1]) if not np.any(matrix[:, j] >= MATCH_IOU)])
    return result


def analyze_iou_matrix(matrix, high_indices, groups, representatives, gt_areas, image_size):
    """Expose the four-graph algebra for toy/independent verification."""
    matrix = np.asarray(matrix, dtype=float)
    maximum_matching(matrix)  # schema/range validation, including empty axes
    width, height = _image_size(image_size)
    n, truth_count = matrix.shape
    high = list(map(int, high_indices)); reps = list(map(int, representatives))
    groups = [list(map(int, group)) for group in groups]
    areas = np.asarray(gt_areas, dtype=float)
    if areas.shape != (truth_count,) or not np.isfinite(areas).all() or np.any(areas <= 0):
        raise ValueError('Invalid GT areas')
    if len(high) != len(set(high)) or any(i < 0 or i >= n for i in high):
        raise ValueError('Invalid high-candidate mapping')
    flattened = [i for group in groups for i in group]
    if len(groups) != len(reps) or sorted(flattened) != sorted(high) or len(flattened) != len(set(flattened)):
        raise ValueError('Groups must partition high candidates exactly')
    if any(not group or rep not in group for group, rep in zip(groups, reps)):
        raise ValueError('Invalid representative')
    all_witness = np.broadcast_to(np.arange(n)[:, None], matrix.shape)
    high_matrix = matrix[high, :]
    high_witness = np.broadcast_to(np.asarray(high, dtype=int)[:, None], high_matrix.shape)
    grouped_matrix = np.zeros((len(groups), truth_count), float)
    grouped_witness = np.zeros((len(groups), truth_count), int)
    for g, members in enumerate(groups):
        members = sorted(members)
        if truth_count:
            chosen = np.argmax(matrix[members, :], axis=0)
            grouped_witness[g, :] = np.asarray(members)[chosen]
            grouped_matrix[g, :] = matrix[grouped_witness[g, :], np.arange(truth_count)]
    rep_matrix = matrix[reps, :]
    rep_witness = np.broadcast_to(np.asarray(reps, dtype=int)[:, None], rep_matrix.shape)
    matrices = dict(all_candidates=matrix, high_candidates=high_matrix, grouped=grouped_matrix,
                    representatives=rep_matrix)
    witness_matrices = dict(all_candidates=all_witness, high_candidates=high_witness,
                            grouped=grouped_witness, representatives=rep_witness)
    graphs = dict(all_candidates=_graph(matrix, all_witness, range(n), 'candidate'),
                  high_candidates=_graph(high_matrix, high_witness, high, 'candidate'),
                  grouped=_graph(grouped_matrix, grouped_witness, reps, 'group_root_candidate'),
                  representatives=_graph(rep_matrix, rep_witness, reps, 'candidate'))
    graphs['grouped']['member_candidate_indices'] = groups
    counts = [graphs[k]['matched_count'] for k in matrices]
    if not truth_count >= counts[0] >= counts[1] >= counts[2] >= counts[3]:
        raise AssertionError('Capacity chain is not monotone')
    losses = dict(cached_candidate_gap=truth_count-counts[0], confidence_filter_loss=counts[0]-counts[1],
                  group_capacity_loss_proxy=counts[1]-counts[2], representative_choice_loss=counts[2]-counts[3],
                  total_c1_fn=truth_count-counts[3])
    if sum(v for k, v in losses.items() if k != 'total_c1_fn') != losses['total_c1_fn']:
        raise AssertionError('Loss decomposition failed')
    small = [j for j, area in enumerate(areas) if area < SMALL_AREA_FRACTION*width*height]
    small_bounds = {key: len(maximum_matching(values[:, small])) for key, values in matrices.items()}
    per_gt = []
    for j in range(truth_count):
        item = dict(gt=j, area=int(areas[j]), small=j in small)
        for key, values in matrices.items():
            item['best_iou_'+key] = float(values[:, j].max()) if len(values) else 0.
            item['best_candidate_'+key] = int(witness_matrices[key][int(np.argmax(values[:, j])), j]) if len(values) else None
            item['edges_'+key] = int(np.count_nonzero(values[:, j] >= MATCH_IOU))
        per_gt.append(item)
    return dict(candidates=n, high_candidates=len(high), truth=truth_count, small_gt_ids=small,
                graphs=graphs, loss_chain=losses, small_subgraph_bounds=small_bounds, per_gt=per_gt,
                interpretations=dict(matching='maximum cardinality, deterministic IoU-ordered augmentations; no maximum-total-IoU claim',
                    grouping='one selected member per frozen C1 group; source-mask capacity proxy, not confirmed biological identity error',
                    small='small-GT induced-subgraph capacity bounds, not deployed small recall',
                    attribution='aggregate telescoping losses only; per-GT unmatched witnesses are not unique causal labels',
                    candidate_ceiling='cached >=0.25 proposals after per-view NMS and resolution constraints; not an absolute detector ceiling',
                    count_accuracy='mask capacities do not establish berry-count MAE improvement'))


def analyze_candidates(candidates, annotation_polygons, image_size, points):
    """Audit an A-only caller-supplied image; no file access or model inference."""
    width, height = _image_size(image_size)
    points = np.asarray(points, dtype=float).reshape(-1, 2)
    if not np.isfinite(points).all():
        raise ValueError('Nonfinite source points')
    if any(not np.isfinite(c.confidence) or not CACHE_CONFIDENCE <= c.confidence <= 1 for c in candidates):
        raise ValueError('Candidates must be from the frozen >=.25 cache')
    predicted = [raster_roi([c.polygon], image_size) for c in candidates]
    truth = [raster_roi(polygons, image_size) for polygons in annotation_polygons]
    if any(region.area == 0 for region in truth+predicted):
        raise ValueError('Empty source or candidate raster')
    intersections = np.zeros((len(predicted), len(truth)), np.int64)
    matrix = np.zeros(intersections.shape, float)
    for i, pred in enumerate(predicted):
        for j, gt in enumerate(truth):
            intersection = raster_intersection(pred, gt)
            intersections[i, j] = intersection
            matrix[i, j] = intersection/(pred.area+gt.area-intersection)
    high = [i for i, c in enumerate(candidates) if c.confidence >= OPERATIVE_CONFIDENCE]
    associated = associate_c1([candidates[i] for i in high], containment=.9, iou=.45)
    reps = [high[i] for i in associated['representatives']]
    groups = [[high[i] for i in associated['members'][r]] for r in associated['representatives']]
    record = analyze_iou_matrix(matrix, high, groups, reps, [r.area for r in truth], image_size)
    record['image_size'] = [width, height]
    record['association'] = dict(representatives=reps,
        members={str(root): group for root, group in zip(reps, groups)},
        decisions=[{**d, 'candidate': high[d['candidate']], 'representative': high[d['representative']]}
                   for d in associated['decisions']], policy=associated['policy'])
    source_memberships = np.asarray([point_membership(points, r) for r in truth], dtype=bool).reshape(len(truth), len(points))
    source_degree = source_memberships.sum(axis=0)
    flagged = []
    for i in high:
        if not np.any(intersections[i, :]) and not np.any(point_membership(points, predicted[i])):
            flagged.append(i)
    record['annotation_scope_flags'] = dict(
        unmatched_high_candidates_zero_gt_intersection_zero_source_points=flagged,
        source_points_total=len(points), source_points_outside_all_gt=int(np.count_nonzero(source_degree == 0)),
        source_points_ambiguous=int(np.count_nonzero(source_degree > 1)),
        source_points_per_gt=source_memberships.sum(axis=1).astype(int).tolist(),
        source_masks_zero_points=np.flatnonzero(source_memberships.sum(axis=1) == 0).astype(int).tolist(),
        interpretation='candidate review flags only: neither confirmed label omissions nor confirmed false-positive objects',
        labels_certified_exhaustive=False)
    return record
