"""Change representative only; never change locked C1 identity membership."""
import math


def confidence_representatives(candidates, decisions):
    if len(decisions) != len(candidates):
        raise ValueError('one decision required per candidate')
    ids = [d['candidate'] for d in decisions]
    if sorted(ids) != list(range(len(candidates))):
        raise ValueError('candidate decisions must form a partition')
    groups = {}
    for d in decisions:
        idx, rep = d['candidate'], d['representative']
        if not isinstance(rep, int) or not 0 <= rep < len(candidates):
            raise ValueError('invalid representative')
        if not math.isfinite(candidates[idx].confidence):
            raise ValueError('nonfinite confidence')
        groups.setdefault(rep, []).append(idx)
    by_id = {d['candidate']: d['representative'] for d in decisions}
    for rep, members in groups.items():
        if rep not in members or by_id[rep] != rep:
            raise ValueError('representative must be a self-rooted member')
    # Preserve original C1 representative order, hence identity count and IDs.
    roots = [d['candidate'] for d in decisions if d['candidate'] == d['representative']]
    selected = [min(groups[r], key=lambda j: (-candidates[j].confidence, j)) for r in roots]
    return dict(original=roots, selected=selected, groups=groups,
                changed=sum(a != b for a, b in zip(roots, selected)),
                policy='C1_fixed_membership_max_confidence_v1')
