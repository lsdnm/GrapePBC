"""Opt-in post-C1 suppression of unambiguous tile-edge fragments only.

No union, expansion, learned scores, GT access, or change to the frozen C1 code.
An entire child group must contain only truncated tile candidates. A stronger
non-truncated representative can absorb it only when views do not conflict.
"""
from .candidate_ceiling import raster_roi, raster_intersection


def suppress_edge_fragments(candidates, association, image_size):
    roots=list(association['representatives'])
    members={r:list(association['members'].get(r,association['members'].get(str(r),[]))) for r in roots}
    flat=[i for r in roots for i in members[r]]
    if sorted(flat)!=list(range(len(candidates))) or any(r not in members[r] for r in roots):
        raise ValueError('Association must partition all supplied candidates')
    regions={r:raster_roi([candidates[r].polygon],image_size) for r in roots}
    anchors=[r for r in roots if not candidates[r].truncated_edges]
    removed=[];decisions=[]
    for r in roots:
        c=candidates[r]
        if c.global_view or not all(not candidates[m].global_view and candidates[m].truncated_edges for m in members[r]):
            continue
        eligible=[]
        for a in anchors:
            p,q=regions[r],regions[a]
            if a==r or not 0<p.area<q.area:continue
            fraction=raster_intersection(p,q)/p.area
            if fraction>=.9:eligible.append((a,fraction))
        # Ambiguity is assessed BEFORE confidence and view-conflict filtering.
        if len(eligible)!=1:continue
        a,fraction=eligible[0]
        if candidates[a].confidence<c.confidence:continue
        child_views={candidates[m].view_id for m in members[r]}
        anchor_views={candidates[m].view_id for m in members[a]}
        if child_views & anchor_views:continue
        removed.append(r)
        decisions.append(dict(removed=r,anchor=a,containment=fraction,reason='unique_stronger_complete_anchor_no_shared_view'))
    return dict(representatives=[r for r in roots if r not in removed],removed=removed,decisions=decisions,
                policy='F1_fixed_edge_fragment_guard',gt_used=False)
