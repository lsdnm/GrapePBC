"""Experimental conservative C1 cross-view identity association for R1.

Opt-in only: the old detector and all frozen runs remain unchanged. Full-view
instances are preferred anchors. Native tiles without a global anchor survive.
Containment alone does not suppress a candidate: a tile-interior truncation is
required, and two instances from one view can never share an identity.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import cv2
import numpy as np
from PIL import Image

from .cluster_detector import _Candidate, _mask_iou, tile_origins


@dataclass(frozen=True)
class IdentityCandidate:
    polygon: np.ndarray
    bbox: np.ndarray
    confidence: float
    view_id: int
    view_bounds: tuple[int, int, int, int]
    global_view: bool
    truncated_edges: tuple[str, ...] = ()

    def legacy(self):
        return _Candidate(self.polygon, self.bbox, self.confidence, self.view_id)


def truncation_edges(polygon: np.ndarray, bounds, image_size, tolerance=3.0):
    """Only interior crop edges count; an original image boundary is not evidence."""
    x0, y0, x1, y1 = bounds
    width, height = image_size
    xy = np.asarray(polygon, dtype=float).reshape(-1, 2)
    edges = []
    if x0 > 0 and xy[:, 0].min() <= x0 + tolerance:
        edges.append('left')
    if y0 > 0 and xy[:, 1].min() <= y0 + tolerance:
        edges.append('top')
    if x1 < width and xy[:, 0].max() >= x1 - 1 - tolerance:
        edges.append('right')
    if y1 < height and xy[:, 1].max() >= y1 - 1 - tolerance:
        edges.append('bottom')
    return tuple(edges)


def containment_fraction(fragment: np.ndarray, anchor: np.ndarray):
    left, top = np.floor(np.minimum(fragment.min(axis=0), anchor.min(axis=0))).astype(int)
    right, bottom = np.ceil(np.maximum(fragment.max(axis=0), anchor.max(axis=0))).astype(int)
    shape = (max(1, bottom-top+1), max(1, right-left+1))
    a, b = np.zeros(shape, np.uint8), np.zeros(shape, np.uint8)
    offset = np.array([left, top])
    cv2.fillPoly(a, [np.rint(fragment-offset).astype(np.int32)], 1)
    cv2.fillPoly(b, [np.rint(anchor-offset).astype(np.int32)], 1)
    na, nb = int(a.sum()), int(b.sum())
    return (float(np.count_nonzero(a & b) / na) if na else 0.0), na, nb


def associate_c1(candidates: list[IdentityCandidate], containment=.9, iou=.45):
    if not 0 < containment <= 1 or not 0 < iou <= 1:
        raise ValueError('invalid association thresholds')
    for c in candidates:
        if len(c.polygon) < 3 or not np.isfinite(c.polygon).all():
            raise ValueError('invalid polygon')
    order = sorted(range(len(candidates)), key=lambda j: (not candidates[j].global_view,
                   -candidates[j].confidence, candidates[j].view_id, *candidates[j].bbox.tolist(), j))
    representatives, members, decisions = [], {}, []
    for idx in order:
        c = candidates[idx]
        matches = []
        for keeper in representatives:
            anchor = candidates[keeper]
            if c.view_id == anchor.view_id:
                continue
            reason = None
            # Cheap spatial rejection before allocating raster masks.
            if np.any(np.minimum(c.bbox[2:], anchor.bbox[2:]) <= np.maximum(c.bbox[:2], anchor.bbox[:2])):
                continue
            if _mask_iou(c.legacy(), anchor.legacy()) >= iou:
                reason = 'cross_view_mask_iou'
            elif anchor.global_view and not c.global_view and c.truncated_edges:
                fraction, child_area, anchor_area = containment_fraction(c.polygon, anchor.polygon)
                if child_area < anchor_area and fraction >= containment:
                    reason = 'truncated_fragment_of_global_anchor'
            if reason:
                same_view_conflict = any(candidates[m].view_id == c.view_id for m in members[keeper])
                matches.append((keeper, reason, same_view_conflict))
        # Do not redirect an ambiguous or same-view-conflicting fragment to an
        # alternative identity merely because the preferred one is unavailable.
        if len(matches) == 1 and not matches[0][2]:
            keeper, reason, _ = matches[0]
            members[keeper].append(idx)
            decisions.append({'candidate': idx, 'representative': keeper, 'reason': reason})
        else:
            representatives.append(idx)
            members[idx] = [idx]
            decisions.append({'candidate': idx, 'representative': idx,
                              'reason': 'ambiguous_keep' if len(matches) > 1 else
                                        'same_view_conflict_keep' if matches else 'independent_keep'})
    return {'representatives': representatives, 'members': members, 'decisions': decisions,
            'policy': 'C1_conservative_global_anchor_v1'}


def collect_identity_candidates(image: Image.Image, detector: Any, *, tile_size=1024,
                                stride=768, confidence=.4, device=0):
    if not 0 <= confidence <= 1:
        raise ValueError('invalid confidence')
    width, height = image.size
    views = [(0, 0, width, height)]
    views.extend((x, y, min(x+tile_size, width), min(y+tile_size, height))
                 for y in tile_origins(height, tile_size, stride)
                 for x in tile_origins(width, tile_size, stride)
                 if (x, y, min(x+tile_size, width), min(y+tile_size, height)) != views[0])
    candidates = []
    for view_id, bounds in enumerate(views):
        x0, y0, x1, y1 = bounds
        bgr = cv2.cvtColor(np.asarray(image.crop(bounds).convert('RGB')), cv2.COLOR_RGB2BGR)
        result = detector.predict(source=bgr, imgsz=tile_size, conf=confidence,
                                  iou=.6, device=device, retina_masks=True, verbose=False)[0]
        if result.boxes is None or result.masks is None:
            continue
        boxes = result.boxes.xyxy.detach().cpu().numpy()
        scores = result.boxes.conf.detach().cpu().numpy()
        for box, score, poly in zip(boxes, scores, result.masks.xy):
            polygon = np.asarray(poly, dtype=float).reshape(-1, 2).copy()
            if len(polygon) < 3:
                continue
            polygon += [x0, y0]
            polygon[:, 0] = np.clip(polygon[:, 0], 0, width-1)
            polygon[:, 1] = np.clip(polygon[:, 1], 0, height-1)
            candidates.append(IdentityCandidate(polygon, np.asarray(box)+[x0,y0,x0,y0],
                              float(score), view_id, bounds, view_id == 0,
                              truncation_edges(polygon, bounds, image.size)))
    return candidates
