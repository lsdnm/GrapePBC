"""Count-observable point-set reconciliation for the frozen CRU output."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class CountReconciliationPolicy:
    """Safeguards for adding or removing point hypotheses."""

    minimum_added_spacing_1024: float = 4.0

    def __post_init__(self) -> None:
        if self.minimum_added_spacing_1024 < 0:
            raise ValueError("minimum added spacing must be non-negative")


def reconcile_point_count(
    points_xy: np.ndarray,
    reliability: np.ndarray,
    candidate_xy: np.ndarray,
    candidate_scores: np.ndarray,
    requested_count: int,
    *,
    image_size: tuple[int, int],
    policy: CountReconciliationPolicy = CountReconciliationPolicy(),
) -> dict[str, object]:
    """Return exactly ``requested_count`` points when valid candidates permit.

    Existing coordinates are retained when adding points.  Over-count repair
    keeps the most reliable existing hypotheses.  Under-count repair appends
    unique, in-bounds HR candidates that are sufficiently separated from all
    already retained points.  The function never uses labels or sample IDs.
    """

    points = np.asarray(points_xy, dtype=np.float32).reshape(-1, 2)
    confidence = np.asarray(reliability, dtype=np.float32).reshape(-1)
    candidates = np.asarray(candidate_xy, dtype=np.float32).reshape(-1, 2)
    scores = np.asarray(candidate_scores, dtype=np.float32).reshape(-1)
    if len(points) != len(confidence) or len(candidates) != len(scores):
        raise ValueError("point/reliability or candidate/score cardinality mismatch")
    if not all(np.isfinite(value).all() for value in (points, confidence, candidates, scores)):
        raise ValueError("all reconciliation inputs must be finite")
    width, height = int(image_size[0]), int(image_size[1])
    if width <= 0 or height <= 0 or requested_count < 0:
        raise ValueError("invalid image size or requested count")
    if np.any(points < 0) or np.any(points >= [width, height]):
        raise ValueError("existing points must lie inside the image")

    requested = int(requested_count)
    diagnostics: dict[str, object] = {
        "input_count": len(points),
        "requested_count": requested,
        "output_count": len(points),
        "added": 0,
        "removed": 0,
        "candidate_shortfall": False,
    }
    if requested == len(points):
        return {"points_xy": points.copy(), "reliability": confidence.copy(), **diagnostics}
    if requested < len(points):
        order = np.argsort(-confidence, kind="stable")[:requested]
        # Preserve original point order so downstream ownership is deterministic.
        keep = np.sort(order)
        output = points[keep].copy(); output_confidence = confidence[keep].copy()
        diagnostics.update({"output_count": len(output), "removed": len(points) - len(output)})
        return {"points_xy": output, "reliability": output_confidence, **diagnostics}

    scale = 1024.0 / max(width, height)
    minimum2 = float(policy.minimum_added_spacing_1024) ** 2
    output_points = [point.copy() for point in points]
    output_scores = [float(value) for value in confidence]
    seen = {(float(point[0]), float(point[1])) for point in points}
    order = np.argsort(-scores, kind="stable")
    for index in order:
        candidate = candidates[index]
        key = (float(candidate[0]), float(candidate[1]))
        if key in seen or np.any(candidate < 0) or np.any(candidate >= [width, height]):
            continue
        if output_points:
            existing = np.asarray(output_points, dtype=np.float32)
            distance2 = np.sum(((existing - candidate) * scale) ** 2, axis=1)
            if float(distance2.min()) < minimum2:
                continue
        output_points.append(candidate.copy()); output_scores.append(float(scores[index])); seen.add(key)
        if len(output_points) == requested:
            break
    output = np.asarray(output_points, dtype=np.float32).reshape(-1, 2)
    output_confidence = np.asarray(output_scores, dtype=np.float32)
    diagnostics.update({
        "output_count": len(output),
        "added": len(output) - len(points),
        "candidate_shortfall": len(output) != requested,
    })
    return {"points_xy": output, "reliability": output_confidence, **diagnostics}


__all__ = ["CountReconciliationPolicy", "reconcile_point_count"]
