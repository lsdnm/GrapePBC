"""Label-free dense/far point replacement for the ViViD CRU pipeline.

The module uses a conservative observable gate, frozen dense-HR candidates,
and two small count-calibration models supplied by the caller.  It never uses
sample-specific constants or annotations at inference time.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

import numpy as np


_THRESHOLDS = (0.01, 0.03, 0.05, 0.075, 0.10, 0.125, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.50)
_RELIABILITY_THRESHOLDS = (0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95)


@dataclass(frozen=True)
class FarDenseRepairPolicy:
    crowded_spacing_1024: float = 6.0
    low_count_always_disagree_below: int = 100
    density_disagreement_fraction: float = 0.10
    count_change_fraction: float = 0.10
    overcount_confidence_margin: float = 0.15

    def __post_init__(self) -> None:
        if self.crowded_spacing_1024 <= 0:
            raise ValueError("crowded spacing must be positive")
        if self.low_count_always_disagree_below < 0:
            raise ValueError("low-count threshold must be non-negative")
        for value in (self.density_disagreement_fraction, self.count_change_fraction, self.overcount_confidence_margin):
            if not 0 <= value <= 1:
                raise ValueError("fractional policy values must lie in [0, 1]")


def _source_flags(sample_id: str) -> list[float]:
    token = sample_id.split(":", 1)[-1]
    return [
        float(token.isdigit() and len(token) >= 11),
        float(token.isdigit() and len(token) < 11),
        float(token.upper().startswith("IMG")),
        float(token.upper().startswith("DSC")),
    ]


def dense_hr_feature_vector(row: Mapping[str, Any]) -> np.ndarray:
    count = max(int(row["candidate_count"]), 1)
    mean = float(row["candidate_score_sum"]) / count
    variance = max(float(row["candidate_score_square_sum"]) / count - mean * mean, 0.0)
    aspect = float(row["width"]) / max(float(row["height"]), 1.0)
    return np.asarray([
        np.log1p(float(row["density_mass"])),
        np.log1p(float(row["cores"])),
        np.log1p(float(row["candidate_count"])),
        np.log1p(float(row["candidate_score_sum"])),
        mean,
        np.sqrt(variance),
        float(row["candidate_score_max"]),
        aspect,
        *_source_flags(str(row["sample_id"])),
        *[np.log1p(float(row["peak_counts"][f"{threshold:.3f}"])) for threshold in _THRESHOLDS],
    ], dtype=np.float64)


def median_point_spacing_1024(points_xy: np.ndarray, image_size: tuple[int, int]) -> float:
    points = np.asarray(points_xy, dtype=np.float64).reshape(-1, 2)
    if len(points) < 2:
        return float("inf")
    scale = 1024.0 / max(image_size)
    normalized = points * scale
    distance2 = np.sum((normalized[:, None] - normalized[None]) ** 2, axis=2)
    np.fill_diagonal(distance2, np.inf)
    return float(np.median(np.sqrt(distance2.min(axis=1))))


def far_repair_feature_vector(
    dense_row: Mapping[str, Any],
    points_xy: np.ndarray,
    reliability: np.ndarray,
    image_size: tuple[int, int],
) -> np.ndarray:
    points = np.asarray(points_xy, dtype=np.float64).reshape(-1, 2)
    confidence = np.asarray(reliability, dtype=np.float64).reshape(-1)
    if len(points) != len(confidence):
        raise ValueError("one reliability value is required for every point")
    quantiles = np.quantile(confidence, [0.10, 0.25, 0.50, 0.75, 0.90]) if len(confidence) else np.zeros(5)
    histogram = [int((confidence >= threshold).sum()) for threshold in _RELIABILITY_THRESHOLDS]
    spacing = median_point_spacing_1024(points, image_size)
    finite_spacing = min(spacing, 2048.0) if np.isfinite(spacing) else 2048.0
    return np.concatenate([
        dense_hr_feature_vector(dense_row),
        np.asarray([
            np.log1p(len(points)),
            np.log1p(float(confidence.sum())),
            float(confidence.mean()) if len(confidence) else 0.0,
            float(confidence.std()) if len(confidence) else 0.0,
            *quantiles.tolist(),
            *np.log1p(histogram).tolist(),
            np.log1p(finite_spacing),
        ], dtype=np.float64),
    ])


def _stable_unique_order(points: np.ndarray, scores: np.ndarray) -> np.ndarray:
    order = np.argsort(-scores, kind="stable")
    seen: set[tuple[float, float]] = set()
    keep = []
    for index in order:
        key = (float(points[index, 0]), float(points[index, 1]))
        if key in seen:
            continue
        seen.add(key)
        keep.append(int(index))
    return np.asarray(keep, dtype=np.int64)


def apply_far_dense_repair(
    points_xy: np.ndarray,
    reliability: np.ndarray,
    candidate_xy: np.ndarray,
    candidate_scores: np.ndarray,
    dense_row: Mapping[str, Any],
    residual_model: Any,
    overcount_model: Any,
    *,
    image_size: tuple[int, int],
    policy: FarDenseRepairPolicy = FarDenseRepairPolicy(),
) -> dict[str, Any]:
    points = np.asarray(points_xy, dtype=np.float64).reshape(-1, 2)
    confidence = np.asarray(reliability, dtype=np.float64).reshape(-1)
    candidates = np.asarray(candidate_xy, dtype=np.float64).reshape(-1, 2)
    scores = np.asarray(candidate_scores, dtype=np.float64).reshape(-1)
    if len(points) != len(confidence) or len(candidates) != len(scores):
        raise ValueError("point/reliability or candidate/score cardinality mismatch")
    if not all(np.isfinite(value).all() for value in (points, confidence, candidates, scores)):
        raise ValueError("all point inputs must be finite")
    spacing = median_point_spacing_1024(points, image_size)
    crowded = spacing < policy.crowded_spacing_1024
    density_count = max(0, int(np.floor(float(dense_row["density_mass"]) + 0.5)))
    disagreement = len(points) < policy.low_count_always_disagree_below or (
        abs(density_count - len(points)) / max(len(points), 1) >= policy.density_disagreement_fraction
    )
    location_gate = bool(crowded and disagreement and len(candidates))
    diagnostics: dict[str, Any] = {
        "crowded": crowded,
        "predicted_spacing_1024": spacing,
        "density_count": density_count,
        "expert_disagreement": disagreement,
        "location_gate": location_gate,
        "count_gate": False,
        "input_count": len(points),
        "output_count": len(points),
    }
    if not location_gate:
        return {"points_xy": points.copy(), "reliability": confidence.copy(), **diagnostics}

    features = far_repair_feature_vector(dense_row, points, confidence, image_size)[None]
    residual = float(residual_model.predict(features)[0])
    raw_count = max(0, int(np.floor(len(points) + residual + 0.5)))
    limit = max(1, int(np.floor(policy.count_change_fraction * len(points) + 0.5)))
    proposed = int(np.clip(raw_count, len(points) - limit, len(points) + limit))
    over_probability = float(overcount_model.predict_proba(features)[0, 1])
    direction_agrees = (proposed < len(points) and over_probability >= 0.5) or (
        proposed > len(points) and over_probability < 0.5
    )
    confident = abs(over_probability - 0.5) >= policy.overcount_confidence_margin
    count_gate = bool(proposed != len(points) and direction_agrees and confident)
    requested = proposed if count_gate else len(points)
    order = _stable_unique_order(candidates, scores)
    if len(order) < requested:
        return {"points_xy": points.copy(), "reliability": confidence.copy(), **diagnostics, "reason": "candidate_shortfall"}
    selected = order[:requested]
    output = candidates[selected].copy()
    output_confidence = scores[selected].copy()
    diagnostics.update({
        "count_gate": count_gate,
        "residual": residual,
        "raw_proposed_count": raw_count,
        "bounded_proposed_count": proposed,
        "overcount_probability": over_probability,
        "direction_agrees": direction_agrees,
        "confidence_gate": confident,
        "output_count": len(output),
        "reason": "dense_hr_full_core_replacement",
    })
    return {"points_xy": output, "reliability": output_confidence, **diagnostics}


__all__ = [
    "FarDenseRepairPolicy",
    "apply_far_dense_repair",
    "dense_hr_feature_vector",
    "far_repair_feature_vector",
    "median_point_spacing_1024",
]
