"""ROI implementation of existing fixed cluster metrics; no inference policy."""
import numpy as np
from .candidate_ceiling import raster_roi,raster_intersection,point_membership,maximum_matching


def owners(points,regions,scores):
    membership=np.asarray([point_membership(points,r) for r in regions],bool).reshape(len(regions),len(points))
    result=np.full(len(points),-1,int)
    order=sorted(range(len(regions)),key=lambda i:(-scores[i],regions[i].area,i))
    for i in reversed(order):result[membership[i]]=i
    return result,membership


def evaluate_roi(candidates,polygons,gt_points,lr_points,image_size):
    predicted=[raster_roi([c.polygon],image_size) for c in candidates]
    truth=[raster_roi(p,image_size) for p in polygons]
    if any(r.area==0 for r in predicted+truth):raise ValueError('Empty region')
    matrix=np.zeros((len(predicted),len(truth)));inter=np.zeros(matrix.shape,dtype=np.int64)
    for i,p in enumerate(predicted):
        for j,t in enumerate(truth):
            v=raster_intersection(p,t);inter[i,j]=v;matrix[i,j]=v/(p.area+t.area-v)
    pairs=maximum_matching(matrix);pi={p for p,g,v in pairs};gi={g for p,g,v in pairs}
    fp=[i for i in range(len(predicted)) if i not in pi];fn=[j for j in range(len(truth)) if j not in gi]
    small={j for j,t in enumerate(truth) if t.area<.001*image_size[0]*image_size[1]}
    gt_points=np.asarray(gt_points).reshape(-1,2);lr_points=np.asarray(lr_points).reshape(-1,2)
    go,gm=owners(gt_points,truth,[1.]*len(truth));certain=gm.sum(0)==1
    lower=(gm & certain).sum(1);upper=gm.sum(1)
    scores=[c.confidence for c in candidates]
    po,pm=owners(gt_points,predicted,scores);mapping=dict((p,g) for p,g,v in pairs)
    correct=sum(bool(certain[n] and mapping.get(int(po[n]),-1)==int(go[n])) for n in range(len(go)))
    def penalty(points):
        owned,m=owners(points,predicted,scores)
        counts=np.bincount(owned[owned>=0],minlength=len(predicted)).astype(int).tolist()
        matched=sum(int(max(lower[g]-counts[p],0,counts[p]-upper[g])) for p,g,v in pairs)
        missed=int(sum(lower[g] for g in fn));spurious=sum(counts[p] for p in fp)
        assigned=sum(counts);unassigned=int(np.count_nonzero(owned<0))
        assert assigned+unassigned==len(points)
        return dict(penalty_sum=matched+missed+spurious,matched_penalty_sum=matched,missed_gt_penalty=missed,
                    spurious_prediction_penalty=spurious,assigned=assigned,unassigned=unassigned,
                    ambiguous=int(np.count_nonzero(m.sum(0)>1)),cluster_counts=counts)
    fragment=[i for i in fp if any(predicted[i].area<t.area and inter[i,j]/predicted[i].area>=.8 for j,t in enumerate(truth))]
    mixed=[]
    for i in range(len(predicted)):
        ids=[j for j in range(len(truth)) if np.count_nonzero(certain&(po==i)&(go==j))>=3]
        if len(ids)>=2:mixed.append(dict(predicted=i,gt_ids=ids))
    return dict(tp=len(pairs),fp=len(fp),fn=len(fn),truth=len(truth),predicted=len(predicted),
                small_tp=len(gi&small),small_total=len(small),pairs=pairs,fp_ids=fp,fn_ids=fn,small_gt_ids=sorted(small),
                fragment_fp_proxy=len(fragment),fragment_fp_ids=fragment,mixed_gt_prediction_proxy=len(mixed),mixed_gt_predictions=mixed,
                certain_gt_points=int(certain.sum()),correctly_owned_gt_points=int(correct),
                gt_ambiguous=int(np.count_nonzero(gm.sum(0)>1)),gt_unassigned=int(np.count_nonzero(gm.sum(0)==0)),
                oracle_points=penalty(gt_points),lr_points=penalty(lr_points))
