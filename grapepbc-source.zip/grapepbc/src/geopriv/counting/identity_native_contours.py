"""Opt-in C4: retain C1 identities, substitute only fully observed native contours.

No GT, berry counts, image identifiers, or learned threshold selection. Keeping
anchor confidence isolates contour geometry from confidence-based point ownership.
"""
from dataclasses import replace
import numpy as np
from .cluster_detector import _mask_iou


def covers_anchor_view(local, anchor, margin=3.):
    if local.global_view or local.truncated_edges or not anchor.global_view:
        return False
    x0,y0,x1,y1=local.view_bounds
    gx0,gy0,gx1,gy1=anchor.view_bounds
    ax0,ay0,ax1,ay1=anchor.bbox
    # A tile boundary coincident with an original-image boundary adds no cut.
    return bool((x0<=gx0 or x0+margin<=ax0) and (y0<=gy0 or y0+margin<=ay0)
        and (x1>=gx1 or x1-margin>=ax1) and (y1>=gy1 or y1-margin>=ay1))


def select_native_contours(candidates, association):
    roots=list(association['representatives'])
    groups={int(k):list(v) for k,v in association['members'].items()}
    if set(roots)!=set(groups) or sorted(i for group in groups.values() for i in group)!=list(range(len(candidates))):
        raise ValueError('Association must partition candidates')
    selected=[];audit=[];output=[]
    for root in roots:
        if root not in groups[root]:raise ValueError('Root not in own group')
        members=groups[root]
        if len({candidates[i].view_id for i in members})!=len(members):
            raise ValueError('Same-view conflict inside group')
        anchor=candidates[root]
        eligible=[i for i in members if covers_anchor_view(candidates[i],anchor)
            and _mask_iou(candidates[i].legacy(),anchor.legacy())>=.45]
        # Global view remains when there is no complete, spatially compatible tile.
        chosen=root;consensus={}
        if eligible:
            for i in eligible:
                others=[j for j in eligible if j!=i]
                consensus[i]=float(np.mean([_mask_iou(candidates[i].legacy(),candidates[j].legacy())
                    for j in others])) if others else 1.
            chosen=min(eligible,key=lambda i:(-consensus[i],-candidates[i].confidence,candidates[i].view_id,i))
        selected.append(chosen)
        output.append(replace(candidates[chosen],confidence=anchor.confidence))
        audit.append(dict(root=root,selected=chosen,eligible=eligible,consensus=consensus,
            anchor_confidence=anchor.confidence,changed=chosen!=root))
    return output,dict(policy='C4_C1_fixed_membership_complete_native_medoid_v1',
        roots=roots,selected=selected,groups=groups,decisions=audit,
        changed=sum(a!=b for a,b in zip(roots,selected)))
