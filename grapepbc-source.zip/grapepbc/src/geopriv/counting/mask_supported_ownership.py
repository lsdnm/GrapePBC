"""Prediction-only ownership tie-break; unchanged frozen berry points/boxes.

This is an experimental alternative, not the deployed assignment default. A
point in multiple rectangles may be reassigned only when exactly one matching
predicted mask supports it. Ambiguous/absent mask support keeps the existing
geometry fallback. No source annotations or source counts enter this function.
"""
from collections import Counter
from collections.abc import Mapping, Sequence
import cv2
import numpy as np
from .per_cluster_boxes import ClusterBox, assign_berries_to_cluster_boxes


def assign_with_predicted_mask_support(
    points_xy: np.ndarray,
    clusters: Sequence[ClusterBox],
    *,
    image_size: tuple[int, int],
    polygon_by_id: Mapping[str, np.ndarray],
) -> dict:
    points = np.asarray(points_xy, dtype=np.float64)
    result = assign_berries_to_cluster_boxes(points, clusters, image_size=image_size)
    contours = {}
    for key, polygon in polygon_by_id.items():
        contour = np.asarray(polygon, dtype=np.float32).reshape(-1, 2)
        if len(contour) >= 3 and np.isfinite(contour).all(): contours[key] = contour
    changes, supported = 0, 0
    for index, point in enumerate(points):
        assignment = result['assignments'][index]
        assignment['point_index'] = index
        containing = [b for b in clusters if b.bbox_xyxy[0] <= point[0] <= b.bbox_xyxy[2]
                      and b.bbox_xyxy[1] <= point[1] <= b.bbox_xyxy[3]]
        if len(containing) < 2: continue
        inside = [b for b in containing if b.cluster_id in contours and
                  cv2.pointPolygonTest(contours[b.cluster_id], (float(point[0]),float(point[1])), False) >= 0]
        if len(inside) == 1:
            supported += 1
            changes += int(assignment['cluster_id'] != inside[0].cluster_id)
            assignment.update(cluster_id=inside[0].cluster_id, reason='unique_predicted_mask_support')
    counts = Counter(a['cluster_id'] for a in result['assignments'])
    for row in result['clusters']: row['visible_berry_count'] = counts[row['cluster_id']]
    assert sum(r['visible_berry_count'] for r in result['clusters']) == len(points)
    assert [a['point_index'] for a in result['assignments']] == list(range(len(points)))
    result.update(mask_supported_overlap_points=supported, mask_reassigned_points=changes,
                  ownership_verified=False, experimental_rule=True)
    return result
