"""Conservative attribution of fused berry centres to predicted cluster masks.

This does not infer completely invisible berries.  A point belongs to at most
one predicted cluster; ambiguous overlapping-mask assignments are disclosed.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Sequence

import numpy as np


@dataclass(frozen=True)
class ClusterRegion:
    cluster_id: str
    mask: np.ndarray
    confidence: float

    def __post_init__(self) -> None:
        if not self.cluster_id:
            raise ValueError("cluster_id must be non-empty")
        if self.mask.ndim != 2 or self.mask.dtype != np.bool_:
            raise ValueError("cluster mask must be a 2-D boolean array")
        if not np.any(self.mask):
            raise ValueError("cluster mask cannot be empty")
        if not math.isfinite(self.confidence) or not 0 <= self.confidence <= 1:
            raise ValueError("confidence must lie in [0, 1]")


def assign_berries_to_clusters(
    points_xy: np.ndarray,
    clusters: Sequence[ClusterRegion],
    *,
    border_margin: int = 0,
) -> dict[str, object]:
    """Count visible predicted berry centres within predicted cluster masks.

    Border-touching masks are flagged as potentially incomplete, but still
    reported rather than silently discarded.  Points outside all masks remain
    unassigned.  Among overlapping masks, higher detection confidence wins;
    equal-confidence ties prefer the smaller mask then stable cluster order.
    """

    points = np.asarray(points_xy, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 2 or not np.isfinite(points).all():
        raise ValueError("points_xy must be a finite (N, 2) array")
    if isinstance(border_margin, bool) or not isinstance(border_margin, int) or border_margin < 0:
        raise ValueError("border_margin must be a non-negative integer")
    if len({cluster.cluster_id for cluster in clusters}) != len(clusters):
        raise ValueError("cluster IDs must be unique")
    if not clusters:
        return {"clusters": [], "total_assigned": 0, "unassigned": int(len(points)), "ambiguous": 0}
    height, width = clusters[0].mask.shape
    if any(cluster.mask.shape != (height, width) for cluster in clusters):
        raise ValueError("all cluster masks must match the source image dimensions")
    masks = [cluster.mask for cluster in clusters]
    areas = [int(np.count_nonzero(mask)) for mask in masks]
    completed: list[bool] = []
    for mask in masks:
        ys, xs = np.nonzero(mask)
        completed.append(
            bool(
                xs.min() > border_margin
                and ys.min() > border_margin
                and xs.max() < width - 1 - border_margin
                and ys.max() < height - 1 - border_margin
            )
        )
    counts = [0] * len(clusters)
    ambiguous = 0
    unassigned = 0
    for x, y in points:
        xi, yi = int(np.floor(x)), int(np.floor(y))
        if xi < 0 or yi < 0 or xi >= width or yi >= height:
            unassigned += 1
            continue
        candidates = [index for index, mask in enumerate(masks) if mask[yi, xi]]
        if not candidates:
            unassigned += 1
            continue
        if len(candidates) > 1:
            ambiguous += 1
        owner = min(
            candidates,
            key=lambda index: (-clusters[index].confidence, areas[index], index),
        )
        counts[owner] += 1
    rows = [
        {
            "cluster_id": cluster.cluster_id,
            "visible_berry_count": counts[index],
            "confidence": cluster.confidence,
            "possibly_complete": completed[index],
            "touches_image_border": not completed[index],
            "completeness_verified": False,
            "mask_area_pixels": areas[index],
        }
        for index, cluster in enumerate(clusters)
    ]
    return {
        "clusters": rows,
        "total_assigned": int(sum(counts)),
        "unassigned": int(unassigned),
        "ambiguous": int(ambiguous),
    }
