"""Opt-in C5: veto C4 expansion into a competing original global anchor.

Inference inputs are predicted masks/provenance only. Not an identity guarantee:
the underlying predictions can be wrong, and tightening changes point ownership.
"""
from dataclasses import replace
import cv2
import numpy as np
from .identity_native_contours import select_native_contours


def added_competitor_pixels(anchor, proposed, competitor):
    """Count new penetration into a competitor interior, in a shared raster ROI."""
    xy = np.concatenate([anchor.polygon, proposed.polygon, competitor.polygon])
    lo = np.floor(xy.min(0)).astype(int) - 4
    hi = np.ceil(xy.max(0)).astype(int) + 4
    shape = (int(hi[1]-lo[1]+1), int(hi[0]-lo[0]+1))
    masks = []
    for candidate in (anchor, proposed, competitor):
        mask = np.zeros(shape, np.uint8)
        # Round in global coordinates before integer translation: half-even
        # rounding is not translation invariant for half-integers.
        cv2.fillPoly(mask, [np.rint(candidate.polygon).astype(np.int32)-lo], 1)
        masks.append(mask)
    interior = cv2.erode(masks[2], np.ones((7,7), np.uint8),
                         borderType=cv2.BORDER_CONSTANT, borderValue=0)
    empty_interior = not bool(interior.any())
    if empty_interior:
        interior = masks[2]
    count = np.count_nonzero((masks[1] != 0) & (masks[0] == 0) & (interior != 0))
    return int(count), empty_interior


def select_conflict_guarded_contours(candidates, association):
    proposed, native = select_native_contours(candidates, association)
    roots = native['roots']
    selected = list(native['selected'])
    output = list(proposed)
    decisions = []
    for order, (root, chosen) in enumerate(zip(roots, selected)):
        anchor = candidates[root]
        conflicts = []
        if chosen != root:
            for peer in roots:
                other = candidates[peer]
                if peer == root or not other.global_view or other.view_id != anchor.view_id:
                    continue
                # Only a cheap rejection; actual evidence is raster-mask overlap.
                a, b = proposed[order].polygon, other.polygon
                if np.any(np.minimum(a.max(0), b.max(0)) < np.maximum(a.min(0), b.min(0))):
                    continue
                pixels, small_fallback = added_competitor_pixels(anchor, proposed[order], other)
                if pixels:
                    conflicts.append(dict(competing_root=peer, new_interior_pixels=pixels,
                                          small_mask_fallback=small_fallback))
        if conflicts:
            selected[order] = root
            output[order] = replace(anchor, confidence=anchor.confidence)
        decisions.append(dict(root=root, proposed=chosen, selected=selected[order],
            vetoed=bool(conflicts), conflicts=conflicts,
            status='conflict_fallback_uncertain' if conflicts else
                   'native_unverified' if chosen != root else 'anchor_unverified',
            completeness_verified=False))
    return output, dict(policy='C5_original_global_anchor_expansion_veto_v1',
        roots=roots, selected=selected, groups=native['groups'], native_proposal=native,
        decisions=decisions, vetoed=sum(d['vetoed'] for d in decisions),
        changed=sum(a != b for a,b in zip(roots, selected)),
        confidence_inherited=True, completeness_verified=False)
