"""Conservative label-free filtering for unsupported interior bunch boxes."""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np

from .per_cluster_boxes import ClusterBox, assign_berries_to_cluster_boxes


def touches_image_guard_band(
    box: ClusterBox,
    *,
    image_size: tuple[int, int],
    guard_fraction: float = 0.01,
) -> bool:
    """Return whether a predicted box reaches the protected outer image band."""

    if not 0.0 <= guard_fraction < 0.5:
        raise ValueError("guard_fraction must be in [0, 0.5)")
    width, height = map(float, image_size)
    if width <= 0 or height <= 0:
        raise ValueError("image dimensions must be positive")
    x0, y0, x1, y1 = map(float, box.bbox_xyxy)
    return bool(
        x0 <= guard_fraction * width
        or y0 <= guard_fraction * height
        or x1 >= (1.0 - guard_fraction) * width
        or y1 >= (1.0 - guard_fraction) * height
    )


def filter_interior_zero_support_boxes(
    points_xy: np.ndarray,
    boxes: Sequence[ClusterBox],
    *,
    image_size: tuple[int, int],
    guard_fraction: float = 0.01,
) -> tuple[list[ClusterBox], dict]:
    """Remove only zero-support rectangles wholly outside the border guard.

    All berry points are first assigned with the unchanged deterministic
    per-bunch assignment.  Border-touching rectangles are retained even when
    their assigned count is zero because truncated edge bunches are a known
    failure mode.  Berry coordinates and total point count are never changed.
    """

    points = np.asarray(points_xy, dtype=np.float64).reshape(-1, 2)
    candidates = list(boxes)
    if not candidates:
        return [], {
            "input_boxes": 0,
            "output_boxes": 0,
            "zero_support_boxes": 0,
            "protected_border_zero_boxes": 0,
            "removed_interior_zero_boxes": 0,
            "removed_cluster_ids": [],
            "point_count": int(len(points)),
            "point_count_changed": False,
        }
    assignment = assign_berries_to_cluster_boxes(points, candidates, image_size=image_size)
    support = {
        str(row["cluster_id"]): int(row["visible_berry_count"])
        for row in assignment["clusters"]
    }
    kept: list[ClusterBox] = []
    removed: list[str] = []
    protected = 0
    zero = 0
    for box in candidates:
        count = support[str(box.cluster_id)]
        if count > 0:
            kept.append(box)
            continue
        zero += 1
        _conf = float(getattr(box, "confidence", 0.0) or 0.0)
        if touches_image_guard_band(
            box, image_size=image_size, guard_fraction=guard_fraction
        ) or _conf >= 0.5:
            kept.append(box)
            protected += 1
        else:
            removed.append(str(box.cluster_id))
    return kept, {
        "input_boxes": int(len(candidates)),
        "output_boxes": int(len(kept)),
        "zero_support_boxes": int(zero),
        "protected_border_zero_boxes": int(protected),
        "removed_interior_zero_boxes": int(len(removed)),
        "removed_cluster_ids": removed,
        "point_count": int(len(points)),
        "point_count_changed": False,
        "guard_fraction": float(guard_fraction),
    }


__all__ = ["filter_interior_zero_support_boxes", "touches_image_guard_band"]
