"""Global-plus-tiled lightweight grape-bunch box detection."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import cv2
import numpy as np
from PIL import Image

from .cluster_detector import tile_origins
from .per_cluster_boxes import ClusterBox


@dataclass(frozen=True)
class _BoxCandidate:
    bbox: np.ndarray
    confidence: float
    view_id: int
    source: str


def box_iou(a: np.ndarray, b: np.ndarray) -> float:
    left_top = np.maximum(a[:2], b[:2])
    right_bottom = np.minimum(a[2:], b[2:])
    intersection = float(np.prod(np.maximum(0.0, right_bottom - left_top)))
    area_a = float(np.prod(np.maximum(0.0, a[2:] - a[:2])))
    area_b = float(np.prod(np.maximum(0.0, b[2:] - b[:2])))
    return intersection / max(area_a + area_b - intersection, 1e-12)


def deduplicate_boxes(candidates: list[_BoxCandidate], threshold: float) -> list[_BoxCandidate]:
    if not 0 < threshold <= 1:
        raise ValueError("NMS threshold must lie in (0, 1]")
    kept: list[_BoxCandidate] = []
    for candidate in sorted(candidates, key=lambda item: (-item.confidence, item.view_id)):
        if all(box_iou(candidate.bbox, prior.bbox) < threshold for prior in kept):
            kept.append(candidate)
    return kept


def _touches_interior_crop_edge(
    box: np.ndarray,
    crop: tuple[int, int, int, int],
    image_size: tuple[int, int],
    margin: float,
) -> bool:
    x0, y0, x1, y1 = crop
    width, height = image_size
    crop_width, crop_height = x1 - x0, y1 - y0
    return bool(
        (x0 > 0 and box[0] <= margin)
        or (y0 > 0 and box[1] <= margin)
        or (x1 < width and box[2] >= crop_width - margin)
        or (y1 < height and box[3] >= crop_height - margin)
    )


def detect_cluster_boxes(
    image: Image.Image,
    detector: Any,
    *,
    image_size: int = 1536,
    confidence: float = 0.05,
    iou: float = 0.6,
    cross_view_iou: float = 0.5,
    tiled: bool = False,
    tile_size: int = 1536,
    stride: int = 1152,
    device: str | int = 0,
    max_det: int = 100,
    augment: bool = False,
) -> list[ClusterBox]:
    """Predict rectangular bunches, optionally adding native-resolution tiles.

    Tile detections truncated by an interior crop boundary are discarded.
    Across-view duplicates use IoU NMS at 0.5 by default; the Stage-6 label
    audit found no distinct development pair at IoU >= 0.5.
    """

    if not 0 <= confidence <= 1 or not 0 < iou <= 1:
        raise ValueError("invalid confidence or IoU")
    width, height = image.size
    views = [(0, 0, width, height, "global")]
    if tiled:
        views.extend(
            (x, y, min(x + tile_size, width), min(y + tile_size, height), "native_tile")
            for y in tile_origins(height, tile_size, stride)
            for x in tile_origins(width, tile_size, stride)
            if (x, y, min(x + tile_size, width), min(y + tile_size, height)) != (0, 0, width, height)
        )
    candidates: list[_BoxCandidate] = []
    for view_id, (x0, y0, x1, y1, source) in enumerate(views):
        crop = image.crop((x0, y0, x1, y1)).convert("RGB")
        bgr = cv2.cvtColor(np.asarray(crop), cv2.COLOR_RGB2BGR)
        prediction = detector.predict(
            source=bgr,
            imgsz=image_size,
            conf=confidence,
            iou=iou,
            max_det=max_det,
            device=device,
            augment=augment,
            verbose=False,
        )[0]
        if prediction.boxes is None:
            continue
        boxes = prediction.boxes.xyxy.detach().cpu().numpy()
        scores = prediction.boxes.conf.detach().cpu().numpy()
        crop_tuple = (x0, y0, x1, y1)
        for local, score in zip(boxes, scores):
            local = np.asarray(local, dtype=np.float64)
            if source != "global" and _touches_interior_crop_edge(
                local, crop_tuple, (width, height), margin=3.0
            ):
                continue
            global_box = local + np.asarray([x0, y0, x0, y0], dtype=np.float64)
            global_box[[0, 2]] = np.clip(global_box[[0, 2]], 0, width - 1)
            global_box[[1, 3]] = np.clip(global_box[[1, 3]], 0, height - 1)
            if global_box[2] <= global_box[0] or global_box[3] <= global_box[1]:
                continue
            candidates.append(_BoxCandidate(global_box, float(score), view_id, source))
    kept = deduplicate_boxes(candidates, cross_view_iou)
    return [
        ClusterBox(
            f"cluster_{index:03d}",
            tuple(float(value) for value in candidate.bbox),
            candidate.confidence,
            candidate.source,
        )
        for index, candidate in enumerate(kept, start=1)
    ]
