"""Conservative inference gates for residual berry-centre corrections.

The functions in this module only change coordinates.  They never add, remove,
or reorder berry hypotheses, which keeps whole-image and per-bunch counts
unchanged while centre localization is refined.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class PrimaryCenterGatePolicy:
    """Policy for the first, confidence-gated residual correction stage."""

    alpha: float = 1.0
    confidence_threshold: float = 0.65
    minimum_spacing: float = 24.0
    spacing_fraction: float = 0.20
    absolute_limit: float = 8.0


@dataclass(frozen=True)
class SupplementalCenterGatePolicy:
    """Policy for a small complementary move after the primary stage."""

    alpha: float = 0.50
    margin: float = 0.0
    absolute_score: float = 0.25
    minimum_spacing: float = 12.0
    spacing_fraction: float = 0.20
    absolute_limit: float = 2.0
    primary_lock_tolerance: float = 0.05


def _validate_points(points: np.ndarray, name: str) -> np.ndarray:
    result = np.asarray(points, dtype=np.float32)
    if result.ndim != 2 or result.shape[1:] != (2,):
        raise ValueError(f"{name} must have shape (N, 2)")
    if not np.isfinite(result).all():
        raise ValueError(f"{name} must be finite")
    return result


def _validate_scale(coordinate_scale: float) -> float:
    scale = float(coordinate_scale)
    if not np.isfinite(scale) or scale <= 0:
        raise ValueError("coordinate_scale must be finite and positive")
    return scale


def _clip_to_image(points: np.ndarray, image_size: tuple[int, int]) -> np.ndarray:
    width, height = (int(image_size[0]), int(image_size[1]))
    if width <= 0 or height <= 0:
        raise ValueError("image_size must contain positive width and height")
    result = points.copy()
    result[:, 0] = np.clip(result[:, 0], 0.0, width - 1e-3)
    result[:, 1] = np.clip(result[:, 1], 0.0, height - 1e-3)
    return result.astype(np.float32, copy=False)


def normalized_nearest_spacing(points_xy: np.ndarray, coordinate_scale: float) -> np.ndarray:
    """Return nearest-neighbour spacing in the normalized coordinate system."""

    points = _validate_points(points_xy, "points_xy")
    scale = _validate_scale(coordinate_scale)
    if len(points) <= 1:
        return np.full(len(points), np.inf, dtype=np.float32)
    normalized = points * scale
    difference = normalized[:, None, :] - normalized[None, :, :]
    distances = np.sqrt(np.sum(difference * difference, axis=2))
    np.fill_diagonal(distances, np.inf)
    return distances.min(axis=1).astype(np.float32)


def apply_primary_center_gate(
    original_xy: np.ndarray,
    offsets_normalized: np.ndarray,
    confidence: np.ndarray,
    *,
    coordinate_scale: float,
    image_size: tuple[int, int],
    policy: PrimaryCenterGatePolicy = PrimaryCenterGatePolicy(),
) -> tuple[np.ndarray, np.ndarray]:
    """Apply the frozen primary gate while preserving every point identity."""

    original = _validate_points(original_xy, "original_xy")
    offsets = _validate_points(offsets_normalized, "offsets_normalized")
    if offsets.shape != original.shape:
        raise ValueError("offsets_normalized must preserve point membership and shape")
    confidence_array = np.asarray(confidence, dtype=np.float32)
    if confidence_array.shape != (len(original),) or not np.isfinite(confidence_array).all():
        raise ValueError("confidence must be a finite vector with shape (N,)")
    scale = _validate_scale(coordinate_scale)
    if policy.alpha < 0 or policy.minimum_spacing < 0:
        raise ValueError("primary policy contains a negative threshold")
    if policy.spacing_fraction < 0 or policy.absolute_limit < 0:
        raise ValueError("primary movement limits must be non-negative")

    spacing = normalized_nearest_spacing(original, scale)
    shift = offsets * float(policy.alpha)
    magnitude = np.linalg.norm(shift, axis=1)
    limit = np.minimum(float(policy.absolute_limit), float(policy.spacing_fraction) * spacing)
    shift *= np.minimum(1.0, limit / np.maximum(magnitude, 1e-6))[:, None]
    moved = (
        (confidence_array >= float(policy.confidence_threshold))
        & (spacing >= float(policy.minimum_spacing))
        & (np.linalg.norm(shift, axis=1) > 0)
    )
    result = original.copy()
    result[moved] += shift[moved] / scale
    return _clip_to_image(result, image_size), moved


def apply_supplemental_candidate_gate(
    original_xy: np.ndarray,
    primary_xy: np.ndarray,
    candidate_offsets_normalized: np.ndarray,
    candidate_scores: np.ndarray,
    *,
    coordinate_scale: float,
    image_size: tuple[int, int],
    policy: SupplementalCenterGatePolicy = SupplementalCenterGatePolicy(),
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Move only primary-unmodified points using the best scored candidate.

    Candidate index zero is the identity candidate.  The returned choice vector
    records the scorer's argmax, while ``moved`` records which choices passed
    all geometry and confidence safeguards.
    """

    original = _validate_points(original_xy, "original_xy")
    primary = _validate_points(primary_xy, "primary_xy")
    if primary.shape != original.shape:
        raise ValueError("primary_xy must preserve point membership and shape")
    offsets = np.asarray(candidate_offsets_normalized, dtype=np.float32)
    scores = np.asarray(candidate_scores, dtype=np.float32)
    if offsets.ndim != 3 or offsets.shape[0] != len(original) or offsets.shape[2] != 2:
        raise ValueError("candidate_offsets_normalized must have shape (N, K, 2)")
    if scores.shape != offsets.shape[:2] or scores.shape[1] < 1:
        raise ValueError("candidate_scores must have shape (N, K)")
    if not np.isfinite(offsets).all() or not np.isfinite(scores).all():
        raise ValueError("candidate offsets and scores must be finite")
    scale = _validate_scale(coordinate_scale)

    if len(original) == 0:
        return primary.copy(), np.zeros(0, dtype=bool), np.zeros(0, dtype=np.int64)
    row = np.arange(len(original))
    choice = scores.argmax(axis=1).astype(np.int64)
    best = scores[row, choice]
    advantage = best - scores[:, 0]
    spacing = normalized_nearest_spacing(original, scale)
    primary_shift = np.linalg.norm((primary - original) * scale, axis=1)
    active = (
        (primary_shift < float(policy.primary_lock_tolerance))
        & (choice > 0)
        & (advantage >= float(policy.margin))
        & (best >= float(policy.absolute_score))
        & (spacing >= float(policy.minimum_spacing))
    )
    shift = offsets[row, choice] * float(policy.alpha)
    magnitude = np.linalg.norm(shift, axis=1)
    limit = np.minimum(float(policy.absolute_limit), float(policy.spacing_fraction) * spacing)
    shift *= np.minimum(1.0, limit / np.maximum(magnitude, 1e-6))[:, None]
    moved = active & (np.linalg.norm(shift, axis=1) > 0)
    result = primary.copy()
    result[moved] = original[moved] + shift[moved] / scale
    return _clip_to_image(result, image_size), moved, choice


def apply_conservative_center_gate(
    original_xy: np.ndarray,
    proposed_xy: np.ndarray,
    *,
    coordinate_scale: float,
    minimum_spacing: float = 12.0,
    minimum_movement: float = 0.0,
    maximum_movement: float = 16.0,
) -> tuple[np.ndarray, np.ndarray]:
    """Choose proposed coordinates only where the correction is conservative.

    Distances are measured after ``coordinate_scale`` normalization.  The gate
    protects crowded predictions from being pulled across neighbouring berry
    identities and rejects implausibly large residual jumps.  Point count,
    order, identity, and any downstream cluster membership are unchanged.

    Returns the gated coordinates and a boolean mask identifying moved points.
    """

    original = _validate_points(original_xy, "original_xy")
    proposed = _validate_points(proposed_xy, "proposed_xy")
    if proposed.shape != original.shape:
        raise ValueError("proposed_xy must preserve point membership and shape")
    scale = _validate_scale(coordinate_scale)
    if minimum_spacing < 0 or minimum_movement < 0 or maximum_movement < minimum_movement:
        raise ValueError("invalid conservative gate thresholds")

    count = len(original)
    if count <= 1:
        spacing = np.full(count, np.inf, dtype=np.float32)
    else:
        spacing = normalized_nearest_spacing(original, scale)
    movement = np.linalg.norm(proposed - original, axis=1) * scale
    moved = (
        (spacing >= float(minimum_spacing))
        & (movement >= float(minimum_movement))
        & (movement <= float(maximum_movement))
    )
    result = original.copy()
    result[moved] = proposed[moved]
    return result, moved


__all__ = [
    "PrimaryCenterGatePolicy",
    "SupplementalCenterGatePolicy",
    "normalized_nearest_spacing",
    "apply_primary_center_gate",
    "apply_supplemental_candidate_gate",
    "apply_conservative_center_gate",
]
