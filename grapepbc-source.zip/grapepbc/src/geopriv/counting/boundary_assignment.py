"""Zero-trainable-parameter boundary-depth point ownership, opt-in only.

Based on UniGC BDMPA, doi:10.3390/app16157500, Section 3.4.
Scale=sqrt(mask area); internal maximum depth; external minimum distance,
limited by rho. This implementation explicitly supports the legacy floor
sampling rule as a controlled adaptation; paper-style sampling uses np.rint.
Ties use stable input order. Outside-canvas padding is background. These
discretization choices are disclosed, not claimed as authors' released code.
"""
from __future__ import annotations

from copy import deepcopy
import math
import cv2
import numpy as np

from .candidate_ceiling import RasterROI
from .roi_cluster_metrics import owners


class BoundaryAssigner:
    def __init__(self, regions, image_size, max_rho=.03):
        self.regions = list(regions)
        if len(image_size) != 2 or any(int(v) != v or v <= 0 for v in image_size):
            raise ValueError('Invalid image size')
        self.width, self.height = map(int, image_size)
        if not math.isfinite(max_rho) or max_rho < 0:
            raise ValueError('Invalid max_rho')
        self.max_rho = max_rho
        self.fields = []
        for r in self.regions:
            if (r.mask.ndim != 2 or r.mask.dtype != np.bool_ or r.area <= 0
                    or int(r.mask.sum()) != r.area or min(r.x, r.y) < 0
                    or r.x+r.mask.shape[1] > self.width
                    or r.y+r.mask.shape[0] > self.height):
                raise ValueError('Invalid raster')
            scale = math.sqrt(r.area)
            pad = math.ceil(max_rho*scale+2)
            mask = np.pad(r.mask.astype(np.uint8), pad)
            inside = cv2.distanceTransform(mask, cv2.DIST_L2, cv2.DIST_MASK_PRECISE)/scale
            outside = cv2.distanceTransform(1-mask, cv2.DIST_L2, cv2.DIST_MASK_PRECISE)/scale
            self.fields.append((r.x-pad, r.y-pad, mask, inside, outside))

    def assign(self, points, *, rho=.03, sampling='floor', confidence=None):
        points = np.asarray(points, dtype=float)
        if points.ndim != 2 or points.shape[1] != 2 or not np.isfinite(points).all():
            raise ValueError('Expected finite Nx2 points')
        if sampling not in ('floor', 'round'):
            raise ValueError('Invalid sampling')
        if not math.isfinite(rho) or not 0 <= rho <= self.max_rho:
            raise ValueError('rho exceeds prepared fields')
        xy = np.floor(points) if sampling == 'floor' else np.rint(points)
        valid = ((xy[:, 0] >= 0) & (xy[:, 0] < self.width)
                 & (xy[:, 1] >= 0) & (xy[:, 1] < self.height))
        n, k = len(points), len(self.regions)
        membership = np.zeros((k, n), bool)
        depths = np.full((k, n), -np.inf)
        distances = np.full((k, n), np.inf)
        for i, (x, y, mask, internal, external) in enumerate(self.fields):
            local = xy-[x, y]
            ok = (valid & (local[:, 0] >= 0) & (local[:, 0] < mask.shape[1])
                  & (local[:, 1] >= 0) & (local[:, 1] < mask.shape[0]))
            ids = np.flatnonzero(ok)
            q = local[ok].astype(np.int64)
            ins = mask[q[:, 1], q[:, 0]].astype(bool)
            membership[i, ids] = ins
            depths[i, ids[ins]] = internal[q[ins, 1], q[ins, 0]]
            distances[i, ids[~ins]] = external[q[~ins, 1], q[~ins, 0]]
        result = np.full(n, -1, dtype=int)
        covered = membership.any(0)
        if k:
            if confidence is None:
                result[covered] = depths[:, covered].argmax(0)
                external = (~covered) & valid & (distances.min(0) <= rho)
                result[external] = distances[:, external].argmin(0)
            else:
                if len(confidence) != k or not np.isfinite(confidence).all():
                    raise ValueError('Invalid confidence scores')
                order = sorted(range(k), key=lambda i: (-confidence[i], self.regions[i].area, i))
                for i in reversed(order):
                    result[membership[i]] = i
        return result, membership


def evaluate_fixed_assignment(reference, truth, gt_points, lr_points, assign):
    """Keep masks, GT intervals, matching and recall exactly fixed.

    Only predicted point owners/counts and ownership-derived diagnostics change.
    Ground-truth intervals ALWAYS use legacy floor sampling, for all variants.
    """
    result = deepcopy(reference)
    gt_points = np.asarray(gt_points).reshape(-1, 2)
    lr_points = np.asarray(lr_points).reshape(-1, 2)
    go, gm = owners(gt_points, truth, [1.]*len(truth))
    certain = gm.sum(0) == 1
    lower, upper = (gm & certain).sum(1), gm.sum(1)
    po, pm = assign(gt_points)
    mapping = {p: g for p, g, _ in reference['pairs']}
    result['correctly_owned_gt_points'] = sum(
        int(certain[n] and mapping.get(int(po[n]), -1) == int(go[n])) for n in range(len(go)))
    mixed = []
    for i in range(reference['predicted']):
        ids = [j for j in range(len(truth)) if np.count_nonzero(certain & (po == i) & (go == j)) >= 3]
        if len(ids) >= 2:
            mixed.append(dict(predicted=i, gt_ids=ids))
    result['mixed_gt_predictions'] = mixed
    result['mixed_gt_prediction_proxy'] = len(mixed)
    for key, points in [('oracle_points', gt_points), ('lr_points', lr_points)]:
        owned, membership = (po, pm) if key == 'oracle_points' else assign(points)
        counts = np.bincount(owned[owned >= 0], minlength=reference['predicted']).astype(int).tolist()
        matched = sum(int(max(lower[g]-counts[p], 0, counts[p]-upper[g])) for p, g, _ in reference['pairs'])
        missed = int(sum(lower[g] for g in reference['fn_ids']))
        spurious = sum(counts[p] for p in reference['fp_ids'])
        assigned = sum(counts)
        unassigned = int(np.count_nonzero(owned < 0))
        if assigned+unassigned != len(points):
            raise ValueError('Point conservation violated')
        result[key] = dict(penalty_sum=matched+missed+spurious,
                           matched_penalty_sum=matched, missed_gt_penalty=missed,
                           spurious_prediction_penalty=spurious, assigned=assigned,
                           unassigned=unassigned, ambiguous=int(np.count_nonzero(membership.sum(0) > 1)),
                           cluster_counts=counts)
    return result
