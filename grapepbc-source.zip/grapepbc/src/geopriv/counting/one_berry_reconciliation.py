"""Count-preserving reconciliation for competing berry-centre hypotheses.

The CRU counter may occasionally place two distinct hypotheses on one visible
berry.  This module does not delete points or use annotations at inference.
Instead, it identifies a conservative conflict supported by the frozen Rich-HR
candidate map and moves only the weaker hypothesis to an unoccupied candidate
inside the same predicted bunch.  Point cardinality, point order and bunch
ownership are therefore preserved.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np


def _nearest_indices_and_distances(
    query: np.ndarray,
    reference: np.ndarray,
    *,
    chunk_size: int = 512,
) -> tuple[np.ndarray, np.ndarray]:
    """Return NumPy-only nearest-neighbour results without a SciPy runtime."""
    if not len(reference):
        return (
            np.full(len(query), -1, dtype=np.int64),
            np.full(len(query), np.inf, dtype=np.float64),
        )
    nearest = np.empty(len(query), dtype=np.int64)
    distance = np.empty(len(query), dtype=np.float64)
    for start in range(0, len(query), chunk_size):
        stop = min(start + chunk_size, len(query))
        squared = np.sum(
            (query[start:stop, None, :] - reference[None, :, :]) ** 2,
            axis=2,
        )
        local = np.argmin(squared, axis=1)
        nearest[start:stop] = local
        distance[start:stop] = np.sqrt(squared[np.arange(stop - start), local])
    return nearest, distance


def _query_pairs_within_radius(points: np.ndarray, radius: float) -> list[tuple[int, int]]:
    """Find unique point pairs with a deterministic spatial grid."""
    if len(points) < 2 or radius <= 0:
        return []
    cell_size = float(radius)
    cells = np.floor(points / cell_size).astype(np.int64)
    grid: dict[tuple[int, int], list[int]] = {}
    pairs: list[tuple[int, int]] = []
    for index, cell_array in enumerate(cells):
        cell = (int(cell_array[0]), int(cell_array[1]))
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for previous in grid.get((cell[0] + dx, cell[1] + dy), ()):
                    if float(np.linalg.norm(points[index] - points[previous])) < radius:
                        pairs.append((previous, index))
        grid.setdefault(cell, []).append(index)
    return pairs


@dataclass(frozen=True)
class OneBerryReconciliationPolicy:
    collision_radius_1024: float = 4.0
    candidate_nms_radius_1024: float = 4.0
    candidate_support_radius_1024: float = 5.0
    replacement_spacing_1024: float = 6.0
    replacement_score_threshold: float = 0.10
    replacement_margin: float = 0.0
    maximum_moves: int = 2
    conflict_mode: str = "shared_or_unsupported"

    def __post_init__(self) -> None:
        if min(
            self.collision_radius_1024,
            self.candidate_nms_radius_1024,
            self.candidate_support_radius_1024,
            self.replacement_spacing_1024,
        ) < 0:
            raise ValueError("distance thresholds must be non-negative")
        if not 0 <= self.replacement_score_threshold <= 1:
            raise ValueError("replacement score threshold must lie in [0, 1]")
        if self.maximum_moves < 0:
            raise ValueError("maximum_moves must be non-negative")
        if self.conflict_mode not in {"shared_candidate", "shared_or_unsupported"}:
            raise ValueError("unknown conflict mode")


@dataclass(frozen=True)
class SemanticReconciliationPolicy:
    minimum_new_score: float = -1.0
    minimum_advantage: float = -2.0


def filter_reconciliation_by_semantic_scores(
    original_points_xy: np.ndarray,
    original_reliability: np.ndarray,
    proposal: dict[str, object],
    old_semantic_scores: np.ndarray,
    new_semantic_scores: np.ndarray,
    *,
    policy: SemanticReconciliationPolicy = SemanticReconciliationPolicy(),
) -> dict[str, object]:
    """Retain only semantically credible moves from a geometric proposal.

    The caller supplies scores from the frozen RGB centre-quality model.  This
    pure filtering step preserves the original point array order and count.
    """
    original = np.asarray(original_points_xy, dtype=np.float64).reshape(-1, 2)
    confidence = np.asarray(original_reliability, dtype=np.float64).reshape(-1)
    proposed = np.asarray(proposal["points_xy"], dtype=np.float64).reshape(-1, 2)
    proposed_confidence = np.asarray(proposal["reliability"], dtype=np.float64).reshape(-1)
    moves = list(proposal.get("move_rows", []))
    old_score = np.asarray(old_semantic_scores, dtype=np.float64).reshape(-1)
    new_score = np.asarray(new_semantic_scores, dtype=np.float64).reshape(-1)
    if len(original) != len(proposed) or len(confidence) != len(original) or len(proposed_confidence) != len(original):
        raise ValueError("proposal must preserve point count and metadata length")
    if len(old_score) != len(moves) or len(new_score) != len(moves):
        raise ValueError("one old/new semantic score is required per proposed move")
    if not np.isfinite(old_score).all() or not np.isfinite(new_score).all():
        raise ValueError("semantic scores must be finite")
    result = original.copy(); result_confidence = confidence.copy()
    accepted: list[dict[str, object]] = []
    for index, move in enumerate(moves):
        advantage = float(new_score[index] - old_score[index])
        if float(new_score[index]) < policy.minimum_new_score or advantage < policy.minimum_advantage:
            continue
        point_index = int(move["point_index"])
        if not 0 <= point_index < len(result):
            raise ValueError("move point index is out of range")
        result[point_index] = proposed[point_index]
        result_confidence[point_index] = proposed_confidence[point_index]
        accepted.append({
            **move,
            "old_semantic_score": float(old_score[index]),
            "new_semantic_score": float(new_score[index]),
            "semantic_advantage": advantage,
        })
    return {
        "points_xy": result,
        "reliability": result_confidence,
        "applied": bool(accepted),
        "moves": len(accepted),
        "proposed_moves": len(moves),
        "reason": "semantic_gate_applied" if accepted else "semantic_gate_rejected_all",
        "move_rows": accepted,
    }


def _nms_candidates(
    points: np.ndarray,
    scores: np.ndarray,
    owners: np.ndarray,
    radius_native: float,
) -> np.ndarray:
    """Return score-ranked, owner-aware spatial NMS indices."""
    order = np.argsort(-scores, kind="stable")
    kept: list[int] = []
    cell_size = max(float(radius_native), 1e-9)
    grids: dict[int, dict[tuple[int, int], list[int]]] = {}
    for raw_index in order:
        index = int(raw_index)
        owner = int(owners[index])
        if owner < 0:
            continue
        grid = grids.setdefault(owner, {})
        cell = tuple(np.floor(points[index] / cell_size).astype(np.int64).tolist())
        neighbours: list[int] = []
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                neighbours.extend(grid.get((cell[0] + dx, cell[1] + dy), ()))
        if neighbours and float(np.min(np.linalg.norm(points[neighbours] - points[index], axis=1))) < radius_native:
            continue
        kept.append(index)
        grid.setdefault(cell, []).append(index)
    return np.asarray(kept, dtype=np.int64)


def reconcile_one_berry_one_point(
    points_xy: np.ndarray,
    reliability: np.ndarray,
    candidate_xy: np.ndarray,
    candidate_scores: np.ndarray,
    point_owner: np.ndarray,
    candidate_owner: np.ndarray,
    *,
    image_size: tuple[int, int],
    owner_resolver: Callable[[np.ndarray], np.ndarray],
    policy: OneBerryReconciliationPolicy = OneBerryReconciliationPolicy(),
) -> dict[str, object]:
    """Relocate conservative duplicate hypotheses without changing count.

    ``owner_resolver`` must implement the same deterministic point-to-bunch
    ownership rule used by the final pipeline.  A proposed relocation is
    accepted only when that rule preserves the source point's owner.
    """
    points = np.asarray(points_xy, dtype=np.float64).reshape(-1, 2)
    confidence = np.asarray(reliability, dtype=np.float64).reshape(-1)
    candidates = np.asarray(candidate_xy, dtype=np.float64).reshape(-1, 2)
    scores = np.asarray(candidate_scores, dtype=np.float64).reshape(-1)
    owners = np.asarray(point_owner, dtype=np.int64).reshape(-1)
    candidate_owners = np.asarray(candidate_owner, dtype=np.int64).reshape(-1)
    width, height = image_size
    if len(confidence) != len(points) or len(owners) != len(points):
        raise ValueError("point metadata length mismatch")
    if len(scores) != len(candidates) or len(candidate_owners) != len(candidates):
        raise ValueError("candidate metadata length mismatch")
    if not np.isfinite(points).all() or not np.isfinite(confidence).all():
        raise ValueError("points and reliability must be finite")
    if not np.isfinite(candidates).all() or not np.isfinite(scores).all():
        raise ValueError("candidates and scores must be finite")
    if np.any(points < 0) or np.any(points >= [width, height]):
        raise ValueError("points must lie inside the image")
    if np.any(candidates < 0) or np.any(candidates >= [width, height]):
        raise ValueError("candidates must lie inside the image")
    if len(points) < 2 or not len(candidates) or policy.maximum_moves == 0:
        return {
            "points_xy": points.copy(), "reliability": confidence.copy(),
            "applied": False, "moves": 0, "conflicts": 0,
            "reason": "insufficient_points_or_candidates",
        }

    scale = 1024.0 / max(width, height)
    nms_index = _nms_candidates(
        candidates, scores, candidate_owners,
        policy.candidate_nms_radius_1024 / scale,
    )
    if not len(nms_index):
        return {
            "points_xy": points.copy(), "reliability": confidence.copy(),
            "applied": False, "moves": 0, "conflicts": 0,
            "reason": "no_owned_candidates_after_nms",
        }
    nms_points = candidates[nms_index]
    nms_scores = scores[nms_index]
    nms_owners = candidate_owners[nms_index]

    # Nearest owner-compatible candidate evidence for every current point.
    nearest = np.full(len(points), -1, dtype=np.int64)
    nearest_distance = np.full(len(points), np.inf, dtype=np.float64)
    nearest_score = np.zeros(len(points), dtype=np.float64)
    for owner in np.unique(owners):
        point_index = np.flatnonzero(owners == owner)
        candidate_index = np.flatnonzero(nms_owners == owner)
        if not len(point_index) or not len(candidate_index):
            continue
        local, distance = _nearest_indices_and_distances(
            points[point_index], nms_points[candidate_index]
        )
        nearest[point_index] = candidate_index[local]
        nearest_distance[point_index] = distance * scale
        nearest_score[point_index] = nms_scores[nearest[point_index]]

    # Build conservative conflicts within each final bunch owner.
    conflicts: list[tuple[float, int, int]] = []
    for owner in np.unique(owners):
        members = np.flatnonzero(owners == owner)
        if len(members) < 2:
            continue
        pairs = _query_pairs_within_radius(
            points[members] * scale, policy.collision_radius_1024
        )
        for local_i, local_j in pairs:
            first, second = int(members[local_i]), int(members[local_j])
            same_candidate = nearest[first] >= 0 and nearest[first] == nearest[second]
            unsupported = (
                nearest_distance[first] > policy.candidate_support_radius_1024
                or nearest_distance[second] > policy.candidate_support_radius_1024
            )
            conflict = same_candidate or (
                policy.conflict_mode == "shared_or_unsupported" and unsupported
            )
            if conflict:
                distance = float(np.linalg.norm(points[first] - points[second]) * scale)
                conflicts.append((distance, first, second))
    conflicts.sort(key=lambda value: (value[0], value[1], value[2]))

    result = points.copy()
    result_confidence = confidence.copy()
    moved: set[int] = set()
    moved_rows: list[dict[str, object]] = []
    used_candidate: set[int] = set()
    replacement_spacing_native = policy.replacement_spacing_1024 / scale

    for distance, first, second in conflicts:
        if len(moved_rows) >= policy.maximum_moves:
            break
        if first in moved or second in moved:
            continue
        # Rank-normalized confidence is not necessary inside one pair.  The
        # combined evidence makes reliability primary and HR support secondary.
        support_first = 0.65 * confidence[first] + 0.35 * nearest_score[first]
        support_second = 0.65 * confidence[second] + 0.35 * nearest_score[second]
        weak, strong = (first, second) if support_first <= support_second else (second, first)
        owner = int(owners[weak])
        available = np.flatnonzero(
            (nms_owners == owner)
            & (nms_scores >= policy.replacement_score_threshold)
            & (nms_scores >= nearest_score[weak] + policy.replacement_margin)
        )
        available = available[np.argsort(-nms_scores[available], kind="stable")]
        replacement = -1
        for local_candidate in available:
            local_candidate = int(local_candidate)
            if local_candidate in used_candidate:
                continue
            proposal = nms_points[local_candidate]
            others = np.delete(result, weak, axis=0)
            if len(others) and float(np.min(np.linalg.norm(others - proposal, axis=1))) < replacement_spacing_native:
                continue
            resolved = np.asarray(owner_resolver(proposal[None]), dtype=np.int64).reshape(-1)
            if len(resolved) != 1 or int(resolved[0]) != owner:
                continue
            replacement = local_candidate
            break
        if replacement < 0:
            continue
        old = result[weak].copy()
        result[weak] = nms_points[replacement]
        result_confidence[weak] = float(nms_scores[replacement])
        moved.add(weak)
        used_candidate.add(replacement)
        moved_rows.append({
            "point_index": int(weak), "kept_index": int(strong),
            "owner": owner, "pair_distance_1024": distance,
            "old_xy": old.tolist(), "new_xy": result[weak].tolist(),
            "old_support": float(nearest_score[weak]),
            "new_score": float(nms_scores[replacement]),
        })

    if len(result) != len(points):
        raise RuntimeError("point count conservation failed")
    if np.any(result < 0) or np.any(result >= [width, height]):
        raise RuntimeError("reconciled point left image bounds")
    final_owner = np.asarray(owner_resolver(result), dtype=np.int64).reshape(-1)
    if not np.array_equal(final_owner, owners):
        raise RuntimeError("point-to-bunch ownership changed")
    return {
        "points_xy": result,
        "reliability": result_confidence,
        "applied": bool(moved_rows),
        "moves": len(moved_rows),
        "conflicts": len(conflicts),
        "reason": "reconciled" if moved_rows else "no_safe_replacement",
        "move_rows": moved_rows,
        "candidate_count_before_nms": len(candidates),
        "candidate_count_after_nms": len(nms_points),
    }


def reconcile_one_berry_one_point_semantic(
    points_xy: np.ndarray,
    reliability: np.ndarray,
    candidate_xy: np.ndarray,
    candidate_scores: np.ndarray,
    point_owner: np.ndarray,
    candidate_owner: np.ndarray,
    *,
    image_size: tuple[int, int],
    owner_resolver: Callable[[np.ndarray], np.ndarray],
    semantic_scorer: Callable[[np.ndarray], np.ndarray],
    geometry_policy: OneBerryReconciliationPolicy = OneBerryReconciliationPolicy(),
    semantic_policy: SemanticReconciliationPolicy = SemanticReconciliationPolicy(),
) -> dict[str, object]:
    """Run geometric proposal and RGB-semantic filtering in one runtime call.

    ``semantic_scorer`` receives an ``(2 * proposed_moves, 2)`` array ordered
    as old/new coordinates for every proposed move. A deployment caller can
    capture the current RGB image and scale in this callable without coupling
    count conservation to a specific neural framework.
    """
    proposal = reconcile_one_berry_one_point(
        points_xy,
        reliability,
        candidate_xy,
        candidate_scores,
        point_owner,
        candidate_owner,
        image_size=image_size,
        owner_resolver=owner_resolver,
        policy=geometry_policy,
    )
    moves = list(proposal.get("move_rows", []))
    if not moves:
        return {
            **proposal,
            "proposed_moves": 0,
            "semantic_gate_applied": False,
            "semantic_reason": "no_geometric_proposal",
        }
    anchors = np.asarray(
        [coordinate for move in moves for coordinate in (move["old_xy"], move["new_xy"])],
        dtype=np.float64,
    )
    scores = np.asarray(semantic_scorer(anchors), dtype=np.float64).reshape(-1)
    if len(scores) != len(anchors) or not np.isfinite(scores).all():
        raise ValueError("semantic scorer must return one finite score per anchor")
    gated = filter_reconciliation_by_semantic_scores(
        points_xy,
        reliability,
        proposal,
        scores[0::2],
        scores[1::2],
        policy=semantic_policy,
    )
    return {
        **gated,
        "conflicts": int(proposal.get("conflicts", 0)),
        "candidate_count_before_nms": int(proposal.get("candidate_count_before_nms", 0)),
        "candidate_count_after_nms": int(proposal.get("candidate_count_after_nms", 0)),
        "semantic_gate_applied": True,
        "semantic_reason": gated["reason"],
    }


__all__ = [
    "OneBerryReconciliationPolicy", "reconcile_one_berry_one_point",
    "reconcile_one_berry_one_point_semantic",
    "SemanticReconciliationPolicy", "filter_reconciliation_by_semantic_scores",
]
