"""Experimental global-anchor ownership, fixed geometry, no learned parameters.

A tile fragment may supply local detail without creating another bunch ID.
Only truncated candidates contained in exactly one global mask are absorbed.
No global masks are merged, expanded, or used to delete remote tile candidates.
This is opt-in development code, not an accepted production policy.
"""
from .candidate_ceiling import raster_roi, raster_intersection
from .cluster_identity import associate_c1


def anchor_ownership(candidates, image_size):
    anchors = [i for i, c in enumerate(candidates) if c.global_view]
    regions = {i: raster_roi([c.polygon], image_size) for i, c in enumerate(candidates)}
    if any(r.area == 0 for r in regions.values()):
        raise ValueError('Empty candidate mask')
    removed = []
    decisions = []
    for i, c in enumerate(candidates):
        if c.global_view or not c.truncated_edges:
            continue
        matches = [a for a in anchors if regions[i].area < regions[a].area
                   and raster_intersection(regions[i], regions[a]) / regions[i].area >= .9]
        if len(matches) == 1:
            removed.append(i)
            decisions.append(dict(candidate=i, anchor=matches[0], reason='unique_global_owner_of_truncated_detail'))
    remaining = [i for i in range(len(candidates)) if i not in set(removed)]
    grouped = associate_c1([candidates[i] for i in remaining])
    return dict(representatives=[remaining[i] for i in grouped['representatives']],
                removed=removed, decisions=decisions,
                policy='G1_global_identity_local_detail_fixed_v1', gt_used=False)
