"""Small dependency-free metrics used during engineering smoke tests."""

from __future__ import annotations

import math
from typing import Sequence

import numpy as np


def aggregate_count_metrics(predicted: Sequence[int], target: Sequence[int]) -> dict[str, float]:
    prediction = np.asarray(predicted, dtype=np.float64)
    truth = np.asarray(target, dtype=np.float64)
    if prediction.shape != truth.shape or prediction.ndim != 1 or len(truth) == 0:
        raise ValueError("predicted and target must be equally sized, non-empty 1D sequences")
    errors = prediction - truth
    absolute_errors = np.abs(errors)
    return {
        "mae": float(np.mean(absolute_errors)),
        "rmse": float(math.sqrt(np.mean(errors**2))),
        # These two normalizations are intentionally named by formula.  WAPE
        # weights images by their true counts, while mean_NAE gives every image
        # equal weight.  Calling either one simply "NAE" is ambiguous in the
        # counting literature.
        "wape": float(np.sum(absolute_errors) / max(float(np.sum(truth)), 1.0)),
        "mean_nae": float(np.mean(absolute_errors / np.maximum(truth, 1.0))),
        "bias": float(np.mean(errors)),
    }


def greedy_point_matches(
    predicted_xy: np.ndarray,
    target_xy: np.ndarray,
    radius: float,
) -> tuple[int, int, int]:
    """Score-ordered one-to-one matching; predictions must already be ranked."""

    prediction = np.asarray(predicted_xy, dtype=np.float32).reshape(-1, 2)
    target = np.asarray(target_xy, dtype=np.float32).reshape(-1, 2)
    unmatched = np.ones(len(target), dtype=np.bool_)
    true_positive = 0
    radius_squared = radius * radius
    for point in prediction:
        candidates = np.flatnonzero(unmatched)
        if not len(candidates):
            break
        distances = np.sum((target[candidates] - point) ** 2, axis=1)
        nearest = int(np.argmin(distances))
        if float(distances[nearest]) <= radius_squared:
            unmatched[candidates[nearest]] = False
            true_positive += 1
    false_positive = len(prediction) - true_positive
    false_negative = len(target) - true_positive
    return true_positive, false_positive, false_negative


def maximum_cardinality_point_matches(
    predicted_xy: np.ndarray,
    target_xy: np.ndarray,
    radius: float,
) -> tuple[int, int, int]:
    """Return an order-independent maximum one-to-one point matching.

    An edge connects a prediction and target when their Euclidean distance is
    at most ``radius``.  The augmenting-path implementation intentionally has
    no SciPy dependency and avoids recursion, so it is safe for dense images
    containing thousands of candidate points.  It maximizes the number of
    matches; localization distance is not used as a secondary objective.
    """

    prediction = np.asarray(predicted_xy, dtype=np.float32).reshape(-1, 2)
    target = np.asarray(target_xy, dtype=np.float32).reshape(-1, 2)
    if radius < 0:
        raise ValueError("radius must be non-negative")
    if not len(prediction) or not len(target):
        return 0, len(prediction), len(target)

    radius_squared = radius * radius
    adjacency: list[np.ndarray] = []
    for point in prediction:
        distances = np.sum((target - point) ** 2, axis=1)
        adjacency.append(np.flatnonzero(distances <= radius_squared))

    # match_left[p] is the target currently paired with prediction p;
    # match_right[t] is the inverse mapping.  Each BFS either finds one
    # augmenting path or proves that the current prediction cannot increase
    # the matching cardinality.
    match_left = np.full(len(prediction), -1, dtype=np.int64)
    match_right = np.full(len(target), -1, dtype=np.int64)
    for start in range(len(prediction)):
        if match_left[start] >= 0:
            continue
        parent_right = np.full(len(target), -1, dtype=np.int64)
        seen_left = np.zeros(len(prediction), dtype=np.bool_)
        seen_left[start] = True
        queue = [start]
        queue_index = 0
        free_right = -1
        while queue_index < len(queue) and free_right < 0:
            left = queue[queue_index]
            queue_index += 1
            for right_value in adjacency[left]:
                right = int(right_value)
                if parent_right[right] >= 0:
                    continue
                parent_right[right] = left
                paired_left = int(match_right[right])
                if paired_left < 0:
                    free_right = right
                    break
                if not seen_left[paired_left]:
                    seen_left[paired_left] = True
                    queue.append(paired_left)

        if free_right < 0:
            continue
        right = free_right
        while right >= 0:
            left = int(parent_right[right])
            previous_right = int(match_left[left])
            match_left[left] = right
            match_right[right] = left
            right = previous_right

    true_positive = int(np.count_nonzero(match_left >= 0))
    false_positive = len(prediction) - true_positive
    false_negative = len(target) - true_positive
    return true_positive, false_positive, false_negative
