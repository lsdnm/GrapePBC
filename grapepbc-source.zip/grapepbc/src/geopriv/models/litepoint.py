"""LitePoint-B0 baseline and the GeoPriv extension.

The baseline deliberately exposes only center and offset heads. GeoPrivNet adds
the privileged radius and density heads used by the proposed training and
count-decoding ablations.
"""

from __future__ import annotations

from typing import Literal

import torch
from torch import Tensor, nn
import torch.nn.functional as F
from torchvision.models import MobileNet_V3_Small_Weights, mobilenet_v3_small


DecoderNorm = Literal["batch", "group"]


def _output_valid_mask(valid_image_mask: Tensor, output_size: tuple[int, int]) -> Tensor:
    """Project an input validity mask without losing odd padding boundaries."""

    if valid_image_mask.ndim == 3:
        mask = valid_image_mask[:, None]
    elif valid_image_mask.ndim == 4 and valid_image_mask.shape[1] == 1:
        mask = valid_image_mask
    else:
        raise ValueError(
            "valid_image_mask must have shape (B, H, W) or (B, 1, H, W), "
            f"got {tuple(valid_image_mask.shape)}"
        )
    if mask.shape[-2:] == output_size:
        return mask.bool()
    input_height, input_width = mask.shape[-2:]
    output_height, output_width = output_size
    if input_height >= output_height and input_width >= output_width:
        return F.adaptive_max_pool2d(mask.float(), output_size=output_size).bool()
    return F.interpolate(mask.float(), size=output_size, mode="nearest").bool()


def _normalization(channels: int, norm: DecoderNorm) -> nn.Module:
    if norm == "batch":
        return nn.BatchNorm2d(channels)
    if norm == "group":
        # Eight groups is the intended configuration. Falling back to the
        # largest divisor keeps custom, smaller FPN widths usable.
        groups = min(8, channels)
        while channels % groups:
            groups -= 1
        return nn.GroupNorm(groups, channels)
    raise ValueError(f"unsupported decoder normalization: {norm!r}")


class _ConvNormAct(nn.Sequential):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int = 3,
        *,
        norm: DecoderNorm = "batch",
    ) -> None:
        padding = kernel_size // 2
        super().__init__(
            nn.Conv2d(in_channels, out_channels, kernel_size, padding=padding, bias=False),
            _normalization(out_channels, norm),
            nn.SiLU(inplace=True),
        )


class MobileFPN(nn.Module):
    """MobileNetV3-Small stages 2/4/8/16 with a top-down FPN."""

    def __init__(
        self,
        channels: int = 64,
        pretrained: bool = False,
        *,
        decoder_norm: DecoderNorm = "batch",
        freeze_backbone_bn: bool = False,
    ) -> None:
        super().__init__()
        self.decoder_norm = decoder_norm
        self.freeze_backbone_bn = freeze_backbone_bn
        weights = MobileNet_V3_Small_Weights.DEFAULT if pretrained else None
        features = mobilenet_v3_small(weights=weights).features
        self.stage2 = nn.Sequential(*features[:1])
        self.stage4 = nn.Sequential(*features[1:2])
        self.stage8 = nn.Sequential(*features[2:4])
        self.stage16 = nn.Sequential(*features[4:7])
        self.lateral2 = nn.Conv2d(16, channels, 1)
        self.lateral4 = nn.Conv2d(16, channels, 1)
        self.lateral8 = nn.Conv2d(24, channels, 1)
        self.lateral16 = nn.Conv2d(40, channels, 1)
        self.smooth8 = _ConvNormAct(channels, channels, norm=decoder_norm)
        self.smooth4 = _ConvNormAct(channels, channels, norm=decoder_norm)
        self.smooth2 = _ConvNormAct(channels, channels, norm=decoder_norm)
        if freeze_backbone_bn:
            self._set_backbone_batch_norm_eval()

    def _backbone_stages(self) -> tuple[nn.Module, ...]:
        return self.stage2, self.stage4, self.stage8, self.stage16

    def _set_backbone_batch_norm_eval(self) -> None:
        for stage in self._backbone_stages():
            for module in stage.modules():
                if isinstance(module, nn.modules.batchnorm._BatchNorm):
                    module.eval()

    def train(self, mode: bool = True) -> MobileFPN:
        super().train(mode)
        if self.freeze_backbone_bn:
            self._set_backbone_batch_norm_eval()
        return self

    def forward(self, images: Tensor) -> tuple[Tensor, Tensor]:
        feature2 = self.stage2(images)
        feature4 = self.stage4(feature2)
        feature8 = self.stage8(feature4)
        feature16 = self.stage16(feature8)
        pyramid16 = self.lateral16(feature16)
        pyramid8 = self.smooth8(
            self.lateral8(feature8)
            + F.interpolate(pyramid16, size=feature8.shape[-2:], mode="bilinear", align_corners=False)
        )
        pyramid4 = self.smooth4(
            self.lateral4(feature4)
            + F.interpolate(pyramid8, size=feature4.shape[-2:], mode="bilinear", align_corners=False)
        )
        pyramid2 = self.smooth2(
            self.lateral2(feature2)
            + F.interpolate(pyramid4, size=feature2.shape[-2:], mode="bilinear", align_corners=False)
        )
        return pyramid2, feature16


def _head(
    channels: int,
    output_channels: int,
    bias: float | None = None,
    *,
    norm: DecoderNorm = "batch",
) -> nn.Sequential:
    block = nn.Sequential(
        _ConvNormAct(channels, channels, norm=norm),
        nn.Conv2d(channels, output_channels, 1),
    )
    if bias is not None:
        nn.init.constant_(block[-1].bias, bias)
    return block


class LitePointB0(nn.Module):
    """Pure anchor-free point baseline used before any proposed modules."""

    output_stride = 2

    def __init__(
        self,
        fpn_channels: int = 64,
        pretrained: bool = False,
        *,
        decoder_norm: DecoderNorm = "batch",
        freeze_backbone_bn: bool = False,
    ) -> None:
        super().__init__()
        self.encoder = MobileFPN(
            fpn_channels,
            pretrained=pretrained,
            decoder_norm=decoder_norm,
            freeze_backbone_bn=freeze_backbone_bn,
        )
        self.center_head = _head(fpn_channels, 1, bias=-2.19, norm=decoder_norm)
        self.offset_head = _head(fpn_channels, 2, norm=decoder_norm)

    def forward(self, images: Tensor, valid_image_mask: Tensor | None = None) -> dict[str, Tensor]:
        feature2, _ = self.encoder(images)
        center_logits = self.center_head(feature2)
        if valid_image_mask is not None:
            valid = _output_valid_mask(valid_image_mask, center_logits.shape[-2:])
            center_logits = center_logits.masked_fill(~valid, -30.0)
        return {"center_logits": center_logits, "offsets": self.offset_head(feature2)}


class GeoPrivNet(nn.Module):
    """Student with training-only radius supervision and a density count head."""

    output_stride = 2

    def __init__(
        self,
        fpn_channels: int = 64,
        pretrained: bool = False,
        *,
        decoder_norm: DecoderNorm = "batch",
        freeze_backbone_bn: bool = False,
    ) -> None:
        super().__init__()
        self.encoder = MobileFPN(
            fpn_channels,
            pretrained=pretrained,
            decoder_norm=decoder_norm,
            freeze_backbone_bn=freeze_backbone_bn,
        )
        self.center_head = _head(fpn_channels, 1, bias=-2.19, norm=decoder_norm)
        self.offset_head = _head(fpn_channels, 2, norm=decoder_norm)
        self.log_radius_head = _head(fpn_channels, 1, norm=decoder_norm)
        self.density_head = _head(fpn_channels, 1, bias=-6.0, norm=decoder_norm)

    def forward(
        self,
        images: Tensor,
        valid_image_mask: Tensor | None = None,
    ) -> dict[str, Tensor]:
        feature2, _ = self.encoder(images)
        center_logits = self.center_head(feature2)
        density_logits = self.density_head(feature2)
        if valid_image_mask is not None:
            valid = _output_valid_mask(valid_image_mask, center_logits.shape[-2:])
            center_logits = center_logits.masked_fill(~valid, -30.0)
            density_logits = density_logits.masked_fill(~valid, -30.0)
        return {
            "center_logits": center_logits,
            "offsets": self.offset_head(feature2),
            "log_radius": self.log_radius_head(feature2),
            "density_logits": density_logits,
        }


@torch.no_grad()
def decode_points(
    outputs: dict[str, Tensor],
    *,
    score_threshold: float = 0.25,
    topk: int = 4096,
    local_max_kernel: int = 3,
    input_sizes: Tensor | None = None,
    output_stride: int = 2,
) -> list[dict[str, Tensor | int | float]]:
    """Decode local heatmap maxima to sub-pixel image coordinates."""

    heatmap = outputs["center_logits"].sigmoid()
    pooled = F.max_pool2d(
        heatmap,
        kernel_size=local_max_kernel,
        stride=1,
        padding=local_max_kernel // 2,
    )
    heatmap = heatmap * (heatmap == pooled)
    offsets = outputs["offsets"]
    batch, _, height, width = heatmap.shape
    maximum = min(topk, height * width)
    decoded: list[dict[str, Tensor | int | float]] = []
    for batch_index in range(batch):
        scores, indices = heatmap[batch_index, 0].reshape(-1).topk(maximum)
        keep = scores >= score_threshold
        scores, indices = scores[keep], indices[keep]
        ys = torch.div(indices, width, rounding_mode="floor")
        xs = indices % width
        gathered_offsets = offsets[batch_index, :, ys, xs].transpose(0, 1)
        points = torch.stack((xs.float(), ys.float()), dim=1) + gathered_offsets
        points = points * output_stride
        if input_sizes is not None and len(points):
            valid_height, valid_width = input_sizes[batch_index]
            valid = (
                (points[:, 0] >= 0)
                & (points[:, 0] < valid_width)
                & (points[:, 1] >= 0)
                & (points[:, 1] < valid_height)
            )
            points, scores, ys, xs = points[valid], scores[valid], ys[valid], xs[valid]
        item: dict[str, Tensor | int | float] = {
            "points": points,
            "scores": scores,
            "count": int(len(points)),
        }
        if "log_radius" in outputs:
            item["radii"] = outputs["log_radius"][batch_index, 0, ys, xs].exp() * output_stride
        if "density_logits" in outputs:
            item["density_count"] = float(F.softplus(outputs["density_logits"][batch_index]).sum())
        decoded.append(item)
    return decoded
