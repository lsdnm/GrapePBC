"""Opt-in local-detail counter; legacy architectures/defaults are untouched."""
import torch
from torch import nn
from .litepoint import LitePointB0, _output_valid_mask


class DetailPointExpert(LitePointB0):
    """Count-supervised local features, NOT supervised berry shape or cluster IDs.

    Two receptive-field branches enrich the FPN feature map. A zero-initialized
    projection preserves the initial counting outputs for a matched trial.
    """
    def __init__(self, fpn_channels=64, pretrained=False, *, decoder_norm="group",
                 freeze_backbone_bn=True, detail=True):
        super().__init__(fpn_channels, pretrained, decoder_norm=decoder_norm,
                         freeze_backbone_bn=freeze_backbone_bn)
        self.detail = detail
        if detail:
            self.local_branches = nn.ModuleList([
                nn.Sequential(
                    nn.Conv2d(fpn_channels, fpn_channels, 3, padding=d, dilation=d, bias=False),
                    nn.GroupNorm(8, fpn_channels), nn.SiLU())
                for d in (1, 2)
            ])
            self.detail_projection = nn.Conv2d(fpn_channels * 2, fpn_channels, 1)
            nn.init.zeros_(self.detail_projection.weight)
            nn.init.zeros_(self.detail_projection.bias)

    def forward(self, images, valid_image_mask=None, *, return_features=False):
        feature, _ = self.encoder(images)
        if self.detail:
            feature = feature + self.detail_projection(
                torch.cat([branch(feature) for branch in self.local_branches], dim=1))
        center = self.center_head(feature)
        if valid_image_mask is not None:
            valid = _output_valid_mask(valid_image_mask, center.shape[-2:])
            center = center.masked_fill(~valid, -30.)
        result = {"center_logits": center, "offsets": self.offset_head(feature)}
        if return_features:
            result["detail_features"] = feature
        return result

    def load_counter_state(self, state):
        """Drop only legacy inactive heads; reject all other mismatches."""
        filtered = {k: v for k, v in state.items()
                    if not k.startswith(("log_radius_head.", "density_head."))}
        result = self.load_state_dict(filtered, strict=False)
        expected = {k for k in self.state_dict()
                    if k.startswith(("local_branches.", "detail_projection."))}
        if result.unexpected_keys or set(result.missing_keys) != expected:
            raise ValueError(f"counter initialization mismatch: {result}")

