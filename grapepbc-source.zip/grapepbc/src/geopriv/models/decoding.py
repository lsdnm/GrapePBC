"""Inference decoders that close the density-to-count prediction loop.

``density_topk`` uses the integral of the non-negative density prediction to
choose how many *distinct center candidates* to retain.  The density head thus
controls the reported count while the center and offset heads still determine
localization.  All limits and diagnostic fields are explicit so an evaluation
report can distinguish a density estimate from candidate or implementation
capacity limits.
"""

from __future__ import annotations

import math
from typing import Literal, Mapping

import torch
from torch import Tensor
import torch.nn.functional as F


CountMode = Literal["peak_threshold", "density_topk"]

# A frozen decoder constant, deliberately far below a useful center score.  It
# only excludes numerical background such as sigmoid(-30), not a tunable
# operating point.
DEFAULT_CANDIDATE_SCORE_FLOOR = 1.0e-6


def round_half_up_nonnegative(value: float) -> int:
    """Round a finite non-negative value with the explicit ``x.5 -> x+1`` rule."""

    if not math.isfinite(value) or value < 0.0:
        raise ValueError(f"value must be finite and non-negative, got {value!r}")
    return int(math.floor(value + 0.5))


def _require_head(
    outputs: Mapping[str, Tensor],
    name: str,
    *,
    channels: int,
    reference_shape: tuple[int, int, int, int] | None = None,
) -> Tensor:
    tensor = outputs.get(name)
    if not isinstance(tensor, Tensor):
        raise KeyError(f"outputs must contain tensor {name!r}")
    if tensor.ndim != 4 or tensor.shape[1] != channels:
        raise ValueError(
            f"outputs[{name!r}] must have shape (B, {channels}, H, W), "
            f"got {tuple(tensor.shape)}"
        )
    if reference_shape is not None:
        expected = (reference_shape[0], channels, reference_shape[2], reference_shape[3])
        if tuple(tensor.shape) != expected:
            raise ValueError(
                f"outputs[{name!r}] must have shape {expected}, got {tuple(tensor.shape)}"
            )
    return tensor


def _output_valid_mask(
    valid_mask: Tensor | None,
    *,
    batch: int,
    output_size: tuple[int, int],
    device: torch.device,
) -> Tensor:
    """Normalize an input- or output-resolution validity mask to ``(B,1,H,W)``."""

    output_height, output_width = output_size
    if valid_mask is None:
        return torch.ones(
            (batch, 1, output_height, output_width), dtype=torch.bool, device=device
        )
    if valid_mask.ndim == 3:
        mask = valid_mask[:, None]
    elif valid_mask.ndim == 4 and valid_mask.shape[1] == 1:
        mask = valid_mask
    else:
        raise ValueError(
            "valid_mask must have shape (B, H, W) or (B, 1, H, W), "
            f"got {tuple(valid_mask.shape)}"
        )
    if mask.shape[0] != batch:
        raise ValueError(f"valid_mask batch must be {batch}, got {mask.shape[0]}")
    mask = mask.to(device=device)
    if mask.shape[-2:] == output_size:
        return mask.bool()
    input_height, input_width = mask.shape[-2:]
    if input_height >= output_height and input_width >= output_width:
        return F.adaptive_max_pool2d(mask.float(), output_size=output_size).bool()
    return F.interpolate(mask.float(), size=output_size, mode="nearest").bool()


def _validate_decoder_options(
    *,
    topk: int,
    local_max_kernel: int,
    candidate_score_floor: float,
    output_stride: int,
) -> None:
    if isinstance(topk, bool) or not isinstance(topk, int) or topk < 0:
        raise ValueError(f"topk must be a non-negative integer, got {topk!r}")
    if (
        isinstance(local_max_kernel, bool)
        or not isinstance(local_max_kernel, int)
        or local_max_kernel < 1
        or local_max_kernel % 2 == 0
    ):
        raise ValueError(
            f"local_max_kernel must be a positive odd integer, got {local_max_kernel!r}"
        )
    if not math.isfinite(candidate_score_floor) or not 0.0 <= candidate_score_floor <= 1.0:
        raise ValueError(
            "candidate_score_floor must be finite and in [0, 1], "
            f"got {candidate_score_floor!r}"
        )
    if isinstance(output_stride, bool) or not isinstance(output_stride, int) or output_stride < 1:
        raise ValueError(f"output_stride must be a positive integer, got {output_stride!r}")


@torch.no_grad()
def decode_density_topk(
    outputs: Mapping[str, Tensor],
    *,
    topk: int = 4096,
    local_max_kernel: int = 3,
    candidate_score_floor: float = DEFAULT_CANDIDATE_SCORE_FLOOR,
    valid_mask: Tensor | None = None,
    output_stride: int = 2,
) -> list[dict[str, Tensor | int | float | bool]]:
    """Decode density-requested counts from unique local center maxima.

    For each image, ``density_count_raw`` is the sum of
    ``softplus(density_logits)`` over valid output cells only.  It is rounded
    half-up to ``requested_k``.  ``actual_count`` is then
    ``min(requested_k, topk, candidate_count)``; candidates are never repeated
    to manufacture the requested count.

    ``candidate_shortfall`` is ``max(requested_k - candidate_count, 0)``.
    ``topk_saturation`` is true whenever ``requested_k > topk``.  It can be true
    at the same time as ``candidate_shortfall`` so both frozen capacity limits
    remain visible rather than one masking the other.
    Candidate ties are stable and therefore resolved by row-major cell index.
    """

    _validate_decoder_options(
        topk=topk,
        local_max_kernel=local_max_kernel,
        candidate_score_floor=candidate_score_floor,
        output_stride=output_stride,
    )
    center_logits = _require_head(outputs, "center_logits", channels=1)
    offsets = _require_head(
        outputs, "offsets", channels=2, reference_shape=tuple(center_logits.shape)
    )
    density_logits = _require_head(
        outputs, "density_logits", channels=1, reference_shape=tuple(center_logits.shape)
    )
    log_radius = outputs.get("log_radius")
    if log_radius is not None:
        if not isinstance(log_radius, Tensor):
            raise TypeError("outputs['log_radius'] must be a tensor when present")
        _require_head(
            {"log_radius": log_radius},
            "log_radius",
            channels=1,
            reference_shape=tuple(center_logits.shape),
        )

    batch, _, height, width = center_logits.shape
    valid = _output_valid_mask(
        valid_mask,
        batch=batch,
        output_size=(height, width),
        device=center_logits.device,
    )
    scores_map = center_logits.float().sigmoid()
    # Mask before pooling as well as after it: padded high logits cannot suppress
    # a valid boundary maximum and padded cells can never become candidates.
    masked_scores = scores_map.masked_fill(~valid, -torch.inf)
    pooled = F.max_pool2d(
        masked_scores,
        kernel_size=local_max_kernel,
        stride=1,
        padding=local_max_kernel // 2,
    )
    maxima = valid & (masked_scores == pooled) & (scores_map >= candidate_score_floor)

    decoded: list[dict[str, Tensor | int | float | bool]] = []
    for batch_index in range(batch):
        valid_for_image = valid[batch_index, 0]
        density_count_tensor = F.softplus(density_logits[batch_index, 0].float())
        density_count_raw = float(density_count_tensor[valid_for_image].sum().item())
        requested_k = round_half_up_nonnegative(density_count_raw)

        flat_indices = maxima[batch_index, 0].reshape(-1).nonzero(as_tuple=False).flatten()
        candidate_scores = scores_map[batch_index, 0].reshape(-1)[flat_indices]
        candidate_count = int(flat_indices.numel())
        actual_count = min(requested_k, topk, candidate_count)

        if actual_count:
            # nonzero() is row-major. Stable descending sort therefore gives a
            # deterministic flat-index tie break without duplicating candidates.
            order = torch.argsort(candidate_scores, descending=True, stable=True)
            selected = order[:actual_count]
            selected_indices = flat_indices[selected]
            selected_scores = candidate_scores[selected]
            ys = torch.div(selected_indices, width, rounding_mode="floor")
            xs = selected_indices % width
            gathered_offsets = offsets[batch_index, :, ys, xs].transpose(0, 1).float()
            points = torch.stack((xs.float(), ys.float()), dim=1) + gathered_offsets
            points = points * output_stride
        else:
            ys = torch.empty((0,), dtype=torch.long, device=center_logits.device)
            xs = torch.empty((0,), dtype=torch.long, device=center_logits.device)
            selected_scores = torch.empty(
                (0,), dtype=scores_map.dtype, device=center_logits.device
            )
            points = torch.empty((0, 2), dtype=torch.float32, device=center_logits.device)

        topk_saturation = requested_k > topk
        item: dict[str, Tensor | int | float | bool] = {
            "points": points,
            "scores": selected_scores,
            "count": actual_count,
            "actual_count": actual_count,
            "density_count": density_count_raw,
            "density_count_raw": density_count_raw,
            "requested_k": requested_k,
            "candidate_count": candidate_count,
            "candidate_shortfall": max(requested_k - candidate_count, 0),
            "topk_saturation": topk_saturation,
        }
        if log_radius is not None:
            item["radii"] = log_radius[batch_index, 0, ys, xs].float().exp() * output_stride
        decoded.append(item)
    return decoded


@torch.no_grad()
def decode_density_guarded_topk(
    outputs: Mapping[str, Tensor],
    *,
    peak_score_threshold: float,
    peak_floor_multiplier: float,
    high_peak_count_threshold: int | None = None,
    high_peak_floor_multiplier: float | None = None,
    topk: int = 4096,
    local_max_kernel: int = 3,
    candidate_score_floor: float = DEFAULT_CANDIDATE_SCORE_FLOOR,
    valid_mask: Tensor | None = None,
    output_stride: int = 2,
) -> list[dict[str, Tensor | int | float | bool]]:
    """Use density count with a frozen fraction of the peak count as a guard.

    The density head remains the primary image-adaptive count estimator.  If it
    requests fewer than ``round(peak_floor_multiplier * peak_count)`` points,
    the latter becomes the requested count.  Both counts are obtained from one
    model forward pass; the guard only changes how many already-ranked local
    centre maxima are retained.
    """

    _validate_decoder_options(
        topk=topk,
        local_max_kernel=local_max_kernel,
        candidate_score_floor=candidate_score_floor,
        output_stride=output_stride,
    )
    if not math.isfinite(peak_score_threshold) or not 0.0 <= peak_score_threshold <= 1.0:
        raise ValueError("peak_score_threshold must be finite and in [0, 1]")
    if not math.isfinite(peak_floor_multiplier) or not 0.0 <= peak_floor_multiplier <= 1.0:
        raise ValueError("peak_floor_multiplier must be finite and in [0, 1]")
    if (high_peak_count_threshold is None) != (high_peak_floor_multiplier is None):
        raise ValueError(
            "high_peak_count_threshold and high_peak_floor_multiplier must be supplied together"
        )
    if high_peak_count_threshold is not None and (
        isinstance(high_peak_count_threshold, bool) or high_peak_count_threshold < 1
    ):
        raise ValueError("high_peak_count_threshold must be a positive integer")
    if high_peak_floor_multiplier is not None and (
        not math.isfinite(high_peak_floor_multiplier)
        or not 0.0 <= high_peak_floor_multiplier <= 1.0
    ):
        raise ValueError("high_peak_floor_multiplier must be finite and in [0, 1]")
    if candidate_score_floor > peak_score_threshold:
        raise ValueError("candidate_score_floor cannot exceed peak_score_threshold")

    density_decoded = decode_density_topk(
        outputs,
        topk=topk,
        local_max_kernel=local_max_kernel,
        candidate_score_floor=candidate_score_floor,
        valid_mask=valid_mask,
        output_stride=output_stride,
    )

    # Reuse the established peak decoder to obtain one score-ranked candidate
    # pool.  A low numerical floor includes candidates needed by either branch.
    from .litepoint import decode_points

    legacy_outputs = dict(outputs)
    center_logits = _require_head(legacy_outputs, "center_logits", channels=1)
    valid = _output_valid_mask(
        valid_mask,
        batch=center_logits.shape[0],
        output_size=tuple(center_logits.shape[-2:]),
        device=center_logits.device,
    )
    legacy_outputs["center_logits"] = center_logits.masked_fill(~valid, -torch.inf)
    candidates = decode_points(
        legacy_outputs,
        score_threshold=candidate_score_floor,
        topk=topk,
        local_max_kernel=local_max_kernel,
        output_stride=output_stride,
    )

    decoded: list[dict[str, Tensor | int | float | bool]] = []
    for density_item, candidate_item in zip(density_decoded, candidates):
        candidate_scores = candidate_item["scores"]
        candidate_points = candidate_item["points"]
        if not isinstance(candidate_scores, Tensor) or not isinstance(candidate_points, Tensor):
            raise TypeError("peak decoder returned invalid candidate tensors")
        peak_count = int((candidate_scores >= peak_score_threshold).sum().item())
        active_multiplier = peak_floor_multiplier
        high_count_guard_activated = False
        if (
            high_peak_count_threshold is not None
            and high_peak_floor_multiplier is not None
            and peak_count >= high_peak_count_threshold
        ):
            active_multiplier = high_peak_floor_multiplier
            high_count_guard_activated = True
        peak_floor_count = round_half_up_nonnegative(active_multiplier * peak_count)
        density_requested = int(density_item["requested_k"])
        guarded_requested = max(density_requested, peak_floor_count)
        actual_count = min(guarded_requested, topk, int(density_item["candidate_count"]))
        item = dict(density_item)
        item.update(
            points=candidate_points[:actual_count],
            scores=candidate_scores[:actual_count],
            count=actual_count,
            actual_count=actual_count,
            requested_k=guarded_requested,
            density_requested_k=density_requested,
            baseline_peak_count=peak_count,
            peak_floor_count=peak_floor_count,
            peak_score_threshold=float(peak_score_threshold),
            peak_floor_multiplier=float(active_multiplier),
            base_peak_floor_multiplier=float(peak_floor_multiplier),
            high_peak_count_threshold=high_peak_count_threshold,
            high_peak_floor_multiplier=high_peak_floor_multiplier,
            high_count_guard_activated=high_count_guard_activated,
            density_guard_activated=peak_floor_count > density_requested,
            candidate_shortfall=max(
                guarded_requested - int(density_item["candidate_count"]), 0
            ),
            topk_saturation=guarded_requested > topk,
        )
        if "radii" in candidate_item:
            radii = candidate_item["radii"]
            if not isinstance(radii, Tensor):
                raise TypeError("peak decoder returned invalid radii")
            item["radii"] = radii[:actual_count]
        decoded.append(item)
    return decoded


@torch.no_grad()
def decode_points_by_mode(
    outputs: Mapping[str, Tensor],
    *,
    count_mode: CountMode,
    score_threshold: float = 0.25,
    topk: int = 4096,
    local_max_kernel: int = 3,
    candidate_score_floor: float = DEFAULT_CANDIDATE_SCORE_FLOOR,
    valid_mask: Tensor | None = None,
    input_sizes: Tensor | None = None,
    output_stride: int = 2,
) -> list[dict[str, Tensor | int | float | bool]]:
    """Compatibility dispatch for the legacy and density-guided decoders."""

    if count_mode == "density_topk":
        if input_sizes is not None:
            raise ValueError("input_sizes is not used by density_topk; pass valid_mask instead")
        return decode_density_topk(
            outputs,
            topk=topk,
            local_max_kernel=local_max_kernel,
            candidate_score_floor=candidate_score_floor,
            valid_mask=valid_mask,
            output_stride=output_stride,
        )
    if count_mode == "peak_threshold":
        # Local import avoids a module cycle while preserving the exact legacy
        # decoder and its established result schema.
        from .litepoint import decode_points

        legacy_outputs = dict(outputs)
        if valid_mask is not None:
            center_logits = _require_head(legacy_outputs, "center_logits", channels=1)
            valid = _output_valid_mask(
                valid_mask,
                batch=center_logits.shape[0],
                output_size=tuple(center_logits.shape[-2:]),
                device=center_logits.device,
            )
            legacy_outputs["center_logits"] = center_logits.masked_fill(~valid, -torch.inf)
            if "density_logits" in legacy_outputs:
                legacy_outputs["density_logits"] = legacy_outputs["density_logits"].masked_fill(
                    ~valid, -torch.inf
                )
        return decode_points(
            legacy_outputs,
            score_threshold=score_threshold,
            topk=topk,
            local_max_kernel=local_max_kernel,
            input_sizes=input_sizes,
            output_stride=output_stride,
        )
    raise ValueError(f"unsupported count_mode: {count_mode!r}")


__all__ = [
    "CountMode",
    "DEFAULT_CANDIDATE_SCORE_FLOOR",
    "decode_density_topk",
    "decode_density_guarded_topk",
    "decode_points_by_mode",
    "round_half_up_nonnegative",
]
