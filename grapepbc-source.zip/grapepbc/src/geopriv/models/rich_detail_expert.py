"""High-resolution counting expert with local detail and deep context.

This module is opt-in.  It leaves the historical LR/HR architectures intact
and adds capacity only to the expert that is called on selected core/halo
regions.  The two residual projections start at zero, so loading a generic
GeoPrivNet state gives exact output parity before training.
"""

from __future__ import annotations

from pathlib import Path

import torch
from torch import Tensor, nn
from torch.nn import functional as F
from torchvision.models import mobilenet_v3_small

from .litepoint import GeoPrivNet, _output_valid_mask


class RichDetailExpert(GeoPrivNet):
    """Region expert combining stride-2 detail and stride-32 context.

    The model preserves the four GeoPrivNet heads.  Its extra branches are
    supervised only by the same berry-centre/count targets as the base model;
    they must not be described as shape, depth, cluster, or cultivar heads.
    """

    def __init__(
        self,
        fpn_channels: int = 64,
        *,
        decoder_norm: str = "group",
        freeze_backbone_bn: bool = True,
        deep_backbone_checkpoint: str | Path | None = None,
    ) -> None:
        super().__init__(
            fpn_channels=fpn_channels,
            pretrained=False,
            decoder_norm=decoder_norm,
            freeze_backbone_bn=freeze_backbone_bn,
        )
        self.local_branches = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Conv2d(
                        fpn_channels,
                        fpn_channels,
                        kernel_size=3,
                        padding=dilation,
                        dilation=dilation,
                        bias=False,
                    ),
                    nn.GroupNorm(8, fpn_channels),
                    nn.SiLU(inplace=True),
                )
                for dilation in (1, 2)
            ]
        )
        self.detail_projection = nn.Conv2d(fpn_channels * 2, fpn_channels, 1)

        generic_backbone = mobilenet_v3_small(weights=None)
        if deep_backbone_checkpoint is not None:
            state = torch.load(
                Path(deep_backbone_checkpoint), map_location="cpu", weights_only=True
            )
            generic_backbone.load_state_dict(state, strict=True)
        # MobileFPN ends after feature block 6 (40 channels).  Blocks 7--11
        # continue the same public ImageNet MobileNetV3-Small backbone and
        # produce 96-channel stride-32 context.
        self.deep_context = nn.Sequential(*generic_backbone.features[7:12])
        self.context_projection = nn.Conv2d(96, fpn_channels, 1)

        nn.init.zeros_(self.detail_projection.weight)
        nn.init.zeros_(self.detail_projection.bias)
        nn.init.zeros_(self.context_projection.weight)
        nn.init.zeros_(self.context_projection.bias)
        self._freeze_deep_batch_norm()

    def _freeze_deep_batch_norm(self) -> None:
        for module in self.deep_context.modules():
            if isinstance(module, nn.modules.batchnorm._BatchNorm):
                module.eval()

    def train(self, mode: bool = True) -> RichDetailExpert:
        super().train(mode)
        self._freeze_deep_batch_norm()
        return self

    def load_base_state(self, state: dict[str, Tensor]) -> None:
        """Load a GeoPrivNet state while retaining the new generic branches."""

        result = self.load_state_dict(state, strict=False)
        expected_prefixes = (
            "local_branches.",
            "detail_projection.",
            "deep_context.",
            "context_projection.",
        )
        missing = set(result.missing_keys)
        unexpected = set(result.unexpected_keys)
        if unexpected or any(
            not key.startswith(expected_prefixes) for key in missing
        ):
            raise ValueError(
                "base initialization mismatch: "
                f"missing={sorted(missing)}, unexpected={sorted(unexpected)}"
            )

    def forward(
        self,
        images: Tensor,
        valid_image_mask: Tensor | None = None,
        *,
        return_features: bool = False,
    ) -> dict[str, Tensor]:
        feature2, feature16 = self.encoder(images)
        local_residual = self.detail_projection(
            torch.cat([branch(feature2) for branch in self.local_branches], dim=1)
        )
        semantic = self.deep_context(feature16)
        semantic_residual = F.interpolate(
            self.context_projection(semantic),
            size=feature2.shape[-2:],
            mode="bilinear",
            align_corners=False,
        )
        feature = feature2 + local_residual + semantic_residual

        center_logits = self.center_head(feature)
        density_logits = self.density_head(feature)
        if valid_image_mask is not None:
            valid = _output_valid_mask(valid_image_mask, center_logits.shape[-2:])
            center_logits = center_logits.masked_fill(~valid, -30.0)
            density_logits = density_logits.masked_fill(~valid, -30.0)
        result = {
            "center_logits": center_logits,
            "offsets": self.offset_head(feature),
            "log_radius": self.log_radius_head(feature),
            "density_logits": density_logits,
        }
        if return_features:
            result["detail_features"] = feature
            result["semantic_features"] = semantic
        return result


__all__ = ["RichDetailExpert"]
