"""Lightweight point-counting models and inference decoders."""

from .decoding import (
    CountMode,
    DEFAULT_CANDIDATE_SCORE_FLOOR,
    decode_density_guarded_topk,
    decode_density_topk,
    decode_points_by_mode,
    round_half_up_nonnegative,
)
from .litepoint import GeoPrivNet, LitePointB0, decode_points
from .rich_detail_expert import RichDetailExpert
from .hr_localization_refiner import HRLocalizationRefiner, apply_hr_localization_repair
from .core_count_head import CoreCountHead, decode_core_counts
from .residual_count_head import ResidualCountHead, decode_residual_counts
from .near_count_repair import NearCountRepairPolicy, apply_near_count_repair
from .large_context_offset_refiner import LargeContextOffsetRefiner, PointPatchCenterRegressor, SpatialPointPatchCenterRegressor, UniqueCenterProposalHead

__all__ = [
    "CountMode",
    "DEFAULT_CANDIDATE_SCORE_FLOOR",
    "LitePointB0",
    "GeoPrivNet",
    "RichDetailExpert",
    "HRLocalizationRefiner",
    "apply_hr_localization_repair",
    "CoreCountHead",
    "decode_core_counts",
    "ResidualCountHead",
    "decode_residual_counts",
    "NearCountRepairPolicy",
    "apply_near_count_repair",
    "LargeContextOffsetRefiner",
    "PointPatchCenterRegressor",
    "SpatialPointPatchCenterRegressor",
    "UniqueCenterProposalHead",
    "decode_density_guarded_topk",
    "decode_density_topk",
    "decode_points",
    "decode_points_by_mode",
    "round_half_up_nonnegative",
]
