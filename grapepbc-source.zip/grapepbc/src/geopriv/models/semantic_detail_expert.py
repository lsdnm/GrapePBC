"""Optional deeper-context HR expert; keeps the historical counter unchanged."""
import torch
from torch import nn
from torch.nn import functional as F
from torchvision.models import mobilenet_v3_small
from .detail_expert import DetailPointExpert
from .litepoint import _output_valid_mask


class SemanticDetailExpert(DetailPointExpert):
    """Restore discarded MobileNet stages to provide stride-32 context.

    This is a count-supervised semantic-context candidate, not a trained shape,
    segmentation, depth or cluster-identity head. Zero projection gives exact
    initial parity with the shallow counter before any training.
    """
    def __init__(self, backbone_checkpoint=None):
        super().__init__(detail=False)
        backbone = mobilenet_v3_small(weights=None)
        if backbone_checkpoint is not None:
            backbone.load_state_dict(torch.load(backbone_checkpoint, map_location='cpu', weights_only=True))
        self.deep_context = nn.Sequential(*backbone.features[7:12])
        self.context_projection = nn.Conv2d(96, 64, 1)
        nn.init.zeros_(self.context_projection.weight)
        nn.init.zeros_(self.context_projection.bias)
        self._freeze_deep_bn()

    def _freeze_deep_bn(self):
        for module in self.deep_context.modules():
            if isinstance(module, nn.modules.batchnorm._BatchNorm): module.eval()

    def train(self, mode=True):
        super().train(mode)
        self._freeze_deep_bn()
        return self

    def load_counter_state(self, state):
        filtered = {k:v for k,v in state.items() if not k.startswith(('log_radius_head.','density_head.'))}
        result = self.load_state_dict(filtered, strict=False)
        expected = {k for k in self.state_dict() if k.startswith(('deep_context.','context_projection.'))}
        # PyTorch supplies missing BN num_batches_tracked buffers internally.
        required_missing = {k for k in expected if not k.endswith('.num_batches_tracked')}
        missing = set(result.missing_keys)
        if result.unexpected_keys or not required_missing <= missing or not missing <= expected:
            raise ValueError(f'counter initialization mismatch: {result}')

    def forward(self, images, valid_image_mask=None, *, return_features=False):
        local, feature16 = self.encoder(images)
        semantic = self.deep_context(feature16)
        feature = local + F.interpolate(self.context_projection(semantic), size=local.shape[-2:],
                                         mode='bilinear', align_corners=False)
        center = self.center_head(feature)
        if valid_image_mask is not None:
            valid = _output_valid_mask(valid_image_mask, center.shape[-2:])
            center = center.masked_fill(~valid, -30.)
        result = dict(center_logits=center, offsets=self.offset_head(feature))
        if return_features: result['detail_features'] = feature
        return result
