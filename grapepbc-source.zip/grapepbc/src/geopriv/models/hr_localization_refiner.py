"""Small residual localization heads for high-resolution CRU experts."""
from __future__ import annotations

import torch
from torch import Tensor, nn
from torch.nn import functional as F


class HRLocalizationRefiner(nn.Module):
    """Multi-scale residual head for centre ranking and sub-cell offsets.

    The output projection is zero initialized, so attaching a new head is an
    exact no-op until trained.  It adds fewer than twenty thousand parameters
    and does not produce a count, cluster, cultivar, or semantic mask.
    """

    def __init__(self, channels: int = 64) -> None:
        super().__init__()
        self.branches = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Conv2d(channels, channels, 3, padding=dilation, dilation=dilation, groups=channels, bias=False),
                    nn.GroupNorm(8, channels),
                    nn.SiLU(inplace=True),
                )
                for dilation in (1, 2, 4)
            ]
        )
        self.fuse = nn.Sequential(
            nn.Conv2d(channels * 3, channels, 1, bias=False),
            nn.GroupNorm(8, channels),
            nn.SiLU(inplace=True),
        )
        self.output = nn.Conv2d(channels, 3, 1)
        nn.init.zeros_(self.output.weight)
        nn.init.zeros_(self.output.bias)

    def forward(self, feature: Tensor) -> tuple[Tensor, Tensor]:
        value = self.output(self.fuse(torch.cat([branch(feature) for branch in self.branches], dim=1)))
        return value[:, :1], value[:, 1:]


def apply_hr_localization_repair(
    outputs: dict[str, Tensor],
    feature: Tensor,
    valid_image_mask: Tensor,
    refiner: HRLocalizationRefiner,
    *,
    center_alpha: float,
    offset_alpha: float | None = None,
    replacement_offset_head: nn.Module | None = None,
) -> dict[str, Tensor]:
    """Apply a frozen repair without changing density/count-related outputs."""
    center_delta, offset_delta = refiner(feature)
    center_logits = outputs["center_logits"] + float(center_alpha) * center_delta
    valid = F.adaptive_max_pool2d(valid_image_mask[:, None].float(), center_logits.shape[-2:]).bool()
    center_logits = center_logits.masked_fill(~valid, -30.0)
    if replacement_offset_head is not None:
        offsets = replacement_offset_head(feature)
    elif offset_alpha is None:
        offsets = outputs["offsets"]
    else:
        offsets = outputs["offsets"] + float(offset_alpha) * offset_delta
    return {**outputs, "center_logits": center_logits, "offsets": offsets}


__all__ = ["HRLocalizationRefiner", "apply_hr_localization_repair"]
