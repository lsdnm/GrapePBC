"""Conservative close-range count and point-set repair.

The repair requires agreement between two independently motivated signals:
low aggregate point reliability and a lower core-count-head estimate.  It can
only remove the least reliable emitted points and therefore never invents a
berry centre or increases the count.
"""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np
from scipy.spatial import cKDTree


@dataclass(frozen=True)
class NearCountRepairPolicy:
    reliability_gap_minimum: float = 0.30
    calibrated_reduction_minimum: int = 8
    calibrated_reduction_fraction_minimum: float = 0.10
    raw_count_maximum: int = 60
    median_spacing_minimum: float = 12.0
    calibrated_blend: float = 0.50


def apply_near_count_repair(
    points_xy: np.ndarray,
    reliability: np.ndarray,
    calibrated_count: int,
    *,
    coordinate_scale: float = 1.0,
    policy: NearCountRepairPolicy = NearCountRepairPolicy(),
) -> tuple[np.ndarray, dict[str, float | int | bool]]:
    """Return the retained points and auditable gate diagnostics."""

    points = np.asarray(points_xy, dtype=np.float32).reshape(-1, 2)
    scores = np.asarray(reliability, dtype=np.float32).reshape(-1)
    if len(points) != len(scores):
        raise ValueError("points and reliability must have equal length")
    raw = len(points)
    calibrated = max(0, int(calibrated_count))
    if raw > 1:
        normalized = points * float(coordinate_scale)
        median_spacing = float(np.median(cKDTree(normalized).query(normalized, k=2)[0][:, 1]))
    else:
        median_spacing = 256.0
    reliability_gap = float((raw - scores.sum()) / max(raw, 1))
    reduction = raw - calibrated
    reduction_fraction = reduction / max(raw, 1)
    activated = bool(
        raw > 0
        and raw <= policy.raw_count_maximum
        and median_spacing >= policy.median_spacing_minimum
        and reliability_gap >= policy.reliability_gap_minimum
        and reduction >= policy.calibrated_reduction_minimum
        and reduction_fraction >= policy.calibrated_reduction_fraction_minimum
    )
    target = raw
    if activated:
        target = int(np.rint(raw + policy.calibrated_blend * (calibrated - raw)))
        target = max(0, min(raw, target))
    # Stable sorting makes exact replay deterministic when scores tie.
    retain = np.argsort(-scores, kind="stable")[:target]
    retain.sort()
    diagnostics: dict[str, float | int | bool] = {
        "activated": activated,
        "raw_count": raw,
        "calibrated_count": calibrated,
        "output_count": int(target),
        "removed_count": int(raw - target),
        "median_spacing": median_spacing,
        "reliability_gap": reliability_gap,
        "calibrated_reduction": int(reduction),
        "calibrated_reduction_fraction": float(reduction_fraction),
    }
    return points[retain], diagnostics


__all__ = ["NearCountRepairPolicy", "apply_near_count_repair"]
