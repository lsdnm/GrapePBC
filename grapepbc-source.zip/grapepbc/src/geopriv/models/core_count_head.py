"""Small frozen-feature head for core-owned berry count calibration."""

from __future__ import annotations

import torch
from torch import Tensor, nn


class CoreCountHead(nn.Module):
    """Predict core occupancy and a conditional log-count.

    The high-resolution localizer remains frozen.  This head receives pooled
    rich features and deterministic centre-score descriptors.  Occupancy is
    separated from conditional count so genuinely empty cores are not forced
    to emit a berry, while non-empty cores retain a stable positive count.
    """

    def __init__(
        self,
        feature_dim: int,
        hidden_dim: int = 64,
        bottleneck_dim: int = 32,
        dropout: float = 0.10,
    ) -> None:
        super().__init__()
        if feature_dim <= 0 or hidden_dim <= 0 or bottleneck_dim <= 0:
            raise ValueError("feature dimensions must be positive")
        if not 0.0 <= dropout < 1.0:
            raise ValueError("dropout must be in [0, 1)")
        self.feature_dim = int(feature_dim)
        self.trunk = nn.Sequential(
            nn.Linear(feature_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, bottleneck_dim),
            nn.SiLU(),
        )
        self.occupancy = nn.Linear(bottleneck_dim, 1)
        self.log_count = nn.Linear(bottleneck_dim, 1)

    def forward(self, features: Tensor) -> dict[str, Tensor]:
        if features.ndim != 2 or features.shape[1] != self.feature_dim:
            raise ValueError(
                f"expected [N,{self.feature_dim}] features, got {tuple(features.shape)}"
            )
        hidden = self.trunk(features)
        return {
            "occupancy_logits": self.occupancy(hidden).squeeze(1),
            "log_count": self.log_count(hidden).squeeze(1),
        }


def decode_core_counts(
    occupancy_logits: Tensor,
    log_count: Tensor,
    candidate_counts: Tensor,
    *,
    occupancy_threshold: float = 0.5,
) -> Tensor:
    """Convert head outputs into non-negative candidate-bounded core counts."""

    if occupancy_logits.shape != log_count.shape:
        raise ValueError("occupancy and count outputs must have identical shapes")
    if candidate_counts.shape != log_count.shape:
        raise ValueError("candidate_counts must match output shape")
    if not 0.0 < occupancy_threshold < 1.0:
        raise ValueError("occupancy_threshold must be strictly between zero and one")
    candidates = candidate_counts.to(dtype=torch.long).clamp_min(0)
    occupied = occupancy_logits.sigmoid() >= float(occupancy_threshold)
    # Bounding log-count avoids numerical overflow without restricting the
    # deployable candidate cap.  Occupied cores emit at least one point when a
    # candidate exists; empty cores emit zero.
    conditional = torch.expm1(log_count.clamp(min=0.0, max=10.0)).round().long()
    conditional = conditional.clamp_min(1)
    decoded = torch.where(occupied & (candidates > 0), conditional, 0)
    return torch.minimum(decoded, candidates)


__all__ = ["CoreCountHead", "decode_core_counts"]
