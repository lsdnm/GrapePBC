"""Large-context residual offsets for precise centres on large berries."""

from __future__ import annotations

import torch
from torch import Tensor, nn
from torchvision.ops import roi_align


class LargeContextOffsetRefiner(nn.Module):
    """Predict a bounded residual displacement without changing point count.

    Texture or specular peaks on a close berry can be tens of stride-2 cells
    away from its annotated centre. The ordinary 3x3 offset head cannot see
    that geometry. Dilated depthwise branches provide the missing context at
    low parameter cost. The final projection is zero initialized, making the
    untrained module an exact coordinate no-op.
    """

    def __init__(self, channels: int = 64, max_displacement_cells: float = 32.0) -> None:
        super().__init__()
        self.max_displacement_cells = float(max_displacement_cells)
        self.branches = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Conv2d(
                        channels,
                        channels,
                        3,
                        padding=dilation,
                        dilation=dilation,
                        groups=channels,
                        bias=False,
                    ),
                    nn.GroupNorm(8, channels),
                    nn.SiLU(inplace=True),
                )
                for dilation in (1, 4, 8, 16)
            ]
        )
        self.fuse = nn.Sequential(
            nn.Conv2d(4 * channels, channels, 1, bias=False),
            nn.GroupNorm(8, channels),
            nn.SiLU(inplace=True),
        )
        self.output = nn.Conv2d(channels, 2, 1)
        nn.init.zeros_(self.output.weight)
        nn.init.zeros_(self.output.bias)

    def forward(self, feature: Tensor) -> Tensor:
        raw = self.output(self.fuse(torch.cat([branch(feature) for branch in self.branches], dim=1)))
        limit = self.max_displacement_cells
        return limit * torch.tanh(raw / limit)


class PointPatchCenterRegressor(nn.Module):
    """Regress a centre displacement from a patch around a selected peak.

    Unlike a dense offset convolution, this head pools a wide, point-centred
    feature window before making one displacement decision. It is intended for
    the large-berry case where a texture peak and the geometric centre are far
    apart. The zero-initialized output keeps an untrained head as a no-op.
    """

    def __init__(
        self,
        channels: int = 64,
        *,
        patch_half_width_cells: float = 24.0,
        pooled_size: int = 9,
        max_displacement_cells: float = 32.0,
    ) -> None:
        super().__init__()
        self.patch_half_width_cells = float(patch_half_width_cells)
        self.pooled_size = int(pooled_size)
        self.max_displacement_cells = float(max_displacement_cells)
        self.encoder = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, groups=channels, bias=False),
            nn.GroupNorm(8, channels),
            nn.SiLU(inplace=True),
            nn.Conv2d(channels, channels, 1, bias=False),
            nn.GroupNorm(8, channels),
            nn.SiLU(inplace=True),
            nn.AdaptiveAvgPool2d(1),
        )
        self.hidden = nn.Sequential(nn.Linear(channels, 32), nn.SiLU(inplace=True))
        self.output = nn.Linear(32, 2)
        nn.init.zeros_(self.output.weight)
        nn.init.zeros_(self.output.bias)

    def forward(self, feature: Tensor, cells_xy: Tensor) -> Tensor:
        if feature.shape[0] != 1:
            raise ValueError("point patch regression currently expects batch size one")
        cells_xy = cells_xy.reshape(-1, 2).to(device=feature.device, dtype=feature.dtype)
        if not len(cells_xy):
            return feature.new_zeros((0, 2))
        half = self.patch_half_width_cells
        boxes = torch.cat((cells_xy - half, cells_xy + half), dim=1)
        patches = roi_align(
            feature,
            [boxes],
            output_size=(self.pooled_size, self.pooled_size),
            spatial_scale=1.0,
            sampling_ratio=2,
            aligned=True,
        )
        raw = self.output(self.hidden(self.encoder(patches).flatten(1)))
        limit = self.max_displacement_cells
        return limit * torch.tanh(raw / limit)


class SpatialPointPatchCenterRegressor(nn.Module):
    """Patch regressor that retains a coarse spatial layout before its MLP."""

    def __init__(
        self,
        channels: int = 64,
        *,
        patch_half_width_cells: float = 24.0,
        pooled_size: int = 9,
        spatial_size: int = 3,
        max_displacement_cells: float = 32.0,
    ) -> None:
        super().__init__()
        self.patch_half_width_cells = float(patch_half_width_cells)
        self.pooled_size = int(pooled_size)
        self.spatial_size = int(spatial_size)
        self.max_displacement_cells = float(max_displacement_cells)
        self.encoder = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, groups=channels, bias=False),
            nn.GroupNorm(8, channels),
            nn.SiLU(inplace=True),
            nn.Conv2d(channels, channels, 1, bias=False),
            nn.GroupNorm(8, channels),
            nn.SiLU(inplace=True),
            nn.AdaptiveAvgPool2d(spatial_size),
        )
        self.hidden = nn.Sequential(nn.Linear(channels * spatial_size * spatial_size, 64), nn.SiLU(inplace=True))
        self.output = nn.Linear(64, 2)
        nn.init.zeros_(self.output.weight)
        nn.init.zeros_(self.output.bias)

    def forward(self, feature: Tensor, cells_xy: Tensor) -> Tensor:
        if feature.shape[0] != 1:
            raise ValueError("point patch regression currently expects batch size one")
        cells_xy = cells_xy.reshape(-1, 2).to(device=feature.device, dtype=feature.dtype)
        if not len(cells_xy):
            return feature.new_zeros((0, 2))
        half = self.patch_half_width_cells
        boxes = torch.cat((cells_xy - half, cells_xy + half), dim=1)
        patches = roi_align(feature, [boxes], output_size=(self.pooled_size, self.pooled_size), spatial_scale=1.0, sampling_ratio=2, aligned=True)
        raw = self.output(self.hidden(self.encoder(patches).flatten(1)))
        limit = self.max_displacement_cells
        return limit * torch.tanh(raw / limit)


class UniqueCenterProposalHead(nn.Module):
    """Large-context residual score and offset head for one-centre proposals."""

    def __init__(self, channels: int = 64, max_offset_delta_cells: float = 32.0) -> None:
        super().__init__()
        self.max_offset_delta_cells = float(max_offset_delta_cells)
        self.branches = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(channels, channels, 3, padding=d, dilation=d, groups=channels, bias=False),
                nn.GroupNorm(8, channels),
                nn.SiLU(inplace=True),
            ) for d in (1, 4, 8, 16)
        ])
        self.fuse = nn.Sequential(
            nn.Conv2d(4 * channels, channels, 1, bias=False),
            nn.GroupNorm(8, channels),
            nn.SiLU(inplace=True),
        )
        self.output = nn.Conv2d(channels, 3, 1)
        nn.init.zeros_(self.output.weight); nn.init.zeros_(self.output.bias)

    def forward(self, feature: Tensor) -> tuple[Tensor, Tensor]:
        raw = self.output(self.fuse(torch.cat([branch(feature) for branch in self.branches], dim=1)))
        limit = self.max_offset_delta_cells
        return raw[:, :1], limit * torch.tanh(raw[:, 1:] / limit)


__all__ = ["LargeContextOffsetRefiner", "PointPatchCenterRegressor", "SpatialPointPatchCenterRegressor", "UniqueCenterProposalHead"]
