"""Core/halo tiling and counterfactual resolution-utility primitives.

The core rectangles form a non-overlapping partition of the image.  A tile's
larger context rectangle is used only as model input; detections are retained
only when their centres lie in that tile's core.  This ownership rule makes
high-resolution reprocessing composable without NMS-based boundary heuristics.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import math
from typing import Iterable, Mapping, Sequence

import numpy as np


@dataclass(frozen=True, slots=True)
class CoreHaloTile:
    """One half-open core rectangle and its clipped context rectangle."""

    tile_id: int
    row: int
    column: int
    core_x0: int
    core_y0: int
    core_x1: int
    core_y1: int
    context_x0: int
    context_y0: int
    context_x1: int
    context_y1: int

    @property
    def core_area(self) -> int:
        return (self.core_x1 - self.core_x0) * (self.core_y1 - self.core_y0)

    @property
    def context_area(self) -> int:
        return (self.context_x1 - self.context_x0) * (
            self.context_y1 - self.context_y0
        )

    def owns(self, x: float, y: float) -> bool:
        return (
            self.core_x0 <= x < self.core_x1
            and self.core_y0 <= y < self.core_y1
        )

    def to_dict(self) -> dict[str, int]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class TileUtility:
    """Counterfactual benefit of replacing a low-res tile count by high-res."""

    tile_id: int
    true_count: int
    low_count: int
    high_count: int
    low_absolute_error: int
    high_absolute_error: int
    error_reduction: int
    count_correction: int

    def to_dict(self) -> dict[str, int]:
        return asdict(self)


def _positive_int(value: int, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError(f"{name} must be a positive integer")
    return value


def make_core_halo_tiles(
    width: int,
    height: int,
    *,
    core_size: int,
    halo: int,
) -> tuple[CoreHaloTile, ...]:
    """Partition an image into row-major cores with clipped halo context."""

    width = _positive_int(width, "width")
    height = _positive_int(height, "height")
    core_size = _positive_int(core_size, "core_size")
    if isinstance(halo, bool) or not isinstance(halo, int) or halo < 0:
        raise ValueError("halo must be a non-negative integer")

    tiles: list[CoreHaloTile] = []
    tile_id = 0
    for row, core_y0 in enumerate(range(0, height, core_size)):
        core_y1 = min(core_y0 + core_size, height)
        for column, core_x0 in enumerate(range(0, width, core_size)):
            core_x1 = min(core_x0 + core_size, width)
            tiles.append(
                CoreHaloTile(
                    tile_id=tile_id,
                    row=row,
                    column=column,
                    core_x0=core_x0,
                    core_y0=core_y0,
                    core_x1=core_x1,
                    core_y1=core_y1,
                    context_x0=max(0, core_x0 - halo),
                    context_y0=max(0, core_y0 - halo),
                    context_x1=min(width, core_x1 + halo),
                    context_y1=min(height, core_y1 + halo),
                )
            )
            tile_id += 1
    validate_core_partition(tiles, width=width, height=height)
    return tuple(tiles)


def validate_core_partition(
    tiles: Sequence[CoreHaloTile], *, width: int, height: int
) -> None:
    """Reject gaps, overlaps, invalid IDs and out-of-frame rectangles."""

    width = _positive_int(width, "width")
    height = _positive_int(height, "height")
    if not tiles:
        raise ValueError("tiles cannot be empty")
    expected_ids = list(range(len(tiles)))
    if [tile.tile_id for tile in tiles] != expected_ids:
        raise ValueError("tile IDs must be unique, contiguous and row-major")

    total_core_area = 0
    for tile in tiles:
        if not (
            0 <= tile.core_x0 < tile.core_x1 <= width
            and 0 <= tile.core_y0 < tile.core_y1 <= height
        ):
            raise ValueError(f"tile {tile.tile_id} has an invalid core rectangle")
        if not (
            0 <= tile.context_x0 <= tile.core_x0
            and tile.core_x1 <= tile.context_x1 <= width
            and 0 <= tile.context_y0 <= tile.core_y0
            and tile.core_y1 <= tile.context_y1 <= height
        ):
            raise ValueError(f"tile {tile.tile_id} has an invalid context rectangle")
        total_core_area += tile.core_area

    if total_core_area != width * height:
        raise ValueError("tile cores do not cover exactly one image area")

    # Equal total area alone does not exclude an overlap paired with a gap.
    for first_index, first in enumerate(tiles):
        for second in tiles[first_index + 1 :]:
            overlap_width = min(first.core_x1, second.core_x1) - max(
                first.core_x0, second.core_x0
            )
            overlap_height = min(first.core_y1, second.core_y1) - max(
                first.core_y0, second.core_y0
            )
            if overlap_width > 0 and overlap_height > 0:
                raise ValueError(
                    f"tile cores {first.tile_id} and {second.tile_id} overlap"
                )


def _point_array(points_xy: np.ndarray | Sequence[Sequence[float]]) -> np.ndarray:
    points = np.asarray(points_xy, dtype=np.float64)
    if points.size == 0:
        return np.empty((0, 2), dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 2:
        raise ValueError(f"points must have shape (N, 2), got {points.shape}")
    if not np.isfinite(points).all():
        raise ValueError("points must be finite")
    return points


def assign_points_to_tiles(
    points_xy: np.ndarray | Sequence[Sequence[float]],
    tiles: Sequence[CoreHaloTile],
    *,
    strict: bool = True,
) -> np.ndarray:
    """Return each point's unique core owner, or -1 outside all cores."""

    points = _point_array(points_xy)
    owners = np.full(len(points), -1, dtype=np.int64)
    for tile in tiles:
        owned = (
            (points[:, 0] >= tile.core_x0)
            & (points[:, 0] < tile.core_x1)
            & (points[:, 1] >= tile.core_y0)
            & (points[:, 1] < tile.core_y1)
        )
        if np.any(owned & (owners >= 0)):
            raise ValueError("a point is owned by more than one core")
        owners[owned] = tile.tile_id
    if strict and np.any(owners < 0):
        bad = np.flatnonzero(owners < 0)[:5].tolist()
        raise ValueError(f"points outside the core partition at indices {bad}")
    return owners


def _nonnegative_count(value: int, *, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, np.integer)) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer")
    return int(value)


def compute_tile_utilities(
    true_counts: Sequence[int],
    low_counts: Sequence[int],
    high_counts: Sequence[int],
) -> tuple[TileUtility, ...]:
    """Compute u_i = |low_i-y_i| - |high_i-y_i| for every tile."""

    if not (len(true_counts) == len(low_counts) == len(high_counts)):
        raise ValueError("true, low and high count sequences must have equal length")
    rows: list[TileUtility] = []
    for tile_id, (truth_raw, low_raw, high_raw) in enumerate(
        zip(true_counts, low_counts, high_counts, strict=True)
    ):
        truth = _nonnegative_count(truth_raw, name="true_count")
        low = _nonnegative_count(low_raw, name="low_count")
        high = _nonnegative_count(high_raw, name="high_count")
        low_error = abs(low - truth)
        high_error = abs(high - truth)
        rows.append(
            TileUtility(
                tile_id=tile_id,
                true_count=truth,
                low_count=low,
                high_count=high,
                low_absolute_error=low_error,
                high_absolute_error=high_error,
                error_reduction=low_error - high_error,
                count_correction=high - low,
            )
        )
    return tuple(rows)


def stable_topk(scores: Mapping[int, float], budget: int) -> tuple[int, ...]:
    """Select exact Top-K with a deterministic ascending-ID tie break."""

    if isinstance(budget, bool) or not isinstance(budget, int) or budget < 0:
        raise ValueError("budget must be a non-negative integer")
    if budget > len(scores):
        raise ValueError("budget cannot exceed the number of candidate tiles")
    checked: list[tuple[int, float]] = []
    for tile_id, score_raw in scores.items():
        if isinstance(tile_id, bool) or not isinstance(tile_id, int) or tile_id < 0:
            raise ValueError("tile IDs must be non-negative integers")
        score = float(score_raw)
        if not math.isfinite(score):
            raise ValueError("routing scores must be finite")
        checked.append((tile_id, score))
    checked.sort(key=lambda item: (-item[1], item[0]))
    return tuple(tile_id for tile_id, _ in checked[:budget])


def select_density_topk(low_counts: Sequence[int], budget: int) -> tuple[int, ...]:
    """Density heuristic: spend the budget on the most low-res detections."""

    scores = {
        tile_id: float(_nonnegative_count(count, name="low_count"))
        for tile_id, count in enumerate(low_counts)
    }
    return stable_topk(scores, budget)


def select_oracle_topk(
    utilities: Sequence[TileUtility], budget: int
) -> tuple[int, ...]:
    """Upper-bound selector using unavailable ground-truth utility labels."""

    return stable_topk(
        {row.tile_id: float(row.error_reduction) for row in utilities}, budget
    )


def select_random(tile_count: int, budget: int, *, seed: int) -> tuple[int, ...]:
    """Deterministic random-budget control."""

    tile_count = _positive_int(tile_count, "tile_count")
    if isinstance(budget, bool) or not isinstance(budget, int) or not 0 <= budget <= tile_count:
        raise ValueError("budget must lie between zero and tile_count")
    generator = np.random.default_rng(seed)
    return tuple(int(value) for value in generator.permutation(tile_count)[:budget])


def revised_count(
    low_counts: Sequence[int],
    high_counts: Sequence[int],
    selected_tile_ids: Iterable[int],
) -> int:
    """Replace selected low-res core counts by their high-res alternatives."""

    if len(low_counts) != len(high_counts):
        raise ValueError("low and high count sequences must have equal length")
    low = [_nonnegative_count(value, name="low_count") for value in low_counts]
    high = [_nonnegative_count(value, name="high_count") for value in high_counts]
    selected = tuple(selected_tile_ids)
    if len(set(selected)) != len(selected):
        raise ValueError("selected tile IDs must be unique")
    result = sum(low)
    for tile_id in selected:
        if isinstance(tile_id, bool) or not isinstance(tile_id, int):
            raise ValueError("selected tile IDs must be integers")
        if not 0 <= tile_id < len(low):
            raise ValueError(f"selected tile ID out of range: {tile_id}")
        result += high[tile_id] - low[tile_id]
    return result


def fuse_core_owned_points(
    low_points_xy: np.ndarray | Sequence[Sequence[float]],
    high_points_by_tile: Mapping[int, np.ndarray | Sequence[Sequence[float]]],
    tiles: Sequence[CoreHaloTile],
    selected_tile_ids: Iterable[int],
) -> np.ndarray:
    """Replace low-res core points with context-cropped high-res predictions."""

    low_points = _point_array(low_points_xy)
    low_owners = assign_points_to_tiles(low_points, tiles)
    selected = tuple(selected_tile_ids)
    if len(set(selected)) != len(selected):
        raise ValueError("selected tile IDs must be unique")
    tile_map = {tile.tile_id: tile for tile in tiles}
    selected_set = set(selected)
    unknown = selected_set.difference(tile_map)
    if unknown:
        raise ValueError(f"unknown selected tile IDs: {sorted(unknown)}")
    missing = selected_set.difference(high_points_by_tile)
    if missing:
        raise ValueError(f"missing high-res predictions for tiles: {sorted(missing)}")

    parts: list[np.ndarray] = [low_points[~np.isin(low_owners, list(selected_set))]]
    for tile_id in selected:
        tile = tile_map[tile_id]
        high_points = _point_array(high_points_by_tile[tile_id])
        owned = (
            (high_points[:, 0] >= tile.core_x0)
            & (high_points[:, 0] < tile.core_x1)
            & (high_points[:, 1] >= tile.core_y0)
            & (high_points[:, 1] < tile.core_y1)
        )
        parts.append(high_points[owned])
    return np.concatenate(parts, axis=0) if parts else np.empty((0, 2), dtype=np.float64)


def high_resolution_processing_load(
    selected_tile_ids: Iterable[int],
    tiles: Sequence[CoreHaloTile],
    *,
    width: int,
    height: int,
) -> float:
    """Sum processed context pixels divided by full-image pixels.

    Overlapping halo pixels are deliberately charged more than once because
    the model processes them once per selected crop.
    """

    image_area = _positive_int(width, "width") * _positive_int(height, "height")
    tile_map = {tile.tile_id: tile for tile in tiles}
    selected = tuple(selected_tile_ids)
    if len(set(selected)) != len(selected):
        raise ValueError("selected tile IDs must be unique")
    try:
        processed = sum(tile_map[tile_id].context_area for tile_id in selected)
    except KeyError as exc:
        raise ValueError(f"unknown selected tile ID: {exc.args[0]}") from exc
    return processed / image_area


def unique_high_resolution_coverage(
    selected_tile_ids: Iterable[int],
    tiles: Sequence[CoreHaloTile],
    *,
    width: int,
    height: int,
) -> float:
    """Union area of selected context rectangles divided by image area."""

    image_area = _positive_int(width, "width") * _positive_int(height, "height")
    tile_map = {tile.tile_id: tile for tile in tiles}
    selected = tuple(selected_tile_ids)
    if len(set(selected)) != len(selected):
        raise ValueError("selected tile IDs must be unique")
    try:
        rectangles = [tile_map[tile_id] for tile_id in selected]
    except KeyError as exc:
        raise ValueError(f"unknown selected tile ID: {exc.args[0]}") from exc
    if not rectangles:
        return 0.0

    x_edges = sorted(
        {edge for tile in rectangles for edge in (tile.context_x0, tile.context_x1)}
    )
    union_area = 0
    for x0, x1 in zip(x_edges, x_edges[1:]):
        intervals = sorted(
            (tile.context_y0, tile.context_y1)
            for tile in rectangles
            if tile.context_x0 < x1 and tile.context_x1 > x0
        )
        if not intervals:
            continue
        covered_y = 0
        current_start, current_end = intervals[0]
        for start, end in intervals[1:]:
            if start > current_end:
                covered_y += current_end - current_start
                current_start, current_end = start, end
            else:
                current_end = max(current_end, end)
        covered_y += current_end - current_start
        union_area += (x1 - x0) * covered_y
    return union_area / image_area
