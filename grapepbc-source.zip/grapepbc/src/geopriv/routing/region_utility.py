"""Lightweight signed local-count-utility regressor for adaptive CRU."""
import torch
from torch import nn


class RegionUtilityRouter(nn.Module):
    def __init__(self, features: int = 18, hidden: int = 64) -> None:
        super().__init__()
        self.network = nn.Sequential(nn.Linear(features, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden // 2), nn.ReLU(), nn.Linear(hidden // 2, 1))

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        return self.network(inputs).squeeze(-1)
