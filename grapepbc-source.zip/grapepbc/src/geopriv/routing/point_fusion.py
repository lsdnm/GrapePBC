"""Count-conserving point realization for adaptive LR/HR routing.

The functions in this module do not estimate a new count.  They realize an
already frozen integer count as a native-coordinate point set while preserving
non-overlapping core ownership and explicit point provenance.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence

import numpy as np

from .counterfactual import CoreHaloTile, assign_points_to_tiles


LR_SOURCE = np.int8(0)
SPARSE_HR_SOURCE = np.int8(1)
STABLE_FULL_HR_SOURCE = np.int8(2)
DENSITY_FULL_HR_SOURCE = np.int8(3)


@dataclass(frozen=True)
class PointFusionResult:
    points: np.ndarray
    sources: np.ndarray
    owners: np.ndarray
    expected_count: int
    exact_duplicate_count: int


def _points(value: np.ndarray | Sequence[Sequence[float]]) -> np.ndarray:
    array = np.asarray(value, dtype=np.float32)
    if array.size == 0:
        return np.empty((0, 2), dtype=np.float32)
    if array.ndim != 2 or array.shape[1] != 2 or not np.isfinite(array).all():
        raise ValueError("points must be a finite array with shape (N, 2)")
    return array


def _scores(value: np.ndarray | Sequence[float], count: int) -> np.ndarray:
    array = np.asarray(value, dtype=np.float32).reshape(-1)
    if len(array) != count or not np.isfinite(array).all():
        raise ValueError("scores must be finite and aligned with points")
    return array


def exact_duplicate_count(points: np.ndarray) -> int:
    points = _points(points)
    if not len(points):
        return 0
    # Exact float32 coordinate equality detects implementation duplication
    # without merging legitimately close berry centres.
    return int(len(points) - len(np.unique(points, axis=0)))


def _validate_selected(selected: Sequence[int], tiles: Sequence[CoreHaloTile]) -> tuple[int, ...]:
    values = tuple(int(value) for value in selected)
    if len(values) != len(set(values)):
        raise ValueError("selected tile IDs must be unique")
    valid = {tile.tile_id for tile in tiles}
    unknown = set(values).difference(valid)
    if unknown:
        raise ValueError(f"unknown selected tile IDs: {sorted(unknown)}")
    return values


def fuse_sparse_core_points(
    low_points_xy: np.ndarray | Sequence[Sequence[float]],
    tiles: Sequence[CoreHaloTile],
    selected_tile_ids: Sequence[int],
    requested_counts_by_tile: Mapping[int, int],
    high_candidates_by_tile: Mapping[int, np.ndarray],
    high_scores_by_tile: Mapping[int, np.ndarray],
) -> PointFusionResult:
    """Replace selected LR-owned cores by exact Top-K HR candidates."""

    low = _points(low_points_xy)
    low_owners = assign_points_to_tiles(low, tiles, strict=True)
    selected = _validate_selected(selected_tile_ids, tiles)
    if set(requested_counts_by_tile) != set(selected):
        raise ValueError("requested-count keys must equal selected tile IDs")
    if set(selected).difference(high_candidates_by_tile) or set(selected).difference(high_scores_by_tile):
        raise ValueError("selected tiles require HR candidates and scores")

    selected_set = set(selected)
    keep = ~np.isin(low_owners, np.asarray(selected, dtype=np.int64))
    point_parts = [low[keep]]
    source_parts = [np.full(int(keep.sum()), LR_SOURCE, dtype=np.int8)]
    owner_parts = [low_owners[keep]]
    expected = int(keep.sum())
    tile_map = {tile.tile_id: tile for tile in tiles}

    for tile_id in selected:
        requested = int(requested_counts_by_tile[tile_id])
        if requested < 0:
            raise ValueError("requested core count must be non-negative")
        candidates = _points(high_candidates_by_tile[tile_id])
        scores = _scores(high_scores_by_tile[tile_id], len(candidates))
        tile = tile_map[tile_id]
        owned = (
            (candidates[:, 0] >= tile.core_x0)
            & (candidates[:, 0] < tile.core_x1)
            & (candidates[:, 1] >= tile.core_y0)
            & (candidates[:, 1] < tile.core_y1)
        )
        candidates, scores = candidates[owned], scores[owned]
        if requested > len(candidates):
            raise ValueError(
                f"tile {tile_id} has {len(candidates)} owned candidates for requested count {requested}"
            )
        order = np.argsort(-scores, kind="stable")[:requested]
        chosen = candidates[order]
        point_parts.append(chosen)
        source_parts.append(np.full(len(chosen), SPARSE_HR_SOURCE, dtype=np.int8))
        owner_parts.append(np.full(len(chosen), tile_id, dtype=np.int64))
        expected += requested

    points = np.concatenate(point_parts).astype(np.float32, copy=False)
    sources = np.concatenate(source_parts).astype(np.int8, copy=False)
    owners = np.concatenate(owner_parts).astype(np.int64, copy=False)
    if len(points) != expected:
        raise AssertionError("sparse point fusion violated count conservation")
    if len(points) and not np.array_equal(assign_points_to_tiles(points, tiles, strict=True), owners):
        raise AssertionError("stored point ownership does not match geometry")
    return PointFusionResult(points, sources, owners, expected, exact_duplicate_count(points))


def interpolate_full_hr_points(
    stable_points_xy: np.ndarray | Sequence[Sequence[float]],
    density_points_xy: np.ndarray | Sequence[Sequence[float]],
    density_scores: np.ndarray | Sequence[float],
    requested_count: int,
    *,
    match_radius: float = 8.0,
) -> tuple[np.ndarray, np.ndarray]:
    """Move a stable HR point set toward a density point set without duplicates.

    The requested count must lie between the two expert counts, as it does for
    the frozen conservative interpolation gate.  Stable points are retained by
    default.  When the count increases, the highest-scored unmatched density
    points are added; when it decreases, stable points unsupported by a unique
    density match are removed first.
    """

    stable = _points(stable_points_xy)
    density = _points(density_points_xy)
    scores = _scores(density_scores, len(density))
    requested = int(requested_count)
    if requested < min(len(stable), len(density)) or requested > max(len(stable), len(density)):
        raise ValueError("requested count must lie between stable and density counts")
    if not np.isfinite(match_radius) or match_radius <= 0:
        raise ValueError("match_radius must be positive and finite")
    if requested == len(stable):
        return stable.copy(), np.full(len(stable), STABLE_FULL_HR_SOURCE, dtype=np.int8)

    # Score-prioritized one-to-one matching.  This is deterministic and gives
    # the most confident density candidates first access to stable identities.
    matched_stable: dict[int, tuple[int, float]] = {}
    matched_density: set[int] = set()
    available_stable = np.ones(len(stable), dtype=bool)
    radius2 = float(match_radius) ** 2
    for density_index in np.argsort(-scores, kind="stable"):
        if not len(stable):
            break
        distance2 = np.square(stable - density[density_index]).sum(axis=1)
        distance2[~available_stable] = np.inf
        stable_index = int(np.argmin(distance2))
        if float(distance2[stable_index]) <= radius2:
            available_stable[stable_index] = False
            matched_stable[stable_index] = (int(density_index), float(scores[density_index]))
            matched_density.add(int(density_index))

    if requested > len(stable):
        needed = requested - len(stable)
        extra = [
            int(index) for index in np.argsort(-scores, kind="stable")
            if int(index) not in matched_density
        ]
        if len(extra) < needed:
            raise ValueError("insufficient unmatched density points for requested increase")
        add = density[np.asarray(extra[:needed], dtype=np.int64)]
        points = np.concatenate((stable, add)).astype(np.float32, copy=False)
        sources = np.concatenate(
            (
                np.full(len(stable), STABLE_FULL_HR_SOURCE, dtype=np.int8),
                np.full(len(add), DENSITY_FULL_HR_SOURCE, dtype=np.int8),
            )
        )
        return points, sources

    remove = len(stable) - requested
    unmatched_stable = [index for index in range(len(stable)) if index not in matched_stable]
    # If additional removals are required, discard stable identities supported
    # only by the weakest matched density candidates.
    weakly_supported = [
        index for index, _ in sorted(matched_stable.items(), key=lambda item: (item[1][1], item[0]))
    ]
    removal_order = unmatched_stable + weakly_supported
    if len(removal_order) < remove:
        raise ValueError("insufficient stable points for requested decrease")
    keep = np.ones(len(stable), dtype=bool)
    keep[np.asarray(removal_order[:remove], dtype=np.int64)] = False
    return (
        stable[keep].astype(np.float32, copy=False),
        np.full(int(keep.sum()), STABLE_FULL_HR_SOURCE, dtype=np.int8),
    )


def validate_native_point_set(
    points_xy: np.ndarray | Sequence[Sequence[float]],
    *,
    width: int,
    height: int,
    expected_count: int,
) -> dict[str, int | bool]:
    points = _points(points_xy)
    if int(expected_count) < 0 or len(points) != int(expected_count):
        raise ValueError("point count does not equal the frozen count")
    if len(points):
        inside = (
            (points[:, 0] >= 0)
            & (points[:, 0] < int(width))
            & (points[:, 1] >= 0)
            & (points[:, 1] < int(height))
        )
        if not bool(inside.all()):
            raise ValueError("native point lies outside the image")
    duplicates = exact_duplicate_count(points)
    return {
        "count_conserved": True,
        "all_points_in_bounds": True,
        "exact_duplicate_count": duplicates,
    }
