"""Cluster-first, scale-adaptive CRU regions with disjoint pixel ownership.

The region geometry uses predicted masks and RGB, never ground-truth counts.
Small bunches receive tight contexts even when LR detects zero berries.
Unsegmented image pixels retain grid-region coverage rather than disappearing.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Sequence, Mapping

import numpy as np
from PIL import Image

from geopriv.counting.per_cluster import ClusterRegion


@dataclass(frozen=True)
class RefinementRegion:
    region_id: int
    cluster_id: str | None
    context_xyxy: tuple[int, int, int, int]
    owned_pixels: int
    cluster_confidence: float


@dataclass(frozen=True)
class RegionPartition:
    ownership: np.ndarray
    regions: tuple[RefinementRegion, ...]

    def owners(self, points: np.ndarray) -> np.ndarray:
        points = np.asarray(points, dtype=np.float64)
        if points.ndim != 2 or points.shape[1] != 2 or not np.isfinite(points).all():
            raise ValueError("points must be a finite (N, 2) array")
        xy = np.floor(points).astype(np.int64)
        h, w = self.ownership.shape
        valid = (xy[:, 0] >= 0) & (xy[:, 0] < w) & (xy[:, 1] >= 0) & (xy[:, 1] < h)
        result = np.full(len(points), -1, dtype=np.int32)
        result[valid] = self.ownership[xy[valid, 1], xy[valid, 0]]
        return result


def _context(bounds: tuple[int, int, int, int], width: int, height: int,
             minimum: int, halo: int) -> tuple[int, int, int, int]:
    x0, y0, x1, y1 = bounds
    side = max(minimum, x1 - x0 + 2 * halo, y1 - y0 + 2 * halo)
    left = max(0, min((x0 + x1 - side) // 2, max(0, width - side)))
    top = max(0, min((y0 + y1 - side) // 2, max(0, height - side)))
    return left, top, min(width, left + side), min(height, top + side)


def build_region_partition(width: int, height: int, clusters: Sequence[ClusterRegion], *,
                           cluster_core_size: int = 768, background_core_size: int = 1024,
                           minimum_context: int = 256, halo: int = 96) -> RegionPartition:
    """Partition every pixel once; cap crop size, not the number of bunches."""
    if min(width, height, cluster_core_size, background_core_size, minimum_context) <= 0 or halo < 0:
        raise ValueError("invalid region geometry")
    if any(c.mask.shape != (height, width) for c in clusters):
        raise ValueError("cluster masks must match image dimensions")
    if len({c.cluster_id for c in clusters}) != len(clusters):
        raise ValueError("duplicate cluster IDs")
    owner = np.full((height, width), -1, dtype=np.int32)
    regions: list[RefinementRegion] = []

    def append(mask: np.ndarray, x0: int, y0: int, cluster: ClusterRegion | None) -> None:
        yy, xx = np.nonzero(mask)
        if not len(xx):
            return
        bounds = (x0 + int(xx.min()), y0 + int(yy.min()),
                  x0 + int(xx.max()) + 1, y0 + int(yy.max()) + 1)
        context = _context(bounds, width, height, minimum_context, halo)
        region_id = len(regions)
        owner[y0:y0 + mask.shape[0], x0:x0 + mask.shape[1]][mask] = region_id
        regions.append(RefinementRegion(region_id, cluster.cluster_id if cluster else None,
                                        context, len(xx), cluster.confidence if cluster else 0.0))

    ordered = sorted(enumerate(clusters), key=lambda pair: (-pair[1].confidence,
                       int(pair[1].mask.sum()), pair[0]))
    for _, cluster in ordered:
        ys, xs = np.nonzero(cluster.mask)
        for y0 in range(int(ys.min()), int(ys.max()) + 1, cluster_core_size):
            for x0 in range(int(xs.min()), int(xs.max()) + 1, cluster_core_size):
                mask = cluster.mask[y0:y0 + cluster_core_size, x0:x0 + cluster_core_size]
                available = mask & (owner[y0:y0 + mask.shape[0], x0:x0 + mask.shape[1]] < 0)
                append(available, x0, y0, cluster)
    for y0 in range(0, height, background_core_size):
        for x0 in range(0, width, background_core_size):
            append(owner[y0:y0 + background_core_size, x0:x0 + background_core_size] < 0,
                   x0, y0, None)
    if np.any(owner < 0):
        raise RuntimeError("incomplete pixel ownership")
    return RegionPartition(owner, tuple(regions))


def fuse_region_points(low_points: np.ndarray, high_points: Mapping[int, np.ndarray],
                       partition: RegionPartition) -> np.ndarray:
    """Replace points only on selected supports, including valid zero predictions."""
    known = {r.region_id for r in partition.regions}
    if not set(high_points).issubset(known):
        raise ValueError("unknown selected region")
    owners = partition.owners(low_points)
    pieces = [np.asarray(low_points)[~np.isin(owners, list(high_points))]]
    for region_id, points in sorted(high_points.items()):
        pieces.append(np.asarray(points)[partition.owners(points) == region_id])
    return np.concatenate(pieces, axis=0).astype(np.float32, copy=False)


REGION_FEATURE_NAMES = (
    "low_count", "low_count_per_megapixel", "score_mean", "score_std", "score_max",
    "global_low_count", "is_cluster", "cluster_confidence", "owned_area_ratio",
    "context_area_ratio", "context_side_ratio", "ownership_occupancy",
    "luminance_mean", "luminance_std", "saturation_mean", "red_mean", "green_mean", "blue_mean",
)


def region_features(image: Image.Image, partition: RegionPartition, low_points: np.ndarray,
                    low_scores: np.ndarray) -> np.ndarray:
    if len(low_points) != len(low_scores) or not np.isfinite(low_scores).all():
        raise ValueError("unaligned or invalid LR scores")
    owners = partition.owners(low_points)
    width, height = image.size
    if partition.ownership.shape != (height, width):
        raise ValueError("partition dimensions differ from image")
    rows = []
    for region in partition.regions:
        x0, y0, x1, y1 = region.context_xyxy
        rgb = np.asarray(image.crop(region.context_xyxy).resize((64, 64)).convert("RGB"), dtype=np.float32) / 255
        lum = rgb @ np.asarray([.299, .587, .114])
        maximum = rgb.max(axis=2)
        sat = (maximum - rgb.min(axis=2)) / np.maximum(maximum, 1e-6)
        scores = np.asarray(low_scores)[owners == region.region_id]
        area = (x1 - x0) * (y1 - y0)
        rows.append([
            len(scores), len(scores) * 1e6 / region.owned_pixels,
            float(scores.mean()) if len(scores) else 0., float(scores.std()) if len(scores) else 0.,
            float(scores.max()) if len(scores) else 0., len(low_points),
            float(region.cluster_id is not None), region.cluster_confidence,
            region.owned_pixels / (width * height), area / (width * height),
            max(x1 - x0, y1 - y0) / max(width, height), region.owned_pixels / area,
            float(lum.mean()), float(lum.std()), float(sat.mean()),
            *[float(rgb[:, :, i].mean()) for i in range(3)],
        ])
    result = np.asarray(rows, dtype=np.float32)
    if not np.isfinite(result).all():
        raise ValueError("nonfinite region features")
    return result
