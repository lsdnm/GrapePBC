"""Per-image high-resolution call allocation for experimental CRU variants.

The original fixed-quota CRU remains unchanged.  This policy consumes only
router scores available at inference; its threshold must be selected on a
development/validation split, never from held-out ground truth.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Mapping, Sequence

from .counterfactual import stable_topk


@dataclass(frozen=True)
class AdaptiveRoutingPolicy:
    """Select zero to ``max_calls`` cores according to their predicted benefit."""

    score_threshold: float
    max_calls: int
    score_budget_fraction: float

    def __post_init__(self) -> None:
        if not math.isfinite(self.score_threshold):
            raise ValueError("score_threshold must be finite")
        if isinstance(self.max_calls, bool) or not isinstance(self.max_calls, int):
            raise ValueError("max_calls must be an integer")
        if self.max_calls < 1:
            raise ValueError("max_calls must be positive")
        if not 0 < self.score_budget_fraction <= 1:
            raise ValueError("score_budget_fraction must lie in (0, 1]")

    def select(self, scores: Sequence[float]) -> tuple[int, ...]:
        if len(scores) == 0:
            return ()
        eligible: dict[int, float] = {}
        for tile_id, raw_score in enumerate(scores):
            score = float(raw_score)
            if not math.isfinite(score):
                raise ValueError("router scores must be finite")
            if score > self.score_threshold:
                eligible[tile_id] = score
        return stable_topk(eligible, min(self.max_calls, len(eligible)))


def calibrate_adaptive_threshold(
    images: Sequence[Mapping[str, object]],
    *,
    max_calls: int,
    target_mean_calls: float,
    score_budget_fraction: float,
) -> tuple[AdaptiveRoutingPolicy, dict[str, float]]:
    """Fit one global threshold on validation predictions under a call budget.

    Each item contains ``scores``, ``low_counts``, ``high_counts`` and
    ``true_count``.  No test split may be passed by the caller.  Thresholds
    are enumerated exactly at score change-points; ties favor fewer calls.
    """

    if not images:
        raise ValueError("at least one validation image is required")
    if not math.isfinite(target_mean_calls) or target_mean_calls < 0:
        raise ValueError("target_mean_calls must be finite and non-negative")
    if target_mean_calls > max_calls:
        raise ValueError("target_mean_calls cannot exceed max_calls")
    all_scores: list[float] = []
    checked: list[tuple[list[float], list[int], list[int], int]] = []
    for image in images:
        scores = [float(value) for value in image["scores"]]  # type: ignore[union-attr]
        low = [int(value) for value in image["low_counts"]]  # type: ignore[union-attr]
        high = [int(value) for value in image["high_counts"]]  # type: ignore[union-attr]
        if not scores or len(scores) != len(low) or len(scores) != len(high):
            raise ValueError("each validation image needs aligned non-empty tiles")
        if not all(math.isfinite(score) for score in scores):
            raise ValueError("router scores must be finite")
        checked.append((scores, low, high, int(image["true_count"])))
        all_scores.extend(scores)
    minimum = min(all_scores)
    lower = minimum - max(1.0, abs(minimum))
    thresholds = [lower, *sorted(set(all_scores))]
    best: tuple[float, float, float] | None = None
    best_policy: AdaptiveRoutingPolicy | None = None
    for threshold in thresholds:
        policy = AdaptiveRoutingPolicy(threshold, max_calls, score_budget_fraction)
        absolute_error = 0.0
        calls = 0
        for scores, low, high, truth in checked:
            selected = policy.select(scores)
            predicted = sum(low) + sum(high[i] - low[i] for i in selected)
            absolute_error += abs(predicted - truth)
            calls += len(selected)
        mean_calls = calls / len(checked)
        if mean_calls > target_mean_calls + 1e-9:
            continue
        mae = absolute_error / len(checked)
        objective = (mae, mean_calls, -threshold)
        if best is None or objective < best:
            best = objective
            best_policy = policy
    if best is None or best_policy is None:
        raise RuntimeError("no feasible adaptive policy")
    return best_policy, {
        "validation_mae": best[0],
        "mean_high_resolution_calls": best[1],
        "validation_image_count": float(len(checked)),
    }
