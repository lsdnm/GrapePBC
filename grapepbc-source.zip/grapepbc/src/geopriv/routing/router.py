"""Lightweight budget-conditioned resolution-utility router."""

from __future__ import annotations

import torch
from torch import Tensor, nn


class BudgetConditionedUtilityRouter(nn.Module):
    """Predict per-tile high-resolution utility under a normalized budget.

    The network is intentionally tiny enough for CPU/mobile server inference.
    A scalar budget fraction is concatenated to every tile feature vector, so
    one checkpoint can learn different rankings for sparse and broad budgets.
    """

    def __init__(
        self,
        feature_count: int,
        *,
        hidden_channels: int = 64,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        if feature_count <= 0:
            raise ValueError("feature_count must be positive")
        if hidden_channels <= 0:
            raise ValueError("hidden_channels must be positive")
        if not 0.0 <= dropout < 1.0:
            raise ValueError("dropout must lie in [0, 1)")
        self.feature_count = feature_count
        self.hidden_channels = hidden_channels
        self.dropout = dropout
        self.network = nn.Sequential(
            nn.Linear(feature_count + 1, hidden_channels),
            nn.LayerNorm(hidden_channels),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_channels, hidden_channels // 2),
            nn.SiLU(),
            nn.Linear(hidden_channels // 2, 1),
        )

    def forward(self, features: Tensor, budget_fraction: Tensor | float) -> Tensor:
        if features.ndim != 2 or features.shape[1] != self.feature_count:
            raise ValueError(
                f"features must have shape (N, {self.feature_count}), "
                f"got {tuple(features.shape)}"
            )
        if isinstance(budget_fraction, Tensor):
            budget = budget_fraction.to(device=features.device, dtype=features.dtype)
            if budget.ndim == 0:
                budget = budget.expand(len(features), 1)
            elif budget.ndim == 1 and len(budget) == len(features):
                budget = budget[:, None]
            elif budget.shape != (len(features), 1):
                raise ValueError("budget tensor must be scalar, (N,) or (N, 1)")
        else:
            budget = features.new_full((len(features), 1), float(budget_fraction))
        if torch.any((budget < 0) | (budget > 1)):
            raise ValueError("budget fraction must lie in [0, 1]")
        return self.network(torch.cat((features, budget), dim=1)).squeeze(1)
