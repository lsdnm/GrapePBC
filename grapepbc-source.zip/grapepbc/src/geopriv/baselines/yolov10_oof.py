"""Leakage-controlled YOLOv10n baseline for the fixed GBISC five-fold protocol.

This module deliberately separates deterministic data preparation, training and
validation-only model selection from outer-test inference.  The outer-test
phase refuses to run until every fold/seed combination has a frozen checkpoint
and threshold record.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import shutil
import statistics
import sys
import time
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
import torch
import yaml


PROJECT_ROOT = Path(__file__).resolve().parents[3]
GBISC_ROOT = PROJECT_ROOT / "data/raw/gbisc"
CRU_EXPERIMENT = PROJECT_ROOT / "reports/gbisc_fixed5fold_cv_v1"
EXPERIMENT = PROJECT_ROOT / "reports/gbisc_yolov10n_fixed5fold_oof_v1"
DERIVED_ROOT = PROJECT_ROOT / "data/derived/gbisc_yolov10n_fixed5fold_oof_v1"
BASE_WEIGHTS = PROJECT_ROOT / "models/baselines/yolov10n_thumig_v1.1.pt"
FOLDS = tuple(range(5))
SEEDS = (20260917, 20260918, 20260919)
MAX_DET = 4096
EPOCHS = 120
EVAL_EVERY = 5
IMAGE_SIZE = 768
BATCH_SIZE = 4
PROTOCOL_NAME = "GBISC-YOLOV10N-FIXED5CV-v1"
AMENDMENT_PATH = EXPERIMENT / "PROTOCOL_AMENDMENT_1.json"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_write_text(text: str, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(text, encoding="utf-8")
    temporary.replace(path)


def atomic_json_write(payload: object, path: Path) -> None:
    atomic_write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True, default=str) + "\n",
        path,
    )


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected a JSON object: {path}")
    return value


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        value = json.loads(line)
        if not isinstance(value, dict):
            raise ValueError(f"non-object JSONL row at {path}:{line_number}")
        rows.append(value)
    return rows


def safe_sample_name(sample_id: str, suffix: str) -> str:
    stem = "".join(character if character.isalnum() else "_" for character in sample_id)
    return f"{stem}{suffix.lower()}"


def _load_coco(path: Path, cache: dict[Path, dict[str, Any]]) -> dict[str, Any]:
    if path not in cache:
        payload = read_json(path)
        images = {int(row["id"]): row for row in payload["images"]}
        annotations: dict[int, list[dict[str, Any]]] = defaultdict(list)
        for annotation in payload["annotations"]:
            annotations[int(annotation["image_id"])].append(annotation)
        cache[path] = {"images": images, "annotations": annotations}
    return cache[path]


def yolo_rows_for_record(
    record: Mapping[str, Any],
    *,
    coco_cache: dict[Path, dict[str, Any]],
) -> tuple[list[str], dict[str, int]]:
    width = int(record["width"])
    height = int(record["height"])
    if width <= 0 or height <= 0:
        raise ValueError(f"invalid image size for {record['sample_id']}")
    annotation_path = GBISC_ROOT / str(record["instances_path"])
    coco = _load_coco(annotation_path, coco_cache)
    image_id = int(record["extra"]["coco_image_id"])
    source_image = coco["images"].get(image_id)
    if source_image is None:
        raise ValueError(f"missing COCO image id {image_id} in {annotation_path}")
    annotations = coco["annotations"].get(image_id, [])
    lines: list[str] = []
    clipped = 0
    for annotation in annotations:
        x, y, box_width, box_height = (float(value) for value in annotation["bbox"])
        x1 = min(max(x, 0.0), float(width))
        y1 = min(max(y, 0.0), float(height))
        x2 = min(max(x + box_width, 0.0), float(width))
        y2 = min(max(y + box_height, 0.0), float(height))
        if (x1, y1, x2, y2) != (x, y, x + box_width, y + box_height):
            clipped += 1
        if x2 <= x1 or y2 <= y1:
            raise ValueError(f"zero-area clipped box for {record['sample_id']}")
        center_x = ((x1 + x2) / 2.0) / width
        center_y = ((y1 + y2) / 2.0) / height
        normalized_width = (x2 - x1) / width
        normalized_height = (y2 - y1) / height
        values = (center_x, center_y, normalized_width, normalized_height)
        if any(not math.isfinite(value) or value <= 0.0 or value > 1.0 for value in values):
            raise ValueError(f"invalid normalized box for {record['sample_id']}: {values}")
        lines.append("0 " + " ".join(f"{value:.10f}" for value in values))
    expected = int(record["point_count"])
    if len(lines) != expected or len(lines) != int(record["instance_count"]):
        raise ValueError(
            f"annotation count mismatch for {record['sample_id']}: "
            f"bbox={len(lines)}, point={expected}, instance={record['instance_count']}"
        )
    return lines, {"boxes": len(lines), "clipped_boxes": clipped}


def _copy_or_verify(source: Path, destination: Path) -> str:
    """Create an independent image copy.

    Ultralytics may append a missing JPEG EOI marker while scanning a dataset.
    A hardlink would therefore mutate the archived source image as well, so
    hardlinks are expressly forbidden here.
    """
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        if destination.stat().st_size != source.stat().st_size or sha256(destination) != sha256(source):
            raise ValueError(f"existing derived image differs from source: {destination}")
        if not os.path.samefile(source, destination):
            return "existing_independent_copy"
        temporary = destination.with_suffix(destination.suffix + ".independent-copy.tmp")
        shutil.copy2(source, temporary)
        temporary.replace(destination)
        if os.path.samefile(source, destination):
            raise RuntimeError(f"failed to break source hardlink: {destination}")
        return "hardlink_replaced_with_copy"
    shutil.copy2(source, destination)
    if os.path.samefile(source, destination):
        raise RuntimeError(f"derived image unexpectedly aliases source: {destination}")
    return "copy"


def prepare_dataset() -> dict[str, Any]:
    """Create YOLO labels and fold lists without running a model."""
    fold_manifests = [CRU_EXPERIMENT / "manifests" / f"fold_{fold}.jsonl" for fold in FOLDS]
    for manifest in fold_manifests:
        if not manifest.is_file():
            raise FileNotFoundError(manifest)
    canonical = read_jsonl(fold_manifests[0])
    if len(canonical) != 150:
        raise ValueError(f"expected 150 canonical samples, found {len(canonical)}")
    canonical_by_id = {str(row["sample_id"]): row for row in canonical}
    if len(canonical_by_id) != 150:
        raise ValueError("duplicate sample IDs in canonical manifest")

    images_dir = DERIVED_ROOT / "images/all"
    labels_dir = DERIVED_ROOT / "labels/all"
    coco_cache: dict[Path, dict[str, Any]] = {}
    sample_paths: dict[str, Path] = {}
    sample_label_counts: dict[str, int] = {}
    link_modes: dict[str, int] = defaultdict(int)
    clipped_total = 0
    for sample_id in sorted(canonical_by_id):
        record = canonical_by_id[sample_id]
        source = GBISC_ROOT / str(record["image_path"])
        if not source.is_file():
            raise FileNotFoundError(source)
        target = images_dir / safe_sample_name(sample_id, source.suffix)
        link_modes[_copy_or_verify(source, target)] += 1
        label_path = labels_dir / f"{target.stem}.txt"
        lines, box_audit = yolo_rows_for_record(record, coco_cache=coco_cache)
        atomic_write_text("\n".join(lines) + "\n", label_path)
        sample_paths[sample_id] = target.resolve()
        sample_label_counts[sample_id] = len(lines)
        clipped_total += box_audit["clipped_boxes"]

    fold_audits: list[dict[str, Any]] = []
    outer_test_occurrences: dict[str, int] = defaultdict(int)
    for fold, manifest in zip(FOLDS, fold_manifests, strict=True):
        rows = read_jsonl(manifest)
        ids = {str(row["sample_id"]) for row in rows}
        if ids != set(canonical_by_id):
            raise ValueError(f"fold {fold} sample universe differs from canonical manifest")
        role_rows: dict[str, list[dict[str, Any]]] = {}
        for role in ("train", "val", "test"):
            selected = [row for row in rows if str(row["split"]) == role]
            role_rows[role] = selected
            expected = {"train": 96, "val": 24, "test": 30}[role]
            if len(selected) != expected:
                raise ValueError(f"fold {fold} {role}: expected {expected}, found {len(selected)}")
            list_path = DERIVED_ROOT / f"fold_{fold}" / f"{role}.txt"
            atomic_write_text(
                "\n".join(str(sample_paths[str(row["sample_id"])]) for row in selected) + "\n",
                list_path,
            )
        role_sets = {role: {str(row["sample_id"]) for row in selected} for role, selected in role_rows.items()}
        if any(role_sets[left] & role_sets[right] for left, right in (("train", "val"), ("train", "test"), ("val", "test"))):
            raise ValueError(f"fold {fold} has split overlap")
        for sample_id in role_sets["test"]:
            outer_test_occurrences[sample_id] += 1
        yaml_path = DERIVED_ROOT / f"fold_{fold}" / "dataset.yaml"
        atomic_write_text(
            yaml.safe_dump(
                {
                    "path": str(DERIVED_ROOT.resolve()),
                    "train": str((DERIVED_ROOT / f"fold_{fold}" / "train.txt").resolve()),
                    "val": str((DERIVED_ROOT / f"fold_{fold}" / "val.txt").resolve()),
                    "test": str((DERIVED_ROOT / f"fold_{fold}" / "test.txt").resolve()),
                    "names": {0: "berry"},
                },
                sort_keys=False,
            ),
            yaml_path,
        )
        fold_audits.append(
            {
                "fold": fold,
                "manifest": str(manifest.resolve()),
                "manifest_sha256": sha256(manifest),
                "roles": {
                    role: {
                        "images": len(selected),
                        "berries": sum(int(row["point_count"]) for row in selected),
                        "max_berries": max(int(row["point_count"]) for row in selected),
                        "varieties": dict(
                            sorted(
                                {
                                    variety: sum(1 for row in selected if str(row["source_subset"]) == variety)
                                    for variety in {str(row["source_subset"]) for row in selected}
                                }.items()
                            )
                        ),
                    }
                    for role, selected in role_rows.items()
                },
            }
        )
    if set(outer_test_occurrences.values()) != {1} or len(outer_test_occurrences) != 150:
        raise ValueError("each sample must be an outer-test sample exactly once")
    counts = list(sample_label_counts.values())
    audit: dict[str, Any] = {
        "schema_version": 1,
        "generated_at_utc": utc_now(),
        "protocol": PROTOCOL_NAME,
        "images": len(sample_paths),
        "berries": sum(counts),
        "berries_per_image": {
            "minimum": min(counts),
            "maximum": max(counts),
            "mean": statistics.fmean(counts),
            "images_over_300": sum(value > 300 for value in counts),
            "images_over_500": sum(value > 500 for value in counts),
        },
        "bbox_policy": "source COCO bbox clipped to the image frame; class remapped to berry=0",
        "clipped_boxes": clipped_total,
        "link_modes": dict(sorted(link_modes.items())),
        "folds": fold_audits,
    }
    atomic_json_write(audit, EXPERIMENT / "DATASET_AUDIT.json")
    return audit


def build_protocol_lock(dataset_audit: Mapping[str, Any]) -> dict[str, Any]:
    try:
        import ultralytics
    except ImportError as error:  # pragma: no cover - environment guard
        raise RuntimeError("ultralytics is required for the YOLOv10n baseline") from error
    if not BASE_WEIGHTS.is_file():
        raise FileNotFoundError(BASE_WEIGHTS)
    source_files = [
        PROJECT_ROOT / "src/geopriv/baselines/yolov10_oof.py",
        PROJECT_ROOT / "scripts/run_gbisc_yolov10_oof.py",
        CRU_EXPERIMENT / "PROTOCOL_LOCK.json",
        CRU_EXPERIMENT / "OOF_FINAL_RESULTS.json",
        EXPERIMENT / "DATASET_AUDIT.json",
    ]
    lock: dict[str, Any] = {
        "schema_version": 1,
        "protocol": PROTOCOL_NAME,
        "status": "locked_before_any_yolov10n_gbisc_model_result",
        "locked_at_utc": utc_now(),
        "evidence_classification": (
            "controlled architecture-matched retraining of a published visible-berry YOLOv10n "
            "under the existing post-hoc GBISC five-fold OOF protocol; not an exact reproduction "
            "of the authors' dataset result and not independent confirmation"
        ),
        "published_model_source": {
            "paper": "Moreira, Santos and Cunha (2026), A YOLO-based approach to grape berry detection and counting with ampelographic feature analysis for grapevine yield estimation",
            "doi": "10.1016/j.inpa.2026.03.002",
            "selection_rule": "YOLOv10n was selected before GBISC inference because it had the lowest visible-berry counting MAPE among the four lightweight YOLO variants in the source paper",
            "source_paper_training_recipe_not_used_for_primary_comparison": {
                "image_size": 640,
                "epochs": 250,
                "batch_size": 16,
                "optimizer": "AdamW",
                "learning_rate": 0.01,
                "weight_decay": 0.0005,
                "momentum": 0.937,
            },
            "implementation": "THU-MIG YOLOv10 v1.1 pretrained checkpoint loaded by Ultralytics",
            "implementation_url": "https://github.com/THU-MIG/yolov10",
        },
        "task": "visible or partially occluded grape berry counting from one RGB image",
        "data_protocol": {
            "dataset": "GBISC",
            "folds": 5,
            "per_fold": {"train": 96, "val": 24, "test": 30},
            "outer_test_release_gate": "all fold/seed checkpoints and validation-selected thresholds must be frozen before any outer-test prediction",
            "test_use": "each of the 150 images is outer test exactly once",
            "ground_truth": "number of source COCO berry instances, matching the CRU visible/partially-occluded point count",
            "dataset_audit_summary": dataset_audit,
        },
        "primary_training": {
            "weights": str(BASE_WEIGHTS.resolve()),
            "weights_sha256": sha256(BASE_WEIGHTS),
            "seeds": list(SEEDS),
            "image_size": IMAGE_SIZE,
            "epochs": EPOCHS,
            "batch_size": BATCH_SIZE,
            "nominal_batch_size": BATCH_SIZE,
            "optimizer": "AdamW",
            "learning_rate": 0.0003,
            "learning_rate_schedule": "constant (lrf=1.0; no warmup)",
            "adam_beta1": 0.9,
            "adam_beta2": 0.999,
            "weight_decay": 0.0001,
            "amp": True,
            "pretrained": "COCO",
            "model_specific_components": "native YOLOv10 detection losses and end-to-end/NMS-free prediction head",
            "augmentation": {
                "horizontal_flip_probability": 0.5,
                "rotation_crop_translate_scale_shear_perspective_mosaic_mixup": "disabled",
                "color_mapping": "Ultralytics HSV approximation: hsv_h=0, hsv_s=0.05, hsv_v=0.1",
                "known_difference_from_cru": "Ultralytics cannot express the CRU ColorJitter probability=0.8 and contrast=0.1 exactly; this implementation uses the closest native detector transform and records the difference",
            },
            "gradient_clip": {
                "cru": 5.0,
                "yolov10n_ultralytics_native": 10.0,
                "reason": "Ultralytics 8.4.142 hard-codes detector gradient clipping and does not expose a training argument",
            },
        },
        "selection": {
            "candidate_frequency_epochs": EVAL_EVERY,
            "candidate_epochs": list(range(EVAL_EVERY, EPOCHS + 1, EVAL_EVERY)),
            "prediction_confidence_floor": 0.001,
            "threshold_grid": {"start": 0.01, "stop": 0.99, "step": 0.01},
            "criterion": "lowest validation counting MAE",
            "tie_break": ["lower validation RMSE", "lower absolute validation bias", "earlier epoch", "lower threshold"],
            "outer_test_not_used": True,
        },
        "inference": {
            "count": "number of berry detections at the fold/seed validation-selected confidence threshold",
            "max_det": MAX_DET,
            "max_det_rationale": "GBISC has up to 642 berries per image and 93/150 images exceed the YOLOv10 default max_det=300",
            "postprocessing": "native YOLOv10 end-to-end NMS-free postprocessing; no added NMS",
        },
        "analysis": {
            "primary_yolo_estimate": "predictions pooled across all 150 OOF images and three prespecified training seeds",
            "metrics": ["MAE", "RMSE", "WAPE", "MAPE", "R2", "bias"],
            "paired_comparisons": ["CRU minus YOLO absolute error", "LR minus YOLO absolute error"],
            "bootstrap": {"resamples": 10000, "seed": 20260925, "strata": "grape variety"},
        },
        "software": {
            "python": sys.version,
            "platform": platform.platform(),
            "torch": torch.__version__,
            "cuda_available": torch.cuda.is_available(),
            "cuda": torch.version.cuda,
            "ultralytics": ultralytics.__version__,
        },
        "source_sha256": {str(path.relative_to(PROJECT_ROOT)).replace("\\", "/"): sha256(path) for path in source_files},
        "fold_manifest_sha256": {
            f"fold_{fold}.jsonl": sha256(CRU_EXPERIMENT / "manifests" / f"fold_{fold}.jsonl") for fold in FOLDS
        },
    }
    return lock


def prepare_protocol(*, replace_unstarted_lock: bool = False) -> dict[str, Any]:
    lock_path = EXPERIMENT / "PROTOCOL_LOCK.json"
    if lock_path.exists() and not replace_unstarted_lock:
        verify_protocol_lock(lock_path)
        return read_json(lock_path)
    if replace_unstarted_lock and any((EXPERIMENT / "runs").glob("fold_*/seed_*/weights/*.pt")):
        raise RuntimeError("refusing to replace protocol lock after a training checkpoint exists")
    audit = prepare_dataset()
    lock = build_protocol_lock(audit)
    atomic_json_write(lock, lock_path)
    atomic_write_text(f"{sha256(lock_path)}  PROTOCOL_LOCK.json\n", EXPERIMENT / "PROTOCOL_LOCK.sha256")
    return lock


def verify_protocol_lock(lock_path: Path | None = None) -> dict[str, Any]:
    path = lock_path or (EXPERIMENT / "PROTOCOL_LOCK.json")
    lock = read_json(path)
    if lock.get("protocol") != PROTOCOL_NAME or lock.get("status") != "locked_before_any_yolov10n_gbisc_model_result":
        raise ValueError("unexpected or unlocked YOLOv10n protocol")
    changed: list[str] = []
    for relative, expected in lock["source_sha256"].items():
        source = PROJECT_ROOT / str(relative)
        if not source.is_file():
            changed.append(str(relative))
            continue
        observed = sha256(source)
        if observed == str(expected):
            continue
        amendment_valid = False
        if AMENDMENT_PATH.is_file():
            amendment = read_json(AMENDMENT_PATH)
            amendment_hashes = amendment.get("source_sha256", {})
            amendment_valid = (
                amendment.get("base_protocol_lock_sha256") == sha256(path)
                and amendment.get("protocol_changes") is False
                and isinstance(amendment_hashes, dict)
                and amendment_hashes.get(str(relative)) == observed
            )
        if not amendment_valid:
            changed.append(str(relative))
    for name, expected in lock["fold_manifest_sha256"].items():
        source = CRU_EXPERIMENT / "manifests" / str(name)
        if not source.is_file() or sha256(source) != str(expected):
            changed.append(str(source.relative_to(PROJECT_ROOT)))
    weights = Path(str(lock["primary_training"]["weights"]))
    if not weights.is_file() or sha256(weights) != str(lock["primary_training"]["weights_sha256"]):
        changed.append(str(weights))
    if changed:
        raise RuntimeError(f"locked YOLOv10n protocol inputs changed: {changed}")
    return lock


def _run_dir(fold: int, seed: int) -> Path:
    return EXPERIMENT / "runs" / f"fold_{fold}" / f"seed_{seed}"


def _checkpoint_epoch(path: Path) -> int:
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    return int(checkpoint.get("epoch", -1)) + 1


def _save_every_five_callback(checkpoint_dir: Path):
    def callback(trainer: Any) -> None:
        epoch = int(trainer.epoch) + 1
        if epoch % EVAL_EVERY:
            return
        destination = checkpoint_dir / f"epoch_{epoch:03d}.pt"
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_suffix(".pt.tmp")
        shutil.copy2(Path(trainer.last), temporary)
        temporary.replace(destination)

    return callback


def _train_arguments(fold: int, seed: int, *, epochs: int = EPOCHS, image_size: int = IMAGE_SIZE) -> dict[str, Any]:
    return {
        "data": str((DERIVED_ROOT / f"fold_{fold}" / "dataset.yaml").resolve()),
        "epochs": epochs,
        "imgsz": image_size,
        "batch": BATCH_SIZE,
        "nbs": BATCH_SIZE,
        "device": 0,
        "workers": 0,
        "optimizer": "AdamW",
        "lr0": 0.0003,
        "lrf": 1.0,
        "momentum": 0.9,
        "weight_decay": 0.0001,
        "warmup_epochs": 0.0,
        "warmup_momentum": 0.9,
        "warmup_bias_lr": 0.0,
        "amp": True,
        "seed": seed,
        "deterministic": True,
        "patience": 0,
        "pretrained": True,
        "val": False,
        "save": True,
        "save_period": -1,
        "plots": False,
        "verbose": True,
        "max_det": MAX_DET,
        "hsv_h": 0.0,
        "hsv_s": 0.05,
        "hsv_v": 0.1,
        "degrees": 0.0,
        "translate": 0.0,
        "scale": 0.0,
        "shear": 0.0,
        "perspective": 0.0,
        "flipud": 0.0,
        "fliplr": 0.5,
        "mosaic": 0.0,
        "mixup": 0.0,
        "copy_paste": 0.0,
        "auto_augment": None,
        "erasing": 0.0,
        "close_mosaic": 0,
        "multi_scale": False,
        "rect": False,
        "cache": False,
        "project": str((_run_dir(fold, seed).parent).resolve()),
        "name": _run_dir(fold, seed).name,
        "exist_ok": True,
    }


def train_one(fold: int, seed: int) -> dict[str, Any]:
    verify_protocol_lock()
    if fold not in FOLDS or seed not in SEEDS:
        raise ValueError(f"unregistered fold/seed: {fold}/{seed}")
    from ultralytics import YOLO

    run_dir = _run_dir(fold, seed)
    last = run_dir / "weights/last.pt"
    complete_path = run_dir / "TRAIN_COMPLETE.json"
    checkpoint_dir = run_dir / "interval_checkpoints"
    final_interval = checkpoint_dir / f"epoch_{EPOCHS:03d}.pt"
    if complete_path.is_file():
        complete = read_json(complete_path)
        if not final_interval.is_file() or _checkpoint_epoch(final_interval) != EPOCHS:
            raise RuntimeError(f"completion record does not match final interval checkpoint: {run_dir}")
        return complete
    started = time.perf_counter()
    if final_interval.is_file() and _checkpoint_epoch(final_interval) == EPOCHS:
        pass
    elif last.is_file():
        completed_epochs = _checkpoint_epoch(last)
        if completed_epochs < EPOCHS:
            if completed_epochs < 1:
                raise RuntimeError(
                    f"last.pt was stripped after completed training but epoch_{EPOCHS:03d}.pt is missing: {run_dir}"
                )
            model = YOLO(str(last))
            model.add_callback("on_model_save", _save_every_five_callback(checkpoint_dir))
            model.train(resume=True)
        elif completed_epochs > EPOCHS:
            raise RuntimeError(f"checkpoint exceeds locked epoch budget: {last}")
    else:
        model = YOLO(str(BASE_WEIGHTS))
        model.add_callback("on_model_save", _save_every_five_callback(checkpoint_dir))
        model.train(**_train_arguments(fold, seed))
    if not final_interval.is_file() or _checkpoint_epoch(final_interval) != EPOCHS:
        raise RuntimeError(f"training did not finish {EPOCHS} epochs: {run_dir}")
    candidates = [checkpoint_dir / f"epoch_{epoch:03d}.pt" for epoch in range(EVAL_EVERY, EPOCHS + 1, EVAL_EVERY)]
    missing = [path.name for path in candidates if not path.is_file()]
    if missing:
        raise RuntimeError(f"missing interval checkpoints in {run_dir}: {missing}")
    result = {
        "schema_version": 1,
        "completed_at_utc": utc_now(),
        "fold": fold,
        "seed": seed,
        "epochs": EPOCHS,
        "duration_seconds_this_invocation": time.perf_counter() - started,
        "last": str(last.resolve()),
        "last_sha256": sha256(last),
        "interval_checkpoints": {path.name: sha256(path) for path in candidates},
    }
    atomic_json_write(result, complete_path)
    return result


def smoke_train() -> dict[str, Any]:
    """One-epoch, train/validation-only GPU smoke test in a separate directory."""
    verify_protocol_lock()
    from ultralytics import YOLO

    smoke_dir = EXPERIMENT / "smoke"
    if smoke_dir.exists():
        raise RuntimeError(f"smoke directory already exists; refusing to overwrite: {smoke_dir}")
    started = time.perf_counter()
    model = YOLO(str(BASE_WEIGHTS))
    arguments = _train_arguments(0, SEEDS[0], epochs=1)
    arguments.update({"project": str(EXPERIMENT.resolve()), "name": "smoke", "exist_ok": False, "val": True})
    model.train(**arguments)
    result = {
        "schema_version": 1,
        "completed_at_utc": utc_now(),
        "fold": 0,
        "seed": SEEDS[0],
        "epochs": 1,
        "duration_seconds": time.perf_counter() - started,
        "used_outer_test": False,
        "max_det": MAX_DET,
    }
    atomic_json_write(result, smoke_dir / "SMOKE_COMPLETE.json")
    return result


def metric_values(predictions: Sequence[float], truth: Sequence[int]) -> dict[str, float]:
    predicted = np.asarray(predictions, dtype=np.float64)
    actual = np.asarray(truth, dtype=np.float64)
    if predicted.shape != actual.shape or not len(actual):
        raise ValueError("metric arrays must be non-empty and have equal shape")
    errors = predicted - actual
    absolute = np.abs(errors)
    denominator = float(np.sum(actual))
    ss_total = float(np.sum((actual - float(np.mean(actual))) ** 2))
    return {
        "mae": float(np.mean(absolute)),
        "rmse": float(np.sqrt(np.mean(errors**2))),
        "wape": float(np.sum(absolute) / denominator),
        "mape_percent": float(np.mean(absolute / actual) * 100.0),
        "r2": float(1.0 - float(np.sum(errors**2)) / ss_total) if ss_total > 0 else float("nan"),
        "bias": float(np.mean(errors)),
    }


def _thresholds() -> list[float]:
    return [value / 100.0 for value in range(1, 100)]


def select_threshold(confidences: Sequence[np.ndarray], truth: Sequence[int]) -> dict[str, Any]:
    best: tuple[tuple[float, float, float, float], dict[str, Any]] | None = None
    for threshold in _thresholds():
        predictions = [int(np.count_nonzero(values >= threshold)) for values in confidences]
        metrics = metric_values(predictions, truth)
        key = (metrics["mae"], metrics["rmse"], abs(metrics["bias"]), threshold)
        result = {"threshold": threshold, "metrics": metrics, "predictions": predictions}
        if best is None or key < best[0]:
            best = (key, result)
    assert best is not None
    return best[1]


def _predict_confidences(model_path: Path, image_paths: Sequence[Path]) -> list[np.ndarray]:
    from ultralytics import YOLO

    model = YOLO(str(model_path))
    results = model.predict(
        source=[str(path) for path in image_paths],
        imgsz=IMAGE_SIZE,
        batch=BATCH_SIZE,
        conf=0.001,
        iou=0.7,
        max_det=MAX_DET,
        device=0,
        half=False,
        verbose=False,
        stream=True,
        save=False,
        plots=False,
    )
    collected: list[np.ndarray] = []
    for result in results:
        values = result.boxes.conf.detach().float().cpu().numpy()
        if len(values) > MAX_DET:
            raise RuntimeError(f"prediction exceeds locked max_det={MAX_DET}")
        collected.append(values)
    if len(collected) != len(image_paths):
        raise RuntimeError(f"prediction count mismatch: expected {len(image_paths)}, found {len(collected)}")
    del model
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    return collected


def _fold_rows(fold: int, role: str) -> list[dict[str, Any]]:
    rows = read_jsonl(CRU_EXPERIMENT / "manifests" / f"fold_{fold}.jsonl")
    return [row for row in rows if str(row["split"]) == role]


def _derived_image_path(row: Mapping[str, Any]) -> Path:
    suffix = Path(str(row["image_path"])).suffix
    return (DERIVED_ROOT / "images/all" / safe_sample_name(str(row["sample_id"]), suffix)).resolve()


def select_one(fold: int, seed: int) -> dict[str, Any]:
    verify_protocol_lock()
    run_dir = _run_dir(fold, seed)
    if not (run_dir / "TRAIN_COMPLETE.json").is_file():
        raise RuntimeError(f"training is not complete: fold {fold}, seed {seed}")
    frozen_record_path = run_dir / "FROZEN_SELECTION.json"
    if frozen_record_path.is_file():
        record = read_json(frozen_record_path)
        frozen_path = Path(str(record["frozen_checkpoint"]))
        if not frozen_path.is_file() or sha256(frozen_path) != str(record["frozen_sha256"]):
            raise RuntimeError(f"frozen checkpoint hash mismatch: {frozen_path}")
        return record
    validation_rows = _fold_rows(fold, "val")
    image_paths = [_derived_image_path(row) for row in validation_rows]
    truth = [int(row["point_count"]) for row in validation_rows]
    candidates: list[dict[str, Any]] = []
    for epoch in range(EVAL_EVERY, EPOCHS + 1, EVAL_EVERY):
        checkpoint = run_dir / "interval_checkpoints" / f"epoch_{epoch:03d}.pt"
        if not checkpoint.is_file():
            raise FileNotFoundError(checkpoint)
        confidences = _predict_confidences(checkpoint, image_paths)
        selected = select_threshold(confidences, truth)
        candidates.append(
            {
                "epoch": epoch,
                "checkpoint": str(checkpoint.resolve()),
                "checkpoint_sha256": sha256(checkpoint),
                **selected,
            }
        )
    candidates.sort(
        key=lambda row: (
            float(row["metrics"]["mae"]),
            float(row["metrics"]["rmse"]),
            abs(float(row["metrics"]["bias"])),
            int(row["epoch"]),
            float(row["threshold"]),
        )
    )
    best = candidates[0]
    frozen = run_dir / "frozen.pt"
    temporary = frozen.with_suffix(".pt.tmp")
    shutil.copy2(Path(str(best["checkpoint"])), temporary)
    temporary.replace(frozen)
    record = {
        "schema_version": 1,
        "frozen_at_utc": utc_now(),
        "protocol_lock_sha256": sha256(EXPERIMENT / "PROTOCOL_LOCK.json"),
        "fold": fold,
        "seed": seed,
        "validation_images": len(validation_rows),
        "selection_rule": read_json(EXPERIMENT / "PROTOCOL_LOCK.json")["selection"],
        "selected_epoch": int(best["epoch"]),
        "selected_threshold": float(best["threshold"]),
        "selected_validation_metrics": best["metrics"],
        "selected_validation_predictions": [
            {
                "sample_id": str(row["sample_id"]),
                "true_count": int(row["point_count"]),
                "predicted_count": int(prediction),
            }
            for row, prediction in zip(validation_rows, best["predictions"], strict=True)
        ],
        "frozen_checkpoint": str(frozen.resolve()),
        "frozen_sha256": sha256(frozen),
        "candidate_summaries": [
            {
                "epoch": int(row["epoch"]),
                "threshold": float(row["threshold"]),
                "metrics": row["metrics"],
                "checkpoint_sha256": row["checkpoint_sha256"],
            }
            for row in sorted(candidates, key=lambda item: int(item["epoch"]))
        ],
        "outer_test_used": False,
    }
    atomic_json_write(record, frozen_record_path)
    return record


def freeze_gate() -> dict[str, Any]:
    verify_protocol_lock()
    records: list[dict[str, Any]] = []
    for fold in FOLDS:
        for seed in SEEDS:
            record_path = _run_dir(fold, seed) / "FROZEN_SELECTION.json"
            if not record_path.is_file():
                raise RuntimeError(f"outer-test gate closed: missing {record_path}")
            record = read_json(record_path)
            frozen = Path(str(record["frozen_checkpoint"]))
            if not frozen.is_file() or sha256(frozen) != str(record["frozen_sha256"]):
                raise RuntimeError(f"outer-test gate closed: invalid frozen model {frozen}")
            records.append(record)
    gate = {
        "schema_version": 1,
        "opened_at_utc": utc_now(),
        "protocol_lock_sha256": sha256(EXPERIMENT / "PROTOCOL_LOCK.json"),
        "frozen_models": len(records),
        "expected_models": len(FOLDS) * len(SEEDS),
        "records": [
            {
                "fold": row["fold"],
                "seed": row["seed"],
                "selected_epoch": row["selected_epoch"],
                "selected_threshold": row["selected_threshold"],
                "frozen_sha256": row["frozen_sha256"],
            }
            for row in records
        ],
    }
    gate_path = EXPERIMENT / "OUTER_TEST_RELEASE_GATE.json"
    if gate_path.exists():
        existing = read_json(gate_path)
        if existing["protocol_lock_sha256"] != gate["protocol_lock_sha256"] or existing["records"] != gate["records"]:
            raise RuntimeError("existing outer-test release gate differs from current frozen records")
        return existing
    atomic_json_write(gate, gate_path)
    return gate


def test_one(fold: int, seed: int) -> dict[str, Any]:
    verify_protocol_lock()
    gate = freeze_gate()
    gate_path = EXPERIMENT / "OUTER_TEST_RELEASE_GATE.json"
    run_dir = _run_dir(fold, seed)
    output_path = run_dir / "OUTER_TEST_PREDICTIONS.json"
    if output_path.is_file():
        return read_json(output_path)
    frozen_record = read_json(run_dir / "FROZEN_SELECTION.json")
    frozen = Path(str(frozen_record["frozen_checkpoint"]))
    test_rows = _fold_rows(fold, "test")
    confidences = _predict_confidences(frozen, [_derived_image_path(row) for row in test_rows])
    threshold = float(frozen_record["selected_threshold"])
    predictions = [int(np.count_nonzero(values >= threshold)) for values in confidences]
    truth = [int(row["point_count"]) for row in test_rows]
    result = {
        "schema_version": 1,
        "generated_at_utc": utc_now(),
        "protocol_lock_sha256": sha256(EXPERIMENT / "PROTOCOL_LOCK.json"),
        "outer_test_release_gate": str(gate_path.resolve()),
        "outer_test_release_gate_sha256": sha256(gate_path),
        "frozen_models_at_release": gate["frozen_models"],
        "fold": fold,
        "seed": seed,
        "checkpoint": str(frozen.resolve()),
        "checkpoint_sha256": sha256(frozen),
        "selected_epoch": frozen_record["selected_epoch"],
        "selected_threshold": threshold,
        "metrics": metric_values(predictions, truth),
        "samples": [
            {
                "sample_id": str(row["sample_id"]),
                "variety": str(row["source_subset"]),
                "true_count": int(row["point_count"]),
                "predicted_count": int(prediction),
                "signed_error": int(prediction) - int(row["point_count"]),
                "absolute_error": abs(int(prediction) - int(row["point_count"])),
            }
            for row, prediction in zip(test_rows, predictions, strict=True)
        ],
    }
    atomic_json_write(result, output_path)
    return result


def stratified_bootstrap(
    differences: Sequence[float],
    strata: Sequence[str],
    *,
    resamples: int = 10000,
    seed: int = 20260925,
) -> dict[str, float | int]:
    values = np.asarray(differences, dtype=np.float64)
    labels = np.asarray(strata)
    random = np.random.default_rng(seed)
    indices = [np.flatnonzero(labels == label) for label in sorted(set(labels.tolist()))]
    draws = np.empty(resamples, dtype=np.float64)
    for draw in range(resamples):
        sampled = np.concatenate([random.choice(group, size=len(group), replace=True) for group in indices])
        draws[draw] = float(np.mean(values[sampled]))
    return {
        "estimate": float(np.mean(values)),
        "ci95_lower": float(np.quantile(draws, 0.025)),
        "ci95_upper": float(np.quantile(draws, 0.975)),
        "bootstrap_probability_difference_le_zero": float(np.mean(draws <= 0.0)),
        "resamples": resamples,
        "seed": seed,
    }


def aggregate() -> dict[str, Any]:
    lock = verify_protocol_lock()
    freeze_gate()
    cru = read_json(CRU_EXPERIMENT / "OOF_FINAL_RESULTS.json")
    cru_by_id = {str(row["sample_id"]): row for row in cru["samples"]}
    rows: dict[str, dict[str, Any]] = {}
    input_hashes: dict[str, str] = {}
    for fold in FOLDS:
        for seed in SEEDS:
            path = _run_dir(fold, seed) / "OUTER_TEST_PREDICTIONS.json"
            if not path.is_file():
                raise RuntimeError(f"missing outer-test predictions: {path}")
            report = read_json(path)
            input_hashes[str(path.relative_to(EXPERIMENT)).replace("\\", "/")] = sha256(path)
            for sample in report["samples"]:
                sample_id = str(sample["sample_id"])
                row = rows.setdefault(
                    sample_id,
                    {
                        "sample_id": sample_id,
                        "fold": fold,
                        "variety": str(sample["variety"]),
                        "true_count": int(sample["true_count"]),
                        "yolov10n_predictions": {},
                    },
                )
                if int(row["fold"]) != fold or int(row["true_count"]) != int(sample["true_count"]):
                    raise ValueError(f"inconsistent OOF row for {sample_id}")
                predictions = row["yolov10n_predictions"]
                if str(seed) in predictions:
                    raise ValueError(f"duplicate prediction for {sample_id}, seed {seed}")
                predictions[str(seed)] = int(sample["predicted_count"])
    if len(rows) != 150:
        raise ValueError(f"expected 150 OOF images, found {len(rows)}")
    ordered = [rows[sample_id] for sample_id in sorted(rows)]
    seed_keys = {str(seed) for seed in SEEDS}
    if any(set(row["yolov10n_predictions"]) != seed_keys for row in ordered):
        raise ValueError("incomplete three-seed predictions")
    truth = [int(row["true_count"]) for row in ordered]
    seed_metrics = {
        str(seed): metric_values([int(row["yolov10n_predictions"][str(seed)]) for row in ordered], truth)
        for seed in SEEDS
    }
    pooled_predictions = [
        int(row["yolov10n_predictions"][str(seed)]) for row in ordered for seed in SEEDS
    ]
    pooled_truth = [actual for actual in truth for _ in SEEDS]
    pooled_metrics = metric_values(pooled_predictions, pooled_truth)
    yolo_errors = np.asarray(
        [
            statistics.fmean(
                abs(int(row["yolov10n_predictions"][str(seed)]) - int(row["true_count"])) for seed in SEEDS
            )
            for row in ordered
        ],
        dtype=np.float64,
    )
    cru_errors = np.asarray(
        [
            statistics.fmean(
                abs(int(cru_by_id[str(row["sample_id"])]["cru_predictions"][str(seed)]) - int(row["true_count"]))
                for seed in SEEDS
            )
            for row in ordered
        ],
        dtype=np.float64,
    )
    lr_errors = np.asarray(
        [abs(int(cru_by_id[str(row["sample_id"])]["low_count"]) - int(row["true_count"])) for row in ordered],
        dtype=np.float64,
    )
    varieties = [str(row["variety"]) for row in ordered]
    bootstrap_config = lock["analysis"]["bootstrap"]
    cru_minus_yolo = cru_errors - yolo_errors
    lr_minus_yolo = lr_errors - yolo_errors
    selected_records = [read_json(_run_dir(fold, seed) / "FROZEN_SELECTION.json") for fold in FOLDS for seed in SEEDS]
    fold_summaries: list[dict[str, Any]] = []
    for fold in FOLDS:
        indices = [index for index, row in enumerate(ordered) if int(row["fold"]) == fold]
        fold_summaries.append(
            {
                "fold": fold,
                "images": len(indices),
                "yolov10n_mae": float(np.mean(yolo_errors[indices])),
                "cru_mae": float(np.mean(cru_errors[indices])),
                "lr_mae": float(np.mean(lr_errors[indices])),
                "cru_minus_yolov10n": float(np.mean(cru_minus_yolo[indices])),
            }
        )
    variety_summaries: dict[str, Any] = {}
    for variety in sorted(set(varieties)):
        indices = [index for index, value in enumerate(varieties) if value == variety]
        variety_summaries[variety] = {
            "images": len(indices),
            "yolov10n_mae": float(np.mean(yolo_errors[indices])),
            "cru_mae": float(np.mean(cru_errors[indices])),
            "lr_mae": float(np.mean(lr_errors[indices])),
            "cru_minus_yolov10n": float(np.mean(cru_minus_yolo[indices])),
        }
    result: dict[str, Any] = {
        "schema_version": 1,
        "generated_at_utc": utc_now(),
        "protocol": PROTOCOL_NAME,
        "protocol_lock_sha256": sha256(EXPERIMENT / "PROTOCOL_LOCK.json"),
        "evidence_classification": lock["evidence_classification"],
        "images": 150,
        "primary": {
            "yolov10n_three_seed_pooled": pooled_metrics,
            "yolov10n_seed_mae_mean": statistics.fmean(seed_metrics[str(seed)]["mae"] for seed in SEEDS),
            "yolov10n_seed_mae_sample_sd": statistics.stdev(seed_metrics[str(seed)]["mae"] for seed in SEEDS),
            "cru": cru["primary"]["cru_randomized_three_seed"],
            "lr": cru["primary"]["lr"],
            "paired_cru_minus_yolov10n_absolute_error": stratified_bootstrap(
                cru_minus_yolo,
                varieties,
                resamples=int(bootstrap_config["resamples"]),
                seed=int(bootstrap_config["seed"]),
            ),
            "paired_lr_minus_yolov10n_absolute_error": stratified_bootstrap(
                lr_minus_yolo,
                varieties,
                resamples=int(bootstrap_config["resamples"]),
                seed=int(bootstrap_config["seed"]) + 1,
            ),
            "cru_vs_yolov10n_image_outcomes": {
                "yolov10n_lower_error": int(np.count_nonzero(cru_minus_yolo > 0)),
                "cru_lower_error": int(np.count_nonzero(cru_minus_yolo < 0)),
                "tied": int(np.count_nonzero(cru_minus_yolo == 0)),
            },
        },
        "seed_metrics": seed_metrics,
        "selected_epochs": [int(row["selected_epoch"]) for row in selected_records],
        "selected_thresholds": [float(row["selected_threshold"]) for row in selected_records],
        "folds": fold_summaries,
        "varieties": variety_summaries,
        "input_sha256": dict(sorted(input_hashes.items())),
        "samples": ordered,
    }
    output_json = EXPERIMENT / "OOF_FINAL_RESULTS.json"
    output_md = EXPERIMENT / "OOF_FINAL_RESULTS.md"
    if output_json.exists() or output_md.exists():
        raise RuntimeError("refusing to overwrite existing final YOLOv10n OOF results")
    atomic_json_write(result, output_json)
    primary = result["primary"]
    yolo = primary["yolov10n_three_seed_pooled"]
    paired = primary["paired_cru_minus_yolov10n_absolute_error"]
    lines = [
        "# GBISC YOLOv10n fixed-protocol five-fold OOF results",
        "",
        f"- Evidence status: {result['evidence_classification']}",
        "- Published model chosen before GBISC inference: Moreira et al. (2026) YOLOv10n",
        f"- Images: {result['images']}",
        f"- YOLOv10n MAE (three training seeds pooled): {yolo['mae']:.3f}",
        f"- YOLOv10n RMSE: {yolo['rmse']:.3f}",
        f"- YOLOv10n MAPE: {yolo['mape_percent']:.3f}%",
        f"- YOLOv10n bias: {yolo['bias']:.3f}",
        f"- YOLOv10n seed MAE: {primary['yolov10n_seed_mae_mean']:.3f} +/- {primary['yolov10n_seed_mae_sample_sd']:.3f}",
        f"- CRU MAE: {primary['cru']['mae']:.3f}",
        f"- LR MAE: {primary['lr']['mae']:.3f}",
        (
            "- Paired CRU-YOLOv10n absolute-error difference: "
            f"{paired['estimate']:.3f}, variety-stratified bootstrap 95% CI "
            f"[{paired['ci95_lower']:.3f}, {paired['ci95_upper']:.3f}]"
        ),
        "",
        "| Fold | YOLOv10n MAE | CRU MAE | LR MAE | CRU-YOLOv10n |",
        "|---:|---:|---:|---:|---:|",
    ]
    for row in fold_summaries:
        lines.append(
            f"| {row['fold']} | {row['yolov10n_mae']:.3f} | {row['cru_mae']:.3f} | "
            f"{row['lr_mae']:.3f} | {row['cru_minus_yolov10n']:.3f} |"
        )
    lines.extend(
        [
            "",
            "The published paper's original-dataset MAPE/RMSE are not compared numerically with these GBISC results.",
            "This is architecture-matched controlled retraining, not an exact reproduction of the authors' experiment.",
            "",
        ]
    )
    atomic_write_text("\n".join(lines), output_md)
    return result


def train_all() -> None:
    for fold in FOLDS:
        for seed in SEEDS:
            train_one(fold, seed)


def select_all() -> None:
    for fold in FOLDS:
        for seed in SEEDS:
            select_one(fold, seed)


def test_all() -> None:
    freeze_gate()
    for fold in FOLDS:
        for seed in SEEDS:
            test_one(fold, seed)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "phase",
        choices=("prepare", "smoke", "train", "select", "freeze-gate", "test", "aggregate", "all"),
    )
    parser.add_argument("--fold", type=int, choices=FOLDS)
    parser.add_argument("--seed", type=int, choices=SEEDS)
    parser.add_argument("--replace-unstarted-lock", action="store_true")
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    if args.phase == "prepare":
        prepare_protocol(replace_unstarted_lock=args.replace_unstarted_lock)
    elif args.phase == "smoke":
        smoke_train()
    elif args.phase == "train":
        if (args.fold is None) != (args.seed is None):
            raise SystemExit("--fold and --seed must be provided together")
        train_one(args.fold, args.seed) if args.fold is not None else train_all()
    elif args.phase == "select":
        if (args.fold is None) != (args.seed is None):
            raise SystemExit("--fold and --seed must be provided together")
        select_one(args.fold, args.seed) if args.fold is not None else select_all()
    elif args.phase == "freeze-gate":
        freeze_gate()
    elif args.phase == "test":
        if (args.fold is None) != (args.seed is None):
            raise SystemExit("--fold and --seed must be provided together")
        test_one(args.fold, args.seed) if args.fold is not None else test_all()
    elif args.phase == "aggregate":
        aggregate()
    else:
        prepare_protocol(replace_unstarted_lock=args.replace_unstarted_lock)
        train_all()
        select_all()
        test_all()
        aggregate()


if __name__ == "__main__":
    main()
