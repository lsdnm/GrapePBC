"""Published baseline reproductions used by the GeoPriv project."""

