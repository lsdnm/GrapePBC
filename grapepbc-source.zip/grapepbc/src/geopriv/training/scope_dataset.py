"""Pinned, letterbox-only dataset for the isolated S1 paired experiment.

The immutable source crop manifest binds train image/label bytes.  Only files
inside a caller-created mirror may be read by YOLODataset (and its label cache).
Scope regions remain unknown, not positive labels. Validation has no scope
keys and must use the official criterion. The control arm uses the SAME train
dataset; the trainer zeros its ignore raster after collation.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import cv2
import numpy as np
import torch
import ultralytics
from ultralytics.data.dataset import YOLODataset

from .scope_segmentation_loss import SCOPE_TRANSFORM, SUPPORTED_ULTRALYTICS


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def transform_scope_masks(unknown, protect, size, *, metadata=None):
    """Audited BaseDataset ceil resize followed by centered square LetterBox.

    This is the verified ``verify_r1_scope_batch`` mapping, kept inside src so
    the trainer has no scripts import. Downsampling preserves any nonzero
    overlap; nearest is used for upsampling. Protection wins and pad is false.
    """
    require(type(size) is int and size > 0, "Invalid canvas size")
    require(unknown.dtype == protect.dtype == bool and unknown.ndim == 2
            and unknown.shape == protect.shape and min(unknown.shape) > 0,
            "Scope masks must be same-size 2D boolean arrays")
    h, w = unknown.shape
    r = size / max(h, w)
    hp, wp = min(math.ceil(h*r), size), min(math.ceil(w*r), size)
    top, left = round((size-hp)/2-.1), round((size-wp)/2-.1)
    ratio_pad = ((hp/h, wp/w), (left, top))
    if metadata is not None:
        require(tuple(metadata["ori_shape"]) == (h, w), "Original crop shape differs from dataset")
        require(tuple(metadata["resized_shape"]) == (size, size), "Unexpected transformed image shape")
        given_ratio, given_pad = metadata["ratio_pad"]
        require(np.allclose(given_ratio, ratio_pad[0], rtol=0, atol=1e-12)
                and tuple(given_pad) == ratio_pad[1], "Dataset/mask transform misalignment")

    def one(mask):
        resized = cv2.resize(mask.astype(np.float32), (wp, hp),
                             interpolation=cv2.INTER_AREA if r < 1 else cv2.INTER_NEAREST) > 0
        canvas = np.zeros((size, size), bool)
        canvas[top:top+hp, left:left+wp] = resized
        return canvas

    up, pp = one(unknown), one(protect)
    conflicts = int(np.count_nonzero(up & pp))
    up &= ~pp
    return up, pp, dict(original_shape=[h, w], load_resized_shape=[hp, wp],
        ratio_pad=ratio_pad, mapped_overlap_resolved_by_protection=conflicts,
        unknown_pixels=int(up.sum()), protect_pixels=int(pp.sum()), padding_unknown=False)


def load_scope_mask(root, info, shape):
    """Load the source-preparation 0/1 PNG, rejecting altered or escaped bytes."""
    if info is None:
        return np.zeros(shape, bool)
    root = Path(root).resolve()
    path = (root / info["path"]).resolve()
    require(path.is_relative_to(root) and sha256_file(path) == info["sha256"],
            "Scope mask hash/path drift")
    value = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    require(value is not None and value.shape == tuple(shape)
            and set(np.unique(value)) <= {0, 1}, "Invalid binary mask encoding")
    require(tuple(info["shape"]) == tuple(shape), "Mask manifest shape changed")
    result = value != 0
    require(int(result.sum()) == info["pixels"], "Scope mask pixel count changed")
    return result


class ScopeDataset(YOLODataset):
    """YOLO segment dataset with final-pixel masks for training only.

    Only the optional first positional argument (img_path) is accepted. This
    prevents positional flags from bypassing the fail-closed geometry checks.
    ``mirror_root`` is the new dataset directory containing images and labels.
    Its train/val directories may hold a subset for an engineering-only smoke.
    """

    def __init__(self, *args, scope_root, mirror_root, train_scope, **kwargs):
        require(ultralytics.__version__ == SUPPORTED_ULTRALYTICS,
                "Unsupported Ultralytics version; re-audit dataset geometry")
        require(len(args) <= 1, "Use keyword dataset arguments after img_path")
        require(type(train_scope) is bool, "train_scope must be bool")
        require(kwargs.get("augment", False) is False, "ScopeDataset requires augment=False")
        require(kwargs.get("rect", False) is False, "ScopeDataset requires rect=False")
        require(kwargs.get("cache", False) is False, "ScopeDataset requires cache=False")
        # The pinned loader treats integer 1 as one image, not a 100% ratio.
        require(type(kwargs.get("fraction", 1.0)) is float and kwargs.get("fraction", 1.0) == 1.0,
                "ScopeDataset must not silently subsample; fraction must be float 1.0")
        require(kwargs.get("task", "segment") == "segment", "ScopeDataset supports segmentation only")
        require(type(kwargs.get("imgsz", 640)) is int, "Square scalar imgsz required")
        self.scope_root = Path(scope_root).resolve()
        self.mirror_root = Path(mirror_root).resolve()
        self.train_scope = train_scope
        self._rows = {}
        manifest = self.scope_root / "crop_manifest.jsonl"
        summary = json.loads((self.scope_root / "summary.json").read_text(encoding="utf-8"))
        require(summary["crop_manifest_sha256"] == sha256_file(manifest), "Scope crop manifest hash drift")
        require(summary["protocol_sha256"] == sha256_file(self.scope_root / "protocol.json"),
                "Scope protocol hash drift")
        require(summary.get("final_test") is False, "Scope inputs must not contain final-test data")
        for line in manifest.read_text(encoding="utf-8").splitlines():
            row = json.loads(line)
            stem = row["crop_id"]
            require(stem not in self._rows, "Duplicate source crop_id")
            require(Path(row["image_path"]).stem == stem and Path(row["label_path"]).stem == stem,
                    "Source crop stem mismatch")
            require(self.mirror_root not in Path(row["image_path"]).resolve().parents
                    and self.mirror_root not in Path(row["label_path"]).resolve().parents,
                    "A separate mirror is required; never use the original crop dataset")
            self._rows[stem] = row
        require(len(self._rows) == summary["crops"] and self._rows, "Incomplete crop manifest")
        img_path = args[0] if args else kwargs.get("img_path")
        require(isinstance(img_path, (str, Path)), "One explicit mirror image directory required")
        resolved_images = Path(img_path).resolve()
        require(resolved_images in {self.mirror_root / "images" / "train", self.mirror_root / "images" / "val"},
                "Images must be in the mirror images/train or images/val directory")
        self._split = resolved_images.name
        require(not train_scope or self._split == "train", "Scope supervision is training-only")
        kwargs.update(augment=False, rect=False, cache=False, task="segment")
        super().__init__(*args, **kwargs)
        require(not self.augment and not self.rect, "Unexpected dataset geometry")

    def get_img_files(self, img_path):
        files = super().get_img_files(img_path)
        stems = set()
        for filename in files:
            image = Path(filename).resolve()
            require(image.parent == self.mirror_root / "images" / self._split,
                    "Image escaped the isolated mirror")
            require(image.stem not in stems, "Duplicate mirror crop stem")
            stems.add(image.stem)
            label = (self.mirror_root / "labels" / self._split / (image.stem + ".txt")).resolve()
            require(label.parent == self.mirror_root / "labels" / self._split,
                    "Label escaped the isolated mirror")
            require(label.is_file(), "Every mirrored crop needs its frozen label file")
            require(not image.with_suffix(".npy").exists(), "Stale .npy image caches are not allowed")
            if self.train_scope:
                require(image.stem in self._rows, "Train crop is absent from the frozen A manifest")
                row = self._rows[image.stem]
                require(sha256_file(image) == row["image_sha256"], "Mirrored crop image hash drift")
                require(sha256_file(label) == row["label_sha256"], "Mirrored crop label hash drift")
        return files

    def __getitem__(self, index):
        require(not self.augment and not self.rect, "Dataset geometry changed after construction")
        sample = super().__getitem__(index)
        if not self.train_scope:
            return sample
        row = self._rows[Path(sample["im_file"]).stem]
        shape = (row["height"], row["width"])
        unknown = load_scope_mask(self.scope_root, row["unknown"], shape)
        protect = load_scope_mask(self.scope_root, row["protect"], shape)
        unknown, protect, _ = transform_scope_masks(unknown, protect, self.imgsz, metadata=sample)
        sample["scope_ignore_mask"] = torch.from_numpy(unknown)
        sample["scope_protect_mask"] = torch.from_numpy(protect)
        return sample

    @staticmethod
    def collate_fn(batch):
        require(bool(batch), "Cannot collate an empty scope batch")
        names = ("scope_ignore_mask", "scope_protect_mask")
        presence = [tuple(name in sample for name in names) for sample in batch]
        require(all(p == presence[0] for p in presence) and presence[0] in {(False, False), (True, True)},
                "Mixed or incomplete scope batch")
        require(all("scope_transform" not in sample for sample in batch), "Per-item transform tags are unsupported")
        plain = [{key: value for key, value in sample.items() if key not in names} for sample in batch]
        result = YOLODataset.collate_fn(plain)
        if presence[0][0]:
            for name in names:
                values = [sample[name] for sample in batch]
                require(all(isinstance(value, torch.Tensor) and value.dtype == torch.bool
                            and value.ndim == 2 and tuple(value.shape) == tuple(sample["img"].shape[-2:])
                            for value, sample in zip(values, batch)), "Scope masks must be bool HxW aligned to img")
                result[name] = torch.stack(values)
            result["scope_transform"] = SCOPE_TRANSFORM
        return result
