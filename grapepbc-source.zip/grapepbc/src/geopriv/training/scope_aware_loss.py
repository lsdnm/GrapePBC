"""Point loss with explicit negative-supervision weights.

Positive point centres and offsets are always retained. Region weights affect
only negative centre supervision, so an uncertain/unlabelled region can be
ignored as background without inventing positive berry coordinates.
"""
from __future__ import annotations

import torch
from torch import Tensor


def scope_aware_point_loss(
    outputs: dict[str, Tensor],
    targets: dict[str, Tensor],
    *,
    negative_weights: Tensor | None = None,
) -> dict[str, Tensor]:
    logits = outputs["center_logits"]
    offsets = outputs["offsets"]
    heatmap = targets["heatmap"]
    target_offsets = targets["offsets"]
    positive_mask = targets["positive_mask"]
    valid = targets["valid_output_mask"]
    if logits.ndim != 4 or logits.shape[1] != 1:
        raise ValueError("center logits must be Bx1xHxW")
    if heatmap.shape != logits.shape or positive_mask.shape != logits.shape or valid.shape != logits.shape:
        raise ValueError("centre target shape mismatch")
    if offsets.shape != target_offsets.shape or offsets.shape != (logits.shape[0], 2, *logits.shape[-2:]):
        raise ValueError("offset target shape mismatch")
    if positive_mask.dtype != torch.bool or valid.dtype != torch.bool:
        raise TypeError("positive and valid masks must be boolean")
    prediction = logits.float().sigmoid().clamp(1e-6, 1 - 1e-6)
    float_target = heatmap.float()
    valid_float = valid.to(prediction.dtype)
    if negative_weights is None:
        negative_weights = torch.ones_like(prediction)
    if negative_weights.shape != logits.shape or not negative_weights.is_floating_point():
        raise ValueError("negative_weights must be floating Bx1xHxW")
    negative_weights = negative_weights.to(device=prediction.device, dtype=prediction.dtype)
    if not bool(torch.isfinite(negative_weights).all()) or bool((negative_weights < 0).any()):
        raise ValueError("negative_weights must be finite and non-negative")
    positive = float_target.eq(1).to(prediction.dtype) * valid_float
    negative = float_target.lt(1).to(prediction.dtype) * valid_float
    negative_shape_weight = (1 - float_target).pow(4)
    positive_loss = -prediction.log() * (1 - prediction).pow(2) * positive
    negative_loss = (-(1 - prediction).log() * prediction.pow(2) *
                     negative_shape_weight * negative * negative_weights)
    positive_count = positive.sum()
    center = (positive_loss.sum() + negative_loss.sum()) / positive_count.clamp_min(1.0)
    offset_mask = positive_mask.expand_as(offsets).to(torch.float32)
    offset = ((offsets.float() - target_offsets.float()).abs() * offset_mask).sum()
    offset = offset / offset_mask.sum().clamp_min(1.0)
    return {"loss": center + offset, "center_loss": center, "offset_loss": offset}


def region_negative_weights(
    targets: list[dict],
    regions_by_sample: dict[str, list[dict]],
    *,
    output_height: int,
    output_width: int,
    output_stride: int,
    background_weight: float = 2.0,
) -> Tensor:
    if output_height <= 0 or output_width <= 0 or output_stride <= 0:
        raise ValueError("invalid output geometry")
    if background_weight < 1 or not float(background_weight) < float("inf"):
        raise ValueError("background_weight must be finite and >=1")
    result = torch.ones((len(targets), 1, output_height, output_width), dtype=torch.float32)
    for batch_index, target in enumerate(targets):
        affine = torch.as_tensor(target["forward_affine"], dtype=torch.float32)
        if affine.shape != (3, 3):
            raise ValueError("forward_affine must be 3x3")
        for region in regions_by_sample.get(target["sample_id"], []):
            x0, y0, x1, y1 = map(float, region["bbox_xyxy"])
            corners = torch.tensor([[x0, y0, 1.0], [x1, y0, 1.0],
                                    [x0, y1, 1.0], [x1, y1, 1.0]])
            mapped = corners @ affine.T
            ox0 = max(0, min(output_width, int(torch.floor(mapped[:, 0].min() / output_stride))))
            oy0 = max(0, min(output_height, int(torch.floor(mapped[:, 1].min() / output_stride))))
            ox1 = max(0, min(output_width, int(torch.ceil(mapped[:, 0].max() / output_stride))))
            oy1 = max(0, min(output_height, int(torch.ceil(mapped[:, 1].max() / output_stride))))
            if ox1 <= ox0 or oy1 <= oy0:
                continue
            policy = region["negative_supervision_policy"]
            if policy == "mask":
                value = 0.0
            elif policy == "retain":
                value = background_weight
            else:
                raise ValueError("unknown negative supervision policy")
            result[batch_index, 0, oy0:oy1, ox0:ox1] = value
    return result
