"""Explicit-role native instance dataset for the matched-context experiment.

No new labels, augmentation, JPEG re-encoding or test roles. Source masks are
cached in a small LRU, avoiding an all-dataset foreground raster in memory.
"""
from collections import OrderedDict
import hashlib
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps
import torch
from torch.utils.data import Dataset, Sampler

from geopriv.counting.candidate_ceiling import raster_roi
from geopriv.counting.native_mask import NativeMask
from geopriv.training.native_context_dataset import make_native_sample, NativeContextDataset


class MatchedUpdateSampler(Sampler):
    """Complete random permutations followed by a deterministic random prefix."""
    def __init__(self, length, samples, seed):
        if length <= 0 or samples < length or samples % 2:
            raise ValueError('Budget must cover dataset and contain complete pairs')
        self.length, self.samples, self.seed, self.epoch = length, samples, seed, 0

    def set_epoch(self, epoch):
        self.epoch = int(epoch)

    def order(self):
        generator = torch.Generator().manual_seed(self.seed + self.epoch)
        order = []
        while len(order) < self.samples:
            order.extend(torch.randperm(self.length, generator=generator).tolist())
        return order[:self.samples]

    def __iter__(self):
        return iter(self.order())

    def __len__(self):
        return self.samples


class NativePairDataset(Dataset):
    collate_fn = staticmethod(NativeContextDataset.collate_fn)

    def __init__(self, raw_root, sources, records, annotations, *, role,
                 require_complete=False, size=768, mask_ratio=4):
        if role not in ('expert_A', 'development_val'):
            raise ValueError('B or test role forbidden')
        self.root = Path(raw_root).resolve()
        self.sources = {r['original_id']: r for r in sources}
        if len(sources) != len(self.sources):
            raise ValueError('Duplicate sources')
        for r in sources:
            if (r['role'] != role or r['split'] != ('train' if role == 'expert_A' else 'val')
                    or r.get('external_test') or r.get('final_test') or not r['supervision_approved']):
                raise ValueError('Role/supervision boundary violated')
        self.records, self.annotations = records, annotations
        self.size, self.mask_ratio, self.require_complete = size, mask_ratio, require_complete
        self._cache, self._verified = OrderedDict(), set()
        self.im_files = []
        for i, record in enumerate(records):
            row = self.sources.get(record['image'])
            if row is None:
                raise ValueError('Crop source outside explicit role')
            x0, y0, x1, y1 = record['bounds']
            if (any(type(v) is not int for v in record['bounds']) or
                    not 0 <= x0 < x1 <= row['width'] or not 0 <= y0 < y1 <= row['height']):
                raise ValueError('Invalid crop bounds')
            if any(not 0 <= gt < len(annotations[record['image']]) for gt in record['intended_gt_ids']):
                raise ValueError('Unknown intended instance')
            # Unique metadata name only; pixels always read from hashed source.
            self.im_files.append(str(self.root / f'native_metadata/{role}/{Path(record["image"]).stem}_{i:05d}.png'))
        self.last_audit = None

    def __len__(self):
        return len(self.records)

    def source(self, name):
        if name in self._cache:
            self._cache.move_to_end(name)
            return self._cache[name]
        row = self.sources[name]
        path = (self.root / row['image_path']).resolve()
        if not path.is_relative_to(self.root):
            raise ValueError('Source path escape')
        if name not in self._verified:
            with path.open('rb') as stream:
                if hashlib.file_digest(stream, 'sha256').hexdigest() != row['sha256']:
                    raise ValueError('Source pixels changed')
            self._verified.add(name)
        with Image.open(path) as opened:
            raw = ImageOps.exif_transpose(opened).convert('RGB')
            if raw.size != (row['width'], row['height']):
                raise ValueError('Source dimensions changed')
            rgb = np.asarray(raw).copy()
        masks = []
        for a in self.annotations[name]:
            roi = raster_roi(a['polygons_xy'], (row['width'], row['height']))
            masks.append(NativeMask(roi.x, roi.y, roi.mask))
        self._cache[name] = rgb, masks
        while len(self._cache) > 2:
            self._cache.popitem(last=False)
        return rgb, masks

    def __getitem__(self, index):
        record = self.records[index]
        rgb, source_masks = self.source(record['image'])
        x0, y0, x1, y1 = record['bounds']
        masks, ids = [], []
        for gt, mask in enumerate(source_masks):
            cropped = mask.crop(record['bounds'])
            if self.require_complete and gt in record['intended_gt_ids'] and int(cropped.sum()) != mask.area:
                raise ValueError('Intended target truncated')
            if cropped.any():
                ids.append(gt)
                masks.append(cropped)
        sample, survival = make_native_sample(rgb[y0:y1, x0:x1], masks, size=self.size,
            mask_ratio=self.mask_ratio, im_file=self.im_files[index])
        self.last_audit = dict(image=record['image'], bounds=record['bounds'], source_gt_ids=ids,
            intended_gt_ids=record['intended_gt_ids'], mask_survival=survival,
            vanished_loss_masks=sum(s['loss_pixels'] == 0 for s in survival))
        return sample
