"""Opt-in partial-label supervision. Scope is training-only, never ROI gating.

Cluster polygons indicate annotated support, NOT certified complete berry masks.
All original positive points remain supervised. Outside support the frozen
counter supplies a soft consistency reference, never a fabricated background GT.
"""
import torch
from .losses import geopriv_loss


def scoped_count_loss(outputs, targets, scope, teacher_logits, *, weights, consistency_weight=.1):
    valid = targets['valid_output_mask']
    if scope.dtype != torch.bool or scope.shape != valid.shape:
        raise ValueError('scope must be a boolean output-sized mask')
    if teacher_logits.shape != outputs['center_logits'].shape:
        raise ValueError('teacher/student size mismatch')
    if not 0 <= consistency_weight <= 1:
        raise ValueError('consistency weight outside declared range')
    # Preserve every positive and its Gaussian support even if polygons miss it.
    supervised = (scope | (targets['heatmap'] > 0)) & valid
    if bool((targets['positive_mask'] & ~supervised).any()):
        raise ValueError('positive supervision lost')
    selected = dict(targets, valid_output_mask=supervised)
    base = geopriv_loss(outputs, selected, weights=weights)
    unknown = valid & ~supervised
    student = outputs['center_logits'].float().sigmoid()
    teacher = teacher_logits.detach().float().sigmoid()
    normalizer = targets['positive_mask'].sum().clamp_min(1)
    consistency = ((student-teacher).square()*unknown).sum()/normalizer
    return dict(loss=base['loss']+consistency_weight*consistency,
        supervised_loss=base['loss'], consistency_loss=consistency,
        supervised_pixels=supervised.sum(), unknown_pixels=unknown.sum())
