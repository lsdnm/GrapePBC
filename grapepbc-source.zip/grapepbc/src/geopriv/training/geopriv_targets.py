"""Targets for the geometry-privileged GeoPriv training stage.

The point heads can represent at most one instance per output cell.  When two
points collide, one deterministic representative (preferring an instance with
geometry) is used consistently for the center, offset, and radius targets.
The density target has no such restriction and retains one unit of mass for
every valid instance.
"""

from __future__ import annotations

from collections.abc import Sequence
import math

import torch
from torch import Tensor
import torch.nn.functional as F

from .targets import _draw_gaussian


def _as_instance_vector(
    value: Tensor | float | bool | None,
    count: int,
    *,
    dtype: torch.dtype,
    device: torch.device,
    default: float | bool,
    name: str,
) -> Tensor:
    if value is None:
        return torch.full((count,), default, dtype=dtype, device=device)
    tensor = torch.as_tensor(value, dtype=dtype, device=device)
    if tensor.ndim == 0:
        return tensor.expand(count)
    if tensor.ndim != 1 or tensor.numel() != count:
        raise ValueError(f"{name} must be scalar or have shape ({count},), got {tuple(tensor.shape)}")
    return tensor


def _batch_item(
    values: Sequence[Tensor | float | bool | None] | Tensor | None,
    index: int,
    batch: int,
    *,
    name: str,
) -> Tensor | float | bool | None:
    if values is None:
        return None
    if isinstance(values, Tensor):
        if values.ndim == 0:
            return values
        if len(values) != batch:
            raise ValueError(f"{name} must contain {batch} batch items, got {len(values)}")
        return values[index]
    if len(values) != batch:
        raise ValueError(f"{name} must contain {batch} batch items, got {len(values)}")
    return values[index]


def _output_valid_mask(
    valid_image_mask: Tensor | None,
    *,
    batch: int,
    output_height: int,
    output_width: int,
    device: torch.device,
) -> Tensor:
    if valid_image_mask is None:
        return torch.ones(
            (batch, 1, output_height, output_width), dtype=torch.bool, device=device
        )
    mask = valid_image_mask.to(device=device)
    if mask.ndim == 3:
        mask = mask[:, None]
    if mask.ndim != 4 or mask.shape[0] != batch or mask.shape[1] != 1:
        raise ValueError(
            "valid_image_mask must have shape (B, H, W) or (B, 1, H, W), "
            f"got {tuple(mask.shape)}"
        )
    if mask.dtype != torch.bool:
        if not mask.is_floating_point() and mask.dtype not in {
            torch.uint8,
            torch.int8,
            torch.int16,
            torch.int32,
            torch.int64,
        }:
            raise TypeError("valid_image_mask must be boolean or a binary numeric tensor")
        if bool(((mask != 0) & (mask != 1)).any()):
            raise ValueError("valid_image_mask must contain only 0/1 values")
        mask = mask.bool()
    if mask.shape[-2:] != (output_height, output_width):
        input_height, input_width = mask.shape[-2:]
        if input_height >= output_height and input_width >= output_width:
            # An output cell is valid when any input pixel represented by that
            # cell is valid.  Nearest-neighbour sampling loses the first valid
            # row/column whenever letterbox padding has an odd extent.
            mask = F.adaptive_max_pool2d(
                mask.float(), output_size=(output_height, output_width)
            ).bool()
        else:
            mask = F.interpolate(
                mask.float(), size=(output_height, output_width), mode="nearest"
            ).bool()
    return mask


def _add_unit_density(
    density: Tensor,
    valid_mask: Tensor,
    *,
    center_x: float,
    center_y: float,
    sigma: float,
) -> None:
    """Add a cropped Gaussian whose mass on valid output pixels is exactly one."""

    if not sigma > 0:
        raise ValueError("density_sigma must be positive")
    height, width = density.shape
    support = max(1, math.ceil(4.0 * sigma))
    floor_x = math.floor(center_x)
    floor_y = math.floor(center_y)
    left = max(0, floor_x - support)
    right = min(width, floor_x + support + 1)
    top = max(0, floor_y - support)
    bottom = min(height, floor_y + support + 1)

    xs = torch.arange(left, right, device=density.device, dtype=density.dtype)
    ys = torch.arange(top, bottom, device=density.device, dtype=density.dtype)
    yy, xx = torch.meshgrid(ys, xs, indexing="ij")
    kernel = torch.exp(
        -((xx - center_x).square() + (yy - center_y).square()) / (2.0 * sigma * sigma)
    )
    kernel = kernel * valid_mask[top:bottom, left:right].to(kernel.dtype)
    mass = kernel.sum()
    mass_value = mass.item()
    if not math.isfinite(mass_value) or mass_value <= 0:
        raise ValueError("a valid point has no valid output pixel on which to place density")
    density[top:bottom, left:right] += kernel / mass


def build_geopriv_targets(
    points_xy: Sequence[Tensor],
    *,
    output_height: int,
    output_width: int,
    stride: int = 2,
    gaussian_radius: int = 2,
    density_sigma: float = 1.5,
    density_sigma_mode: str = "fixed",
    density_radius_divisor: float = 3.0,
    density_sigma_min: float = 0.5,
    density_sigma_max: float = 4.0,
    equivalent_radius: Sequence[Tensor | None] | Tensor | None = None,
    frame_boundary_completeness: Sequence[Tensor | None] | Tensor | None = None,
    geometry_available: Sequence[Tensor | bool | None] | Tensor | None = None,
    valid_image_mask: Tensor | None = None,
    device: torch.device | str | None = None,
) -> dict[str, Tensor]:
    """Build GeoPriv center, geometry, density, and count targets.

    Coordinates and radii are supplied in input-image pixels.  Radius targets
    are ``log(equivalent_radius / stride)``.  Frame-boundary completeness is a
    confidence weight, not an occlusion estimate.  Geometry may be marked
    available per image (scalar) or per instance (length ``N``). In
    ``privileged_radius`` mode, a geometry-bearing berry's density sigma is
    ``equivalent_radius / stride / density_radius_divisor``, clamped to the
    configured bounds. Every Gaussian remains normalized to unit mass.
    """

    if output_height <= 0 or output_width <= 0:
        raise ValueError("output dimensions must be positive")
    if stride <= 0:
        raise ValueError("stride must be positive")
    if gaussian_radius < 0:
        raise ValueError("gaussian_radius must be non-negative")
    if density_sigma <= 0:
        raise ValueError("density_sigma must be positive")
    if density_sigma_mode not in {"fixed", "privileged_radius"}:
        raise ValueError(
            "density_sigma_mode must be 'fixed' or 'privileged_radius'"
        )
    if density_radius_divisor <= 0:
        raise ValueError("density_radius_divisor must be positive")
    if density_sigma_min <= 0:
        raise ValueError("density_sigma_min must be positive")
    if density_sigma_max < density_sigma_min:
        raise ValueError("density_sigma_max must be at least density_sigma_min")

    batch = len(points_xy)
    target_device = torch.device(device) if device is not None else (
        points_xy[0].device if batch else torch.device("cpu")
    )
    # Target generation is deliberately kept on CPU.  The implementation has
    # per-instance control flow and small Gaussian kernels; running that loop
    # on CUDA would force repeated device/host scalar synchronisations.  The
    # completed target mapping is transferred only at the API boundary below.
    build_device = torch.device("cpu")
    shape = (batch, 1, output_height, output_width)
    heatmap = torch.zeros(shape, dtype=torch.float32, device=build_device)
    offsets = torch.zeros((batch, 2, output_height, output_width), device=build_device)
    positive_mask = torch.zeros(shape, dtype=torch.bool, device=build_device)
    log_radius = torch.zeros(shape, dtype=torch.float32, device=build_device)
    radius_mask = torch.zeros(shape, dtype=torch.bool, device=build_device)
    radius_weights = torch.zeros(shape, dtype=torch.float32, device=build_device)
    density = torch.zeros(shape, dtype=torch.float32, device=build_device)
    representative_instance_indices = torch.full(
        shape, -1, dtype=torch.int64, device=build_device
    )
    valid_output_mask = _output_valid_mask(
        valid_image_mask,
        batch=batch,
        output_height=output_height,
        output_width=output_width,
        device=build_device,
    )
    counts = torch.zeros((batch,), dtype=torch.float32, device=build_device)
    collision_counts = torch.zeros((batch,), dtype=torch.int64, device=build_device)

    for batch_index, raw_points in enumerate(points_xy):
        points = torch.as_tensor(raw_points, dtype=torch.float32, device=build_device)
        if points.ndim != 2 or points.shape[1] != 2:
            raise ValueError(
                f"points_xy[{batch_index}] must have shape (N, 2), got {tuple(points.shape)}"
            )
        if not bool(torch.isfinite(points).all()):
            raise ValueError(f"points_xy[{batch_index}] contains non-finite coordinates")
        count = len(points)

        radii_item = _batch_item(
            equivalent_radius, batch_index, batch, name="equivalent_radius"
        )
        availability_item = _batch_item(
            geometry_available, batch_index, batch, name="geometry_available"
        )
        if availability_item is None:
            availability = torch.full(
                (count,), radii_item is not None, dtype=torch.bool, device=build_device
            )
        else:
            availability = _as_instance_vector(
                availability_item,
                count,
                dtype=torch.bool,
                device=build_device,
                default=False,
                name=f"geometry_available[{batch_index}]",
            )
        if bool(availability.any()) and radii_item is None:
            raise ValueError(
                f"equivalent_radius[{batch_index}] is required when geometry is available"
            )
        radii = _as_instance_vector(
            radii_item,
            count,
            dtype=torch.float32,
            device=build_device,
            default=1.0,
            name=f"equivalent_radius[{batch_index}]",
        )
        completeness = _as_instance_vector(
            _batch_item(
                frame_boundary_completeness,
                batch_index,
                batch,
                name="frame_boundary_completeness",
            ),
            count,
            dtype=torch.float32,
            device=build_device,
            default=1.0,
            name=f"frame_boundary_completeness[{batch_index}]",
        )
        if bool(availability.any()):
            available_radii = radii[availability]
            available_completeness = completeness[availability]
            if not bool(torch.isfinite(available_radii).all()) or bool(
                (available_radii <= 0).any()
            ):
                raise ValueError("available equivalent radii must be finite and positive")
            if not bool(torch.isfinite(available_completeness).all()) or bool(
                ((available_completeness < 0) | (available_completeness > 1)).any()
            ):
                raise ValueError("frame_boundary_completeness must lie in [0, 1]")

        scaled = points / float(stride)
        valid_map = valid_output_mask[batch_index, 0]
        candidates_by_cell: dict[tuple[int, int], list[int]] = {}
        scaled_xy = scaled.tolist()
        for instance_index, (x, y) in enumerate(scaled_xy):
            cell_x, cell_y = math.floor(x), math.floor(y)
            if not (0 <= cell_x < output_width and 0 <= cell_y < output_height):
                continue
            if not bool(valid_map[cell_y, cell_x]):
                continue

            counts[batch_index] += 1
            instance_density_sigma = density_sigma
            if (
                density_sigma_mode == "privileged_radius"
                and bool(availability[instance_index])
            ):
                instance_density_sigma = min(
                    density_sigma_max,
                    max(
                        density_sigma_min,
                        float(radii[instance_index])
                        / float(stride)
                        / density_radius_divisor,
                    ),
                )
            _add_unit_density(
                density[batch_index, 0],
                valid_map,
                center_x=x,
                center_y=y,
                sigma=instance_density_sigma,
            )
            candidates_by_cell.setdefault((cell_y, cell_x), []).append(instance_index)

        for (cell_y, cell_x), candidate_indices in sorted(candidates_by_cell.items()):
            collision_counts[batch_index] += len(candidate_indices) - 1

            def representative_key(instance_index: int) -> tuple[float, ...]:
                x, y = scaled_xy[instance_index]
                has_geometry = bool(availability[instance_index])
                # Geometry-bearing instances take precedence.  The remaining
                # fields make the result independent of COCO annotation order.
                radius = float(radii[instance_index]) if has_geometry else math.inf
                completeness_value = (
                    float(completeness[instance_index]) if has_geometry else math.inf
                )
                return (
                    0.0 if has_geometry else 1.0,
                    y,
                    x,
                    radius,
                    -completeness_value,
                )

            instance_index = min(candidate_indices, key=representative_key)
            x, y = scaled_xy[instance_index]
            positive_mask[batch_index, 0, cell_y, cell_x] = True
            representative_instance_indices[batch_index, 0, cell_y, cell_x] = instance_index
            offsets[batch_index, 0, cell_y, cell_x] = x - cell_x
            offsets[batch_index, 1, cell_y, cell_x] = y - cell_y
            _draw_gaussian(
                heatmap[batch_index, 0], cell_x, cell_y, gaussian_radius
            )
            if bool(availability[instance_index]):
                radius_mask[batch_index, 0, cell_y, cell_x] = True
                log_radius[batch_index, 0, cell_y, cell_x] = torch.log(
                    radii[instance_index] / float(stride)
                )
                radius_weights[batch_index, 0, cell_y, cell_x] = completeness[
                    instance_index
                ]

    # Gaussian shoulders and all density mass must be absent from padding.
    heatmap *= valid_output_mask
    density *= valid_output_mask
    total_valid_points = counts.sum()
    total_collisions = collision_counts.sum()
    result = {
        "heatmap": heatmap,
        "offsets": offsets,
        "positive_mask": positive_mask,
        "log_radius": log_radius,
        "radius_mask": radius_mask,
        "radius_weights": radius_weights,
        "density": density,
        "counts": counts,
        "valid_output_mask": valid_output_mask,
        "representative_instance_indices": representative_instance_indices,
        "valid_point_count": total_valid_points.to(torch.int64),
        "collision_count": total_collisions,
        "collision_rate": total_collisions.float() / total_valid_points.clamp_min(1),
    }
    if target_device != build_device:
        result = {
            name: value.to(device=target_device, non_blocking=False)
            for name, value in result.items()
        }
    return result
