"""Composable losses for GeoPriv-GrapeCount."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

import torch
from torch import Tensor
import torch.nn.functional as F


@dataclass(frozen=True)
class GeoPrivLossWeights:
    """Weights for independently switchable GeoPriv loss terms."""

    center: float = 1.0
    offset: float = 1.0
    radius: float = 0.25
    density: float = 0.2
    count_conservation: float = 0.1

    def __post_init__(self) -> None:
        for name, value in self.__dict__.items():
            if value < 0 or not float(value) < float("inf"):
                raise ValueError(f"{name} weight must be finite and non-negative")


def _masked_centernet_focal_loss(logits: Tensor, targets: Tensor, valid: Tensor) -> Tensor:
    predictions = logits.float().sigmoid().clamp(1e-6, 1 - 1e-6)
    float_targets = targets.float()
    valid_float = valid.to(predictions.dtype)
    positive = float_targets.eq(1).to(predictions.dtype) * valid_float
    negative = float_targets.lt(1).to(predictions.dtype) * valid_float
    negative_weights = (1 - float_targets).pow(4)
    positive_loss = -(predictions.log()) * (1 - predictions).pow(2) * positive
    negative_loss = (
        -((1 - predictions).log())
        * predictions.pow(2)
        * negative_weights
        * negative
    )
    positive_count = positive.sum()
    return (positive_loss.sum() + negative_loss.sum()) / positive_count.clamp_min(1.0)


def _zero(reference: Tensor) -> Tensor:
    return reference.sum() * 0.0


def _coerce_weights(
    weights: GeoPrivLossWeights | Mapping[str, float] | None,
) -> GeoPrivLossWeights:
    if weights is None:
        return GeoPrivLossWeights()
    if isinstance(weights, GeoPrivLossWeights):
        return weights
    allowed = {field for field in GeoPrivLossWeights.__dataclass_fields__}
    unknown = set(weights) - allowed
    if unknown:
        raise ValueError(f"unknown GeoPriv loss weights: {sorted(unknown)}")
    return GeoPrivLossWeights(**{name: float(value) for name, value in weights.items()})


def _tensor(mapping: dict[str, Tensor], key: str, *, owner: str) -> Tensor:
    if key not in mapping:
        raise KeyError(f"{owner} must contain {key}")
    value = mapping[key]
    if not isinstance(value, Tensor):
        raise TypeError(f"{owner}[{key!r}] must be a torch.Tensor")
    return value


def _validate_floating(
    tensor: Tensor,
    *,
    name: str,
    shape: tuple[int, ...],
    device: torch.device,
) -> None:
    if tuple(tensor.shape) != shape:
        raise ValueError(f"{name} must have shape {shape}, got {tuple(tensor.shape)}")
    if not tensor.is_floating_point():
        raise TypeError(f"{name} must have a floating-point dtype, got {tensor.dtype}")
    if tensor.device != device:
        raise ValueError(f"{name} must be on {device}, got {tensor.device}")


def _validate_bool(
    tensor: Tensor,
    *,
    name: str,
    shape: tuple[int, ...],
    device: torch.device,
) -> None:
    if tuple(tensor.shape) != shape:
        raise ValueError(f"{name} must have shape {shape}, got {tuple(tensor.shape)}")
    if tensor.dtype != torch.bool:
        raise TypeError(f"{name} must have dtype torch.bool, got {tensor.dtype}")
    if tensor.device != device:
        raise ValueError(f"{name} must be on {device}, got {tensor.device}")


def geopriv_loss(
    outputs: dict[str, Tensor],
    targets: dict[str, Tensor],
    *,
    weights: GeoPrivLossWeights | Mapping[str, float] | None = None,
    count_conservation_mode: str = "relative_l1",
) -> dict[str, Tensor]:
    """Compute the five supervised GeoPriv terms and their weighted sum.

    A term is disabled by assigning it weight zero.  Disabled terms do not
    require the corresponding output head.  Radius loss is an exact,
    differentiable zero when a batch contains no usable geometry.
    """

    loss_weights = _coerce_weights(weights)
    if count_conservation_mode not in {"relative_l1", "poisson_smooth_l1"}:
        raise ValueError(
            "count_conservation_mode must be 'relative_l1' or "
            "'poisson_smooth_l1'"
        )
    reference = _tensor(outputs, "center_logits", owner="outputs")
    if reference.ndim != 4 or reference.shape[1] != 1:
        raise ValueError(
            "outputs['center_logits'] must have shape (B, 1, H, W), "
            f"got {tuple(reference.shape)}"
        )
    if not reference.is_floating_point():
        raise TypeError("outputs['center_logits'] must have a floating-point dtype")
    batch, _, height, width = reference.shape
    dense_shape = (batch, 1, height, width)
    device = reference.device
    zero = _zero(reference)
    valid = _tensor(targets, "valid_output_mask", owner="targets")
    _validate_bool(
        valid,
        name="targets['valid_output_mask']",
        shape=dense_shape,
        device=device,
    )

    if loss_weights.center:
        heatmap = _tensor(targets, "heatmap", owner="targets")
        _validate_floating(
            heatmap,
            name="targets['heatmap']",
            shape=dense_shape,
            device=device,
        )
        center = _masked_centernet_focal_loss(
            reference, heatmap, valid
        )
    else:
        center = zero

    if loss_weights.offset:
        predicted_offsets = _tensor(outputs, "offsets", owner="outputs")
        target_offsets = _tensor(targets, "offsets", owner="targets")
        offset_shape = (batch, 2, height, width)
        _validate_floating(
            predicted_offsets,
            name="outputs['offsets']",
            shape=offset_shape,
            device=device,
        )
        _validate_floating(
            target_offsets,
            name="targets['offsets']",
            shape=offset_shape,
            device=device,
        )
        positive_mask = _tensor(targets, "positive_mask", owner="targets")
        _validate_bool(
            positive_mask,
            name="targets['positive_mask']",
            shape=dense_shape,
            device=device,
        )
        offset_mask = positive_mask.expand(offset_shape).to(torch.float32)
        offset_error = (predicted_offsets.float() - target_offsets.float()).abs()
        offset = (offset_error * offset_mask).sum() / offset_mask.sum().clamp_min(1.0)
    else:
        offset = zero

    if loss_weights.radius:
        predicted_radius = _tensor(outputs, "log_radius", owner="outputs")
        target_radius = _tensor(targets, "log_radius", owner="targets")
        radius_mask = _tensor(targets, "radius_mask", owner="targets")
        radius_weights = _tensor(targets, "radius_weights", owner="targets")
        _validate_floating(
            predicted_radius,
            name="outputs['log_radius']",
            shape=dense_shape,
            device=device,
        )
        _validate_floating(
            target_radius,
            name="targets['log_radius']",
            shape=dense_shape,
            device=device,
        )
        _validate_bool(
            radius_mask,
            name="targets['radius_mask']",
            shape=dense_shape,
            device=device,
        )
        _validate_floating(
            radius_weights,
            name="targets['radius_weights']",
            shape=dense_shape,
            device=device,
        )
        radius_weight = radius_weights.float() * radius_mask
        weight_sum = radius_weight.sum()
        elementwise = F.smooth_l1_loss(
            predicted_radius.float(),
            target_radius.float(),
            reduction="none",
        )
        radius = (elementwise * radius_weight).sum() / weight_sum.clamp_min(
            torch.finfo(radius_weight.dtype).tiny
        )
    else:
        radius = zero

    needs_density = bool(loss_weights.density or loss_weights.count_conservation)
    predicted_density: Tensor | None = None
    target_density: Tensor | None = None
    true_counts: Tensor | None = None
    if needs_density:
        density_logits = _tensor(outputs, "density_logits", owner="outputs")
        _validate_floating(
            density_logits,
            name="outputs['density_logits']",
            shape=dense_shape,
            device=device,
        )
        predicted_density = F.softplus(density_logits.float())
        predicted_density = predicted_density * valid.to(predicted_density.dtype)
        true_counts = _tensor(targets, "counts", owner="targets")
        _validate_floating(
            true_counts,
            name="targets['counts']",
            shape=(batch,),
            device=device,
        )

    if loss_weights.density:
        assert predicted_density is not None
        assert true_counts is not None
        target_density = _tensor(targets, "density", owner="targets")
        _validate_floating(
            target_density,
            name="targets['density']",
            shape=dense_shape,
            device=device,
        )
        squared_error = (
            predicted_density - target_density.float()
        ).square() * valid.to(predicted_density.dtype)
        # Normalizing by canvas area makes this supervision vanish as image
        # resolution grows.  Density maps carry one unit of mass per instance,
        # so a per-image SSE normalized by the true count has stable meaning
        # across letterbox sizes and across sparse/dense bunches.
        count_normalizer = true_counts.to(squared_error.dtype).clamp_min(1.0)
        density = (squared_error.flatten(1).sum(1) / count_normalizer).mean()
    else:
        density = zero

    if loss_weights.count_conservation:
        assert predicted_density is not None
        assert true_counts is not None
        predicted_counts = predicted_density.flatten(1).sum(1)
        true_counts = true_counts.to(predicted_counts.dtype)
        count_error = predicted_counts - true_counts
        if count_conservation_mode == "relative_l1":
            count_conservation = (
                count_error.abs() / true_counts.clamp_min(1.0)
            ).mean()
        else:
            # The square-root denominator approximates Poisson variance while
            # avoiding the strong 1/N weighting that over-prioritizes sparse
            # bunches and pulls dense-bunch predictions toward the mean.
            standardized_error = count_error / true_counts.clamp_min(1.0).sqrt()
            count_conservation = F.smooth_l1_loss(
                standardized_error,
                torch.zeros_like(standardized_error),
                beta=1.0,
            )
    else:
        count_conservation = zero

    total = (
        loss_weights.center * center
        + loss_weights.offset * offset
        + loss_weights.radius * radius
        + loss_weights.density * density
        + loss_weights.count_conservation * count_conservation
    )
    return {
        "loss": total,
        "center_loss": center,
        "offset_loss": offset,
        "radius_loss": radius,
        "density_loss": density,
        "count_conservation_loss": count_conservation,
    }
