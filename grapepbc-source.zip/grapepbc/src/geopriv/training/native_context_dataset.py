"""Opt-in exact-instance training input. Engineering adapter, no auto-training.

No contour joining; source instances are kept intact across disconnected parts.
Nearest pixel resize and mask downsampling are explicit and not called lossless.
Only frozen expert_A sources are accepted. No augmentation is implemented yet.
"""
import hashlib
import math
from pathlib import Path
import cv2
import numpy as np
from PIL import Image,ImageOps
import torch
from torch.utils.data import Dataset
from ultralytics.data.dataset import YOLODataset
from geopriv.counting.candidate_ceiling import raster_roi
from geopriv.counting.native_mask import NativeMask


def make_native_sample(rgb,masks,*,size=768,mask_ratio=4,im_file='engineering'):
    if size<=0 or mask_ratio<=0 or size%mask_ratio:raise ValueError('Invalid size/mask ratio')
    if rgb.ndim!=3 or rgb.shape[2]!=3 or rgb.dtype!=np.uint8:raise ValueError('RGB uint8 required')
    h,w=rgb.shape[:2];scale=size/max(h,w);hp,wp=min(math.ceil(h*scale),size),min(math.ceil(w*scale),size)
    top,left=round((size-hp)/2-.1),round((size-wp)/2-.1)
    image=np.full((size,size,3),114,np.uint8);image[top:top+hp,left:left+wp]=cv2.resize(rgb,(wp,hp),interpolation=cv2.INTER_LINEAR)
    transformed=[];boxes=[];survival=[]
    for mask in masks:
        if mask.shape!=(h,w) or mask.dtype!=bool or not mask.any():raise ValueError('Invalid instance mask')
        ys,xs=np.nonzero(mask);x0,y0=float(xs.min())*wp/w+left,float(ys.min())*hp/h+top
        x1,y1=float(xs.max()+1)*wp/w+left,float(ys.max()+1)*hp/h+top
        canvas=np.zeros((size,size),np.uint8);canvas[top:top+hp,left:left+wp]=cv2.resize(mask.astype(np.uint8),(wp,hp),interpolation=cv2.INTER_NEAREST)
        reduced=cv2.resize(canvas,(size//mask_ratio,size//mask_ratio),interpolation=cv2.INTER_NEAREST)
        transformed.append(reduced);boxes.append([(x0+x1)/2/size,(y0+y1)/2/size,(x1-x0)/size,(y1-y0)/size])
        survival.append(dict(source_pixels=int(mask.sum()),input_pixels=int(canvas.sum()),loss_pixels=int(reduced.sum())))
    n=len(masks)
    sample=dict(img=torch.from_numpy(np.ascontiguousarray(image.transpose(2,0,1))),
        masks=torch.from_numpy(np.asarray(transformed,dtype=np.uint8).reshape(n,size//mask_ratio,size//mask_ratio)),
        bboxes=torch.tensor(boxes,dtype=torch.float32).reshape(n,4),cls=torch.zeros((n,1)),batch_idx=torch.zeros(n),
        sem_masks=torch.zeros((size//mask_ratio,size//mask_ratio)),im_file=str(im_file),ori_shape=(h,w),resized_shape=(size,size),
        ratio_pad=((hp/h,wp/w),(left,top)))
    return sample,survival


class NativeContextDataset(Dataset):
    """A-only raw-image crop loader with source hash checks and no side effects.

    Source/plan/annotation manifests must be hash-bound by the calling protocol.
    This class alone is not a durable full-training integration.
    """
    collate_fn=staticmethod(YOLODataset.collate_fn)

    def __init__(self,raw_root,sources,plans,annotations,size=768,mask_ratio=4):
        self.root=Path(raw_root).resolve();self.size=size;self.mask_ratio=mask_ratio
        self.sources={r['original_id']:r for r in sources};self.records=[];self.masks={};self._verified=set();self.last_audit=None
        if len(self.sources)!=len(sources) or set(self.sources)!={p['image'] for p in plans}:raise ValueError('Source/plan scope differs')
        for row in sources:
            if row.get('role')!='expert_A' or row.get('split')!='train' or row.get('external_test') or row.get('final_test'):
                raise ValueError('Only frozen expert A train sources allowed')
            name=row['original_id'];self.masks[name]=[]
            for a in annotations[name]:
                r=raster_roi(a['polygons_xy'],(row['width'],row['height']));self.masks[name].append(NativeMask(r.x,r.y,r.mask))
        for plan in plans:
            if plan['source_sha256']!=self.sources[plan['image']]['sha256']:raise ValueError('Plan source drift')
            for crop in plan['crops']:self.records.append((plan['image'],tuple(crop['bounds']),crop['intended_gt_ids']))

    def __len__(self):return len(self.records)

    def __getitem__(self,index):
        name,bounds,intended=self.records[index];row=self.sources[name];path=(self.root/row['image_path']).resolve()
        if not path.is_relative_to(self.root):raise ValueError('Source path escape')
        if name not in self._verified:
            with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
            if digest!=row['sha256']:raise ValueError('Source image drift')
            self._verified.add(name)
        with Image.open(path) as opened:
            raw=ImageOps.exif_transpose(opened).convert('RGB')
            if raw.size!=(row['width'],row['height']):raise ValueError('Source dimensions drift')
            rgb=np.asarray(raw.crop(bounds))
        masks=[];ids=[]
        for gt,m in enumerate(self.masks[name]):
            local=m.crop(bounds)
            if gt in intended and int(local.sum())!=m.area:raise ValueError('Intended target truncated')
            if local.any():masks.append(local);ids.append(gt)
        sample,survival=make_native_sample(rgb,masks,size=self.size,mask_ratio=self.mask_ratio,im_file=path)
        self.last_audit=dict(image=name,bounds=bounds,intended_gt_ids=intended,source_gt_ids=ids,mask_survival=survival,
            intended_missing_after_resize=[gt for gt,s in zip(ids,survival) if gt in intended and not s['loss_pixels']])
        return sample
