"""Exact training-only UNKNOWN/protected rasters, never new ground truth."""
from __future__ import annotations

import numpy as np

from geopriv.counting.candidate_ceiling import raster_roi


def polygon_union(polygons, image_size):
    """Use the audited global-round-before-crop raster, without dilation."""
    width, height = image_size
    raster = raster_roi(polygons, image_size)
    mask = np.zeros((height, width), dtype=bool)
    if raster.area:
        mask[raster.y:raster.y+raster.mask.shape[0],
             raster.x:raster.x+raster.mask.shape[1]] = raster.mask
    return mask


def build_scope_masks(flagged_polygons, source_polygons, source_points, image_size):
    """Fail on a source conflict; UNKNOWN proposals are not pseudo positives."""
    unknown = polygon_union(flagged_polygons, image_size)
    protect = polygon_union(source_polygons, image_size)
    points = np.asarray(source_points, dtype=float)
    if points.ndim != 2 or points.shape[1] != 2 or not np.isfinite(points).all():
        raise ValueError('Source points must be finite Nx2')
    width, height = image_size
    xy = np.floor(points).astype(np.int64)
    if np.any(xy < 0) or np.any(xy >= np.array([width, height])):
        raise ValueError('Source point outside source canvas')
    protect[xy[:, 1], xy[:, 0]] = True
    if np.any(unknown & protect):
        raise ValueError('UNKNOWN/protect source conflict; do not silently subtract GT')
    return unknown, protect


def crop_scope_masks(unknown, protect, bounds):
    if unknown.dtype != bool or protect.dtype != bool or unknown.shape != protect.shape or unknown.ndim != 2:
        raise ValueError('Expected same-shape boolean U/P masks')
    if len(bounds) != 4 or any(type(v) not in (int, np.int32, np.int64) for v in bounds):
        raise ValueError('Expected four integer crop coordinates')
    x0, y0, x1, y1 = bounds
    h, w = unknown.shape
    if not 0 <= x0 < x1 <= w or not 0 <= y0 < y1 <= h:
        raise ValueError('Crop outside source canvas')
    if np.any(unknown & protect):
        raise ValueError('UNKNOWN/protect source conflict')
    return unknown[y0:y1, x0:x1].copy(), protect[y0:y1, x0:x1].copy()


def training_crop_plan(manifest, rows):
    """Read metadata only; reject role leakage before any derived-image access."""
    by_name = {row['original_id']: row for row in rows}
    if len(by_name) != len(rows) or any(row['role'] != 'expert_A' for row in rows):
        raise ValueError('Only unique expert_A rows are permitted')
    train = [crop for crop in manifest if crop['split'] == 'train']
    if {crop['source_image'] for crop in train} != set(by_name):
        raise ValueError('Training crops must cover exactly expert_A')
    names = set()
    for crop in train:
        name = crop['output_image'].replace('\\', '/')
        parts = name.split('/')
        if len(parts) != 3 or parts[:2] != ['images', 'train'] or parts[2] in ('', '.', '..'):
            raise ValueError('Unsafe/non-A output crop path')
        if name in names:
            raise ValueError('Duplicate training crop')
        names.add(name)
        row = by_name[crop['source_image']]
        bounds = crop['crop_xyxy']
        if (len(bounds) != 4 or any(type(v) is not int for v in bounds)
                or not 0 <= bounds[0] < bounds[2] <= row['width']
                or not 0 <= bounds[1] < bounds[3] <= row['height']):
            raise ValueError('Invalid A crop bounds')
    return train
