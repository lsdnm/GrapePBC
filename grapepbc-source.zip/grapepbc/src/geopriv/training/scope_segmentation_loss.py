"""Opt-in, fail-closed unknown-region loss for Ultralytics 8.4.142.

This is an engineering-only adapter, not installed into an existing trainer.
Its caller must transform ``scope_ignore_mask`` and ``scope_protect_mask`` with
the image. Both are boolean BxHxW tensors on the image device, in final input
pixel coordinates. ``scope_transform`` must be ``letterbox_only_v1``: random
geometry, mosaic, mixup, cutmix and independently transformed masks are NOT
supported. Protect must include source GT and source-point pixels. This module
additionally protects the union of all provided GT masks and TAL foreground.

Unknown regions are not pseudo-positive labels: only negative classification
anchors are muted. Instance-mask, box/DFL losses and all official normalizers
are unchanged. Unknown berries can belong to another cluster and must remain
negative pixels for the annotated instance. All-zero effective ignore uses the exact
official implementation. Source labels and model weights remain unmodified.
"""
from __future__ import annotations

import torch
import torch.nn.functional as F
import ultralytics
from ultralytics.utils.loss import v8SegmentationLoss
from ultralytics.utils.tal import make_anchors

SUPPORTED_ULTRALYTICS = "8.4.142"
SCOPE_TRANSFORM = "letterbox_only_v1"


def resize_bool(mask: torch.Tensor, size: tuple[int, int]) -> torch.Tensor:
    """Nearest-neighbor boolean raster resizing; no implicit dilation."""
    if tuple(mask.shape[-2:]) == tuple(size):
        return mask
    return F.interpolate(mask[:, None].float(), size=size, mode="nearest")[:, 0].bool()


def classification_keep_mask(
    ignore: torch.Tensor, foreground: torch.Tensor, pixel_centres: torch.Tensor
) -> torch.Tensor:
    """Keep TAL positives and all anchors whose centre is outside unknown."""
    height, width = ignore.shape[-2:]
    if (pixel_centres < 0).any() or (pixel_centres[:, 0] >= width).any() or (pixel_centres[:, 1] >= height).any():
        raise ValueError("Anchor centres fall outside the final image raster")
    xy = pixel_centres.floor().long()
    return ~ignore[:, xy[:, 1], xy[:, 0]] | foreground.bool()


class ScopeAwareSegmentationLoss(v8SegmentationLoss):
    """Version-pinned prototype criterion with strict aligned-mask contract."""

    def __init__(self, model, tal_topk=10, tal_topk2=None):
        if ultralytics.__version__ != SUPPORTED_ULTRALYTICS:
            raise RuntimeError(f"Requires ultralytics=={SUPPORTED_ULTRALYTICS}; re-audit before upgrading")
        head = model.model[-1]
        if getattr(head, "end2end", False) or getattr(head, "one2one_cv2", None) is not None:
            raise ValueError("End-to-end / one-to-one heads are unsupported")
        super().__init__(model, tal_topk, tal_topk2)
        self._active_ignore = None
        self._in_scope_call = False

    def _validate_scope(self, preds, batch):
        # Format always supplies sem_masks for instance-segmentation batches.
        # Only a semantic prediction branch, not that unused target, is unsupported.
        if isinstance(preds.get("proto"), tuple) or "one2one" in preds or "one2many" in preds:
            raise ValueError("Semantic and end-to-end segmentation are unsupported")
        if batch.get("scope_transform") != SCOPE_TRANSFORM:
            raise ValueError("scope_transform must attest audited letterbox-only geometry")
        image = batch.get("img")
        if not isinstance(image, torch.Tensor) or image.ndim != 4 or image.shape[1] != 3:
            raise ValueError("batch img must have shape Bx3xHxW")
        expected = (image.shape[0], *image.shape[-2:])
        for name in ("scope_ignore_mask", "scope_protect_mask"):
            value = batch.get(name)
            if not isinstance(value, torch.Tensor) or value.dtype != torch.bool or tuple(value.shape) != expected:
                raise ValueError(f"{name} must be bool BxHxW in final image coordinates")
            if value.device != image.device or value.device != self.device:
                raise ValueError(f"{name}, image and criterion must share a device")
        if not isinstance(batch.get("masks"), torch.Tensor) or batch["masks"].ndim != 3:
            raise ValueError("GT masks are mandatory even for empty-label batches")
        batch_size = image.shape[0]
        masks = batch["masks"].to(self.device)
        if self.overlap:
            if masks.shape[0] != batch_size:
                raise ValueError("Overlap GT masks must have one raster per image")
            present = masks != 0
        else:
            batch_idx = batch["batch_idx"].view(-1).long().to(self.device)
            if len(batch_idx) != len(masks) or ((batch_idx < 0) | (batch_idx >= batch_size)).any():
                raise ValueError("Non-overlap GT masks must align with valid batch indices")
            present = torch.zeros(batch_size, *masks.shape[-2:], dtype=torch.bool, device=self.device)
            for i in range(batch_size):
                selected = masks[batch_idx == i]
                if len(selected):
                    present[i] = selected.ne(0).any(dim=0)
        inferred = tuple(int(v * self.stride[0]) for v in preds["feats"][0].shape[-2:])
        if inferred != tuple(image.shape[-2:]) or preds["scores"].shape[0] != batch_size:
            raise ValueError("Prediction / final-image geometry differs")
        protect = batch["scope_protect_mask"] | resize_bool(present, image.shape[-2:])
        return batch["scope_ignore_mask"] & ~protect

    def loss(self, preds, batch):
        if self._in_scope_call:
            raise RuntimeError("Concurrent or reentrant criterion use is unsupported")
        ignore = self._validate_scope(preds, batch)
        self._in_scope_call = True
        self._active_ignore = ignore if ignore.any() else None
        try:
            return super().loss(preds, batch)
        finally:
            self._active_ignore = None
            self._in_scope_call = False

    def get_assigned_targets_and_loss(self, preds, batch):
        if not self._in_scope_call:
            raise RuntimeError("Call the criterion with its full scope batch contract")
        if self._active_ignore is None:
            return super().get_assigned_targets_and_loss(preds, batch)
        # Mirrors pinned 8.4.142; only the marked BCE keep mask differs.
        loss = torch.zeros(3, device=self.device)
        pred_distri = preds["boxes"].permute(0, 2, 1).contiguous()
        pred_scores = preds["scores"].permute(0, 2, 1).contiguous()
        anchor_points, stride_tensor = make_anchors(preds["feats"], self.stride, 0.5)
        dtype = pred_scores.dtype
        batch_size = pred_scores.shape[0]
        imgsz = torch.tensor(preds["feats"][0].shape[2:], device=self.device, dtype=dtype) * self.stride[0]
        targets = torch.cat((batch["batch_idx"].view(-1, 1), batch["cls"].view(-1, 1), batch["bboxes"]), 1)
        targets = self.preprocess(targets.to(self.device), batch_size, scale_tensor=imgsz[[1, 0, 1, 0]])
        gt_labels, gt_bboxes = targets.split((1, 4), 2)
        mask_gt = gt_bboxes.sum(2, keepdim=True).gt_(0.0)
        pred_bboxes = self.bbox_decode(anchor_points, pred_distri)
        _, target_bboxes, target_scores, fg_mask, target_gt_idx = self.assigner(
            pred_scores.detach().sigmoid(), (pred_bboxes.detach() * stride_tensor).type(gt_bboxes.dtype),
            anchor_points * stride_tensor, gt_labels, gt_bboxes, mask_gt,
        )
        target_scores_sum = max(target_scores.sum(), 1)
        bce_loss = self.bce(pred_scores, target_scores.to(dtype))
        if self.class_weights is not None:
            bce_loss *= self.class_weights
        keep = classification_keep_mask(self._active_ignore, fg_mask, anchor_points * stride_tensor)
        loss[1] = (bce_loss * keep.unsqueeze(-1).to(bce_loss.dtype)).sum() / target_scores_sum
        if fg_mask.sum():
            loss[0], loss[2] = self.bbox_loss(
                pred_distri, pred_bboxes, anchor_points, target_bboxes / stride_tensor,
                target_scores, target_scores_sum, fg_mask, imgsz, stride_tensor,
            )
        else:
            loss[0] += pred_distri[..., :0].sum()
        loss[0] *= self.hyp.box
        loss[1] *= self.hyp.cls
        loss[2] *= self.hyp.dfl
        return ((fg_mask, target_gt_idx, target_bboxes, anchor_points, stride_tensor), loss,
                dict(zip(self.loss_names, loss.detach())))

