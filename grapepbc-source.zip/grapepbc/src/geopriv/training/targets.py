"""CenterNet-style supervision for grape berry points."""

from __future__ import annotations

from collections.abc import Sequence

import torch
from torch import Tensor
import torch.nn.functional as F


def _draw_gaussian(target: Tensor, center_x: int, center_y: int, radius: int) -> None:
    diameter = 2 * radius + 1
    axis = torch.arange(diameter, device=target.device, dtype=target.dtype) - radius
    yy, xx = torch.meshgrid(axis, axis, indexing="ij")
    sigma = max(diameter / 6.0, 1e-6)
    gaussian = torch.exp(-(xx.square() + yy.square()) / (2 * sigma * sigma))
    height, width = target.shape
    left, right = min(center_x, radius), min(width - center_x - 1, radius)
    top, bottom = min(center_y, radius), min(height - center_y - 1, radius)
    if min(left, right, top, bottom) < 0:
        return
    target_slice = target[
        center_y - top : center_y + bottom + 1,
        center_x - left : center_x + right + 1,
    ]
    gaussian_slice = gaussian[
        radius - top : radius + bottom + 1,
        radius - left : radius + right + 1,
    ]
    torch.maximum(target_slice, gaussian_slice, out=target_slice)


def build_point_targets(
    points: Sequence[Tensor],
    *,
    output_height: int,
    output_width: int,
    stride: int = 2,
    gaussian_radius: int = 2,
    device: torch.device | str | None = None,
) -> dict[str, Tensor]:
    """Build heatmap/offset targets and expose stride-cell collisions."""

    batch = len(points)
    heatmap = torch.zeros((batch, 1, output_height, output_width), device=device)
    offsets = torch.zeros((batch, 2, output_height, output_width), device=device)
    positive_mask = torch.zeros((batch, 1, output_height, output_width), dtype=torch.bool, device=device)
    collision_count = 0
    valid_point_count = 0
    for batch_index, image_points in enumerate(points):
        scaled = image_points.to(device=device, dtype=torch.float32) / stride
        for point in scaled:
            x, y = point
            cell_x, cell_y = int(torch.floor(x)), int(torch.floor(y))
            if not (0 <= cell_x < output_width and 0 <= cell_y < output_height):
                continue
            valid_point_count += 1
            if positive_mask[batch_index, 0, cell_y, cell_x]:
                collision_count += 1
                continue
            positive_mask[batch_index, 0, cell_y, cell_x] = True
            offsets[batch_index, 0, cell_y, cell_x] = x - cell_x
            offsets[batch_index, 1, cell_y, cell_x] = y - cell_y
            _draw_gaussian(heatmap[batch_index, 0], cell_x, cell_y, gaussian_radius)
    collision_rate = collision_count / max(valid_point_count, 1)
    return {
        "heatmap": heatmap,
        "offsets": offsets,
        "positive_mask": positive_mask,
        "valid_point_count": torch.tensor(valid_point_count, device=device),
        "collision_count": torch.tensor(collision_count, device=device),
        "collision_rate": torch.tensor(collision_rate, device=device),
    }


def centernet_focal_loss(logits: Tensor, targets: Tensor) -> Tensor:
    # The logarithms must stay in FP32 under autocast: 1 - 1e-6 rounds to 1
    # in FP16 and would silently create log(0)=inf.
    predictions = logits.float().sigmoid().clamp(1e-6, 1 - 1e-6)
    float_targets = targets.float()
    positive = float_targets.eq(1).to(predictions.dtype)
    negative = float_targets.lt(1).to(predictions.dtype)
    negative_weights = (1 - float_targets).pow(4)
    positive_loss = -(predictions.log()) * (1 - predictions).pow(2) * positive
    negative_loss = -((1 - predictions).log()) * predictions.pow(2) * negative_weights * negative
    positive_count = positive.sum()
    if positive_count.item() == 0:
        return negative_loss.sum()
    return (positive_loss.sum() + negative_loss.sum()) / positive_count


def litepoint_loss(outputs: dict[str, Tensor], targets: dict[str, Tensor]) -> dict[str, Tensor]:
    center = centernet_focal_loss(outputs["center_logits"], targets["heatmap"])
    mask = targets["positive_mask"].expand_as(outputs["offsets"])
    if mask.any():
        offset = F.l1_loss(
            outputs["offsets"][mask].float(), targets["offsets"][mask].float()
        )
    else:
        offset = outputs["offsets"].sum() * 0
    return {"loss": center + offset, "center_loss": center, "offset_loss": offset}
