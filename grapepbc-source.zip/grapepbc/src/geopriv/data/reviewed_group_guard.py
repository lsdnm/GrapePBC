"""Preflight for explicitly reviewed related views, including transitive groups."""
from collections import defaultdict


def reviewed_group_conflicts(records, links):
    rows={r['sample_id']:r for r in records}
    if len(rows)!=len(records):raise ValueError('duplicate sample identity')
    parent={k:k for k in rows}
    def root(k):
        while parent[k]!=k:
            parent[k]=parent[parent[k]];k=parent[k]
        return k
    def union(a,b):
        if a in rows and b in rows:parent[root(a)]=root(b)
    # Existing declared capture/source groups supplement newly reviewed links.
    groups=defaultdict(list)
    for k,r in rows.items():
        g=r.get('capture_group_id') or r.get('extra',{}).get('source_group_id')
        if g:groups[str(g)].append(k)
    for ids in groups.values():
        for k in ids[1:]:union(ids[0],k)
    # Include absent intermediary IDs so subsets do not silently sever a group.
    for link in links:
        if link.get('decision')!='group_together':continue
        for k in (link['a'],link['b']):parent.setdefault(k,k)
        parent[root(link['a'])]=root(link['b'])
    sets=defaultdict(list)
    for k in rows:sets[root(k)].append(k)
    conflicts=[]
    for ids in sets.values():
        roles={rows[k].get('extra',{}).get('data_role',rows[k].get('split')) for k in ids}
        if None in roles:raise ValueError('missing sample role')
        if len(roles)>1:conflicts.append(dict(sample_ids=sorted(ids),roles=sorted(roles)))
    return sorted(conflicts,key=lambda r:r['sample_ids'])
