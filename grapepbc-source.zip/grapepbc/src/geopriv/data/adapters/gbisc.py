"""GBISC COCO adapter and mask-to-geometry conversion.

The official Mask-GK release uses ``images/`` together with
``annotations_COCO_{train,val,test}.json``.  The discovery code also accepts
common COCO export names so that repackaging the public download does not
require hand-editing paths.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import asdict, dataclass, field
import json
import math
import os
from pathlib import Path
import re
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
from PIL import Image

from ..geometry import (
    CENTER_POLICY,
    COCO_BBOX_BOUNDARY_TOLERANCE_PX,
    COCO_BBOX_POLYGON_EDGE_TOLERANCE_PX,
    GEOMETRY_CONVERTER_VERSION,
    GEOMETRY_SCHEMA_VERSION,
    MIN_POLYGON_AREA_PX2,
    MIN_RASTER_AREA_PX,
    ORIENTATION_ECCENTRICITY_THRESHOLD,
    InstanceGeometry,
    extract_polygon_geometry,
    geometry_arrays,
)
from ..hash_utils import file_sha256, image_dhash64
from ..schema import SampleRecord


GBISC_PROVENANCE_URL = "https://github.com/volcanoYcc/Mask-GK"
GBISC_SEMANTIC_CATEGORY_IDS = {"berry": 1}
_OFFICIAL_PATTERN = re.compile(
    r"annotations[_-]coco[_-](train|val|validation|test)\.json$", re.IGNORECASE
)


@dataclass(slots=True)
class GeometryConversionSummary:
    annotation_files: list[str] = field(default_factory=list)
    annotation_sha256: dict[str, str] = field(default_factory=dict)
    source_category_mappings: dict[str, list[dict[str, Any]]] = field(
        default_factory=dict
    )
    image_count: int = 0
    instance_count: int = 0
    skipped_crowd: int = 0
    skipped_invalid: int = 0
    frame_boundary_touching_count: int = 0
    source_coco_bbox_missing_count: int = 0
    source_coco_bbox_boundary_clipped_count: int = 0
    source_coco_bbox_boundary_clipped_instances: list[dict[str, Any]] = field(
        default_factory=list
    )
    multiframe_image_count: int = 0
    errors: list[dict[str, Any]] = field(default_factory=list)
    geometry_schema_version: int = GEOMETRY_SCHEMA_VERSION
    geometry_converter_version: str = GEOMETRY_CONVERTER_VERSION
    conversion_parameters: dict[str, Any] = field(default_factory=dict)
    contact_geometry_included: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _canonical_split(value: str) -> str:
    lowered = value.lower()
    if lowered == "validation":
        return "val"
    if lowered not in {"train", "val", "test"}:
        raise ValueError(f"unsupported GBISC split: {value!r}")
    return lowered


def _split_from_path(path: Path) -> str:
    match = _OFFICIAL_PATTERN.search(path.name)
    if match:
        return _canonical_split(match.group(1))
    lowered = path.stem.lower()
    for split in ("train", "validation", "val", "test"):
        if re.search(rf"(?:^|[_-]){split}(?:$|[_-])", lowered):
            return _canonical_split(split)
    raise ValueError(
        f"cannot infer split from {path.name}; use a standard train/val/test COCO filename"
    )


def discover_gbisc_annotations(root: str | Path) -> list[tuple[str, Path]]:
    """Return one COCO annotation path per discovered official split."""

    root_path = Path(root).resolve()
    candidates: list[Path] = []
    for pattern in (
        "annotations_COCO_*.json",
        "*/annotations_COCO_*.json",
        "annotations/annotations_COCO_*.json",
        "annotations/instances_*.json",
        "*/_annotations.coco.json",
    ):
        candidates.extend(root_path.glob(pattern))
    discovered: dict[str, Path] = {}
    for path in sorted({candidate.resolve() for candidate in candidates}):
        try:
            split = _split_from_path(path)
        except ValueError:
            # Roboflow-style parent directories often carry the split name.
            try:
                split = _canonical_split(path.parent.name)
            except ValueError:
                continue
        if split in discovered and discovered[split] != path:
            raise ValueError(
                f"multiple GBISC annotation files found for {split}: "
                f"{discovered[split]} and {path}"
            )
        discovered[split] = path
    if not discovered:
        raise FileNotFoundError(
            "no GBISC COCO annotations found; expected annotations_COCO_train/val/test.json"
        )
    return [
        (split, discovered[split])
        for split in ("train", "val", "test")
        if split in discovered
    ]


def _load_coco(path: Path) -> dict[str, Any]:
    document = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(document, dict):
        raise ValueError(f"{path} must contain a COCO JSON object")
    for key in ("images", "annotations", "categories"):
        if not isinstance(document.get(key), list):
            raise ValueError(f"{path} has no COCO {key!r} list")
    category_ids: set[int] = set()
    category_names: set[str] = set()
    for category in document["categories"]:
        if not isinstance(category, Mapping) or not {"id", "name"}.issubset(category):
            raise ValueError(f"{path} contains a category without id/name")
        category_id = int(category["id"])
        category_name = _normalise_category_name(category["name"])
        if category_id in category_ids:
            raise ValueError(f"duplicate category id {category_id} in {path}")
        if category_name in category_names:
            raise ValueError(
                f"duplicate semantic category name {category_name!r} in {path}"
            )
        if category_name not in GBISC_SEMANTIC_CATEGORY_IDS:
            raise ValueError(
                f"unsupported GBISC category name {category_name!r} in {path}"
            )
        category_ids.add(category_id)
        category_names.add(category_name)
    image_ids: set[int] = set()
    for image in document["images"]:
        if not isinstance(image, Mapping) or "id" not in image:
            raise ValueError(f"{path} contains an image without an id")
        image_id = int(image["id"])
        if image_id in image_ids:
            raise ValueError(f"duplicate image id {image_id} in {path}")
        image_ids.add(image_id)
    annotation_ids: set[int] = set()
    for annotation in document["annotations"]:
        if not isinstance(annotation, Mapping):
            raise ValueError(f"{path} contains a non-object annotation")
        missing = {
            key
            for key in ("id", "image_id", "category_id", "segmentation")
            if key not in annotation
        }
        if missing:
            raise ValueError(f"{path} annotation is missing fields: {sorted(missing)}")
        annotation_id = int(annotation["id"])
        if annotation_id in annotation_ids:
            raise ValueError(f"duplicate annotation id {annotation_id} in {path}")
        annotation_ids.add(annotation_id)
        image_id = int(annotation["image_id"])
        if image_id not in image_ids:
            raise ValueError(
                f"annotation {annotation_id} references absent image {image_id} in {path}"
            )
        source_category_id = int(annotation["category_id"])
        if source_category_id not in category_ids:
            raise ValueError(
                f"annotation {annotation_id} references absent category "
                f"{source_category_id} in {path}"
            )
    return document


def _normalise_category_name(value: Any) -> str:
    name = " ".join(str(value).strip().casefold().split())
    if not name:
        raise ValueError("COCO category name must not be empty")
    return name


def _category_mapping(document: Mapping[str, Any]) -> dict[int, tuple[str, int]]:
    """Map file-local COCO ids to stable name-derived semantic ids."""

    result: dict[int, tuple[str, int]] = {}
    for category in document["categories"]:
        name = _normalise_category_name(category["name"])
        result[int(category["id"])] = (name, GBISC_SEMANTIC_CATEGORY_IDS[name])
    return result


def _normalise_annotation_inputs(
    root: Path, annotation_files: Sequence[str | Path] | None
) -> list[tuple[str, Path]]:
    if annotation_files is None:
        return discover_gbisc_annotations(root)
    result: list[tuple[str, Path]] = []
    seen: set[str] = set()
    for value in annotation_files:
        path = Path(value)
        if not path.is_absolute():
            path = root / path
        path = path.resolve()
        if not path.is_file():
            raise FileNotFoundError(path)
        split = _split_from_path(path)
        if split in seen:
            raise ValueError(f"duplicate annotation input for split {split!r}")
        seen.add(split)
        result.append((split, path))
    return sorted(result, key=lambda item: ("train", "val", "test").index(item[0]))


def _safe_token(value: Any) -> str:
    rendered = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value)).strip("._")
    return rendered or "unknown"


def geometry_relative_path(split: str, image: Mapping[str, Any]) -> Path:
    stem = Path(str(image.get("file_name", "image"))).stem
    return Path(split) / f"{_safe_token(stem)}__image{_safe_token(image['id'])}.npz"


def _atomic_savez(path: Path, arrays: Mapping[str, np.ndarray]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    try:
        with temporary.open("wb") as stream:
            np.savez_compressed(stream, **arrays)
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def convert_gbisc_geometry(
    root: str | Path,
    output_dir: str | Path,
    *,
    annotation_files: Sequence[str | Path] | None = None,
    category_ids: set[int] | None = None,
    strict: bool = True,
) -> GeometryConversionSummary:
    """Convert non-crowd GBISC polygons to per-image privileged targets.

    Cross-instance contact/adjacency geometry is not generated here.  The
    frame-boundary field only describes clipping at the image border.
    """

    root_path = Path(root).resolve()
    output_path = Path(output_dir)
    if not output_path.is_absolute():
        output_path = root_path / output_path
    output_path = output_path.resolve()
    try:
        output_path.relative_to(root_path)
    except ValueError as exc:
        raise ValueError(
            "GBISC geometry output must stay under the dataset root"
        ) from exc
    summary = GeometryConversionSummary(
        conversion_parameters={
            "category_ids": sorted(category_ids) if category_ids is not None else None,
            "strict": strict,
            "excludes_crowd": True,
            "verifies_image_dimensions": True,
            "rejects_non_identity_exif_orientation": True,
            "exif_orientation_identity_values": [None, 0, 1],
            "image_frame_policy": "frame_0_only",
            "minimum_polygon_area_px2": MIN_POLYGON_AREA_PX2,
            "minimum_raster_area_px": MIN_RASTER_AREA_PX,
            "orientation_eccentricity_threshold": ORIENTATION_ECCENTRICITY_THRESHOLD,
            "center_policy": CENTER_POLICY,
            "geometry_bbox_source": "rasterized_polygon_mask",
            "source_coco_bbox_role": "audit_only",
            "source_coco_bbox_boundary_tolerance_px": COCO_BBOX_BOUNDARY_TOLERANCE_PX,
            "source_coco_bbox_polygon_edge_tolerance_px": (
                COCO_BBOX_POLYGON_EDGE_TOLERANCE_PX
            ),
        }
    )
    for split, annotation_path in _normalise_annotation_inputs(
        root_path, annotation_files
    ):
        document = _load_coco(annotation_path)
        category_mapping = _category_mapping(document)
        annotation_sha256 = file_sha256(annotation_path)
        annotation_relative = _relative(annotation_path, root_path)
        summary.annotation_files.append(annotation_relative)
        summary.annotation_sha256[annotation_relative] = annotation_sha256
        summary.source_category_mappings[annotation_relative] = [
            {
                "source_category_id": source_id,
                "category_name": category_mapping[source_id][0],
                "semantic_category_id": category_mapping[source_id][1],
            }
            for source_id in sorted(category_mapping)
        ]
        images: dict[int, Mapping[str, Any]] = {}
        for image in document["images"]:
            image_id = int(image["id"])
            width, height = int(image["width"]), int(image["height"])
            image_path = _find_image(
                root_path, annotation_path, str(image["file_name"])
            )
            frame_count = _validate_image_coordinate_frame(
                image_path, width=width, height=height, verify_dimensions=True
            )
            summary.multiframe_image_count += int(frame_count > 1)
            images[image_id] = image
        grouped: dict[int, list[InstanceGeometry]] = defaultdict(list)
        excluded: dict[int, list[int]] = defaultdict(list)
        for annotation in sorted(
            document["annotations"], key=lambda item: int(item["id"])
        ):
            image_id = int(annotation["image_id"])
            if (
                category_ids is not None
                and int(annotation["category_id"]) not in category_ids
            ):
                continue
            if bool(annotation.get("iscrowd", 0)):
                summary.skipped_crowd += 1
                continue
            image = images[image_id]
            try:
                geometry = extract_polygon_geometry(
                    annotation,
                    image_width=int(image["width"]),
                    image_height=int(image["height"]),
                    semantic_category_id=category_mapping[
                        int(annotation["category_id"])
                    ][1],
                )
            except Exception as exc:
                error = {
                    "split": split,
                    "annotation_file": str(annotation_path),
                    "annotation_id": annotation.get("id"),
                    "image_id": image_id,
                    "error": str(exc),
                }
                summary.errors.append(error)
                summary.skipped_invalid += 1
                excluded[image_id].append(int(annotation["id"]))
                if strict:
                    raise ValueError(
                        f"invalid GBISC annotation {annotation.get('id')} in {annotation_path}: {exc}"
                    ) from exc
                continue
            grouped[image_id].append(geometry)
            summary.instance_count += 1
            summary.frame_boundary_touching_count += int(
                geometry.touches_image_boundary
            )
            summary.source_coco_bbox_missing_count += int(
                not geometry.source_coco_bbox_present
            )
            if geometry.source_coco_bbox_boundary_clipped:
                summary.source_coco_bbox_boundary_clipped_count += 1
                summary.source_coco_bbox_boundary_clipped_instances.append(
                    {
                        "split": split,
                        "annotation_id": geometry.annotation_id,
                        "image_id": image_id,
                        "source_coco_bbox_xywh": list(
                            map(float, annotation["bbox"])
                        ),
                        "archived_clipped_bbox_xywh": list(
                            geometry.source_coco_bbox_xywh
                        ),
                    }
                )

        for image_id, image in images.items():
            destination = output_path / geometry_relative_path(split, image)
            _atomic_savez(
                destination,
                geometry_arrays(
                    grouped.get(image_id, []),
                    source_annotation_sha256=annotation_sha256,
                    source_image_id=image_id,
                    source_image_width=int(image["width"]),
                    source_image_height=int(image["height"]),
                    category_ids=category_ids,
                    strict=strict,
                    source_category_mapping=category_mapping,
                    excluded_annotation_ids=excluded.get(image_id, []),
                ),
            )
            summary.image_count += 1
    return summary


def _find_image(root: Path, annotation_path: Path, file_name: str) -> Path:
    normalised = file_name.replace("\\", "/")
    relative = Path(normalised)
    candidates = (
        root / relative,
        root / "images" / relative,
        annotation_path.parent / relative,
        annotation_path.parent / "images" / relative,
        root / relative.name,
        root / "images" / relative.name,
    )
    for candidate in candidates:
        if candidate.is_file():
            resolved = candidate.resolve()
            try:
                resolved.relative_to(root)
            except ValueError as exc:
                raise ValueError(f"image path escapes GBISC root: {resolved}") from exc
            return resolved
    raise FileNotFoundError(f"could not locate GBISC image {file_name!r}")


def _relative(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError as exc:
        raise ValueError(f"{path} must be located under dataset root {root}") from exc


def _validate_image_coordinate_frame(
    path: Path, *, width: int, height: int, verify_dimensions: bool
) -> int:
    """Validate COCO coordinates against frame 0 and return image frame count.

    Official GBISC includes JPEG/MPO containers.  COCO annotations address the
    first image, so frame 0 is selected explicitly.  EXIF Orientation values
    missing, 0 (unspecified), and 1 are all treated as identity; transformed
    orientations 2--8 remain fatal because their coordinates need remapping.
    """

    if width <= 0 or height <= 0:
        raise ValueError(f"invalid COCO dimensions for {path.name}: {(width, height)}")
    with Image.open(path) as opened:
        frame_count = int(getattr(opened, "n_frames", 1))
        opened.seek(0)
        orientation_value = opened.getexif().get(274)
        orientation = None if orientation_value is None else int(orientation_value)
        actual_size = opened.size
    if orientation not in {None, 0, 1}:
        raise ValueError(
            f"unsupported EXIF Orientation={orientation} for {path.name}; "
            "bake the orientation into pixels and transform COCO coordinates first"
        )
    if verify_dimensions and actual_size != (width, height):
        raise ValueError(
            f"dimension mismatch for {path.name}: COCO={(width, height)}, image={actual_size}"
        )
    return frame_count


def _infer_variety(image: Mapping[str, Any]) -> str | None:
    for key in ("variety", "cultivar", "grape_variety"):
        value = image.get(key)
        if value:
            return str(value)
    compact = re.sub(r"[^a-z]", "", str(image.get("file_name", "")).lower())
    aliases = {
        "kyoho": "Kyoho",
        "shine": "Shine Muscat",
        "muscat": "Shine Muscat",
        "summerblack": "Summer Black",
    }
    for token, variety in aliases.items():
        if token in compact:
            return variety
    return None


def _scalar(arrays: Mapping[str, np.ndarray], key: str, path: Path) -> Any:
    value = np.asarray(arrays[key])
    if value.shape != ():
        raise ValueError(f"{path}: {key} must be a scalar, got {value.shape}")
    return value.item()


def _validate_geometry_archive(
    path: Path,
    *,
    annotation_sha256: str,
    image_id: int,
    image_width: int,
    image_height: int,
    expected_annotations: Sequence[Mapping[str, Any]],
    category_ids: set[int] | None,
    source_category_mapping: Mapping[int, tuple[str, int]],
    allow_geometry_subset: bool,
) -> tuple[np.ndarray, int, int, int, int, int]:
    """Validate a cached geometry file against its exact COCO source."""

    with np.load(path, allow_pickle=False) as archive:
        arrays = {key: np.asarray(archive[key]) for key in archive.files}
    required = {
        "points_xy",
        "centroids_xy",
        "equivalent_radius",
        "inscribed_radius",
        "axes",
        "eccentricity",
        "orientation_vector",
        "orientation_valid",
        "frame_boundary_completeness",
        "touches_image_boundary",
        "area_px",
        "mask_bbox_xywh",
        "source_coco_bbox_xywh",
        "source_coco_bbox_present",
        "source_coco_bbox_boundary_clipped",
        "component_count",
        "annotation_ids",
        "source_category_ids",
        "semantic_category_ids",
        "geometry_schema_version",
        "geometry_converter_version",
        "source_annotation_sha256",
        "source_image_id",
        "source_image_width",
        "source_image_height",
        "conversion_all_categories",
        "conversion_category_ids",
        "source_category_map_ids",
        "source_category_map_names",
        "source_category_map_semantic_ids",
        "conversion_strict",
        "conversion_excludes_crowd",
        "conversion_verifies_image_dimensions",
        "conversion_rejects_non_identity_exif_orientation",
        "conversion_exif_zero_means_unspecified",
        "conversion_image_frame_index",
        "excluded_annotation_ids",
        "minimum_polygon_area_px2",
        "minimum_raster_area_px",
        "coco_bbox_boundary_tolerance_px",
        "coco_bbox_polygon_edge_tolerance_px",
        "orientation_eccentricity_threshold",
        "center_policy",
        "orientation_representation",
        "contact_geometry_included",
    }
    missing = required.difference(arrays)
    if missing:
        raise ValueError(f"{path} is missing geometry arrays: {sorted(missing)}")

    version = int(_scalar(arrays, "geometry_schema_version", path))
    if version != GEOMETRY_SCHEMA_VERSION:
        raise ValueError(
            f"{path}: geometry schema {version} != supported {GEOMETRY_SCHEMA_VERSION}; "
            "rerun convert_gbisc_geometry"
        )
    converter_version = str(_scalar(arrays, "geometry_converter_version", path))
    if converter_version != GEOMETRY_CONVERTER_VERSION:
        raise ValueError(
            f"{path}: converter {converter_version!r} != {GEOMETRY_CONVERTER_VERSION!r}"
        )
    if str(_scalar(arrays, "source_annotation_sha256", path)) != annotation_sha256:
        raise ValueError(f"{path}: source COCO SHA-256 changed; regenerate geometry")
    source_identity = (
        int(_scalar(arrays, "source_image_id", path)),
        int(_scalar(arrays, "source_image_width", path)),
        int(_scalar(arrays, "source_image_height", path)),
    )
    if source_identity != (image_id, image_width, image_height):
        raise ValueError(
            f"{path}: source image metadata {source_identity} does not match "
            f"{(image_id, image_width, image_height)}"
        )

    all_categories = bool(_scalar(arrays, "conversion_all_categories", path))
    stored_category_filter = arrays["conversion_category_ids"]
    if stored_category_filter.ndim != 1 or not np.issubdtype(
        stored_category_filter.dtype, np.integer
    ):
        raise ValueError(f"{path}: conversion_category_ids must be a 1-D integer array")
    expected_all_categories = category_ids is None
    expected_category_filter = np.asarray(sorted(category_ids or set()), dtype=np.int64)
    if all_categories != expected_all_categories or not np.array_equal(
        stored_category_filter.astype(np.int64, copy=False), expected_category_filter
    ):
        raise ValueError(
            f"{path}: category filter differs from the current indexing request"
        )
    mapping_ids = np.asarray(sorted(source_category_mapping), dtype=np.int64)
    mapping_names = np.asarray(
        [source_category_mapping[value][0] for value in mapping_ids]
    )
    mapping_semantic_ids = np.asarray(
        [source_category_mapping[value][1] for value in mapping_ids], dtype=np.int64
    )
    if not np.array_equal(arrays["source_category_map_ids"], mapping_ids):
        raise ValueError(f"{path}: source category ids changed; regenerate geometry")
    if not np.array_equal(arrays["source_category_map_names"], mapping_names):
        raise ValueError(f"{path}: source category names changed; regenerate geometry")
    if not np.array_equal(
        arrays["source_category_map_semantic_ids"], mapping_semantic_ids
    ):
        raise ValueError(f"{path}: semantic category mapping changed")
    if bool(_scalar(arrays, "conversion_strict", path)) != (not allow_geometry_subset):
        raise ValueError(f"{path}: strict/subset conversion policy mismatch")
    if not bool(_scalar(arrays, "conversion_excludes_crowd", path)):
        raise ValueError(f"{path}: crowd annotations must be excluded")
    if not bool(_scalar(arrays, "conversion_verifies_image_dimensions", path)):
        raise ValueError(f"{path}: source image dimensions were not verified")
    if not bool(
        _scalar(arrays, "conversion_rejects_non_identity_exif_orientation", path)
    ):
        raise ValueError(f"{path}: EXIF orientation safety policy was not recorded")
    if not bool(_scalar(arrays, "conversion_exif_zero_means_unspecified", path)):
        raise ValueError(f"{path}: EXIF Orientation=0 policy was not recorded")
    if int(_scalar(arrays, "conversion_image_frame_index", path)) != 0:
        raise ValueError(f"{path}: geometry must be derived from image frame 0")
    if bool(_scalar(arrays, "contact_geometry_included", path)):
        raise ValueError(f"{path}: unexpected cross-instance contact geometry flag")
    if str(_scalar(arrays, "center_policy", path)) != CENTER_POLICY:
        raise ValueError(f"{path}: unsupported point-centre policy")
    if (
        str(_scalar(arrays, "orientation_representation", path))
        != "cos_2theta_sin_2theta"
    ):
        raise ValueError(f"{path}: unsupported orientation representation")
    numeric_metadata = {
        "minimum_polygon_area_px2": MIN_POLYGON_AREA_PX2,
        "minimum_raster_area_px": MIN_RASTER_AREA_PX,
        "orientation_eccentricity_threshold": ORIENTATION_ECCENTRICITY_THRESHOLD,
        "coco_bbox_boundary_tolerance_px": COCO_BBOX_BOUNDARY_TOLERANCE_PX,
        "coco_bbox_polygon_edge_tolerance_px": (
            COCO_BBOX_POLYGON_EDGE_TOLERANCE_PX
        ),
    }
    for key, expected in numeric_metadata.items():
        actual = float(_scalar(arrays, key, path))
        if not math.isclose(actual, float(expected), rel_tol=1e-6, abs_tol=1e-6):
            raise ValueError(
                f"{path}: {key}={actual} does not match converter value {expected}"
            )

    points = arrays["points_xy"]
    if points.ndim != 2 or points.shape[1] != 2:
        raise ValueError(f"{path}: points_xy must have shape (N, 2)")
    count = len(points)
    shapes = {
        "centroids_xy": (count, 2),
        "equivalent_radius": (count,),
        "inscribed_radius": (count,),
        "axes": (count, 2),
        "eccentricity": (count,),
        "orientation_vector": (count, 2),
        "orientation_valid": (count,),
        "frame_boundary_completeness": (count,),
        "touches_image_boundary": (count,),
        "area_px": (count,),
        "mask_bbox_xywh": (count, 4),
        "source_coco_bbox_xywh": (count, 4),
        "source_coco_bbox_present": (count,),
        "source_coco_bbox_boundary_clipped": (count,),
        "component_count": (count,),
        "annotation_ids": (count,),
        "source_category_ids": (count,),
        "semantic_category_ids": (count,),
    }
    for key, expected_shape in shapes.items():
        if arrays[key].shape != expected_shape:
            raise ValueError(
                f"{path}: {key} must have shape {expected_shape}, got {arrays[key].shape}"
            )
    numeric_keys = {
        "points_xy",
        "centroids_xy",
        "equivalent_radius",
        "inscribed_radius",
        "axes",
        "eccentricity",
        "orientation_vector",
        "frame_boundary_completeness",
        "area_px",
        "mask_bbox_xywh",
        "source_coco_bbox_xywh",
    }
    for key in numeric_keys:
        if (
            not np.issubdtype(arrays[key].dtype, np.number)
            or not np.isfinite(arrays[key]).all()
        ):
            raise ValueError(f"{path}: {key} must contain only finite numeric values")
    for key in (
        "orientation_valid",
        "touches_image_boundary",
        "source_coco_bbox_present",
        "source_coco_bbox_boundary_clipped",
    ):
        if arrays[key].dtype != np.bool_:
            raise ValueError(f"{path}: {key} must use boolean dtype")
    for key in (
        "component_count",
        "annotation_ids",
        "source_category_ids",
        "semantic_category_ids",
    ):
        if not np.issubdtype(arrays[key].dtype, np.integer):
            raise ValueError(f"{path}: {key} must use an integer dtype")

    for key in ("points_xy", "centroids_xy"):
        xy = arrays[key]
        if count and (
            np.any(xy[:, 0] < 0)
            or np.any(xy[:, 0] >= image_width)
            or np.any(xy[:, 1] < 0)
            or np.any(xy[:, 1] >= image_height)
        ):
            raise ValueError(f"{path}: {key} contains coordinates outside the image")
    if count and (
        np.any(arrays["equivalent_radius"] <= 0)
        or np.any(arrays["inscribed_radius"] <= 0)
        or np.any(arrays["area_px"] < MIN_RASTER_AREA_PX)
    ):
        raise ValueError(
            f"{path}: radius/area targets must be positive and non-degenerate"
        )
    axes = arrays["axes"]
    if count and (np.any(axes[:, 1] <= 0) or np.any(axes[:, 0] < axes[:, 1])):
        raise ValueError(f"{path}: axes must satisfy major >= minor > 0")
    eccentricity = arrays["eccentricity"]
    if np.any((eccentricity < 0) | (eccentricity > 1)):
        raise ValueError(f"{path}: eccentricity must lie in [0, 1]")
    orientation_valid = arrays["orientation_valid"]
    orientation_norm = np.linalg.norm(arrays["orientation_vector"], axis=1)
    if np.any(~np.isclose(orientation_norm[orientation_valid], 1.0, atol=1e-4)):
        raise ValueError(f"{path}: valid orientation vectors must have unit norm")
    if np.any(~np.isclose(orientation_norm[~orientation_valid], 0.0, atol=1e-6)):
        raise ValueError(f"{path}: invalid orientations must use the zero vector")
    tolerance = 1e-6
    if np.any(
        (
            orientation_valid
            & (eccentricity < ORIENTATION_ECCENTRICITY_THRESHOLD - tolerance)
        )
        | (
            ~orientation_valid
            & (eccentricity > ORIENTATION_ECCENTRICITY_THRESHOLD + tolerance)
        )
    ):
        raise ValueError(
            f"{path}: orientation_valid disagrees with eccentricity threshold"
        )
    frame_completeness = arrays["frame_boundary_completeness"]
    if np.any((frame_completeness < 0) | (frame_completeness > 1)):
        raise ValueError(f"{path}: frame_boundary_completeness must lie in [0, 1]")
    touches = arrays["touches_image_boundary"]
    if np.any(touches != (frame_completeness < 1.0)):
        raise ValueError(f"{path}: frame-boundary flag and completeness disagree")
    bbox = arrays["mask_bbox_xywh"]
    if count and (
        np.any(bbox[:, :2] < 0)
        or np.any(bbox[:, 2:] <= 0)
        or np.any(bbox[:, 0] + bbox[:, 2] > image_width + 1e-3)
        or np.any(bbox[:, 1] + bbox[:, 3] > image_height + 1e-3)
    ):
        raise ValueError(
            f"{path}: mask_bbox_xywh contains invalid or out-of-image boxes"
        )
    source_bbox = arrays["source_coco_bbox_xywh"]
    source_bbox_present = arrays["source_coco_bbox_present"]
    source_bbox_clipped = arrays["source_coco_bbox_boundary_clipped"]
    if np.any(source_bbox_clipped & ~source_bbox_present):
        raise ValueError(
            f"{path}: a missing source COCO bbox cannot be boundary-clipped"
        )
    if count and np.any(source_bbox[~source_bbox_present] != 0):
        raise ValueError(
            f"{path}: missing source COCO bboxes must use an all-zero sentinel"
        )
    present_bbox = source_bbox[source_bbox_present]
    if len(present_bbox) and (
        np.any(present_bbox[:, :2] < 0)
        or np.any(present_bbox[:, 2:] <= 0)
        or np.any(present_bbox[:, 0] + present_bbox[:, 2] > image_width + 1e-3)
        or np.any(present_bbox[:, 1] + present_bbox[:, 3] > image_height + 1e-3)
    ):
        raise ValueError(
            f"{path}: archived source_coco_bbox_xywh must be clipped inside the image"
        )
    if np.any(arrays["component_count"] < 1):
        raise ValueError(f"{path}: component_count must be positive")

    annotation_ids = arrays["annotation_ids"].astype(np.int64, copy=False)
    stored_source_category_ids = arrays["source_category_ids"].astype(
        np.int64, copy=False
    )
    stored_semantic_category_ids = arrays["semantic_category_ids"].astype(
        np.int64, copy=False
    )
    excluded_ids = arrays["excluded_annotation_ids"]
    if excluded_ids.ndim != 1 or not np.issubdtype(excluded_ids.dtype, np.integer):
        raise ValueError(f"{path}: excluded_annotation_ids must be a 1-D integer array")
    excluded_ids = excluded_ids.astype(np.int64, copy=False)
    if count > 1 and np.any(np.diff(annotation_ids) <= 0):
        raise ValueError(
            f"{path}: annotation_ids must be unique and strictly increasing"
        )
    if len(np.unique(excluded_ids)) != len(excluded_ids):
        raise ValueError(f"{path}: excluded_annotation_ids contains duplicates")
    included_set = set(map(int, annotation_ids))
    excluded_set = set(map(int, excluded_ids))
    if included_set.intersection(excluded_set):
        raise ValueError(f"{path}: included and excluded annotation ids overlap")
    expected_by_id = {
        int(annotation["id"]): int(annotation["category_id"])
        for annotation in expected_annotations
    }
    if included_set.union(excluded_set) != set(expected_by_id):
        raise ValueError(
            f"{path}: annotation ids do not exactly match the current COCO source"
        )
    if excluded_set and not allow_geometry_subset:
        raise ValueError(
            f"{path}: excluded invalid instances require allow_geometry_subset"
        )
    expected_source_categories = np.asarray(
        [expected_by_id[int(annotation_id)] for annotation_id in annotation_ids],
        dtype=np.int64,
    )
    if not np.array_equal(stored_source_category_ids, expected_source_categories):
        raise ValueError(
            f"{path}: source_category_ids do not match current COCO annotations"
        )
    expected_semantic_categories = np.asarray(
        [
            source_category_mapping[int(source_id)][1]
            for source_id in expected_source_categories
        ],
        dtype=np.int64,
    )
    if not np.array_equal(
        stored_semantic_category_ids, expected_semantic_categories
    ):
        raise ValueError(
            f"{path}: semantic_category_ids do not match category-name mapping"
        )
    touching_count = int(np.count_nonzero(touches))
    source_bbox_clipped_count = int(np.count_nonzero(source_bbox_clipped))
    source_bbox_missing_count = int(np.count_nonzero(~source_bbox_present))
    return (
        points.astype(np.float32, copy=False),
        version,
        touching_count,
        len(excluded_ids),
        source_bbox_clipped_count,
        source_bbox_missing_count,
    )


def index_gbisc(
    root: str | Path,
    *,
    geometry_dir: str | Path = "geometry",
    annotation_files: Sequence[str | Path] | None = None,
    category_ids: set[int] | None = None,
    as_external_test: bool = False,
    verify_dimensions: bool = True,
    allow_geometry_subset: bool = False,
) -> list[SampleRecord]:
    """Index converted GBISC samples into the common manifest schema."""

    root_path = Path(root).resolve()
    geometry_root = Path(geometry_dir)
    if not geometry_root.is_absolute():
        geometry_root = root_path / geometry_root
    geometry_root = geometry_root.resolve()
    records: list[SampleRecord] = []
    seen_sample_ids: set[str] = set()
    for official_split, annotation_path in _normalise_annotation_inputs(
        root_path, annotation_files
    ):
        document = _load_coco(annotation_path)
        source_category_mapping = _category_mapping(document)
        annotation_sha256 = file_sha256(annotation_path)
        expected_annotations: dict[int, list[Mapping[str, Any]]] = defaultdict(list)
        for annotation in document["annotations"]:
            if bool(annotation.get("iscrowd", 0)):
                continue
            if (
                category_ids is not None
                and int(annotation["category_id"]) not in category_ids
            ):
                continue
            expected_annotations[int(annotation["image_id"])].append(annotation)
        for annotations in expected_annotations.values():
            annotations.sort(key=lambda item: int(item["id"]))
        for image in sorted(document["images"], key=lambda item: int(item["id"])):
            image_id = int(image["id"])
            image_path = _find_image(
                root_path, annotation_path, str(image["file_name"])
            )
            width, height = int(image["width"]), int(image["height"])
            _validate_image_coordinate_frame(
                image_path,
                width=width,
                height=height,
                verify_dimensions=verify_dimensions,
            )
            geometry_path = geometry_root / geometry_relative_path(
                official_split, image
            )
            if not geometry_path.is_file():
                raise FileNotFoundError(
                    f"geometry target missing for image {image_id}: {geometry_path}; "
                    "run convert_gbisc_geometry first"
                )
            (
                points,
                version,
                touching_count,
                missing_geometry_count,
                source_bbox_clipped_count,
                source_bbox_missing_count,
            ) = _validate_geometry_archive(
                geometry_path,
                annotation_sha256=annotation_sha256,
                image_id=image_id,
                image_width=width,
                image_height=height,
                expected_annotations=expected_annotations.get(image_id, []),
                category_ids=category_ids,
                source_category_mapping=source_category_mapping,
                allow_geometry_subset=allow_geometry_subset,
            )
            sample_id = f"gbisc:{official_split}:{image_id}"
            if sample_id in seen_sample_ids:
                raise ValueError(f"duplicate GBISC sample id: {sample_id}")
            seen_sample_ids.add(sample_id)
            variety = _infer_variety(image)
            records.append(
                SampleRecord(
                    sample_id=sample_id,
                    dataset="gbisc",
                    source_subset=variety or official_split,
                    source_domain=variety,
                    split="test" if as_external_test else official_split,
                    image_path=_relative(image_path, root_path),
                    width=width,
                    height=height,
                    annotation_kind="instances",
                    points_path=_relative(geometry_path, root_path),
                    instances_path=_relative(annotation_path, root_path),
                    point_count=int(len(points)),
                    instance_count=int(len(points)),
                    original_id=Path(str(image["file_name"])).stem,
                    sha256=file_sha256(image_path),
                    dhash64=image_dhash64(image_path),
                    license="CC-BY-4.0",
                    external_test=as_external_test,
                    processing_version=f"gbisc-geometry-v{version}",
                    bunch_id=f"gbisc:{Path(str(image['file_name'])).stem}",
                    has_native_points=False,
                    has_instance_masks=True,
                    provenance_url=GBISC_PROVENANCE_URL,
                    quality_flags=(
                        (
                            ["contains_frame_truncated_instances"]
                            if touching_count
                            else []
                        )
                        + (
                            ["invalid_instances_excluded"]
                            if missing_geometry_count
                            else []
                        )
                        + (
                            ["source_coco_bbox_boundary_clipped"]
                            if source_bbox_clipped_count
                            else []
                        )
                        + (
                            ["source_coco_bbox_missing"]
                            if source_bbox_missing_count
                            else []
                        )
                    ),
                    extra={
                        "official_split": official_split,
                        "variety": variety,
                        "derived_point_policy": CENTER_POLICY,
                        "geometry_schema_version": version,
                        "frame_boundary_touching_instance_count": touching_count,
                        "excluded_invalid_instance_count": missing_geometry_count,
                        "source_coco_bbox_boundary_clipped_instance_count": (
                            source_bbox_clipped_count
                        ),
                        "source_coco_bbox_missing_instance_count": (
                            source_bbox_missing_count
                        ),
                        "source_category_mapping": [
                            {
                                "source_category_id": source_id,
                                "category_name": source_category_mapping[source_id][0],
                                "semantic_category_id": source_category_mapping[
                                    source_id
                                ][1],
                            }
                            for source_id in sorted(source_category_mapping)
                        ],
                        "coco_image_id": image_id,
                        "source_annotation_sha256": annotation_sha256,
                        "contact_geometry_included": False,
                    },
                )
            )
    if not records:
        raise RuntimeError(f"no GBISC samples found under {root_path}")
    return records
