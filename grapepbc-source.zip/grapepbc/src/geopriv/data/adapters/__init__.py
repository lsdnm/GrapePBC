"""Dataset-specific adapters into the unified manifest schema."""

from .gbisc import convert_gbisc_geometry, discover_gbisc_annotations, index_gbisc
from .vivid import index_vivid
from .wgisd import index_wgisd

__all__ = [
    "convert_gbisc_geometry",
    "discover_gbisc_annotations",
    "index_gbisc",
    "index_vivid",
    "index_wgisd",
]
