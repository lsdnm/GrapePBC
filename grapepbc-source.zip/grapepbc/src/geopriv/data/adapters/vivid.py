"""ViViD-5K manifest adapter for both the full release and sparse samples."""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Iterable

import numpy as np
from PIL import Image, ImageFile, ImageOps

from ..hash_utils import file_sha256, image_dhash64
from ..schema import SampleRecord

ImageFile.LOAD_TRUNCATED_IMAGES = True


def _first_existing(candidates: Iterable[Path], kind: str) -> Path:
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    rendered = ", ".join(str(candidate) for candidate in candidates)
    raise FileNotFoundError(f"could not locate {kind}; checked: {rendered}")


def _relative(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def index_vivid(
    root: str | Path,
    *,
    hash_images: bool = True,
    verify_dimensions: bool = True,
    require_all_metadata_rows: bool = False,
) -> list[SampleRecord]:
    """Index available ViViD images.

    A sparse sample directory may contain the full metadata table but only a
    few image/point pairs. Missing rows are skipped unless ``require_all`` is
    enabled. The full release layout from the dataset card is auto-detected.
    """

    root_path = Path(root).resolve()
    metadata = _first_existing(
        [root_path / "metadata.csv", root_path / "data" / "metadata.csv"], "metadata.csv"
    )
    image_roots = [root_path, root_path / "data" / "imgs"]
    point_roots = [root_path, root_path / "data" / "anns" / "points"]
    cluster_annotations = next(
        (
            candidate
            for candidate in (
                root_path / "instances_updated.json",
                root_path / "data" / "anns" / "instances_updated.json",
            )
            if candidate.is_file()
        ),
        None,
    )
    records: list[SampleRecord] = []
    missing: list[str] = []

    with metadata.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        required = {"file_name", "split", "berry_count", "cluster_count", "width", "height"}
        if reader.fieldnames is None or not required.issubset(reader.fieldnames):
            raise ValueError(f"metadata is missing required columns: {sorted(required)}")
        for row in reader:
            file_name = row["file_name"].strip()
            image = next((base / file_name for base in image_roots if (base / file_name).is_file()), None)
            if image is None:
                missing.append(file_name)
                continue
            stem = Path(file_name).stem
            points = next((base / f"{stem}.npy" for base in point_roots if (base / f"{stem}.npy").is_file()), None)
            if points is None:
                raise FileNotFoundError(f"image {file_name} has no point annotation")
            point_array = np.load(points, allow_pickle=False)
            if point_array.ndim != 2 or point_array.shape[1] != 2:
                raise ValueError(f"{points} must have shape (N, 2), got {point_array.shape}")
            expected_count = int(row["berry_count"])
            if len(point_array) != expected_count:
                raise ValueError(
                    f"point count mismatch for {file_name}: metadata={expected_count}, npy={len(point_array)}"
                )
            width, height = int(row["width"]), int(row["height"])
            if len(point_array):
                finite = np.isfinite(point_array).all(axis=1)
                inside = (
                    (point_array[:, 0] >= 0)
                    & (point_array[:, 0] < width)
                    & (point_array[:, 1] >= 0)
                    & (point_array[:, 1] < height)
                )
                if not np.all(finite & inside):
                    bad = int(np.count_nonzero(~(finite & inside)))
                    raise ValueError(f"{file_name} contains {bad} invalid or out-of-bounds points")
            duplicate_coordinates = len(point_array) - len(np.unique(point_array, axis=0))
            if verify_dimensions:
                with Image.open(image) as opened:
                    actual_width, actual_height = ImageOps.exif_transpose(opened).size
                if (width, height) != (actual_width, actual_height):
                    raise ValueError(
                        f"dimension mismatch for {file_name}: metadata={(width, height)}, "
                        f"image={(actual_width, actual_height)}"
                    )
            records.append(
                SampleRecord(
                    sample_id=f"vivid5k:{stem}",
                    dataset="vivid5k",
                    source_subset="unresolved",
                    split="val" if row["split"].strip() == "validation" else row["split"].strip(),
                    image_path=_relative(image, root_path),
                    width=width,
                    height=height,
                    annotation_kind="points+clusters" if cluster_annotations is not None else "points",
                    points_path=_relative(points, root_path),
                    instances_path=(
                        _relative(cluster_annotations, root_path)
                        if cluster_annotations is not None
                        else None
                    ),
                    point_count=expected_count,
                    cluster_count=int(row["cluster_count"]),
                    original_id=stem,
                    sha256=file_sha256(image) if hash_images else "0" * 64,
                    dhash64=image_dhash64(image) if hash_images else "0" * 16,
                    license="CC-BY-4.0",
                    external_test=False,
                    has_native_points=True,
                    has_cluster_masks=cluster_annotations is not None,
                    provenance_url="https://huggingface.co/datasets/XZhi/ViViD-5k",
                    quality_flags=["duplicate_point_coordinates"] if duplicate_coordinates else [],
                    extra={
                        "original_file_name": file_name,
                        "duplicate_coordinate_count": duplicate_coordinates,
                    },
                )
            )

    if require_all_metadata_rows and missing:
        preview = ", ".join(missing[:5])
        raise FileNotFoundError(f"{len(missing)} metadata images are absent; first entries: {preview}")
    if not records:
        raise RuntimeError(f"no image/point pairs were found under {root_path}")
    return records
