"""WGISD adapter for the 300-image contributed berry-point protocol."""

from __future__ import annotations

from pathlib import Path

import numpy as np
from PIL import Image, ImageOps

from ..hash_utils import file_sha256, image_dhash64
from ..schema import SampleRecord


VARIETIES = {
    "CDY": "Chardonnay",
    "CFR": "Cabernet Franc",
    "CSV": "Cabernet Sauvignon",
    "SVB": "Sauvignon Blanc",
    "SYH": "Syrah",
}


def _load_name_set(path: Path) -> set[str]:
    if not path.is_file():
        return set()
    names: set[str] = set()
    for raw_line in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()
        if not line:
            continue
        token = line.split()[0].replace("\\", "/")
        names.add(Path(token).stem)
    return names


def _load_points(path: Path) -> np.ndarray:
    if path.stat().st_size == 0:
        return np.empty((0, 2), dtype=np.float32)
    points = np.loadtxt(path, dtype=np.float32, ndmin=2)
    if points.ndim != 2 or points.shape[1] != 2:
        raise ValueError(f"{path} must contain two columns X Y, got {points.shape}")
    return points


def index_wgisd(
    root: str | Path,
    *,
    as_external_test: bool = True,
    hash_images: bool = True,
) -> list[SampleRecord]:
    root_path = Path(root).resolve()
    image_root = root_path / "data"
    point_root = root_path / "contrib" / "berries"
    if not image_root.is_dir() or not point_root.is_dir():
        raise FileNotFoundError("WGISD requires data/ and contrib/berries/ directories")

    official_test = _load_name_set(root_path / "test.txt")
    official_train = _load_name_set(root_path / "train.txt")
    image_files = sorted(
        path for path in image_root.iterdir() if path.suffix.lower() in {".jpg", ".jpeg", ".png"}
    )
    records: list[SampleRecord] = []
    missing_points: list[str] = []
    for image in image_files:
        stem = image.stem
        point_file = point_root / f"{stem}-berries.txt"
        if not point_file.is_file():
            missing_points.append(stem)
            continue
        points = _load_points(point_file)
        with Image.open(image) as opened:
            width, height = ImageOps.exif_transpose(opened).size
        if len(points):
            valid = (
                np.isfinite(points).all(axis=1)
                & (points[:, 0] >= 0)
                & (points[:, 0] < width)
                & (points[:, 1] >= 0)
                & (points[:, 1] < height)
            )
            if not np.all(valid):
                raise ValueError(f"{point_file} has {int(np.count_nonzero(~valid))} invalid points")

        box_file = image_root / f"{stem}.txt"
        cluster_count = None
        if box_file.is_file():
            cluster_count = sum(
                1 for line in box_file.read_text(encoding="utf-8").splitlines() if line.strip()
            )
        official_split = (
            "test" if stem in official_test else "train" if stem in official_train else "unspecified"
        )
        prefix = stem.split("_", 1)[0]
        capture_group_id = stem.split("_BURST", 1)[0] if "_BURST" in stem else stem
        records.append(
            SampleRecord(
                sample_id=f"wgisd:{stem}",
                dataset="wgisd",
                source_subset=prefix,
                source_domain=VARIETIES.get(prefix, prefix),
                capture_group_id=f"wgisd:{capture_group_id}",
                split="test" if as_external_test else official_split,
                image_path=image.relative_to(root_path).as_posix(),
                width=width,
                height=height,
                annotation_kind="points+clusters" if box_file.is_file() else "points",
                points_path=point_file.relative_to(root_path).as_posix(),
                instances_path=box_file.relative_to(root_path).as_posix() if box_file.is_file() else None,
                point_count=int(len(points)),
                cluster_count=cluster_count,
                original_id=stem,
                sha256=file_sha256(image) if hash_images else "0" * 64,
                dhash64=image_dhash64(image) if hash_images else "0" * 16,
                license="CC-BY-NC-4.0",
                external_test=as_external_test,
                has_native_points=True,
                provenance_url="https://github.com/thsant/wgisd",
                quality_flags=[],
                extra={
                    "official_split": official_split,
                    "berry_protocol": "WGISD-300-Contrib",
                    "variety": VARIETIES.get(prefix),
                    "cluster_annotation_kind": "yolo_boxes" if box_file.is_file() else None,
                },
            )
        )
    if missing_points:
        preview = ", ".join(missing_points[:5])
        raise FileNotFoundError(
            f"{len(missing_points)} WGISD images lack contributed berry points; first: {preview}"
        )
    if not records:
        raise RuntimeError(f"no WGISD image/point pairs found under {root_path}")
    return records
