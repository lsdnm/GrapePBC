"""Versioned, dataset-independent sample schema."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Mapping


ALLOWED_SPLITS = {"train", "val", "test", "unspecified"}
ALLOWED_ANNOTATIONS = {
    "count",
    "points",
    "instances",
    "points+clusters",
    "instances+clusters",
}


@dataclass(slots=True)
class SampleRecord:
    """One image and its annotations, with paths relative to a dataset root."""

    sample_id: str
    dataset: str
    source_subset: str
    split: str
    image_path: str
    width: int
    height: int
    annotation_kind: str
    point_count: int
    original_id: str
    sha256: str
    dhash64: str
    license: str
    points_path: str | None = None
    instances_path: str | None = None
    instance_count: int | None = None
    cluster_count: int | None = None
    external_test: bool = False
    processing_version: str = "raw-v1"
    source_domain: str | None = None
    capture_group_id: str | None = None
    bunch_id: str | None = None
    has_native_points: bool = False
    has_instance_masks: bool = False
    has_cluster_masks: bool = False
    provenance_url: str | None = None
    quality_flags: list[str] = field(default_factory=list)
    extra: dict[str, Any] = field(default_factory=dict)
    schema_version: int = 1

    def validate(self) -> None:
        if not self.sample_id or ":" not in self.sample_id:
            raise ValueError("sample_id must be non-empty and namespaced, e.g. vivid5k:0")
        if not self.dataset:
            raise ValueError("dataset must be non-empty")
        if self.split not in ALLOWED_SPLITS:
            raise ValueError(f"unsupported split: {self.split!r}")
        if self.annotation_kind not in ALLOWED_ANNOTATIONS:
            raise ValueError(f"unsupported annotation_kind: {self.annotation_kind!r}")
        if self.width <= 0 or self.height <= 0:
            raise ValueError("image dimensions must be positive")
        if self.point_count < 0:
            raise ValueError("point_count cannot be negative")
        if self.instance_count is not None and self.instance_count < 0:
            raise ValueError("instance_count cannot be negative")
        if self.cluster_count is not None and self.cluster_count < 0:
            raise ValueError("cluster_count cannot be negative")
        if len(self.sha256) != 64 or any(c not in "0123456789abcdef" for c in self.sha256):
            raise ValueError("sha256 must be a 64-character lowercase hexadecimal digest")
        if len(self.dhash64) != 16 or any(c not in "0123456789abcdef" for c in self.dhash64):
            raise ValueError("dhash64 must be a 16-character lowercase hexadecimal digest")
        if self.points_path is None and "points" in self.annotation_kind:
            raise ValueError("point annotations require points_path")
        if self.instances_path is None and "instances" in self.annotation_kind:
            raise ValueError("instance annotations require instances_path")
        if self.instances_path is None and "clusters" in self.annotation_kind:
            raise ValueError("cluster annotations require instances_path")
        if self.has_native_points and self.points_path is None:
            raise ValueError("has_native_points requires points_path")
        if (self.has_instance_masks or self.has_cluster_masks) and self.instances_path is None:
            raise ValueError("mask availability flags require instances_path")

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return asdict(self)

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "SampleRecord":
        record = cls(**dict(value))
        record.validate()
        return record
