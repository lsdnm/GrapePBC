"""Geometry targets distilled from COCO polygon instance masks.

The converter deliberately works on each instance's tight crop rather than on
the full 12-megapixel GBISC image.  This keeps memory bounded while producing
the geometric targets used only by the privileged training branch.

``frame_boundary_completeness`` describes truncation at the image frame only.
It must not be interpreted as berry-to-berry contact or occlusion completeness;
cross-instance contact geometry is deliberately not part of this per-instance
converter.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import math
from typing import Any, Mapping, Sequence

import numpy as np
from PIL import Image, ImageDraw


GEOMETRY_SCHEMA_VERSION = 3
GEOMETRY_CONVERTER_VERSION = "gbisc-polygon-v3"
MIN_POLYGON_AREA_PX2 = 0.5
MIN_RASTER_AREA_PX = 3
ORIENTATION_ECCENTRICITY_THRESHOLD = 0.2
CENTER_POLICY = "maximum_inscribed_circle_center_nearest_centroid_tiebreak"
COCO_BBOX_BOUNDARY_TOLERANCE_PX = 0.5
COCO_BBOX_POLYGON_EDGE_TOLERANCE_PX = 1.0
COORDINATE_EPSILON_PX = 1e-6


@dataclass(slots=True, frozen=True)
class InstanceGeometry:
    """Geometry of one visible berry instance in original-image pixels."""

    annotation_id: int
    image_id: int
    source_category_id: int
    semantic_category_id: int
    center_x: float
    center_y: float
    centroid_x: float
    centroid_y: float
    area_px: float
    equivalent_radius: float
    inscribed_radius: float
    major_axis: float
    minor_axis: float
    eccentricity: float
    orientation_vector: tuple[float, float]
    orientation_valid: bool
    frame_boundary_completeness: float
    touches_image_boundary: bool
    component_count: int
    mask_bbox_xywh: tuple[float, float, float, float]
    source_coco_bbox_xywh: tuple[float, float, float, float]
    source_coco_bbox_present: bool
    source_coco_bbox_boundary_clipped: bool
    schema_version: int = GEOMETRY_SCHEMA_VERSION

    @property
    def point_xy(self) -> tuple[float, float]:
        """Return the maximum-inscribed-circle centre used as point target."""

        return self.center_x, self.center_y

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _normalise_polygons(segmentation: Any) -> list[np.ndarray]:
    """Validate and normalise a COCO polygon segmentation.

    Compressed/uncompressed COCO RLE is intentionally rejected.  GBISC uses
    polygons, and silently interpreting an RLE dictionary as vertices would
    corrupt the teacher targets.
    """

    if isinstance(segmentation, Mapping):
        raise ValueError("RLE segmentation is unsupported; expected COCO polygons")
    if not isinstance(segmentation, Sequence) or isinstance(segmentation, (str, bytes)):
        raise ValueError("segmentation must be a COCO polygon list")
    if not segmentation:
        raise ValueError("segmentation contains no polygons")
    first = segmentation[0]
    raw_polygons = [segmentation] if isinstance(first, (int, float)) else segmentation
    polygons: list[np.ndarray] = []
    for index, raw in enumerate(raw_polygons):
        values = np.asarray(raw, dtype=np.float64)
        if values.ndim != 1 or len(values) < 6 or len(values) % 2:
            raise ValueError(f"polygon {index} must contain at least three x/y pairs")
        points = values.reshape(-1, 2)
        if not np.isfinite(points).all():
            raise ValueError(f"polygon {index} contains non-finite coordinates")
        x = points[:, 0]
        y = points[:, 1]
        signed_twice_area = float(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))
        area = 0.5 * abs(signed_twice_area)
        if area < MIN_POLYGON_AREA_PX2:
            raise ValueError(
                f"polygon {index} has near-zero continuous area {area:.6g} px^2"
            )
        polygons.append(points)
    return polygons


def _rasterize_crop(
    polygons: Sequence[np.ndarray], image_width: int, image_height: int
) -> tuple[np.ndarray, int, int]:
    if image_width <= 0 or image_height <= 0:
        raise ValueError("image dimensions must be positive")
    all_points = np.concatenate(polygons, axis=0)
    left = max(0, int(math.floor(float(all_points[:, 0].min()))))
    top = max(0, int(math.floor(float(all_points[:, 1].min()))))
    right = min(image_width - 1, int(math.ceil(float(all_points[:, 0].max()))))
    bottom = min(image_height - 1, int(math.ceil(float(all_points[:, 1].max()))))
    if right < left or bottom < top:
        raise ValueError("polygon lies completely outside the image")

    # Pillow is a required project dependency and handles multiple polygon
    # components without allocating a full-resolution canvas.
    canvas = Image.new("L", (right - left + 1, bottom - top + 1), 0)
    draw = ImageDraw.Draw(canvas)
    for polygon in polygons:
        shifted = [(float(x - left), float(y - top)) for x, y in polygon]
        draw.polygon(shifted, fill=1)
    mask = np.asarray(canvas, dtype=np.uint8)
    raster_area = int(np.count_nonzero(mask))
    if raster_area < MIN_RASTER_AREA_PX:
        raise ValueError(
            f"polygon rasterized to only {raster_area} pixels; "
            f"minimum is {MIN_RASTER_AREA_PX}"
        )
    return mask, left, top


def _audit_source_coco_bbox(
    annotation: Mapping[str, Any],
    *,
    polygons: Sequence[np.ndarray],
    image_width: int,
    image_height: int,
) -> tuple[tuple[float, float, float, float], bool, bool]:
    """Validate source bbox metadata without using it as a geometry target.

    GBISC was exported with an ISAT/COCO half-pixel convention: a few berries
    touching the left frame have ``x=-0.5`` although every polygon vertex is
    inside the image.  Such a source box is clipped for archival/audit use when
    its overrun is at most half a pixel.  Larger overruns and boxes that do not
    agree with their polygon envelope are rejected instead of being silently
    repaired.  All learned geometry continues to come from the polygon mask.
    """

    if "bbox" not in annotation:
        return (0.0, 0.0, 0.0, 0.0), False, False
    raw_bbox = np.asarray(annotation["bbox"], dtype=np.float64)
    if raw_bbox.shape != (4,) or not np.isfinite(raw_bbox).all():
        raise ValueError("source COCO bbox must contain four finite xywh values")
    bbox_x, bbox_y, bbox_width, bbox_height = map(float, raw_bbox)
    if bbox_width <= 0 or bbox_height <= 0:
        raise ValueError("source COCO bbox width and height must be positive")
    bbox_right = bbox_x + bbox_width
    bbox_bottom = bbox_y + bbox_height
    overrun = max(
        0.0,
        -bbox_x,
        -bbox_y,
        bbox_right - image_width,
        bbox_bottom - image_height,
    )
    if overrun > COCO_BBOX_BOUNDARY_TOLERANCE_PX + COORDINATE_EPSILON_PX:
        raise ValueError(
            "source COCO bbox exceeds the image by "
            f"{overrun:.6g}px; maximum auditable boundary tolerance is "
            f"{COCO_BBOX_BOUNDARY_TOLERANCE_PX}px"
        )

    clipped_left = float(np.clip(bbox_x, 0.0, image_width))
    clipped_top = float(np.clip(bbox_y, 0.0, image_height))
    clipped_right = float(np.clip(bbox_right, 0.0, image_width))
    clipped_bottom = float(np.clip(bbox_bottom, 0.0, image_height))
    if clipped_right <= clipped_left or clipped_bottom <= clipped_top:
        raise ValueError("source COCO bbox has no positive-area intersection with image")

    all_points = np.concatenate(polygons, axis=0)
    polygon_edges = np.asarray(
        [
            all_points[:, 0].min(),
            all_points[:, 1].min(),
            all_points[:, 0].max(),
            all_points[:, 1].max(),
        ],
        dtype=np.float64,
    )
    bbox_edges = np.asarray(
        [bbox_x, bbox_y, bbox_right, bbox_bottom], dtype=np.float64
    )
    edge_disagreement = float(np.max(np.abs(bbox_edges - polygon_edges)))
    if (
        edge_disagreement
        > COCO_BBOX_POLYGON_EDGE_TOLERANCE_PX + COORDINATE_EPSILON_PX
    ):
        raise ValueError(
            "source COCO bbox disagrees with polygon envelope by "
            f"{edge_disagreement:.6g}px; maximum is "
            f"{COCO_BBOX_POLYGON_EDGE_TOLERANCE_PX}px"
        )

    boundary_clipped = overrun > COORDINATE_EPSILON_PX
    return (
        (
            clipped_left,
            clipped_top,
            clipped_right - clipped_left,
            clipped_bottom - clipped_top,
        ),
        True,
        boundary_clipped,
    )


def _distance_transform(mask: np.ndarray) -> np.ndarray:
    """Euclidean distance to background with a zero border.

    OpenCV is used when available (the verified training environment includes
    it).  A vectorised exact fallback keeps data conversion testable in the
    minimal package without making OpenCV an inference-time dependency.
    """

    padded = np.pad(mask.astype(np.uint8, copy=False), 1, constant_values=0)
    try:
        import cv2  # type: ignore[import-not-found]

        transformed = cv2.distanceTransform(padded, cv2.DIST_L2, cv2.DIST_MASK_PRECISE)
        return transformed[1:-1, 1:-1].astype(np.float32, copy=False)
    except ImportError:
        foreground = np.argwhere(padded != 0)
        background = np.argwhere(padded == 0)
        distances = np.zeros(padded.shape, dtype=np.float32)
        # The fallback is exact and chunked.  It is intended for tests and
        # small conversions; production GBISC conversion takes the fast path.
        for start in range(0, len(foreground), 1024):
            points = foreground[start : start + 1024]
            squared = ((points[:, None, :] - background[None, :, :]) ** 2).sum(axis=2)
            distances[points[:, 0], points[:, 1]] = np.sqrt(squared.min(axis=1))
        return distances[1:-1, 1:-1]


def _mask_boundary(mask: np.ndarray) -> np.ndarray:
    padded = np.pad(mask.astype(bool, copy=False), 1, constant_values=False)
    height, width = mask.shape
    eroded = np.ones((height, width), dtype=bool)
    for dy in range(3):
        for dx in range(3):
            eroded &= padded[dy : dy + height, dx : dx + width]
    return mask.astype(bool, copy=False) & ~eroded


def _axis_geometry(mask: np.ndarray, left: int, top: int) -> tuple[Any, ...]:
    ys, xs = np.nonzero(mask)
    global_x = xs.astype(np.float64) + left
    global_y = ys.astype(np.float64) + top
    centroid_x = float(global_x.mean())
    centroid_y = float(global_y.mean())
    if len(xs) <= 1:
        return centroid_x, centroid_y, 0.0, 0.0, 0.0, (0.0, 0.0), False
    centered = np.stack((global_x - centroid_x, global_y - centroid_y), axis=0)
    covariance = centered @ centered.T / len(xs)
    eigenvalues, eigenvectors = np.linalg.eigh(covariance)
    order = np.argsort(eigenvalues)[::-1]
    major_variance = max(float(eigenvalues[order[0]]), 0.0)
    minor_variance = max(float(eigenvalues[order[1]]), 0.0)
    # For a uniformly filled ellipse covariance is diag(a^2/4, b^2/4),
    # where a and b are semi-axes.  The full axis lengths are therefore 4√λ.
    major_axis = 4.0 * math.sqrt(major_variance)
    minor_axis = 4.0 * math.sqrt(minor_variance)
    eccentricity = (
        math.sqrt(max(0.0, 1.0 - (minor_axis / major_axis) ** 2))
        if major_axis > 0
        else 0.0
    )
    orientation_valid = bool(
        major_axis > 0 and eccentricity >= ORIENTATION_ECCENTRICITY_THRESHOLD
    )
    if orientation_valid:
        # The principal eigenvector has an arbitrary sign.  Encoding 2*theta
        # makes v and -v identical and avoids a discontinuity at theta +/- pi.
        direction = eigenvectors[:, order[0]]
        dx, dy = float(direction[0]), float(direction[1])
        orientation_vector = (dx * dx - dy * dy, 2.0 * dx * dy)
    else:
        # Orientation is not a meaningful target for a near-circular instance.
        orientation_vector = (0.0, 0.0)
    return (
        centroid_x,
        centroid_y,
        major_axis,
        minor_axis,
        eccentricity,
        orientation_vector,
        orientation_valid,
    )


def extract_polygon_geometry(
    annotation: Mapping[str, Any],
    *,
    image_width: int,
    image_height: int,
    semantic_category_id: int = 1,
) -> InstanceGeometry:
    """Extract scale, shape, centre, and truncation cues from one annotation."""

    required = ("id", "image_id", "category_id", "segmentation")
    missing = [key for key in required if key not in annotation]
    if missing:
        raise ValueError(f"annotation is missing required fields: {missing}")
    polygons = _normalise_polygons(annotation["segmentation"])
    source_coco_bbox, source_coco_bbox_present, source_coco_bbox_boundary_clipped = (
        _audit_source_coco_bbox(
            annotation,
            polygons=polygons,
            image_width=image_width,
            image_height=image_height,
        )
    )
    mask, left, top = _rasterize_crop(polygons, image_width, image_height)
    area = float(np.count_nonzero(mask))
    equivalent_radius = math.sqrt(area / math.pi)
    (
        centroid_x,
        centroid_y,
        major_axis,
        minor_axis,
        eccentricity,
        orientation_vector,
        orientation_valid,
    ) = _axis_geometry(mask, left, top)

    distance = _distance_transform(mask)
    inscribed_radius = float(distance.max())
    peak_candidates = np.argwhere(
        np.isclose(distance, inscribed_radius, rtol=1e-6, atol=1e-6)
    )
    global_candidates = peak_candidates[:, ::-1].astype(np.float64)
    global_candidates[:, 0] += left
    global_candidates[:, 1] += top
    squared_to_centroid = (global_candidates[:, 0] - centroid_x) ** 2 + (
        global_candidates[:, 1] - centroid_y
    ) ** 2
    peak_y, peak_x = peak_candidates[int(np.argmin(squared_to_centroid))]
    center_x, center_y = float(peak_x + left), float(peak_y + top)

    boundary = _mask_boundary(mask)
    touching = np.zeros_like(boundary)
    if left == 0:
        touching[:, 0] |= boundary[:, 0]
    if top == 0:
        touching[0, :] |= boundary[0, :]
    if left + mask.shape[1] == image_width:
        touching[:, -1] |= boundary[:, -1]
    if top + mask.shape[0] == image_height:
        touching[-1, :] |= boundary[-1, :]
    touch_count = int(touching.sum())
    boundary_count = max(int(boundary.sum()), 1)
    frame_completeness = float(np.clip(1.0 - touch_count / boundary_count, 0.0, 1.0))

    ys, xs = np.nonzero(mask)
    mask_bbox = (
        float(xs.min() + left),
        float(ys.min() + top),
        float(xs.max() - xs.min() + 1),
        float(ys.max() - ys.min() + 1),
    )

    return InstanceGeometry(
        annotation_id=int(annotation["id"]),
        image_id=int(annotation["image_id"]),
        source_category_id=int(annotation["category_id"]),
        semantic_category_id=int(semantic_category_id),
        center_x=center_x,
        center_y=center_y,
        centroid_x=centroid_x,
        centroid_y=centroid_y,
        area_px=area,
        equivalent_radius=equivalent_radius,
        inscribed_radius=inscribed_radius,
        major_axis=major_axis,
        minor_axis=minor_axis,
        eccentricity=eccentricity,
        orientation_vector=orientation_vector,
        orientation_valid=orientation_valid,
        frame_boundary_completeness=frame_completeness,
        touches_image_boundary=bool(touch_count),
        component_count=len(polygons),
        mask_bbox_xywh=mask_bbox,
        source_coco_bbox_xywh=source_coco_bbox,
        source_coco_bbox_present=source_coco_bbox_present,
        source_coco_bbox_boundary_clipped=source_coco_bbox_boundary_clipped,
    )


def geometry_arrays(
    instances: Sequence[InstanceGeometry],
    *,
    source_annotation_sha256: str,
    source_image_id: int,
    source_image_width: int,
    source_image_height: int,
    category_ids: set[int] | None,
    strict: bool,
    source_category_mapping: Mapping[int, tuple[str, int]],
    excluded_annotation_ids: Sequence[int] = (),
) -> dict[str, np.ndarray]:
    """Pack records and source-binding metadata into a per-image NPZ payload."""

    ordered = sorted(instances, key=lambda item: item.annotation_id)
    count = len(ordered)
    vector = lambda values: np.asarray(values, dtype=np.float32)  # noqa: E731
    source_category_map_ids = sorted(source_category_mapping)
    return {
        "points_xy": np.asarray(
            [item.point_xy for item in ordered], dtype=np.float32
        ).reshape(count, 2),
        "centroids_xy": np.asarray(
            [(item.centroid_x, item.centroid_y) for item in ordered], dtype=np.float32
        ).reshape(count, 2),
        "equivalent_radius": vector([item.equivalent_radius for item in ordered]),
        "inscribed_radius": vector([item.inscribed_radius for item in ordered]),
        "axes": np.asarray(
            [(item.major_axis, item.minor_axis) for item in ordered], dtype=np.float32
        ).reshape(count, 2),
        "eccentricity": vector([item.eccentricity for item in ordered]),
        "orientation_vector": np.asarray(
            [item.orientation_vector for item in ordered], dtype=np.float32
        ).reshape(count, 2),
        "orientation_valid": np.asarray(
            [item.orientation_valid for item in ordered], dtype=np.bool_
        ),
        "frame_boundary_completeness": vector(
            [item.frame_boundary_completeness for item in ordered]
        ),
        "touches_image_boundary": np.asarray(
            [item.touches_image_boundary for item in ordered], dtype=np.bool_
        ),
        "area_px": vector([item.area_px for item in ordered]),
        "mask_bbox_xywh": np.asarray(
            [item.mask_bbox_xywh for item in ordered], dtype=np.float32
        ).reshape(count, 4),
        "source_coco_bbox_xywh": np.asarray(
            [item.source_coco_bbox_xywh for item in ordered], dtype=np.float32
        ).reshape(count, 4),
        "source_coco_bbox_present": np.asarray(
            [item.source_coco_bbox_present for item in ordered], dtype=np.bool_
        ),
        "source_coco_bbox_boundary_clipped": np.asarray(
            [item.source_coco_bbox_boundary_clipped for item in ordered],
            dtype=np.bool_,
        ),
        "component_count": np.asarray(
            [item.component_count for item in ordered], dtype=np.int16
        ),
        "annotation_ids": np.asarray(
            [item.annotation_id for item in ordered], dtype=np.int64
        ),
        "source_category_ids": np.asarray(
            [item.source_category_id for item in ordered], dtype=np.int64
        ),
        "semantic_category_ids": np.asarray(
            [item.semantic_category_id for item in ordered], dtype=np.int64
        ),
        "geometry_schema_version": np.asarray(GEOMETRY_SCHEMA_VERSION, dtype=np.int16),
        "geometry_converter_version": np.asarray(GEOMETRY_CONVERTER_VERSION),
        "source_annotation_sha256": np.asarray(source_annotation_sha256),
        "source_image_id": np.asarray(source_image_id, dtype=np.int64),
        "source_image_width": np.asarray(source_image_width, dtype=np.int32),
        "source_image_height": np.asarray(source_image_height, dtype=np.int32),
        "conversion_all_categories": np.asarray(category_ids is None, dtype=np.bool_),
        "conversion_category_ids": np.asarray(
            sorted(category_ids or set()), dtype=np.int64
        ),
        "source_category_map_ids": np.asarray(
            source_category_map_ids, dtype=np.int64
        ),
        "source_category_map_names": np.asarray(
            [source_category_mapping[value][0] for value in source_category_map_ids]
        ),
        "source_category_map_semantic_ids": np.asarray(
            [source_category_mapping[value][1] for value in source_category_map_ids],
            dtype=np.int64,
        ),
        "conversion_strict": np.asarray(strict, dtype=np.bool_),
        "conversion_excludes_crowd": np.asarray(True, dtype=np.bool_),
        "conversion_verifies_image_dimensions": np.asarray(True, dtype=np.bool_),
        "conversion_rejects_non_identity_exif_orientation": np.asarray(
            True, dtype=np.bool_
        ),
        "conversion_exif_zero_means_unspecified": np.asarray(True, dtype=np.bool_),
        "conversion_image_frame_index": np.asarray(0, dtype=np.int16),
        "excluded_annotation_ids": np.asarray(
            sorted(int(value) for value in excluded_annotation_ids), dtype=np.int64
        ),
        "minimum_polygon_area_px2": np.asarray(MIN_POLYGON_AREA_PX2, dtype=np.float32),
        "minimum_raster_area_px": np.asarray(MIN_RASTER_AREA_PX, dtype=np.int32),
        "coco_bbox_boundary_tolerance_px": np.asarray(
            COCO_BBOX_BOUNDARY_TOLERANCE_PX, dtype=np.float32
        ),
        "coco_bbox_polygon_edge_tolerance_px": np.asarray(
            COCO_BBOX_POLYGON_EDGE_TOLERANCE_PX, dtype=np.float32
        ),
        "orientation_eccentricity_threshold": np.asarray(
            ORIENTATION_ECCENTRICITY_THRESHOLD, dtype=np.float32
        ),
        "center_policy": np.asarray(CENTER_POLICY),
        "orientation_representation": np.asarray("cos_2theta_sin_2theta"),
        "contact_geometry_included": np.asarray(False, dtype=np.bool_),
    }
