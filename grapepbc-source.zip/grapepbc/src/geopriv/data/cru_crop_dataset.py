"""Virtual core/halo crops for training a CRU local counting expert."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any, Sequence

import numpy as np
from PIL import Image, ImageOps
import torch
from torch.utils.data import Dataset

from geopriv.routing import CoreHaloTile, make_core_halo_tiles

from .manifest import read_manifest
from .point_dataset import (
    IMAGENET_MEAN,
    IMAGENET_STD,
    letterbox_image_and_points,
    load_points,
)
from .schema import SampleRecord


class CRUContextCropDataset(Dataset[dict[str, Any]]):
    """Expose every source image as non-overlapping cores with halo context.

    All annotated centres inside the context crop supervise the detector.  A
    separate ``core_points_xy`` field identifies the only predictions owned by
    this tile at evaluation/inference time.  This avoids teaching halo berries
    as background while retaining duplicate-free final ownership.
    """

    def __init__(
        self,
        manifest: str | Path,
        root: str | Path,
        *,
        split: str,
        image_size: int = 768,
        core_size: int = 1024,
        halo: int = 128,
        max_images: int | None = None,
        cache_images: int = 2,
    ) -> None:
        if image_size <= 0 or core_size <= 0:
            raise ValueError("image_size and core_size must be positive")
        if halo < 0:
            raise ValueError("halo must be non-negative")
        if max_images is not None and max_images <= 0:
            raise ValueError("max_images must be positive when provided")
        if cache_images < 0:
            raise ValueError("cache_images must be non-negative")
        records = [record for record in read_manifest(manifest) if record.split == split]
        if max_images is not None:
            records = records[:max_images]
        if not records:
            raise ValueError(f"no records selected for split={split!r}")
        for record in records:
            if record.points_path is None:
                raise ValueError(f"{record.sample_id} has no point annotations")

        self.records = records
        self.root = Path(root).resolve()
        self.image_size = int(image_size)
        self.core_size = int(core_size)
        self.halo = int(halo)
        self.items: list[tuple[int, CoreHaloTile]] = []
        for record_index, record in enumerate(records):
            for tile in make_core_halo_tiles(
                record.width,
                record.height,
                core_size=self.core_size,
                halo=self.halo,
            ):
                self.items.append((record_index, tile))

        # Bind a per-instance LRU so workers do not share mutable image objects.
        self._load_source = lru_cache(maxsize=cache_images)(self._load_source_uncached)

    def __len__(self) -> int:
        return len(self.items)

    def _resolve(self, relative: str) -> Path:
        candidate = (self.root / relative).resolve()
        try:
            candidate.relative_to(self.root)
        except ValueError as exc:
            raise ValueError(f"path escapes dataset root: {relative}") from exc
        return candidate

    def _load_source_uncached(self, record_index: int) -> tuple[Image.Image, np.ndarray]:
        record = self.records[record_index]
        with Image.open(self._resolve(record.image_path)) as source:
            image = ImageOps.exif_transpose(source).convert("RGB")
        points = load_points(self._resolve(str(record.points_path))).astype(
            np.float32, copy=False
        )
        if image.size != (record.width, record.height):
            raise ValueError(f"{record.sample_id}: image dimensions differ from manifest")
        if len(points) != record.point_count:
            raise ValueError(
                f"{record.sample_id}: manifest count={record.point_count}, loaded={len(points)}"
            )
        return image, points

    def __getitem__(self, index: int) -> dict[str, Any]:
        record_index, tile = self.items[index]
        record = self.records[record_index]
        source_image, source_points = self._load_source(record_index)
        image = source_image.crop(
            (
                tile.context_x0,
                tile.context_y0,
                tile.context_x1,
                tile.context_y1,
            )
        )
        in_context = (
            (source_points[:, 0] >= tile.context_x0)
            & (source_points[:, 0] < tile.context_x1)
            & (source_points[:, 1] >= tile.context_y0)
            & (source_points[:, 1] < tile.context_y1)
        )
        context_points = source_points[in_context].copy()
        context_points[:, 0] -= tile.context_x0
        context_points[:, 1] -= tile.context_y0

        transformed_image, transformed_points, valid, affine = (
            letterbox_image_and_points(image, context_points, self.image_size)
        )
        owned_in_context = (
            (context_points[:, 0] >= tile.core_x0 - tile.context_x0)
            & (context_points[:, 0] < tile.core_x1 - tile.context_x0)
            & (context_points[:, 1] >= tile.core_y0 - tile.context_y0)
            & (context_points[:, 1] < tile.core_y1 - tile.context_y0)
        )
        core_points = transformed_points[owned_in_context]

        core_corners = np.asarray(
            [
                [tile.core_x0 - tile.context_x0, tile.core_y0 - tile.context_y0, 1.0],
                [tile.core_x1 - tile.context_x0, tile.core_y1 - tile.context_y0, 1.0],
            ],
            dtype=np.float32,
        )
        transformed_corners = (affine @ core_corners.T).T[:, :2]
        core_bounds = np.asarray(
            [
                transformed_corners[0, 0],
                transformed_corners[0, 1],
                transformed_corners[1, 0],
                transformed_corners[1, 1],
            ],
            dtype=np.float32,
        )
        array = (
            np.asarray(transformed_image, dtype=np.float32)
            .transpose(2, 0, 1)
            .copy()
            / 255.0
        )
        image_tensor = (torch.from_numpy(array) - IMAGENET_MEAN) / IMAGENET_STD
        return {
            "image": image_tensor,
            "valid_image_mask": torch.from_numpy(valid),
            "target": {
                "sample_id": record.sample_id,
                "tile_id": tile.tile_id,
                "points_xy": torch.from_numpy(transformed_points),
                "core_points_xy": torch.from_numpy(core_points.copy()),
                "core_bounds_xyxy": torch.from_numpy(core_bounds),
                "context_count": torch.tensor(len(transformed_points), dtype=torch.int64),
                "core_count": torch.tensor(len(core_points), dtype=torch.int64),
                "source_count": torch.tensor(record.point_count, dtype=torch.int64),
                "forward_affine": torch.from_numpy(affine),
                "inverse_affine": torch.from_numpy(
                    np.linalg.inv(affine).astype(np.float32)
                ),
                "context_origin_xy": torch.tensor(
                    [tile.context_x0, tile.context_y0], dtype=torch.float32
                ),
            },
        }


def collate_cru_crops(batch: Sequence[dict[str, Any]]) -> dict[str, Any]:
    if not batch:
        raise ValueError("cannot collate an empty batch")
    return {
        "images": torch.stack([item["image"] for item in batch]),
        "valid_image_masks": torch.stack(
            [item["valid_image_mask"] for item in batch]
        ),
        "targets": [item["target"] for item in batch],
    }


__all__ = ["CRUContextCropDataset", "collate_cru_crops"]
