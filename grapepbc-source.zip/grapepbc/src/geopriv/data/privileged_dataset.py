"""Mixed point/privileged-geometry dataset for GeoPriv training.

GBISC geometry archives contain training-only supervision derived from instance
masks.  Point-only datasets deliberately expose no placeholder radius or
completeness values: ``geometry_available`` is false and the geometry fields
are ``None``.  This makes it difficult for a mixed-domain training loop to
accidentally treat fabricated values as labels.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from pathlib import Path
from types import MappingProxyType
from typing import Any

import numpy as np
from PIL import Image, ImageEnhance, ImageOps
import torch
from torch.utils.data import Dataset

from .geometry import GEOMETRY_SCHEMA_VERSION
from .manifest import read_manifest
from .point_dataset import (
    IMAGENET_MEAN,
    IMAGENET_STD,
    letterbox_image_and_points,
    load_points,
)
from .schema import SampleRecord


# These ids are part of the experiment contract (GeoPrivNet has three domain
# logits).  They must not depend on manifest ordering or on which split is
# selected.  Callers using another dataset must supply an explicit mapping.
DEFAULT_DOMAIN_IDS: Mapping[str, int] = MappingProxyType(
    {"vivid5k": 0, "gbisc": 1, "wgisd": 2}
)

_GEOMETRY_KEYS = {
    "points_xy",
    "equivalent_radius",
    "frame_boundary_completeness",
    "touches_image_boundary",
    "geometry_schema_version",
    "conversion_image_frame_index",
    "conversion_rejects_non_identity_exif_orientation",
    "source_image_width",
    "source_image_height",
}


def _scalar(arrays: Mapping[str, np.ndarray], key: str, path: Path) -> Any:
    value = np.asarray(arrays[key])
    if value.shape != ():
        raise ValueError(f"{path}: {key} must be a scalar, got {value.shape}")
    return value.item()


def _resolve_under_root(root: Path, relative: str, *, kind: str) -> Path:
    candidate = (root / relative).resolve()
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"{kind} path escapes dataset root: {relative!r}") from exc
    if not candidate.is_file():
        raise FileNotFoundError(candidate)
    return candidate


def _validate_domain_ids(values: Mapping[str, int]) -> dict[str, int]:
    result: dict[str, int] = {}
    for dataset_id, domain_id in values.items():
        if not isinstance(dataset_id, str) or not dataset_id:
            raise ValueError("domain-id mapping keys must be non-empty dataset strings")
        if isinstance(domain_id, bool) or not isinstance(domain_id, int) or domain_id < 0:
            raise ValueError("domain ids must be non-negative integers")
        result[dataset_id] = domain_id
    if len(set(result.values())) != len(result):
        raise ValueError("domain ids must be unique")
    return result


def _load_geometry(path: Path, record: SampleRecord) -> dict[str, np.ndarray]:
    if path.suffix.lower() != ".npz":
        raise ValueError(
            f"{record.sample_id}: GBISC privileged geometry must be an NPZ archive"
        )
    with np.load(path, allow_pickle=False) as archive:
        missing = _GEOMETRY_KEYS.difference(archive.files)
        if missing:
            raise ValueError(f"{path}: missing geometry arrays: {sorted(missing)}")
        arrays = {key: np.asarray(archive[key]) for key in _GEOMETRY_KEYS}

    version = int(_scalar(arrays, "geometry_schema_version", path))
    if version != GEOMETRY_SCHEMA_VERSION:
        raise ValueError(
            f"{path}: geometry schema {version} != supported {GEOMETRY_SCHEMA_VERSION}"
        )
    manifest_version = record.extra.get("geometry_schema_version")
    if manifest_version is not None and int(manifest_version) != version:
        raise ValueError(
            f"{record.sample_id}: manifest geometry schema {manifest_version} "
            f"does not match archive schema {version}"
        )
    if int(_scalar(arrays, "conversion_image_frame_index", path)) != 0:
        raise ValueError(f"{path}: geometry must address image frame 0")
    if not bool(
        _scalar(arrays, "conversion_rejects_non_identity_exif_orientation", path)
    ):
        raise ValueError(f"{path}: EXIF coordinate-frame safety policy is missing")
    source_size = (
        int(_scalar(arrays, "source_image_width", path)),
        int(_scalar(arrays, "source_image_height", path)),
    )
    if source_size != (record.width, record.height):
        raise ValueError(
            f"{path}: geometry source size {source_size} does not match manifest "
            f"{(record.width, record.height)}"
        )

    points = np.asarray(arrays["points_xy"], dtype=np.float32)
    radii = np.asarray(arrays["equivalent_radius"], dtype=np.float32)
    completeness = np.asarray(
        arrays["frame_boundary_completeness"], dtype=np.float32
    )
    raw_touches = arrays["touches_image_boundary"]
    if raw_touches.dtype != np.bool_:
        raise ValueError(f"{path}: touches_image_boundary must use boolean dtype")
    touches = np.asarray(raw_touches, dtype=np.bool_)
    count = record.point_count
    expected_shapes = {
        "points_xy": (count, 2),
        "equivalent_radius": (count,),
        "frame_boundary_completeness": (count,),
        "touches_image_boundary": (count,),
    }
    for key, value in (
        ("points_xy", points),
        ("equivalent_radius", radii),
        ("frame_boundary_completeness", completeness),
        ("touches_image_boundary", touches),
    ):
        if value.shape != expected_shapes[key]:
            raise ValueError(
                f"{path}: {key} must have shape {expected_shapes[key]}, got {value.shape}"
            )
    if not np.isfinite(points).all():
        raise ValueError(f"{path}: points_xy contains non-finite values")
    if count and (
        np.any(points[:, 0] < 0)
        or np.any(points[:, 0] >= record.width)
        or np.any(points[:, 1] < 0)
        or np.any(points[:, 1] >= record.height)
    ):
        raise ValueError(f"{path}: points_xy contains out-of-image coordinates")
    if not np.isfinite(radii).all() or np.any(radii <= 0):
        raise ValueError(f"{path}: equivalent_radius must be finite and positive")
    if not np.isfinite(completeness).all() or np.any(
        (completeness < 0) | (completeness > 1)
    ):
        raise ValueError(
            f"{path}: frame_boundary_completeness must lie in [0, 1]"
        )
    if np.any(touches != (completeness < 1.0)):
        raise ValueError(
            f"{path}: touches_image_boundary and completeness are inconsistent"
        )
    return {
        "points_xy": points,
        "equivalent_radius": radii,
        "frame_boundary_completeness": completeness,
        "touches_image_boundary": touches,
    }


def _load_frame_zero(
    path: Path, record: SampleRecord, *, privileged_geometry: bool
) -> Image.Image:
    """Load a detached RGB copy using the adapters' coordinate-frame policy."""

    with Image.open(path) as source:
        source.seek(0)
        orientation_value = source.getexif().get(274)
        orientation = None if orientation_value is None else int(orientation_value)
        if privileged_geometry and orientation not in {None, 0, 1}:
            raise ValueError(
                f"{record.sample_id}: unsupported EXIF Orientation={orientation}; "
                "GBISC geometry uses untransformed frame-0 coordinates"
            )
        if privileged_geometry:
            image = source.convert("RGB").copy()
        else:
            # Point adapters define their dimensions and coordinates after EXIF
            # orientation is applied.
            image = ImageOps.exif_transpose(source).convert("RGB").copy()
    if image.size != (record.width, record.height):
        raise ValueError(
            f"{record.sample_id}: manifest size {(record.width, record.height)} "
            f"does not match decoded frame-0 size {image.size}"
        )
    return image


class PrivilegedManifestDataset(Dataset[dict[str, Any]]):
    """Load point-only and GBISC mask-derived geometry records together."""

    def __init__(
        self,
        manifest: str | Path,
        root: str | Path,
        *,
        split: str | Sequence[str] | None = None,
        image_size: int = 896,
        domain_ids: Mapping[str, int] | None = None,
        max_samples: int | None = None,
        augmentation: bool = False,
        augmentation_seed: int = 0,
        horizontal_flip_probability: float = 0.5,
        color_jitter_probability: float = 0.8,
        brightness_jitter: float = 0.1,
        contrast_jitter: float = 0.1,
        saturation_jitter: float = 0.05,
    ) -> None:
        if image_size <= 0:
            raise ValueError("image_size must be positive")
        if max_samples is not None and max_samples <= 0:
            raise ValueError("max_samples must be positive when provided")
        for name, value in (
            ("horizontal_flip_probability", horizontal_flip_probability),
            ("color_jitter_probability", color_jitter_probability),
        ):
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must lie in [0, 1]")
        for name, value in (
            ("brightness_jitter", brightness_jitter),
            ("contrast_jitter", contrast_jitter),
            ("saturation_jitter", saturation_jitter),
        ):
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must lie in [0, 1]")
        splits = {split} if isinstance(split, str) else set(split or [])
        records = read_manifest(manifest)
        selected = [record for record in records if not splits or record.split in splits]
        if max_samples is not None:
            selected = selected[:max_samples]
        if not selected:
            raise ValueError(f"no records selected from {manifest} for split={split!r}")

        self.domain_ids = _validate_domain_ids(
            DEFAULT_DOMAIN_IDS if domain_ids is None else domain_ids
        )
        unknown = sorted({record.dataset for record in selected}.difference(self.domain_ids))
        if unknown:
            raise ValueError(
                "no stable domain id configured for dataset(s) "
                f"{unknown}; pass domain_ids explicitly"
            )
        self.records = selected
        self.root = Path(root).resolve()
        self.image_size = image_size
        self.augmentation = bool(augmentation)
        self.augmentation_seed = int(augmentation_seed)
        self.horizontal_flip_probability = float(horizontal_flip_probability)
        self.color_jitter_probability = float(color_jitter_probability)
        self.brightness_jitter = float(brightness_jitter)
        self.contrast_jitter = float(contrast_jitter)
        self.saturation_jitter = float(saturation_jitter)
        self._augmentation_epoch = 0

    def set_epoch(self, epoch: int) -> None:
        """Select the deterministic augmentation stream for one training epoch.

        Augmentation randomness is a pure function of ``(seed, epoch, index)``.
        This keeps results reproducible independently of sample order and worker
        scheduling.  Training code must call this before iterating each epoch.
        """

        if epoch < 0:
            raise ValueError("augmentation epoch must be non-negative")
        self._augmentation_epoch = int(epoch)

    def _augmentation_rng(self, index: int) -> np.random.Generator:
        # SeedSequence accepts unsigned entropy.  Masking preserves deterministic
        # behavior for any Python integer supplied through the public API.
        seed = self.augmentation_seed & 0xFFFFFFFF
        return np.random.default_rng(
            np.random.SeedSequence([seed, self._augmentation_epoch, index])
        )

    def _augment_image_and_geometry(
        self,
        image: Image.Image,
        points_xy: np.ndarray,
        valid: np.ndarray,
        affine: np.ndarray,
        *,
        index: int,
    ) -> tuple[Image.Image, np.ndarray, np.ndarray, np.ndarray]:
        """Apply lossless geometry and light photometric training transforms."""

        if not self.augmentation:
            return image, points_xy, valid, affine

        rng = self._augmentation_rng(index)
        if rng.random() < self.color_jitter_probability:
            # A fixed operator order plus seeded factors makes this exactly
            # reproducible.  No geometric labels are affected by these changes.
            factors = (
                (ImageEnhance.Brightness, self.brightness_jitter),
                (ImageEnhance.Contrast, self.contrast_jitter),
                (ImageEnhance.Color, self.saturation_jitter),
            )
            for enhancer, magnitude in factors:
                if magnitude > 0:
                    factor = 1.0 + rng.uniform(-magnitude, magnitude)
                    image = enhancer(image).enhance(float(factor))

        if rng.random() < self.horizontal_flip_probability:
            image = image.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
            valid = np.ascontiguousarray(valid[:, ::-1])
            points_xy = points_xy.copy()
            if len(points_xy):
                points_xy[:, 0] = (self.image_size - 1) - points_xy[:, 0]
            flip = np.array(
                [
                    [-1.0, 0.0, float(self.image_size - 1)],
                    [0.0, 1.0, 0.0],
                    [0.0, 0.0, 1.0],
                ],
                dtype=np.float32,
            )
            affine = flip @ affine

        return image, points_xy, valid, affine

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, index: int) -> dict[str, Any]:
        record = self.records[index]
        if record.points_path is None:
            raise ValueError(f"{record.sample_id} has no point annotations")
        image_path = _resolve_under_root(self.root, record.image_path, kind="image")
        points_path = _resolve_under_root(self.root, record.points_path, kind="points")
        geometry_available = record.dataset == "gbisc"

        if geometry_available:
            labels = _load_geometry(points_path, record)
            points = labels["points_xy"]
        else:
            points = load_points(points_path)
            if len(points) != record.point_count:
                raise ValueError(
                    f"{record.sample_id}: manifest count={record.point_count}, "
                    f"loaded={len(points)}"
                )
            labels = {}

        original = _load_frame_zero(
            image_path, record, privileged_geometry=geometry_available
        )
        image, transformed_points, valid, affine = letterbox_image_and_points(
            original, points, self.image_size
        )
        image, transformed_points, valid, affine = self._augment_image_and_geometry(
            image,
            transformed_points,
            valid,
            affine,
            index=index,
        )
        array = (
            np.asarray(image, dtype=np.float32).transpose(2, 0, 1).copy() / 255.0
        )
        image_tensor = (torch.from_numpy(array) - IMAGENET_MEAN) / IMAGENET_STD
        # The affine may include a reflection after horizontal flipping.  Area
        # scale is positive and yields the original isotropic length scale.
        scale = float(np.sqrt(abs(np.linalg.det(affine[:2, :2]))))

        equivalent_radius = None
        completeness = None
        touches = None
        if geometry_available:
            equivalent_radius = torch.from_numpy(
                (labels["equivalent_radius"] * scale).astype(np.float32, copy=False)
            )
            completeness = torch.from_numpy(
                labels["frame_boundary_completeness"].copy()
            )
            touches = torch.from_numpy(labels["touches_image_boundary"].copy())

        target = {
            "sample_id": record.sample_id,
            "dataset_id": record.dataset,
            "domain_id": torch.tensor(
                self.domain_ids[record.dataset], dtype=torch.int64
            ),
            "source_domain": record.source_domain,
            "points_xy": torch.from_numpy(transformed_points),
            "count": torch.tensor(len(transformed_points), dtype=torch.int64),
            "equivalent_radius": equivalent_radius,
            "frame_boundary_completeness": completeness,
            "touches_image_boundary": touches,
            "geometry_available": geometry_available,
            "orig_size": torch.tensor(
                [record.height, record.width], dtype=torch.int64
            ),
            "input_size": torch.tensor(
                [self.image_size, self.image_size], dtype=torch.int64
            ),
            "forward_affine": torch.from_numpy(affine),
            "inverse_affine": torch.from_numpy(
                np.linalg.inv(affine).astype(np.float32)
            ),
        }
        return {
            "image": image_tensor,
            "valid_image_mask": torch.from_numpy(valid),
            "target": target,
        }


def collate_privileged_samples(batch: Sequence[dict[str, Any]]) -> dict[str, Any]:
    """Collate mixed domains while keeping variable-length labels as a list."""

    if not batch:
        raise ValueError("cannot collate an empty batch")
    targets = [item["target"] for item in batch]
    return {
        "images": torch.stack([item["image"] for item in batch]),
        "valid_image_masks": torch.stack(
            [item["valid_image_mask"] for item in batch]
        ),
        "targets": targets,
        "dataset_ids": [target["dataset_id"] for target in targets],
        "domain_ids": torch.stack([target["domain_id"] for target in targets]),
    }


# A descriptive alias for callers that prefer the project name.
GeoPrivManifestDataset = PrivilegedManifestDataset


__all__ = [
    "DEFAULT_DOMAIN_IDS",
    "GeoPrivManifestDataset",
    "PrivilegedManifestDataset",
    "collate_privileged_samples",
]
