"""Deterministic source-GT training crops, never an inference-time GT policy."""
import math


def complete_context(bounds,image_size,minimum_side=512,context_factor=1.25,alignment=64):
    """Keep all visible components of ONE annotated instance within a crop.

    Bounds use half-open integer raster coordinates. Margin may be clipped at
    the source image edge, but foreground may not be clipped. No GT expansion.
    """
    if len(bounds)!=4 or len(image_size)!=2:raise ValueError('Invalid geometry')
    if any(type(x)is not int for x in (*bounds,*image_size,minimum_side,alignment)):
        raise ValueError('Integer geometry required')
    w,h=image_size;x0,y0,x1,y1=bounds
    if w<=0 or h<=0 or not 0<=x0<x1<=w or not 0<=y0<y1<=h:raise ValueError('Bounds outside source')
    if minimum_side<=0 or alignment<=0 or not math.isfinite(context_factor) or context_factor<1:
        raise ValueError('Invalid context policy')
    side=int(math.ceil(max(minimum_side,max(x1-x0,y1-y0)*context_factor)/alignment)*alignment)
    cw,ch=min(side,w),min(side,h)
    left=max(0,min(int(round((x0+x1-cw)/2)),w-cw))
    top=max(0,min(int(round((y0+y1-ch)/2)),h-ch))
    crop=(left,top,left+cw,top+ch)
    if not(crop[0]<=x0 and crop[1]<=y0 and crop[2]>=x1 and crop[3]>=y1):
        raise AssertionError('Target completeness invariant violated')
    return crop
