"""Stable file and image hashes used to prevent train/test leakage."""

from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps


def file_sha256(path: str | Path, block_size: int = 4 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while block := stream.read(block_size):
            digest.update(block)
    return digest.hexdigest()


def image_dhash64(path: str | Path) -> str:
    """Return a 64-bit difference hash, robust to resizing and mild compression."""

    with Image.open(path) as image:
        gray = ImageOps.exif_transpose(image).convert("L").resize(
            (9, 8), Image.Resampling.LANCZOS
        )
        pixels = np.asarray(gray, dtype=np.int16)
    bits = (pixels[:, 1:] > pixels[:, :-1]).reshape(-1)
    value = 0
    for bit in bits:
        value = (value << 1) | int(bit)
    return f"{value:016x}"


def hamming_distance64(first: str, second: str) -> int:
    if len(first) != 16 or len(second) != 16:
        raise ValueError("both dHash values must contain exactly 16 hexadecimal characters")
    return (int(first, 16) ^ int(second, 16)).bit_count()
