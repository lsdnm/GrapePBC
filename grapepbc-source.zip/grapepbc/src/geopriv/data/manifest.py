"""Read, write, audit and de-duplicate versioned JSONL manifests."""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any, Iterable, Sequence

import numpy as np

from .hash_utils import hamming_distance64
from .schema import SampleRecord


def _load_point_array(path: Path) -> np.ndarray:
    """Load the supported native/canonical point formats for count checks."""

    if path.suffix.lower() == ".npy":
        return np.load(path, allow_pickle=False)
    if path.suffix.lower() == ".npz":
        with np.load(path, allow_pickle=False) as archive:
            if "points_xy" not in archive:
                raise ValueError(f"{path} does not contain points_xy")
            return archive["points_xy"]
    if path.suffix.lower() in {".txt", ".csv"}:
        if path.stat().st_size == 0:
            return np.empty((0, 2), dtype=np.float32)
        delimiter = "," if path.suffix.lower() == ".csv" else None
        return np.loadtxt(path, dtype=np.float32, delimiter=delimiter, ndmin=2)
    raise ValueError(f"unsupported point annotation format: {path.suffix}")


def _meta_path(path: Path) -> Path:
    return path.with_suffix(path.suffix + ".meta.json")


def write_manifest(
    records: Iterable[SampleRecord],
    path: str | Path,
    *,
    metadata: dict[str, Any] | None = None,
) -> int:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    ordered = sorted(records, key=lambda item: item.sample_id)
    seen: set[str] = set()
    with destination.open("w", encoding="utf-8", newline="\n") as stream:
        for record in ordered:
            record.validate()
            if record.sample_id in seen:
                raise ValueError(f"duplicate sample_id while writing: {record.sample_id}")
            seen.add(record.sample_id)
            stream.write(json.dumps(record.to_dict(), ensure_ascii=False, sort_keys=True) + "\n")
    companion = {
        "schema_version": 1,
        "record_count": len(ordered),
        **(metadata or {}),
    }
    _meta_path(destination).write_text(
        json.dumps(companion, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return len(ordered)


def read_manifest(path: str | Path) -> list[SampleRecord]:
    records: list[SampleRecord] = []
    with Path(path).open("r", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, start=1):
            if not line.strip():
                continue
            try:
                records.append(SampleRecord.from_dict(json.loads(line)))
            except Exception as exc:
                raise ValueError(f"invalid manifest line {line_number}: {exc}") from exc
    return records


def _groups(values: dict[str, list[str]]) -> list[dict[str, Any]]:
    return [
        {"key": key, "sample_ids": sorted(sample_ids), "size": len(sample_ids)}
        for key, sample_ids in sorted(values.items())
        if len(sample_ids) > 1
    ]


def find_near_duplicate_groups(
    records: Sequence[SampleRecord], threshold: int = 4
) -> list[dict[str, Any]]:
    """Cluster perceptual hashes using union-find.

    O(n^2) is deliberate for auditable datasets of a few thousand images. Exact
    duplicates are represented by the same group as their perceptual hash.
    """

    if threshold < 0 or threshold > 64:
        raise ValueError("threshold must lie in [0, 64]")
    count = len(records)
    parents = list(range(count))

    def find(index: int) -> int:
        while parents[index] != index:
            parents[index] = parents[parents[index]]
            index = parents[index]
        return index

    def union(first: int, second: int) -> None:
        root_first, root_second = find(first), find(second)
        if root_first != root_second:
            parents[root_second] = root_first

    for first in range(count):
        for second in range(first + 1, count):
            if hamming_distance64(records[first].dhash64, records[second].dhash64) <= threshold:
                union(first, second)

    components: dict[int, list[str]] = defaultdict(list)
    for index, record in enumerate(records):
        components[find(index)].append(record.sample_id)
    return [
        {"group_id": f"near-{number:05d}", "sample_ids": sorted(ids), "size": len(ids)}
        for number, ids in enumerate(
            sorted((ids for ids in components.values() if len(ids) > 1), key=lambda x: x[0]),
            start=1,
        )
    ]


def audit_manifest(
    records: Sequence[SampleRecord],
    *,
    root: str | Path | None = None,
    verify_point_arrays: bool = True,
    near_duplicate_threshold: int = 4,
) -> dict[str, Any]:
    root_path = Path(root).resolve() if root is not None else None
    ids = Counter(record.sample_id for record in records)
    exact: dict[str, list[str]] = defaultdict(list)
    perceptual: dict[str, list[str]] = defaultdict(list)
    missing_files: list[dict[str, str]] = []
    annotation_mismatches: list[dict[str, Any]] = []
    invalid_paths: list[dict[str, str]] = []

    for record in records:
        record.validate()
        exact[record.sha256].append(record.sample_id)
        perceptual[record.dhash64].append(record.sample_id)
        if root_path is None:
            continue
        for kind, relative in (
            ("image", record.image_path),
            ("points", record.points_path),
            ("instances", record.instances_path),
        ):
            if relative is None:
                continue
            candidate = (root_path / relative).resolve()
            try:
                candidate.relative_to(root_path)
            except ValueError:
                invalid_paths.append({"sample_id": record.sample_id, "kind": kind, "path": relative})
                continue
            if not candidate.is_file():
                missing_files.append({"sample_id": record.sample_id, "kind": kind, "path": relative})
        if verify_point_arrays and record.points_path is not None:
            point_file = (root_path / record.points_path).resolve()
            if point_file.is_file():
                points = _load_point_array(point_file)
                valid_shape = points.ndim == 2 and points.shape[1] == 2
                if not valid_shape or len(points) != record.point_count:
                    annotation_mismatches.append(
                        {
                            "sample_id": record.sample_id,
                            "expected": record.point_count,
                            "actual": int(len(points)) if points.ndim else 0,
                            "shape": list(points.shape),
                        }
                    )

    split_counts = Counter(record.split for record in records)
    dataset_counts = Counter(record.dataset for record in records)
    point_counts = [record.point_count for record in records]
    leakage_pairs = []
    for group in _groups(exact):
        grouped_records = [record for record in records if record.sample_id in group["sample_ids"]]
        splits = sorted({record.split for record in grouped_records})
        datasets = sorted({record.dataset for record in grouped_records})
        if len(splits) > 1 or len(datasets) > 1:
            leakage_pairs.append({**group, "splits": splits, "datasets": datasets})

    return {
        "schema_version": 1,
        "record_count": len(records),
        "dataset_counts": dict(sorted(dataset_counts.items())),
        "split_counts": dict(sorted(split_counts.items())),
        "total_points": int(sum(point_counts)),
        "point_count_min": int(min(point_counts)) if point_counts else None,
        "point_count_max": int(max(point_counts)) if point_counts else None,
        "point_count_mean": float(sum(point_counts) / len(point_counts)) if point_counts else None,
        "duplicate_sample_ids": sorted(key for key, value in ids.items() if value > 1),
        "exact_duplicate_groups": _groups(exact),
        "identical_dhash_groups": _groups(perceptual),
        "near_duplicate_threshold": near_duplicate_threshold,
        "near_duplicate_groups": find_near_duplicate_groups(records, near_duplicate_threshold),
        "cross_split_or_dataset_exact_duplicates": leakage_pairs,
        "missing_files": missing_files,
        "invalid_paths": invalid_paths,
        "annotation_mismatches": annotation_mismatches,
        "ok": not (
            any(value > 1 for value in ids.values())
            or missing_files
            or invalid_paths
            or annotation_mismatches
            or leakage_pairs
        ),
    }


@dataclass(slots=True)
class DeduplicationResult:
    kept: list[SampleRecord]
    excluded: list[dict[str, Any]]
    groups: list[dict[str, Any]]


def deduplicate_records(
    records: Sequence[SampleRecord],
    *,
    near_duplicate_threshold: int = 4,
    protected_splits: set[str] | None = None,
) -> DeduplicationResult:
    """Select one canonical record per near-duplicate group.

    External-test records and protected splits win over training records. This
    makes leakage removal deterministic and prevents a training copy from
    displacing an evaluation sample.
    """

    protected = protected_splits or {"test"}
    groups = find_near_duplicate_groups(records, near_duplicate_threshold)
    by_id = {record.sample_id: record for record in records}
    excluded_ids: set[str] = set()
    exclusions: list[dict[str, Any]] = []

    def rank(record: SampleRecord) -> tuple[int, int, str]:
        return (
            0 if record.external_test else 1,
            0 if record.split in protected else 1,
            record.sample_id,
        )

    for group in groups:
        members = [by_id[sample_id] for sample_id in group["sample_ids"]]
        canonical = min(members, key=rank)
        group["canonical_id"] = canonical.sample_id
        for record in members:
            if record.sample_id == canonical.sample_id:
                continue
            excluded_ids.add(record.sample_id)
            exclusions.append(
                {
                    "sample_id": record.sample_id,
                    "canonical_id": canonical.sample_id,
                    "group_id": group["group_id"],
                    "reason": "near_duplicate",
                }
            )
    kept = [record for record in records if record.sample_id not in excluded_ids]
    return DeduplicationResult(kept=kept, excluded=exclusions, groups=groups)
