"""Dataset schemas, adapters and integrity checks."""

from .archive_ingest import (
    GBISC_OFFICIAL_ARCHIVE_BYTES,
    ArchiveValidationError,
    ExistingFileConflictError,
    ingest_gbisc_archive,
    inspect_archive,
)
from .cru_crop_dataset import CRUContextCropDataset, collate_cru_crops
from .geometry import GEOMETRY_SCHEMA_VERSION, InstanceGeometry, extract_polygon_geometry
from .manifest import audit_manifest, read_manifest, write_manifest
from .point_dataset import PointManifestDataset, collate_point_samples
from .privileged_dataset import (
    DEFAULT_DOMAIN_IDS,
    GeoPrivManifestDataset,
    PrivilegedManifestDataset,
    collate_privileged_samples,
)
from .schema import SampleRecord

__all__ = [
    "GEOMETRY_SCHEMA_VERSION",
    "GBISC_OFFICIAL_ARCHIVE_BYTES",
    "ArchiveValidationError",
    "ExistingFileConflictError",
    "CRUContextCropDataset",
    "InstanceGeometry",
    "SampleRecord",
    "PointManifestDataset",
    "PrivilegedManifestDataset",
    "GeoPrivManifestDataset",
    "DEFAULT_DOMAIN_IDS",
    "collate_point_samples",
    "collate_cru_crops",
    "collate_privileged_samples",
    "audit_manifest",
    "extract_polygon_geometry",
    "ingest_gbisc_archive",
    "inspect_archive",
    "read_manifest",
    "write_manifest",
]
