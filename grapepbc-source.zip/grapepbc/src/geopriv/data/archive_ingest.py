"""Safe, reproducible ingestion of the locally supplied GBISC archive.

The public GBISC archive is intentionally not downloaded by this module.  The
caller supplies a local ZIP file, which is fully inventoried before any member
is written.  In particular, ZIP paths are interpreted using Windows as well as
POSIX path rules so that an archive audited on one platform is not unsafe on
another one.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
from typing import BinaryIO
import zipfile


GBISC_OFFICIAL_ARCHIVE_BYTES = 710_020_895
DEFAULT_MAX_EXPANDED_BYTES = 8 * 1024**3
DEFAULT_MAX_MEMBER_BYTES = 2 * 1024**3
DEFAULT_MAX_FILES = 100_000
DEFAULT_MAX_COMPRESSION_RATIO = 1_000.0
PROVENANCE_FILENAME = "geopriv_archive.json"

_WINDOWS_RESERVED_NAMES = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    *(f"COM{number}" for number in range(1, 10)),
    *(f"LPT{number}" for number in range(1, 10)),
}
_WINDOWS_INVALID_CHARS = set('<>:"|?*')


class ArchiveValidationError(ValueError):
    """Raised before extraction when an archive violates an ingestion rule."""


class ExistingFileConflictError(FileExistsError):
    """Raised when extraction would replace a different existing file."""


@dataclass(frozen=True)
class ArchiveMemberPlan:
    """A validated source member and its normalized relative destination."""

    source_name: str
    destination: str
    file_size: int
    compressed_size: int
    crc32: int
    is_directory: bool


@dataclass(frozen=True)
class ArchiveInventory:
    """Audited archive metadata used by the extraction pass."""

    members: tuple[ArchiveMemberPlan, ...]
    wrapper_stripped: bool
    file_count: int
    directory_count: int
    expanded_bytes: int
    compressed_member_bytes: int


@dataclass(frozen=True)
class IngestSummary:
    """Stable facts recorded after successful ingestion."""

    archive_path: str
    archive_filename: str
    archive_size_bytes: int
    expected_archive_size_bytes: int
    archive_size_matches_expected: bool
    allow_size_mismatch: bool
    archive_sha256: str
    destination: str
    wrapper_stripped: bool
    member_count: int
    file_count: int
    directory_count: int
    expanded_bytes: int
    compressed_member_bytes: int
    extracted_file_count: int
    reused_identical_file_count: int
    provenance_path: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _sha256_stream(stream: BinaryIO, block_size: int = 4 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    while block := stream.read(block_size):
        digest.update(block)
    return digest.hexdigest()


def _file_sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return _sha256_stream(stream)


def _validated_parts(raw_name: str) -> tuple[str, ...]:
    if not raw_name or "\x00" in raw_name:
        raise ArchiveValidationError("ZIP member has an empty name or contains NUL")
    # ZIP uses '/', but backslashes become separators during extraction on
    # Windows.  Normalize both before checking traversal and absolute paths.
    if raw_name.startswith(("/", "\\")) or re.match(r"^[A-Za-z]:", raw_name):
        raise ArchiveValidationError(f"absolute ZIP member path is forbidden: {raw_name!r}")
    normalized = raw_name.replace("\\", "/")
    if normalized.startswith("//"):
        raise ArchiveValidationError(f"UNC ZIP member path is forbidden: {raw_name!r}")
    parts = PurePosixPath(normalized).parts
    if not parts:
        raise ArchiveValidationError(f"ZIP member has no usable path: {raw_name!r}")
    if len(parts) > 32:
        raise ArchiveValidationError(f"ZIP member path is too deep: {raw_name!r}")
    for component in parts:
        if component in {"", ".", ".."}:
            raise ArchiveValidationError(
                f"ambiguous or traversing ZIP member path is forbidden: {raw_name!r}"
            )
        if len(component) > 255:
            raise ArchiveValidationError(f"ZIP path component is too long: {raw_name!r}")
        if any(character in _WINDOWS_INVALID_CHARS for character in component):
            raise ArchiveValidationError(
                f"ZIP member contains a Windows-invalid character: {raw_name!r}"
            )
        if component.endswith((" ", ".")):
            raise ArchiveValidationError(
                f"ZIP member has a Windows-ambiguous component: {raw_name!r}"
            )
        stem = component.split(".", 1)[0].upper()
        if stem in _WINDOWS_RESERVED_NAMES:
            raise ArchiveValidationError(
                f"ZIP member uses a reserved Windows name: {raw_name!r}"
            )
    return tuple(parts)


def _is_forbidden_special_file(info: zipfile.ZipInfo) -> bool:
    if info.create_system != 3:
        return False
    file_type = stat.S_IFMT(info.external_attr >> 16)
    return file_type not in {0, stat.S_IFREG, stat.S_IFDIR}


def inspect_archive(
    archive: str | Path,
    *,
    max_expanded_bytes: int = DEFAULT_MAX_EXPANDED_BYTES,
    max_member_bytes: int = DEFAULT_MAX_MEMBER_BYTES,
    max_files: int = DEFAULT_MAX_FILES,
    max_compression_ratio: float = DEFAULT_MAX_COMPRESSION_RATIO,
) -> ArchiveInventory:
    """Inventory and validate every member without writing to disk."""

    archive_path = Path(archive)
    try:
        with zipfile.ZipFile(archive_path, "r") as bundle:
            infos = bundle.infolist()
    except (OSError, zipfile.BadZipFile) as exc:
        raise ArchiveValidationError(f"invalid or unreadable ZIP archive: {exc}") from exc

    if len(infos) > max_files:
        raise ArchiveValidationError(
            f"archive has {len(infos)} members; limit is {max_files}"
        )

    parsed: list[tuple[zipfile.ZipInfo, tuple[str, ...]]] = []
    expanded_bytes = 0
    compressed_bytes = 0
    file_count = 0
    for info in infos:
        parts = _validated_parts(info.filename)
        if info.flag_bits & 0x1:
            raise ArchiveValidationError(
                f"encrypted ZIP members are unsupported: {info.filename!r}"
            )
        if _is_forbidden_special_file(info):
            raise ArchiveValidationError(
                f"links and special files are forbidden: {info.filename!r}"
            )
        if info.file_size < 0 or info.compress_size < 0:
            raise ArchiveValidationError(f"negative member size: {info.filename!r}")
        if info.file_size > max_member_bytes:
            raise ArchiveValidationError(
                f"member expands to {info.file_size} bytes, above the "
                f"{max_member_bytes}-byte limit: {info.filename!r}"
            )
        if not info.is_dir():
            file_count += 1
            expanded_bytes += info.file_size
            compressed_bytes += info.compress_size
            if expanded_bytes > max_expanded_bytes:
                raise ArchiveValidationError(
                    f"archive expands beyond the {max_expanded_bytes}-byte limit"
                )
            if info.file_size:
                ratio = (
                    float("inf")
                    if info.compress_size == 0
                    else info.file_size / info.compress_size
                )
                if ratio > max_compression_ratio:
                    raise ArchiveValidationError(
                        f"member compression ratio {ratio:.1f} exceeds the "
                        f"{max_compression_ratio:.1f} limit: {info.filename!r}"
                    )
        parsed.append((info, parts))

    # The official ZIP may contain a single GBISC/ wrapper.  Strip it only
    # when every non-directory member is below that wrapper; mixed layouts are
    # preserved, never guessed.
    file_parts = [parts for info, parts in parsed if not info.is_dir()]
    wrapper_stripped = bool(file_parts) and all(
        len(parts) >= 2 and parts[0].casefold() == "gbisc" for parts in file_parts
    )

    plans: list[ArchiveMemberPlan] = []
    destinations: dict[str, str] = {}
    for info, parts in parsed:
        mapped_parts = parts[1:] if wrapper_stripped and parts[0].casefold() == "gbisc" else parts
        if not mapped_parts:
            # This is the top-level GBISC/ directory itself.
            continue
        relative = PurePosixPath(*mapped_parts).as_posix()
        if relative.casefold() == PROVENANCE_FILENAME.casefold():
            raise ArchiveValidationError(
                f"ZIP member collides with the reserved provenance file: {info.filename!r}"
            )
        collision_key = relative.casefold()
        previous = destinations.get(collision_key)
        if previous is not None:
            raise ArchiveValidationError(
                f"multiple ZIP members map to the same destination: "
                f"{previous!r} and {info.filename!r}"
            )
        destinations[collision_key] = info.filename
        plans.append(
            ArchiveMemberPlan(
                source_name=info.filename,
                destination=relative,
                file_size=info.file_size,
                compressed_size=info.compress_size,
                crc32=info.CRC,
                is_directory=info.is_dir(),
            )
        )

    # Also reject a file used as the parent of another member (for example,
    # both ``images`` and ``images/a.jpg``).  Such archives otherwise become
    # extraction-order dependent.
    plan_by_key = {plan.destination.casefold(): plan for plan in plans}
    for plan in plans:
        components = PurePosixPath(plan.destination).parts
        for depth in range(1, len(components)):
            parent_key = PurePosixPath(*components[:depth]).as_posix().casefold()
            parent_plan = plan_by_key.get(parent_key)
            if parent_plan is not None and not parent_plan.is_directory:
                raise ArchiveValidationError(
                    f"ZIP file is also used as a directory: {parent_plan.source_name!r}"
                )

    return ArchiveInventory(
        members=tuple(plans),
        wrapper_stripped=wrapper_stripped,
        file_count=file_count,
        directory_count=sum(plan.is_directory for plan in plans),
        expanded_bytes=expanded_bytes,
        compressed_member_bytes=compressed_bytes,
    )


def _assert_contained(target: Path, destination: Path) -> None:
    try:
        target.resolve(strict=False).relative_to(destination.resolve(strict=False))
    except ValueError as exc:
        raise ArchiveValidationError(
            f"normalized member escapes destination: {target}"
        ) from exc


def _assert_no_symlink_parents(target: Path, destination: Path) -> None:
    current = target.parent
    root = destination.resolve(strict=False)
    while current != root:
        try:
            current.relative_to(root)
        except ValueError as exc:
            raise ArchiveValidationError(
                f"destination parent escaped root: {target}"
            ) from exc
        if current.exists() and current.is_symlink():
            raise ArchiveValidationError(
                f"destination contains a symlinked parent: {current}"
            )
        parent = current.parent
        if parent == current:
            raise ArchiveValidationError(f"destination parent escaped root: {target}")
        current = parent


def _member_sha256(bundle: zipfile.ZipFile, source_name: str) -> str:
    with bundle.open(source_name, "r") as source:
        return _sha256_stream(source)


def _preflight_existing_files(
    bundle: zipfile.ZipFile,
    inventory: ArchiveInventory,
    destination: Path,
) -> set[str]:
    identical: set[str] = set()
    for member in inventory.members:
        target = destination / Path(member.destination)
        _assert_contained(target, destination)
        _assert_no_symlink_parents(target, destination)
        if member.is_directory:
            if target.exists() and (target.is_symlink() or not target.is_dir()):
                raise ExistingFileConflictError(
                    f"archive directory conflicts with existing file: {target}"
                )
            continue
        if not target.exists():
            continue
        if not target.is_file() or target.is_symlink():
            raise ExistingFileConflictError(
                f"archive file conflicts with non-regular destination: {target}"
            )
        if target.stat().st_size != member.file_size:
            raise ExistingFileConflictError(
                f"refusing to overwrite different existing file: {target}"
            )
        if _file_sha256(target) != _member_sha256(bundle, member.source_name):
            raise ExistingFileConflictError(
                f"refusing to overwrite different existing file: {target}"
            )
        identical.add(member.destination)
    return identical


def _write_member_exclusive(
    bundle: zipfile.ZipFile,
    member: ArchiveMemberPlan,
    target: Path,
    destination: Path,
) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    _assert_contained(target, destination)
    _assert_no_symlink_parents(target, destination)
    # 'xb' guarantees that a file appearing after preflight is never replaced.
    created_by_us = False
    try:
        with bundle.open(member.source_name, "r") as source:
            with target.open("xb") as sink:
                created_by_us = True
                while block := source.read(4 * 1024 * 1024):
                    sink.write(block)
    except Exception:
        if created_by_us and target.exists() and target.is_file():
            target.unlink()
        raise
    if target.stat().st_size != member.file_size:
        target.unlink()
        raise ArchiveValidationError(
            f"extracted size mismatch for {member.source_name!r}"
        )


def ingest_gbisc_archive(
    archive: str | Path,
    destination: str | Path,
    *,
    allow_size_mismatch: bool = False,
    expected_archive_bytes: int = GBISC_OFFICIAL_ARCHIVE_BYTES,
    max_expanded_bytes: int = DEFAULT_MAX_EXPANDED_BYTES,
    max_member_bytes: int = DEFAULT_MAX_MEMBER_BYTES,
    max_files: int = DEFAULT_MAX_FILES,
    max_compression_ratio: float = DEFAULT_MAX_COMPRESSION_RATIO,
) -> IngestSummary:
    """Validate and extract a local GBISC ZIP without replacing user data."""

    archive_path = Path(archive).resolve(strict=True)
    if not archive_path.is_file():
        raise ArchiveValidationError(f"archive is not a regular file: {archive_path}")
    archive_size = archive_path.stat().st_size
    size_matches = archive_size == expected_archive_bytes
    if not size_matches and not allow_size_mismatch:
        raise ArchiveValidationError(
            f"GBISC archive must be exactly {expected_archive_bytes} bytes; "
            f"got {archive_size}. Re-run with --allow-size-mismatch only for a "
            "known test fixture or a deliberately audited future release."
        )
    archive_sha256 = _file_sha256(archive_path)
    inventory = inspect_archive(
        archive_path,
        max_expanded_bytes=max_expanded_bytes,
        max_member_bytes=max_member_bytes,
        max_files=max_files,
        max_compression_ratio=max_compression_ratio,
    )

    destination_path = Path(destination).resolve(strict=False)
    if destination_path.exists() and not destination_path.is_dir():
        raise ExistingFileConflictError(
            f"destination exists and is not a directory: {destination_path}"
        )
    provenance_path = destination_path / PROVENANCE_FILENAME

    with zipfile.ZipFile(archive_path, "r") as bundle:
        try:
            bad_member = bundle.testzip()
        except (OSError, RuntimeError, zipfile.BadZipFile) as exc:
            raise ArchiveValidationError(
                f"archive member CRC/decompression validation failed: {exc}"
            ) from exc
        if bad_member is not None:
            raise ArchiveValidationError(
                f"archive member failed CRC validation: {bad_member!r}"
            )
        identical = _preflight_existing_files(bundle, inventory, destination_path)

        if provenance_path.exists():
            if provenance_path.is_symlink() or not provenance_path.is_file():
                raise ExistingFileConflictError(
                    f"provenance path is not a regular file: {provenance_path}"
                )
            try:
                previous = json.loads(provenance_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                raise ExistingFileConflictError(
                    f"existing provenance is unreadable: {provenance_path}"
                ) from exc
            if (
                previous.get("archive_sha256") != archive_sha256
                or previous.get("archive_size_bytes") != archive_size
            ):
                raise ExistingFileConflictError(
                    f"refusing to overwrite provenance from another archive: {provenance_path}"
                )

        # All archive paths and all pre-existing targets have now been checked.
        destination_path.mkdir(parents=True, exist_ok=True)
        extracted = 0
        for member in inventory.members:
            target = destination_path / Path(member.destination)
            if member.is_directory:
                target.mkdir(parents=True, exist_ok=True)
                if target.is_symlink():
                    raise ExistingFileConflictError(
                        f"archive directory resolved to a symlink: {target}"
                    )
            elif member.destination not in identical:
                _write_member_exclusive(bundle, member, target, destination_path)
                extracted += 1

    summary = IngestSummary(
        archive_path=str(archive_path),
        archive_filename=archive_path.name,
        archive_size_bytes=archive_size,
        expected_archive_size_bytes=expected_archive_bytes,
        archive_size_matches_expected=size_matches,
        allow_size_mismatch=allow_size_mismatch,
        archive_sha256=archive_sha256,
        destination=str(destination_path),
        wrapper_stripped=inventory.wrapper_stripped,
        member_count=len(inventory.members),
        file_count=inventory.file_count,
        directory_count=inventory.directory_count,
        expanded_bytes=inventory.expanded_bytes,
        compressed_member_bytes=inventory.compressed_member_bytes,
        extracted_file_count=extracted,
        reused_identical_file_count=len(identical),
        provenance_path=str(provenance_path),
    )
    if not provenance_path.exists():
        payload = {
            **summary.to_dict(),
            "dataset": "GBISC",
            "source_repository": "https://github.com/volcanoYcc/Mask-GK",
            "ingested_at_utc": datetime.now(timezone.utc).isoformat(),
            "archive_members": [asdict(member) for member in inventory.members],
            "safety_policy": {
                "max_expanded_bytes": max_expanded_bytes,
                "max_member_bytes": max_member_bytes,
                "max_files": max_files,
                "max_compression_ratio": max_compression_ratio,
                "different_existing_files_overwritten": False,
            },
        }
        provenance_created = False
        try:
            with provenance_path.open("x", encoding="utf-8") as stream:
                provenance_created = True
                json.dump(payload, stream, ensure_ascii=False, indent=2, sort_keys=True)
                stream.write("\n")
        except Exception:
            if provenance_created and provenance_path.exists():
                provenance_path.unlink()
            raise
    return summary
