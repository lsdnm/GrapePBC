"""Opt-in fixed-scale virtual windows; never stretch a clipped edge crop."""
import numpy as np
from PIL import Image
import torch

from .cru_crop_dataset import CRUContextCropDataset
from .point_dataset import IMAGENET_MEAN,IMAGENET_STD,letterbox_image_and_points


class FixedContextCropDataset(CRUContextCropDataset):
    def __getitem__(self,index):
        record_index,tile=self.items[index]
        record=self.records[record_index]
        source,points=self._load_source(record_index)
        extent=self.core_size+2*self.halo
        ox,oy=tile.core_x0-self.halo,tile.core_y0-self.halo
        x0,y0=max(0,ox),max(0,oy)
        x1,y1=min(record.width,ox+extent),min(record.height,oy+extent)
        canvas=Image.new('RGB',(extent,extent),(114,114,114))
        canvas.paste(source.crop((x0,y0,x1,y1)),(x0-ox,y0-oy))
        native_valid=np.zeros((extent,extent),np.uint8)
        native_valid[y0-oy:y1-oy,x0-ox:x1-ox]=1
        context=(points[:,0]>=x0)&(points[:,0]<x1)&(points[:,1]>=y0)&(points[:,1]<y1)
        raw=points[context]
        local=raw-np.array([ox,oy],np.float32)
        image,transformed,_,affine=letterbox_image_and_points(canvas,local,self.image_size)
        valid=np.asarray(Image.fromarray(native_valid).resize((self.image_size,self.image_size),Image.Resampling.NEAREST)).astype(bool)
        owned=(raw[:,0]>=tile.core_x0)&(raw[:,0]<tile.core_x1)&(raw[:,1]>=tile.core_y0)&(raw[:,1]<tile.core_y1)
        corners=np.array([[tile.core_x0-ox,tile.core_y0-oy,1],
                          [tile.core_x1-ox,tile.core_y1-oy,1]],np.float32)
        corners=(affine@corners.T).T[:,:2]
        array=np.asarray(image,np.float32).transpose(2,0,1).copy()/255
        return dict(image=(torch.from_numpy(array)-IMAGENET_MEAN)/IMAGENET_STD,
            valid_image_mask=torch.from_numpy(valid),target=dict(sample_id=record.sample_id,tile_id=tile.tile_id,
            points_xy=torch.from_numpy(transformed),core_points_xy=torch.from_numpy(transformed[owned].copy()),
            core_bounds_xyxy=torch.from_numpy(corners.reshape(-1)),
            context_count=torch.tensor(len(raw)),core_count=torch.tensor(int(owned.sum())),source_count=torch.tensor(record.point_count),
            forward_affine=torch.from_numpy(affine),inverse_affine=torch.from_numpy(np.linalg.inv(affine).astype(np.float32)),
            context_origin_xy=torch.tensor([ox,oy],dtype=torch.float32)))
