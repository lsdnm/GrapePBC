"""Aspect-preserving image/point loading for point-count training."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Sequence

import numpy as np
from PIL import Image, ImageOps
import torch
from torch import Tensor
from torch.utils.data import Dataset

from .manifest import read_manifest
from .schema import SampleRecord


IMAGENET_MEAN = torch.tensor([0.485, 0.456, 0.406])[:, None, None]
IMAGENET_STD = torch.tensor([0.229, 0.224, 0.225])[:, None, None]


def load_points(path: str | Path) -> np.ndarray:
    source = Path(path)
    suffix = source.suffix.lower()
    if suffix == ".npy":
        points = np.load(source, allow_pickle=False)
    elif suffix == ".npz":
        with np.load(source, allow_pickle=False) as archive:
            points = archive["points_xy"]
    elif suffix in {".txt", ".csv"}:
        if source.stat().st_size == 0:
            points = np.empty((0, 2), dtype=np.float32)
        else:
            points = np.loadtxt(
                source,
                dtype=np.float32,
                delimiter="," if suffix == ".csv" else None,
                ndmin=2,
            )
    else:
        raise ValueError(f"unsupported point format: {source}")
    points = np.asarray(points, dtype=np.float32)
    if points.ndim != 2 or points.shape[1] != 2:
        raise ValueError(f"points must have shape (N, 2), got {points.shape} from {source}")
    return points


def letterbox_image_and_points(
    image: Image.Image,
    points_xy: np.ndarray,
    size: int,
    *,
    fill: tuple[int, int, int] = (114, 114, 114),
) -> tuple[Image.Image, np.ndarray, np.ndarray, np.ndarray]:
    """Resize into a square and return points, valid mask and affine matrix."""

    if size <= 0:
        raise ValueError("size must be positive")
    image = image.convert("RGB")
    width, height = image.size
    scale = min(size / width, size / height)
    resized_width = max(1, round(width * scale))
    resized_height = max(1, round(height * scale))
    left = (size - resized_width) // 2
    top = (size - resized_height) // 2
    resized = image.resize((resized_width, resized_height), Image.Resampling.BILINEAR)
    canvas = Image.new("RGB", (size, size), fill)
    canvas.paste(resized, (left, top))
    valid = np.zeros((size, size), dtype=np.bool_)
    valid[top : top + resized_height, left : left + resized_width] = True
    transformed = np.asarray(points_xy, dtype=np.float32).copy()
    if len(transformed):
        transformed[:, 0] = transformed[:, 0] * scale + left
        transformed[:, 1] = transformed[:, 1] * scale + top
    affine = np.array(
        [[scale, 0.0, float(left)], [0.0, scale, float(top)], [0.0, 0.0, 1.0]],
        dtype=np.float32,
    )
    return canvas, transformed, valid, affine


class PointManifestDataset(Dataset[dict[str, Any]]):
    def __init__(
        self,
        manifest: str | Path,
        root: str | Path,
        *,
        split: str | Sequence[str] | None = None,
        image_size: int = 896,
    ) -> None:
        splits = {split} if isinstance(split, str) else set(split or [])
        records = read_manifest(manifest)
        self.records = [record for record in records if not splits or record.split in splits]
        if not self.records:
            raise ValueError(f"no records selected from {manifest} for split={split!r}")
        self.root = Path(root).resolve()
        self.image_size = image_size

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, index: int) -> dict[str, Any]:
        record = self.records[index]
        if record.points_path is None:
            raise ValueError(f"{record.sample_id} has no point annotations")
        image_path = (self.root / record.image_path).resolve()
        points_path = (self.root / record.points_path).resolve()
        with Image.open(image_path) as source:
            # Adapters validate dimensions after EXIF orientation is applied;
            # training must use the same pixel orientation as the annotations.
            original = ImageOps.exif_transpose(source).convert("RGB")
        points = load_points(points_path)
        if len(points) != record.point_count:
            raise ValueError(
                f"{record.sample_id}: manifest count={record.point_count}, loaded={len(points)}"
            )
        image, points, valid, affine = letterbox_image_and_points(
            original, points, self.image_size
        )
        array = np.asarray(image, dtype=np.float32).transpose(2, 0, 1) / 255.0
        tensor = (torch.from_numpy(array) - IMAGENET_MEAN) / IMAGENET_STD
        return {
            "image": tensor,
            "valid_image_mask": torch.from_numpy(valid),
            "target": {
                "sample_id": record.sample_id,
                "points_xy": torch.from_numpy(points),
                "count": torch.tensor(len(points), dtype=torch.int64),
                "orig_size": torch.tensor([record.height, record.width], dtype=torch.int64),
                "input_size": torch.tensor([self.image_size, self.image_size], dtype=torch.int64),
                "forward_affine": torch.from_numpy(affine),
                "inverse_affine": torch.from_numpy(np.linalg.inv(affine).astype(np.float32)),
            },
        }


def collate_point_samples(batch: Sequence[dict[str, Any]]) -> dict[str, Any]:
    return {
        "images": torch.stack([item["image"] for item in batch]),
        "valid_image_masks": torch.stack([item["valid_image_mask"] for item in batch]),
        "targets": [item["target"] for item in batch],
    }
