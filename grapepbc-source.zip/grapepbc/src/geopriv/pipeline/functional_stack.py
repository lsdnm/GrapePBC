"""Version-free names and artifact-backed assembly for the CRU pipeline.

Experiment folders keep their historical names so published hashes and frozen
evidence remain reproducible.  Runtime code and user-facing output, however,
refer to components by what they do:

* CPCR -- Count-Preserving Centre Refinement;
* APIC -- Adaptive Point-Integrity Correction.

The frozen point-integrity stack loads the already accepted APIC point set.
That point set is the output of CPCR followed by APIC; it is not recomputed
from annotations at inference time.  Bounds, count and duplicate invariants are
checked every time it is loaded.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path
from typing import Iterable

import numpy as np


@dataclass(frozen=True, slots=True)
class FunctionalStage:
    code: str
    name_zh: str
    name_en: str
    responsibility: str

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


LOW_RESOLUTION = FunctionalStage(
    "LR",
    "低分辨率全图计数",
    "Low-Resolution Whole-Image Counting",
    "生成全图初始果粒中心、置信度、密度图和区域可观测特征。",
)
ADAPTIVE_HIGH_RESOLUTION = FunctionalStage(
    "AHR",
    "自适应高分辨率专家",
    "Adaptive High-Resolution Expert",
    "按图像难度与区域效用决定高分辨率调用位置和次数。",
)
COUNT_FUSION = FunctionalStage(
    "CCF",
    "计数守恒融合",
    "Count-Conserving Fusion",
    "以非重叠核心区所有权融合LR和HR结果，并保持整数计数可追溯。",
)
CPCR = FunctionalStage(
    "CPCR",
    "计数守恒中心细化",
    "Count-Preserving Centre Refinement",
    "在不改变果粒数和点顺序的前提下，使中心点更接近果粒中心。",
)
BUNCH_ASSIGNMENT = FunctionalStage(
    "BBA",
    "果穗框选与唯一归属",
    "Bunch-Box Assignment",
    "生成果穗矩形框，并把每个果粒中心唯一归入一个果穗。",
)
APIC = FunctionalStage(
    "APIC",
    "自适应单果单点校正",
    "Adaptive Point-Integrity Correction",
    "依据局部尺度、候选中心和同穗约束合并可信重复点。",
)

COMPLETE_STAGE_ORDER = (
    LOW_RESOLUTION,
    ADAPTIVE_HIGH_RESOLUTION,
    COUNT_FUSION,
    CPCR,
    BUNCH_ASSIGNMENT,
    APIC,
    BUNCH_ASSIGNMENT,
)


@dataclass(frozen=True, slots=True)
class CompletePipelineTrace:
    """A small serializable trace returned by every pipeline execution."""

    execution_mode: str
    stages: tuple[dict[str, object], ...]

    def to_dict(self) -> dict[str, object]:
        return {"execution_mode": self.execution_mode, "stages": list(self.stages)}

    @classmethod
    def frozen_complete(cls) -> "CompletePipelineTrace":
        rows = []
        for ordinal, stage in enumerate(COMPLETE_STAGE_ORDER, start=1):
            # BBA appears once to create boxes and again after APIC to refresh
            # the unique point-to-bunch attribution.
            phase = "proposal" if stage is BUNCH_ASSIGNMENT and ordinal == 5 else "final_assignment"
            row: dict[str, object] = {**stage.to_dict(), "ordinal": ordinal, "status": "frozen_artifact"}
            if stage is BUNCH_ASSIGNMENT:
                row["phase"] = phase
            rows.append(row)
        return cls("frozen_complete_replay", tuple(rows))

    @classmethod
    def live_complete(cls) -> "CompletePipelineTrace":
        rows = []
        for ordinal, stage in enumerate(COMPLETE_STAGE_ORDER, start=1):
            phase = "proposal" if stage is BUNCH_ASSIGNMENT and ordinal == 5 else "final_assignment"
            row: dict[str, object] = {**stage.to_dict(), "ordinal": ordinal, "status": "executed_live"}
            if stage is BUNCH_ASSIGNMENT:
                row["phase"] = phase
            rows.append(row)
        return cls("live_complete", tuple(rows))

    @classmethod
    def live_basic(cls) -> "CompletePipelineTrace":
        rows = []
        for ordinal, stage in enumerate((LOW_RESOLUTION, BUNCH_ASSIGNMENT), start=1):
            rows.append({**stage.to_dict(), "ordinal": ordinal, "status": "executed_live"})
        return cls("live_basic", tuple(rows))


class FrozenPointIntegrityStack:
    """Load the frozen CPCR -> APIC output using functional component names."""

    def __init__(self, manifest_path: str | Path) -> None:
        self.manifest_path = Path(manifest_path).resolve()
        payload = json.loads(self.manifest_path.read_text(encoding="utf-8"))
        if payload.get("pipeline_code") != "CRU-AHPI":
            raise ValueError("functional pipeline manifest has an unexpected pipeline_code")
        components = payload.get("components", {})
        if "CPCR" not in components or "APIC" not in components:
            raise ValueError("functional pipeline manifest must register CPCR and APIC")
        self.payload = payload
        self.point_root = Path(components["APIC"]["point_root"]).resolve()
        if not self.point_root.is_dir():
            raise FileNotFoundError(f"APIC point root is missing: {self.point_root}")

    @staticmethod
    def safe_name(sample_id: str) -> str:
        return str(sample_id).replace(":", "_").replace("/", "_").replace("\\", "_")

    def load_points(
        self,
        sample_id: str,
        *,
        width: int,
        height: int,
    ) -> tuple[np.ndarray, np.ndarray, dict[str, object]]:
        path = self.point_root / f"{self.safe_name(sample_id)}.npz"
        if not path.exists():
            raise FileNotFoundError(f"缺少APIC冻结点结果：{path.name}")
        with np.load(path, allow_pickle=False) as cached:
            points = np.asarray(cached["cru"], dtype=np.float32).reshape(-1, 2)
            reliability = (
                np.asarray(cached["reliability"], dtype=np.float32).reshape(-1)
                if "reliability" in cached
                else np.ones(len(points), dtype=np.float32)
            )
        if len(points) != len(reliability):
            raise ValueError("APIC point/reliability cardinality mismatch")
        if not np.isfinite(points).all() or not np.isfinite(reliability).all():
            raise ValueError("APIC artifact contains non-finite values")
        inside = (
            (points[:, 0] >= 0)
            & (points[:, 0] < int(width))
            & (points[:, 1] >= 0)
            & (points[:, 1] < int(height))
        )
        if len(points) and not bool(inside.all()):
            raise ValueError("APIC artifact contains an out-of-image point")
        rounded = np.round(points, decimals=4)
        duplicates = int(len(rounded) - len(np.unique(rounded, axis=0)))
        if duplicates:
            raise ValueError("APIC artifact violates the one-berry-one-point invariant")
        return points, reliability, {
            "component": APIC.code,
            "point_count": int(len(points)),
            "exact_coordinate_duplicates": duplicates,
            "all_points_in_bounds": True,
            "artifact_mode": "frozen_open_development",
        }

    @property
    def stages(self) -> tuple[FunctionalStage, FunctionalStage]:
        return CPCR, APIC

    def describe(self) -> dict[str, object]:
        return {
            "pipeline_code": self.payload["pipeline_code"],
            "pipeline_name": self.payload["pipeline_name"],
            "components": [stage.to_dict() for stage in self.stages],
            "evidence_boundary": self.payload.get("evidence_boundary"),
        }


def stage_codes(stages: Iterable[FunctionalStage]) -> list[str]:
    return [stage.code for stage in stages]


__all__ = [
    "LOW_RESOLUTION",
    "ADAPTIVE_HIGH_RESOLUTION",
    "COUNT_FUSION",
    "CPCR",
    "BUNCH_ASSIGNMENT",
    "APIC",
    "COMPLETE_STAGE_ORDER",
    "FunctionalStage",
    "CompletePipelineTrace",
    "FrozenPointIntegrityStack",
    "stage_codes",
]
